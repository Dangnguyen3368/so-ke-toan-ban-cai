"""Tim va chuyen du lieu cua ban cu (ban chay thang tu thu muc, vi du E:\\...\\ban-dang-chay\\du_lieu\\ketoan.db)
sang file du lieu dang dung.

Nguyen tac: file cu chi duoc DOC, khong bao gio sua. Truoc khi ghi vao file dang dung, nguoi goi phai sao luu.
Gop theo ma so thue: cong ty chua co thi tao moi, cong ty da co thi chi them phan con thieu, khong ghi de.
Chay lai lan nua khong nhan doi du lieu (chung tu, hoa don trung khoa thi bo qua; dong giong het thi bo qua).
"""
import os
import shutil
import sqlite3
import string
import threading
import time
from pathlib import Path

# Bang khong chuyen: thong tin cong ty xu ly rieng; ban quyen, nguoi dung la cua may moi
BO_QUA = {"cong_ty", "ban_quyen", "nguoi_dung", "nguoi_dung_cong_ty", "sqlite_sequence"}
# Thu muc khong can do khi tim
KHONG_DO = {"windows", "program files", "program files (x86)", "programdata", "$recycle.bin", "system volume information",
            "appdata", "node_modules", ".git", "__pycache__", "site-packages", "python", "sao_luu", "ma_cu", "recovery",
            "msocache", "perflogs", "$windows.~bt", "$windows.~ws", "onedrivetemp"}
THU_MUC_CON_DU_LIEU = {"mau_htkk", "xuat"}   # thu muc theo id cong ty: du_lieu/<ten>/<cid>
TEP_DANH_DAU = "DA_CHUYEN_SANG_BAN_CAI.txt"


# ------------------------------------------------------------------ tim

def _o_dia():
    if os.name != "nt":
        return [Path("/")]
    return [Path(f"{d}:\\") for d in string.ascii_uppercase[2:] if os.path.exists(f"{d}:\\")]


def _goc_tim():
    nha = Path.home()
    goc = [nha / "Desktop", nha / "Documents", nha / "Downloads", nha / "OneDrive"] + _o_dia()
    return [g for g in goc if g.exists()]


def tim(hien_tai, bo_qua=(), sau_toi_da=6, gioi_han_giay=8.0, goc=None):
    """Tim cac file <...>/du_lieu/ketoan.db khac file dang dung. Tra ve list Path (khong trung)."""
    het = time.monotonic() + gioi_han_giay
    hien_tai = _chuan(hien_tai)
    bo = {_chuan(x) for x in bo_qua}
    thay, da_xem = [], set()

    def di(tm, sau):
        if sau > sau_toi_da or time.monotonic() > het:
            return
        try:
            with os.scandir(tm) as it:
                ds = list(it)
        except OSError:
            return
        for m in ds:
            try:
                if not m.is_dir(follow_symlinks=False):
                    continue
            except OSError:
                continue
            ten = m.name.lower()
            if ten in KHONG_DO or ten.startswith("."):
                continue
            if ten == "du_lieu":
                f = Path(m.path) / "ketoan.db"
                k = _chuan(f)
                if f.is_file() and k != hien_tai and k not in bo and k not in da_xem:
                    da_xem.add(k)
                    thay.append(f)
                continue
            di(m.path, sau + 1)

    for g in (goc if goc is not None else _goc_tim()):
        di(str(g), 0)
    return thay


def _chuan(p):
    try:
        return os.path.normcase(str(Path(p).resolve()))
    except OSError:
        return os.path.normcase(str(p))


# ------------------------------------------------------------------ doc thu / tom tat

def _mo_doc(duong):
    c = sqlite3.connect(f"file:{Path(duong).as_posix()}?mode=ro", uri=True)
    return c


def _bang(c):
    return [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")]


def _cot(c, t):
    return [r[1] for r in c.execute(f'PRAGMA table_info("{t}")')]


def la_so_ke_toan(duong):
    try:
        c = _mo_doc(duong)
        try:
            b = set(_bang(c))
            return {"cong_ty", "chung_tu", "but_toan"} <= b
        finally:
            c.close()
    except sqlite3.DatabaseError:
        return False


def tom_tat(nguon, dich):
    """Moi cong ty trong file cu: so chung tu / hoa don co trong file cu, va bao nhieu chua co o file dang dung."""
    o = _mo_doc(nguon)
    n = _mo_doc(dich) if Path(dich).exists() else None
    try:
        if o.execute("PRAGMA quick_check").fetchone()[0] != "ok":
            raise ValueError("File dữ liệu cũ bị hỏng")
        co_hd = "hoa_don" in _bang(o)
        ds = []
        for cid, mst, ten in o.execute("SELECT id, mst, ten FROM cong_ty ORDER BY ten").fetchall():
            dcid = n.execute("SELECT id FROM cong_ty WHERE mst=?", (mst,)).fetchone() if n else None
            dcid = dcid[0] if dcid else None
            ct = o.execute("SELECT so_ct, ngay_ht FROM chung_tu WHERE cong_ty_id=?", (cid,)).fetchall()
            hd = o.execute("SELECT nbmst, khmshdon, khhdon, shdon FROM hoa_don WHERE cong_ty_id=?", (cid,)).fetchall() if co_hd else []
            moi_ct, moi_hd = len(ct), len(hd)
            if dcid:
                co = set(n.execute("SELECT so_ct, ngay_ht FROM chung_tu WHERE cong_ty_id=?", (dcid,)).fetchall())
                moi_ct = sum(1 for x in ct if tuple(x) not in co)
                if hd and "hoa_don" in _bang(n):
                    co = set(n.execute("SELECT nbmst, khmshdon, khhdon, shdon FROM hoa_don WHERE cong_ty_id=?", (dcid,)).fetchall())
                    moi_hd = sum(1 for x in hd if tuple(x) not in co)
            ds.append({"mst": mst, "ten": ten, "chung_tu": len(ct), "hoa_don": len(hd), "da_co": bool(dcid),
                       "moi_chung_tu": moi_ct, "moi_hoa_don": moi_hd, "ngay": _khoang_ngay(o, cid)})
        return ds
    finally:
        o.close()
        if n:
            n.close()


def _khoang_ngay(o, cid):
    r = o.execute("SELECT MIN(ngay_ht), MAX(ngay_ht) FROM chung_tu WHERE cong_ty_id=?", (cid,)).fetchone()
    return (r[0], r[1]) if r and r[0] else None


def can_chuyen(tt):
    """Co cong ty nao con chung tu / hoa don chua co o file dang dung khong."""
    return any(x["moi_chung_tu"] or x["moi_hoa_don"] for x in tt)


# ------------------------------------------------------------------ gop

def _thu_tu(o, bang):
    """Sap bang cha truoc bang con (cot <bang>_id tro toi bang <bang>)."""
    phu = {t: {c[:-3] for c in _cot(o, t) if c.endswith("_id") and c[:-3] in bang and c[:-3] != t} for t in bang}
    kq, da = [], set()

    def tham(t, dang):
        if t in da or t in dang:
            return
        dang.add(t)
        for p in sorted(phu[t]):
            tham(p, dang)
        da.add(t)
        kq.append(t)
    for t in sorted(bang):
        tham(t, set())
    return kq


def _khoa_duy_nhat(n, t):
    """Cac bo cot UNIQUE (ke ca khoa chinh nhieu cot) cua bang o file dich."""
    kq = []
    for r in n.execute(f'PRAGMA index_list("{t}")'):
        if r[2]:
            kq.append([x[2] for x in n.execute(f'PRAGMA index_info("{r[1]}")')])
    return kq


def gop(nguon, dich, ds_mst=None):
    """Chuyen du lieu cac cong ty (theo MST; None = tat ca) tu file cu `nguon` vao file `dich`.

    Tra ve list dict {mst, ten, cid, tao_moi, bang: {ten_bang: so_dong_them}, bo_qua_trung}.
    Mot giao dich: loi giua chung thi khong ghi gi."""
    o = _mo_doc(nguon)
    n = sqlite3.connect(str(dich), timeout=30, isolation_level=None)
    n.execute("PRAGMA foreign_keys = ON")
    bang_o, bang_n = set(_bang(o)), set(_bang(n))
    bang = [t for t in bang_o & bang_n if t not in BO_QUA]
    thu_tu = _thu_tu(o, set(bang))
    ket_qua = []
    n.execute("BEGIN IMMEDIATE")
    try:
        ct_cot_o, ct_cot_n = _cot(o, "cong_ty"), _cot(n, "cong_ty")
        chung = [c for c in ct_cot_o if c in ct_cot_n and c != "id"]
        cong_ty = o.execute(f'SELECT id, {",".join(chung)} FROM cong_ty').fetchall()
        for row in cong_ty:
            ocid, gt = row[0], dict(zip(chung, row[1:]))
            if ds_mst is not None and gt["mst"] not in ds_mst:
                continue
            r = n.execute("SELECT id FROM cong_ty WHERE mst=?", (gt["mst"],)).fetchone()
            if r:
                ncid, tao = r[0], False
                for c in chung:
                    if c != "mst" and gt[c] is not None:
                        n.execute(f'UPDATE cong_ty SET "{c}"=? WHERE id=? AND "{c}" IS NULL', (gt[c], ncid))
            else:
                ncid = n.execute(f'INSERT INTO cong_ty ({",".join(chung)}) VALUES ({",".join("?" * len(chung))})',
                                 [gt[c] for c in chung]).lastrowid
                tao = True
            dem, trung = _gop_cong_ty(o, n, ocid, ncid, thu_tu)
            ket_qua.append({"mst": gt["mst"], "ten": gt["ten"], "cid_cu": ocid, "cid": ncid, "tao_moi": tao,
                            "bang": {k: v for k, v in dem.items() if v}, "bo_qua_trung": trung})
        n.execute("COMMIT")
    except Exception:
        n.execute("ROLLBACK")
        raise
    finally:
        o.close()
        n.close()
    return ket_qua


def _gop_cong_ty(o, n, ocid, ncid, thu_tu):
    ban_do = {}      # bang -> {id cu: id moi}
    trung = {}       # bang -> set id cu da co san o file dich (khong chen)
    dem, bo_qua = {}, 0
    for t in thu_tu:
        co = _cot(o, t)
        cn = set(_cot(n, t))
        cot = [c for c in co if c in cn]
        co_id = "id" in cot and _pk(n, t) == ["id"]
        ref = [c for c in cot if c.endswith("_id") and c not in ("cong_ty_id",) and c[:-3] in ban_do]
        if "cong_ty_id" in cot:
            dong = o.execute(f'SELECT {",".join(cot)} FROM "{t}" WHERE cong_ty_id=?', (ocid,)).fetchall()
        elif ref:
            dk = " OR ".join(f'"{c}" IN (SELECT id FROM "{c[:-3]}" WHERE cong_ty_id={int(ocid)})' for c in ref
                             if "cong_ty_id" in _cot(o, c[:-3]))
            if not dk:
                continue
            dong = o.execute(f'SELECT {",".join(cot)} FROM "{t}" WHERE {dk}').fetchall()
        else:
            continue
        nn = {r[1]: bool(r[3] or r[5]) for r in n.execute(f'PRAGMA table_info("{t}")')}   # cot -> bat buoc (NOT NULL / khoa chinh)
        khoa = _khoa_duy_nhat(n, t) if co_id else []
        ban_do[t], trung[t], dem[t] = {}, set(), 0
        cot_ghi = [c for c in cot if not (co_id and c == "id")]
        for r in dong:
            gt = dict(zip(cot, r))
            bo = False
            if "cong_ty_id" in gt:
                gt["cong_ty_id"] = ncid
            for c in ref:
                v = gt[c]
                if v is None:
                    continue
                p = c[:-3]
                if v in trung[p] and nn.get(c):
                    bo = True        # dong con cua ban ghi da co san: giu nguyen ban o file dich
                    break
                if v in ban_do[p]:
                    gt[c] = ban_do[p][v]
                elif nn.get(c):
                    bo = True
                    break
                else:
                    gt[c] = None
            # cot *_id tro toi bang khong chuyen duoc (vd hoa_don rong o ban cu) -> de trong neu duoc
            for c in cot_ghi:
                if c.endswith("_id") and c != "cong_ty_id" and c not in ref and c[:-3] in thu_tu and not nn.get(c):
                    if gt[c] is not None and gt[c] not in ban_do.get(c[:-3], {}):
                        gt[c] = None
            if bo:
                bo_qua += 1
                continue
            vals = [gt[c] for c in cot_ghi]
            if co_id:
                cu = gt["id"]
                da = _tim_trung(n, t, cot_ghi, vals, khoa, gt)
                if da is not None:
                    ban_do[t][cu] = da
                    trung[t].add(cu)
                    bo_qua += 1
                    continue
                try:
                    ban_do[t][cu] = n.execute(f'INSERT INTO "{t}" ({",".join(cot_ghi)}) VALUES ({",".join("?" * len(cot_ghi))})',
                                              vals).lastrowid
                    dem[t] += 1
                except sqlite3.IntegrityError:
                    bo_qua += 1
            else:
                cur = n.execute(f'INSERT OR IGNORE INTO "{t}" ({",".join(cot_ghi)}) VALUES ({",".join("?" * len(cot_ghi))})', vals)
                dem[t] += cur.rowcount
                bo_qua += 1 - cur.rowcount
    return dem, bo_qua


def _pk(n, t):
    return [r[1] for r in sorted(n.execute(f'PRAGMA table_info("{t}")'), key=lambda r: r[5]) if r[5]]


def _tim_trung(n, t, cot, vals, khoa, gt):
    """Id cua dong da co o file dich: trung mot khoa UNIQUE, hoac giong het moi cot."""
    du_khoa = False
    for k in khoa:
        if all(c in gt for c in k):
            du_khoa = True
            r = n.execute(f'SELECT id FROM "{t}" WHERE ' + " AND ".join(f'"{c}" IS ?' for c in k), [gt[c] for c in k]).fetchone()
            if r:
                return r[0]
    if du_khoa:      # bang co khoa UNIQUE: khoa khong trung thi la dong moi
        return None
    r = n.execute(f'SELECT id FROM "{t}" WHERE ' + " AND ".join(f'"{c}" IS ?' for c in cot) + " LIMIT 1", vals).fetchone()
    return r[0] if r else None


def chep_thu_muc(goc_cu, goc_moi, ket_qua):
    """Chep mau HTKK, file da xuat cua tung cong ty (du_lieu/<muc>/<id cu> -> <id moi>), khong ghi de file da co."""
    so = 0
    for kq in ket_qua:
        for muc in THU_MUC_CON_DU_LIEU:
            tu = Path(goc_cu) / muc / str(kq["cid_cu"])
            if not tu.is_dir():
                continue
            toi = Path(goc_moi) / muc / str(kq["cid"])
            for f in tu.rglob("*"):
                if f.is_file():
                    d = toi / f.relative_to(tu)
                    if not d.exists():
                        d.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(f, d)
                        so += 1
    return so


def danh_dau_da_chuyen(nguon, sang):
    """Ghi tep ghi chu canh file cu de nguoi dung biet khong nen mo ban cu nua (khong dung toi file du lieu)."""
    try:
        (Path(nguon).parent / TEP_DANH_DAU).write_text(
            f"Dữ liệu trong thư mục này đã được chuyển sang bản iFix Kế toán cài đặt:\n{sang}\n"
            "Từ nay hãy mở iFix Kế toán từ biểu tượng trên màn hình, không chạy bản cũ ở thư mục này nữa.\n",
            encoding="utf-8")
    except OSError:
        pass


# ------------------------------------------------------------------ quet nen khi mo ung dung

KET_QUA_TIM = {"xong": False, "ds": []}   # ds: [{"duong": str, "tom_tat": [...]}]


def quet_nen(hien_tai, bo_qua):
    """Tim trong luong nen, ket qua de o KET_QUA_TIM cho trang chu doc."""
    def chay():
        ds = []
        try:
            for f in tim(hien_tai, bo_qua):
                try:
                    if la_so_ke_toan(f):
                        tt = tom_tat(f, hien_tai)
                        if can_chuyen(tt):
                            ds.append({"duong": str(f), "tom_tat": tt})
                except (sqlite3.DatabaseError, ValueError, OSError):
                    pass
        finally:
            KET_QUA_TIM["ds"] = ds
            KET_QUA_TIM["xong"] = True
    t = threading.Thread(target=chay, daemon=True)
    t.start()
    return t
