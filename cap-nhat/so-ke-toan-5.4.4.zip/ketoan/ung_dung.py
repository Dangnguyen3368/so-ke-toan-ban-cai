"""Ung dung so ke toan chay tren may, mo bang trinh duyet.

Chay:  python -m ketoan.ung_dung   (hoac bam chay.bat tren Windows)
Chi nghe tren 127.0.0.1 nen chi may nay mo duoc.
"""
import html
import os
import sqlite3
import sys
import threading
import webbrowser
from datetime import date, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlencode, urlparse

from . import PHIEN_BAN, cong_hddt, db, doi_chieu, hoa_don, nha_cung_cap, nhap_misa, so_sach, xuat_excel
from .trang_hoa_don import TrangHoaDon
from .trang_nghiep_vu import TrangNghiepVu
from .trang_bao_cao import TrangBaoCao
from .trang_quan_ly import TrangQuanLy, bang_nhap_dong, doc_dong_but_toan, ds_doi_tuong
from .trang_he_thong import TrangHeThong
from .trang_ai import TrangAI
from . import ban_quyen, cai_dat, doi_tuong, kho, luong, quan_ly, sao_ke, tai_san, to_khai
from . import che_do, gia_thanh, giao_dien, hop_dong, nhap_du_lieu_cu, thuong_hieu, vay
from .trang_che_do import TrangCheDo
from .trang_vay import TrangVay
from .trang_hop_dong import TrangHopDong
from .trang_gia_thanh import TrangGiaThanh

GOC = Path(__file__).resolve().parent.parent
from .giao_dien import THU_MUC_DL  # noqa: E402
FILE_DL = THU_MUC_DL / "ketoan.db"
CONG = int(os.environ.get("KETOAN_CONG") or 8765)

from .giao_dien import CSS, e, form_ky, ky_mac_dinh, ngay_vn, so, trang


_DA_CHUAN_BI = set()


class XuLy(TrangGiaThanh, TrangHopDong, TrangVay, TrangAI, TrangCheDo, TrangQuanLy, TrangHeThong, TrangHoaDon, TrangNghiepVu, TrangBaoCao, BaseHTTPRequestHandler):
    nguoi = None

    def log_message(self, *a):
        pass

    def con(self):
        c = getattr(self, "_con", None)
        if c is not None:
            return c
        c = db.mo(FILE_DL)
        if str(FILE_DL) not in _DA_CHUAN_BI:
            for m in (hoa_don, kho, luong, tai_san, to_khai, sao_ke, quan_ly, cai_dat, doi_tuong, che_do, vay, hop_dong, gia_thanh):
                m.chuan_bi(c)
            c.commit()
            _DA_CHUAN_BI.add(str(FILE_DL))
        self._con = c
        return c

    def ten_nguoi(self):
        return self.nguoi["ten"] if self.nguoi else None

    def la_quan_tri(self):
        """Chua co nguoi dung (mot minh tren may nay) thi coi nhu quan tri."""
        return self.nguoi is None or self.nguoi["vai_tro"] == "quan_tri"

    def gui(self, noi_dung, ma=200, kieu="text/html; charset=utf-8"):
        b = noi_dung.encode("utf-8") if isinstance(noi_dung, str) else noi_dung
        self.send_response(ma)
        self.send_header("Content-Type", kieu)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def chuyen(self, url):
        self.send_response(303)
        self.send_header("Location", url)
        self.end_headers()

    def doc_form(self):
        n = int(self.headers.get("Content-Length") or 0)
        return parse_qs(self.rfile.read(n).decode("utf-8"), keep_blank_values=True)

    # ---- dinh tuyen ----
    def do_GET(self):
        self._chay("GET")

    def do_POST(self):
        self._chay("POST")

    def _chay(self, pt):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        p = [x for x in u.path.split("/") if x]
        giao_dien.HIEN_TAI.duong = u.path
        giao_dien.HIEN_TAI.q = q
        giao_dien.HIEN_TAI.ph = self.cookie("ph") or ""
        giao_dien.HIEN_TAI.nguoi = None
        giao_dien.HIEN_TAI.nam = None
        giao_dien.HIEN_TAI.ban_quyen = None
        giao_dien.HIEN_TAI.ban_moi = None
        giao_dien.HIEN_TAI.che_do = None
        self.nguoi = None
        self._con = None
        if p == ["ping"]:
            return self.gui("so-ke-toan", kieu="text/plain")
        try:
            con = self.con()
            if p and p[0] == "dang-nhap":
                return self.dang_nhap(pt, q)
            if p and p[0] == "dang-xuat":
                return self.dang_xuat()
            if cai_dat.co_nguoi_dung(con):
                self.nguoi = cai_dat.nguoi_cua_phien(con, self.cookie("phien"))
                if not self.nguoi:
                    if pt == "GET":
                        return self.chuyen("/dang-nhap?" + urlencode({"ve": self.path}))
                    return self.chuyen("/dang-nhap")
                giao_dien.HIEN_TAI.nguoi = self.nguoi
                if pt == "POST" and self.nguoi["vai_tro"] == "xem":
                    return self.gui(trang("Không có quyền", '<p class="loi">Tài khoản Chỉ xem không sửa được dữ liệu.</p>'), 403)
            elif self.client_address[0] not in ("127.0.0.1", "::1"):
                return self.gui(trang("Không có quyền", '<p class="loi">Chưa tạo người dùng nên chỉ máy chạy ứng dụng mới mở được.</p>'), 403)
            from . import cap_nhat
            giao_dien.HIEN_TAI.ban_moi = cap_nhat.TRANG_THAI.get("ban_moi") if self.la_quan_tri() else None
            self.bq = bq = ban_quyen.trang_thai(con)
            giao_dien.HIEN_TAI.ban_quyen = bq
            if p and p[0] == "ban-quyen":
                return self.trang_ban_quyen(pt)
            if p == ["tat"]:
                return self.tat_ung_dung(pt)
            if pt == "POST" and not bq["cho_ghi"] and (not p or p[0] != "he-thong"):
                return self.gui(trang("Chỉ xem", f'<div class="the loi"><h2>Ứng dụng đang ở chế độ chỉ xem</h2><p>{e(bq["thong_bao"])}</p>'
                                      '<p>Mọi dữ liệu vẫn xem, in và xuất Excel / XML được bình thường. '
                                      '<a class="nut" href="/ban-quyen">Nhập key kích hoạt</a></p></div>'), 403)
            if not p:
                return self.trang_chu(pt)
            if p[0] == "he-thong":
                return self.he_thong(pt, q, p[1:])
            if p[0] == "cty" and len(p) >= 2:
                cid = int(p[1])
                duoc = cai_dat.cong_ty_duoc_dung(con, self.nguoi)
                if duoc is not None and cid not in duoc:
                    return self.gui(trang("Không có quyền", '<p class="loi">Tài khoản của bạn chưa được giao công ty này. '
                                          'Nhờ người Quản trị giao ở Cài đặt chung → Người dùng.</p>'), 403)
                ct = con.execute("SELECT * FROM cong_ty WHERE id=?", (cid,)).fetchone()
                if not ct:
                    return self.gui(trang("Không tìm thấy", "<p>Không có công ty này.</p>"), 404)
                gan = con.execute("SELECT MAX(ngay_ht) n FROM chung_tu WHERE cong_ty_id=?", (cid,)).fetchone()["n"]
                giao_dien.HIEN_TAI.nam = int(gan[:4]) if gan else None
                giao_dien.HIEN_TAI.che_do = che_do.ma(ct)
                vi = p[2] if len(p) > 2 else ""
                f = {"": self.tong_quan, "cdtk": self.cdtk, "socai": self.socai, "nkc": self.nkc,
                     "chungtu": self.chungtu, "nhap-misa": self.nhap_misa, "xuat": self.xuat,
                     "hoadon": self.hoadon, "caidat": self.caidat, "kho": self.kho, "luong": self.luong,
                     "taisan": self.taisan, "mau": self.mau, "baocao": self.baocao, "viec": self.viec,
                     "nganhang": self.nganhang, "congno": self.congno, "so": self.so_, "luuchuyen": self.luuchuyen,
                     "doichieu": self.doichieu, "khoaso": self.khoaso, "in": self.in_, "doituong": self.doituong,
                     "sochedo": self.sochedo, "ai": self.ai, "phan-he": self.phan_he, "vay": self.vay, "hopdong": self.hopdong, "giathanh": self.giathanh}.get(vi)
                ma_ph = "luong" if vi == "in" and p[3:4] == ["luong"] else vi
                if vi == "baocao":
                    ma_ph = "bc:" + (p[4] if p[3:4] == ["xml"] and len(p) > 4 else (q.get("muc") or giao_dien.muc_bao_cao_dau()))
                if f and not ban_quyen.duoc_dung(bq, ma_ph):
                    return self.ngoai_goi(ma_ph, ct)
                if f:
                    if pt == "POST" and self.nguoi:
                        quan_ly.ghi_nhat_ky(con, cid, "thao_tac", None, {"trang": u.path}, self.ten_nguoi())
                        con.commit()
                    return f(pt, con, ct, q, p[3:])
            self.gui(trang("Không tìm thấy", "<p>Trang không tồn tại.</p>"), 404)
        except sqlite3.IntegrityError as ex:
            self.gui(trang("Không thực hiện được", f'<div class="the loi"><h2>Không thực hiện được</h2><p class="loi">{e(ex)}</p>'
                           '<p><a href="javascript:history.back()">← Quay lại</a></p></div>'), 400)
        except Exception as ex:  # hien loi cho nguoi dung thay vi trang trang
            self.gui(trang("Lỗi", f'<div class="the loi"><h2>Có lỗi</h2><pre>{e(ex)}</pre>'
                           '<p><a href="javascript:history.back()">← Quay lại</a></p></div>'), 500)
        finally:
            c = getattr(self, "_con", None)
            if c is not None:
                c.close()
                self._con = None

    # ---- cac trang ----
    def trang_chu(self, pt):
        con = self.con()
        tb = ""
        if pt == "POST":
            f = {k: v[0].strip() for k, v in self.doc_form().items()}
            toi_da = ban_quyen.so_cong_ty_toi_da(self.bq)
            da_co = con.execute("SELECT COUNT(*) FROM cong_ty").fetchone()[0]
            if toi_da and da_co >= toi_da:
                tb = (f'<p class="loi">Bản quyền hiện tại cho phép tối đa {toi_da} công ty (đã có {da_co}). '
                      f'Liên hệ {ban_quyen.DIEN_THOAI} để mở rộng, rồi nhập key mới ở trang <a href="/ban-quyen">Bản quyền</a>.</p>')
            elif f.get("mst") and f.get("ten"):
                cd = che_do.ma(f.get("che_do"))
                cid = db.tao_cong_ty(con, f["mst"], f["ten"], dia_chi=f.get("dia_chi") or None, che_do=cd)
                che_do.doi_che_do(con, cid, cd)
                duoc = cai_dat.cong_ty_duoc_dung(con, self.nguoi)
                if duoc is not None:
                    giao = duoc | {cid}
                    cai_dat.giao_cong_ty(con, self.nguoi["ten"], giao)
                return self.chuyen(f"/cty/{cid}")
            else:
                tb = '<p class="loi">Cần nhập mã số thuế và tên công ty.</p>'
        ds = con.execute("SELECT * FROM cong_ty ORDER BY ten").fetchall()
        duoc = cai_dat.cong_ty_duoc_dung(con, self.nguoi)
        if duoc is not None:
            ds = [r for r in ds if r["id"] in duoc]
        dong, tong = "", {"do": 0, "vang": 0}
        for r in ds:
            try:
                viec = quan_ly.viec_can_lam(con, r)
            except Exception:
                viec = []
            dem = {m: sum(1 for x in viec if x[0] == m) for m in ("do", "vang")}
            for m in dem:
                tong[m] += dem[m]
            gan = con.execute("SELECT MAX(ngay_ht) n FROM chung_tu WHERE cong_ty_id=?", (r["id"],)).fetchone()["n"]
            nhan = (" ".join(x for x in (giao_dien.nhan_tt(f"{dem['do']} gấp", "do") if dem["do"] else "",
                                         giao_dien.nhan_tt(f"{dem['vang']} cần làm", "vang") if dem["vang"] else "") if x)
                    or giao_dien.nhan_tt("Ổn", "xanh"))
            dau = next((x for x in viec if x[0] == "do"), None) or next((x for x in viec if x[0] == "vang"), None)
            chu = "".join(w[:1] for w in r["ten"].replace("CÔNG TY", "").replace("TNHH", "").replace("CP", "").split()[-2:]).upper()
            dong += (f'<div class="the-cty"><a class="tc-dau" href="/cty/{r["id"]}"><i>{e(chu or "?")}</i><span><b>{e(r["ten"])}</b>'
                     f'<small>MST {e(r["mst"])} · {e(r["che_do"])} · GTGT theo {"quý" if r["ky_ke_khai_gtgt"] == "Q" else "tháng"}</small></span></a>'
                     f'<div class="tc-tt">{nhan}<span class="mo">Chứng từ gần nhất: {ngay_vn(gan) or "chưa có"}</span></div>'
                     f'<p class="tc-viec">{e(dau[1]) if dau else "Không có việc cần xử lý."}</p>'
                     f'<div class="dong-nut"><a class="nut nho" href="/cty/{r["id"]}">Mở sổ</a>'
                     f'<a class="nut phu nho" href="/cty/{r["id"]}/viec">Việc cần làm</a></div></div>')
        dong = dong or '<p class="mo">Chưa có công ty nào. Thêm công ty ở bên dưới.</p>'
        cu = nhap_du_lieu_cu.KET_QUA_TIM["ds"]
        if cu and self.la_quan_tri():
            ten = "; ".join(f'{c["ten"]} ({so(c["moi_chung_tu"])} chứng từ, {so(c["moi_hoa_don"])} hóa đơn)'
                            for x in cu for c in x["tom_tat"] if c["moi_chung_tu"] or c["moi_hoa_don"])
            tb += (f'<div class="the bao"><b>Tìm thấy dữ liệu của bản cũ chưa chuyển sang bản này</b>'
                   f'<p>{e(ten)}</p><p class="mo">Ở {e(", ".join(x["duong"] for x in cu))}</p>'
                   '<div class="dong-nut"><a class="nut" href="/he-thong/nhap-cu">Xem và chuyển sang</a></div></div>')
        o = (giao_dien.o_kpi("cong_ty", "#2563eb", "Công ty đang quản lý", len(ds))
             + giao_dien.o_kpi("viec", "#dc2626", "Việc gấp", tong["do"], "Hạn nộp trong 7 ngày, hóa đơn bị hủy sau khi ghi sổ...")
             + giao_dien.o_kpi("/viec", "#f59e0b", "Việc cần làm", tong["vang"], "Hóa đơn, sao kê chưa ghi sổ, chưa trích khấu hao..."))
        nd = f"""<section class="bia"><div><div class="chao">{giao_dien.TEN_UNG_DUNG} · phần mềm kế toán cho nhiều công ty</div>
<h1>Các công ty của bạn</h1><div class="chip-ds"><span class="chip">TT133 · TT99 · TT58 · TT152</span><span class="chip">Hóa đơn điện tử</span>
<span class="chip">Tờ khai HTKK</span><span class="chip">Dữ liệu lưu trên máy bạn</span></div></div>
<div class="dong-nut"><a class="nut" href="#them" onclick="document.getElementById('them').open=true">{giao_dien.icon("cong", 15)}Thêm công ty</a></div></section>
<div class="luoi-kpi">{o}</div>{tb}<div class="luoi-cty">{dong}</div>
<details class="the" id="them" {'open' if not ds else ''}><summary>Thêm công ty</summary><form class="ngang" method="post" style="margin-top:12px">
<label>Mã số thuế<input name="mst" required></label><label>Tên công ty<input name="ten" size="50" required></label>
<label>Địa chỉ<input name="dia_chi" size="50"></label>
<label>Chế độ kế toán<select name="che_do">{"".join(f'<option value="{m}">{e(che_do.ten_day_du(m))}</option>' for m in che_do.CHE_DO)}</select></label>
<button>Thêm</button></form>
<p class="mo">Công ty mới được tạo sẵn hệ thống tài khoản theo chế độ đã chọn (hộ kinh doanh và doanh nghiệp siêu nhỏ: sổ in theo mẫu riêng của thông tư). Vào Cài đặt công ty để nhập cơ quan thuế, kỳ kê khai, nhà cung cấp hóa đơn.</p></details>"""
        self.gui(trang("Các công ty", nd))

    def khoi_dong_lai(self, thong_bao):
        """Tra trang cho, roi tat may chu; chay() se mo lai tien trinh moi voi ma moi."""
        global _KHOI_DONG_LAI
        _KHOI_DONG_LAI = True
        self.gui(f"""<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>Đang khởi động lại</title><style>
body{{margin:0;height:100vh;display:grid;place-items:center;font:15px/1.5 "Segoe UI",system-ui,sans-serif;background:#f3f5f8;color:#17202c}}
div{{background:#fff;border:1px solid #e1e5ec;border-radius:12px;padding:28px 36px;text-align:center;max-width:520px}}</style></head>
<body><div><h2>Đang khởi động lại iFix Kế toán…</h2><p>{e(thong_bao)}</p><p class="mo">Trang tự mở lại khi xong.</p></div>
<script>setTimeout(function c(){{fetch('/ping').then(function(r){{location.href='/he-thong/phien-ban'}}).catch(function(){{setTimeout(c,1000)}})}},2500)</script>
</body></html>""")
        self.wfile.flush()
        threading.Thread(target=self.server.shutdown, daemon=True).start()

    def ngoai_goi(self, ma, ct):
        """Trang bao phan he khong nam trong goi dang dung."""
        ten = ban_quyen.PHAN_HE.get(ma, ma)
        nd = (f'<div class="the"><h1>{e(ten)}</h1><p>Phân hệ này không có trong gói <b>{e(ban_quyen.ten_goi(self.bq))}</b> '
              f'đang dùng. Cần gói <b>{e(ban_quyen.goi_toi_thieu(ma))}</b> trở lên.</p>'
              f'<p>Liên hệ <b>{ban_quyen.DIEN_THOAI}</b> để nâng gói. Nhận key mới thì dán vào trang Bản quyền, '
              'không phải cài lại, dữ liệu giữ nguyên.</p>'
              '<p><a class="nut" href="/ban-quyen">Xem gói và nhập key</a> '
              f'<a class="nut phu" href="/cty/{ct["id"]}">Về bảng điều khiển</a></p></div>')
        return self.gui(trang(ten, nd, ct["id"], ct["ten"]), 403)

    def tat_ung_dung(self, pt):
        if self.client_address[0] not in ("127.0.0.1", "::1") or not self.la_quan_tri():
            return self.gui(trang("Không có quyền", '<p class="loi">Chỉ người Quản trị trên máy chạy ứng dụng mới tắt được.</p>'), 403)
        if pt != "POST":
            return self.gui(trang("Tắt ứng dụng", '<div class="the"><h1>Tắt iFix Kế toán?</h1><p>Dữ liệu đã được lưu sau mỗi thao tác. '
                                  'Lần sau mở lại bằng biểu tượng iFix Kế toán trên Desktop.</p><form method="post" class="dong-nut">'
                                  '<button class="nguy">Tắt ứng dụng</button><a class="nut phu" href="/">Quay lại</a></form></div>'))
        self.gui("""<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>Đã tắt iFix Kế toán</title><style>
body{margin:0;height:100vh;display:grid;place-items:center;font:15px/1.5 "Segoe UI",system-ui,sans-serif;background:#f3f5f8;color:#17202c}
div{background:#fff;border:1px solid #e1e5ec;border-radius:12px;padding:28px 36px;text-align:center;box-shadow:0 1px 3px rgba(16,24,40,.08)}
</style></head><body><div><h2>Đã tắt iFix Kế toán</h2><p>Có thể đóng thẻ trình duyệt này.<br>Mở lại bằng biểu tượng iFix Kế toán trên Desktop.</p></div></body></html>""")
        self.wfile.flush()
        threading.Thread(target=self.server.shutdown, daemon=True).start()

    def trang_ban_quyen(self, pt):
        con = self.con()
        tb = ""
        if pt == "POST":
            if not self.la_quan_tri():
                return self.gui(trang("Không có quyền", '<p class="loi">Chỉ người Quản trị mới nhập được key.</p>'), 403)
            try:
                k = ban_quyen.kich_hoat(con, self.doc_form().get("key", [""])[0])
                tb = f'<p class="ok">Đã kích hoạt cho {e(k["t"])}. Cảm ơn bạn đã dùng iFix Kế toán.</p>'
            except ValueError as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
            ban_quyen.xoa_luu_tam()
            self.bq = ban_quyen.trang_thai(con)
            giao_dien.HIEN_TAI.ban_quyen = self.bq
        bq = self.bq
        ten_loai = {"key": "Đã kích hoạt", "dung_thu": "Dùng thử", "het_han": "Hết hạn (chỉ xem)",
                    "dong_ho": "Ngày giờ máy không đúng"}[bq["loai"]]
        mau = "xanh" if bq["loai"] == "key" else "vang" if bq["cho_ghi"] else "do"
        han = ("Vĩnh viễn" if bq["loai"] == "key" and not bq["han"] else ngay_vn(bq["han"]) if bq["han"] else "")
        sct = bq.get("so_cong_ty") or 0
        con_lai = f' (còn {bq["con_ngay"]} ngày)' if bq["con_ngay"] else ""
        dong = (f'<tr><th>Tình trạng</th><td>{giao_dien.nhan_tt(ten_loai, mau)}</td></tr>'
                + (f'<tr><th>Đăng ký cho</th><td>{e(bq["ten_khach"])}</td></tr>' if bq["ten_khach"] else "")
                + (f'<tr><th>Hạn dùng</th><td>{han}{con_lai}</td></tr>' if han else "")
                + f'<tr><th>Gói</th><td><b>{e(ban_quyen.ten_goi(bq))}</b>'
                + (' <span class="mo">(dùng thử được mở mọi phân hệ)</span>' if bq["loai"] == "dung_thu" else "") + '</td></tr>'
                + f'<tr><th>Số công ty</th><td>{sct or "Không giới hạn"}</td></tr>')
        g_hien = bq.get("goi") if bq["loai"] != "dung_thu" else None
        cot_goi = list(ban_quyen.GOI)
        bang_goi = ("<table><tr><th>Phân hệ</th>" + "".join(
            f'<th class="g">{e(ban_quyen.GOI[g]["ten"])}{" (đang dùng)" if g == g_hien else ""}</th>' for g in cot_goi) + "</tr>"
            + '<tr><td>Tiền mặt, ngân hàng, mua bán, kho, hóa đơn điện tử, sổ sách, tờ khai GTGT</td>'
            + "".join('<td class="g ok">✓</td>' for _ in cot_goi) + "</tr>"
            + "".join(f'<tr><td>{e(t)}</td>' + "".join(
                f'<td class="g {"ok" if m in ban_quyen.GOI[g]["phan_he"] else "mo"}">{"✓" if m in ban_quyen.GOI[g]["phan_he"] else "—"}</td>'
                for g in cot_goi) + "</tr>" for m, t in ban_quyen.PHAN_HE.items())
            + '<tr><td>Số công ty</td>' + "".join(
                f'<td class="g">{ban_quyen.GOI[g]["cong_ty"] or "Không giới hạn"}</td>' for g in cot_goi) + "</tr></table>"
            + "".join(f'<p class="mo"><b>{e(v["ten"])}:</b> {e(v["mo_ta"])}</p>' for v in ban_quyen.GOI.values()))
        o_key = ('<form method="post"><label>Key kích hoạt<textarea name="key" rows="4" style="width:100%;font-family:monospace" '
                 'required placeholder="Dán nguyên chuỗi key nhận được"></textarea></label>'
                 '<p><button>Kích hoạt</button></p></form>' if self.la_quan_tri()
                 else '<p class="mo">Nhờ người Quản trị đăng nhập để nhập key.</p>')
        nd = f"""<div class="the"><h1>Bản quyền</h1>{tb}<table class="kv">{dong}</table>
{f'<p class="loi">{e(bq["thong_bao"])}</p>' if bq["thong_bao"] and not bq["cho_ghi"] else ""}</div>
<div class="the"><h2>Mã máy</h2><p>Gửi mã này qua Zalo hoặc điện thoại <b>{ban_quyen.DIEN_THOAI}</b> để nhận key cho máy này:</p>
<p><span class="ma-may" id="mm">{e(ban_quyen.ma_may())}</span>
<button type="button" class="phu" onclick="navigator.clipboard.writeText(document.getElementById('mm').textContent);this.textContent='Đã chép'">Chép</button></p>
{o_key}<h3>Liên hệ</h3><div class="logo-sang">{thuong_hieu.LOGO_SANG}</div>{giao_dien.lien_he_html(lon=True)}</div>
<div class="the"><h2>Các gói</h2>{bang_goi}<p class="mo">Nâng gói hoặc gia hạn: nhận key mới, dán vào ô Key kích hoạt ở trên. Không cần cài lại.</p></div>
<div class="the"><h2>Dùng thử và hết hạn</h2><ul>
<li>Bản dùng thử dùng đầy đủ chức năng trong {ban_quyen.SO_NGAY_DUNG_THU} ngày, tối đa {ban_quyen.CONG_TY_DUNG_THU} công ty.</li>
<li>Khi hết hạn, ứng dụng chuyển sang <b>chỉ xem</b>: dữ liệu không bị khóa hay xóa, vẫn xem, in, xuất Excel và XML được. Nhập key là ghi sổ tiếp ngay.</li>
<li>Key gắn với máy này. Đổi máy hoặc cài lại Windows thì gửi mã máy mới để được cấp lại.</li></ul></div>"""
        self.gui(trang("Bản quyền", nd))

    def cdtk(self, pt, con, ct, q, _):
        cid = ct["id"]
        tu, den = ky_mac_dinh(q)
        ds = so_sach.tong_hop_tai_khoan(con, cid, tu, den)
        k = ["dau_no", "dau_co", "ps_no", "ps_co", "cuoi_no", "cuoi_co"]
        tong = [sum(r[x] for r in ds if r["cap"] == 1) for x in k]
        dong = "".join(
            f'<tr class="{"c1" if r["cap"] == 1 else ""}"><td><a href="/cty/{cid}/socai?tk={r["so_tk"]}&tu={tu}&den={den}">'
            f'{e(r["so_tk"])}</a></td><td>{"&nbsp;" * 3 * (r["cap"] - 1)}{e(r["ten"])}</td>'
            + "".join(f'<td class="s">{so(r[x])}</td>' for x in k) + "</tr>" for r in ds)
        dong += '<tr class="c1"><td></td><td>Tổng cộng</td>' + "".join(f'<td class="s">{so(t)}</td>' for t in tong) + "</tr>"
        canh = "" if tong[2] == tong[3] else '<p class="loi">Tổng phát sinh Nợ khác Có, cần kiểm tra.</p>'
        nd = f"""<div class="the"><h1>Bảng cân đối tài khoản</h1>{form_ky(tu, den)}
<p><a class="nut phu" href="/cty/{cid}/xuat/cdtk?tu={tu}&den={den}">Xuất Excel</a></p>{canh}</div>
<table><tr><th>TK</th><th>Tên tài khoản</th><th>Dư Nợ đầu kỳ</th><th>Dư Có đầu kỳ</th><th>Phát sinh Nợ</th>
<th>Phát sinh Có</th><th>Dư Nợ cuối kỳ</th><th>Dư Có cuối kỳ</th></tr>{dong}</table>"""
        self.gui(trang("Cân đối tài khoản", nd, cid, ct["ten"]))

    def socai(self, pt, con, ct, q, _):
        cid = ct["id"]
        tu, den = ky_mac_dinh(q)
        tk = q.get("tk", "111")
        tks = con.execute("SELECT so_tk, ten FROM tai_khoan WHERE cong_ty_id=? ORDER BY so_tk", (cid,)).fetchall()
        chon = "".join(f'<option value="{e(t["so_tk"])}" {"selected" if t["so_tk"] == tk else ""}>'
                       f'{e(t["so_tk"])} - {e(t["ten"])}</option>' for t in tks)
        th = next((r for r in so_sach.tong_hop_tai_khoan(con, cid, tu, den) if r["so_tk"] == tk), None)
        dong = "".join(
            f'<tr><td>{ngay_vn(d["ngay_ht"])}</td><td>{e(d["so_ct"])}</td><td>{ngay_vn(d["ngay_ct"])}</td>'
            f'<td>{e(d["dien_giai"])}</td><td>{e(d["tk_du"])}</td><td class="s">{so(d["no"])}</td><td class="s">{so(d["co"])}</td></tr>'
            for d in so_sach.so_cai(con, cid, tk, tu, den))
        if th:
            dau = f'<tr class="c1"><td colspan="5">Số dư đầu kỳ</td><td class="s">{so(th["dau_no"])}</td><td class="s">{so(th["dau_co"])}</td></tr>'
            cuoi = (f'<tr class="c1"><td colspan="5">Cộng số phát sinh</td><td class="s">{so(th["ps_no"])}</td><td class="s">{so(th["ps_co"])}</td></tr>'
                    f'<tr class="c1"><td colspan="5">Số dư cuối kỳ</td><td class="s">{so(th["cuoi_no"])}</td><td class="s">{so(th["cuoi_co"])}</td></tr>')
        else:
            dau = cuoi = ""
        them = f'<label>Tài khoản<select name="tk">{chon}</select></label>'
        nd = f"""<div class="the"><h1>Sổ cái</h1>{form_ky(tu, den, them)}
<p><a class="nut phu" href="/cty/{cid}/xuat/socai?tu={tu}&den={den}">Xuất Excel sổ cái tất cả tài khoản</a></p></div>
<table><tr><th>Ngày ghi sổ</th><th>Số CT</th><th>Ngày CT</th><th>Diễn giải</th><th>TK đối ứng</th><th>Nợ</th><th>Có</th></tr>
{dau}{dong}{cuoi}</table>"""
        self.gui(trang("Sổ cái", nd, cid, ct["ten"]))

    def nkc(self, pt, con, ct, q, _):
        cid = ct["id"]
        tu, den = ky_mac_dinh(q)
        tim = q.get("q", "").strip().lower()
        ds = [r for r in so_sach.so_nhat_ky_chung(con, cid, tu, den)
              if not tim or tim in (r["so_ct"] + " " + (r["dien_giai"] or "")).lower()]
        dong = "".join(
            f'<tr><td>{ngay_vn(r["ngay_ht"])}</td><td>{e(r["so_ct"])}</td><td>{e(r["dien_giai"])}</td>'
            f'<td>{e(r["tk_no"])}</td><td>{e(r["tk_co"])}</td><td class="s">{so(r["so_tien"])}</td></tr>' for r in ds[:3000])
        them = f'<label>Tìm số CT / diễn giải<input name="q" value="{e(q.get("q", ""))}"></label>'
        nd = f"""<div class="the"><h1>Sổ nhật ký chung</h1>{form_ky(tu, den, them)}
<p class="mo">{len(ds)} định khoản, tổng {so(sum(r['so_tien'] for r in ds))} đồng.</p>
<p><a class="nut phu" href="/cty/{cid}/xuat/nkc?tu={tu}&den={den}">Xuất Excel (mẫu S03a-DNN)</a></p></div>
<table><tr><th>Ngày HT</th><th>Số CT</th><th>Diễn giải</th><th>TK Nợ</th><th>TK Có</th><th>Số tiền</th></tr>{dong}</table>"""
        self.gui(trang("Sổ nhật ký chung", nd, cid, ct["ten"]))

    def chungtu_moi(self, pt, con, ct, q, rest):
        cid = ct["id"]
        thong_bao = ""
        f = {}
        if pt == "POST":
            f = self.doc_form()
            g = lambda k: (f.get(k) or [""])[0].strip()
            try:
                dong = doc_dong_but_toan(f, g("dien_giai"))
                ct_id = db.ghi_chung_tu(con, cid, g("so_ct"), g("ngay_ct") or g("ngay_ht"), g("ngay_ht"), dong,
                                       loai=g("loai") or None, dien_giai=g("dien_giai"), nguon="tay")
                con.commit()
                thong_bao = (f'<p class="ok">Đã ghi chứng từ <a href="/cty/{cid}/chungtu/{ct_id}">{e(g("so_ct"))}</a>. '
                             f'<a href="/cty/{cid}/chungtu/{ct_id}/in" target="_blank">In phiếu</a></p>')
                f = {}
            except (ValueError, sqlite3.IntegrityError) as ex:
                con.rollback()
                thong_bao = f'<p class="loi">Chưa ghi được: {e(ex)}</p>'
        g = lambda k, md="": e((f.get(k) or [md])[0])
        hom_nay = date.today().isoformat()
        loai_chon = g("loai", "PT")
        loai = "".join(f'<option value="{m}" {"selected" if m == loai_chon else ""}>{t}</option>' for m, t in
                       [("PT", "Phiếu thu"), ("PC", "Phiếu chi"), ("BC", "Báo có"), ("BN", "Báo nợ"), ("BH", "Bán hàng"),
                        ("MH", "Mua hàng"), ("NV", "Nghiệp vụ khác")])
        dong_cu = []
        if f:
            for i in range(len(f.get("tk_no", []))):
                lay = lambda k: (f.get(k) or [""] * 99)[i] if i < len(f.get(k) or []) else ""
                dong_cu.append({"tk_no": lay("tk_no"), "tk_co": lay("tk_co"), "so_tien": int(lay("so_tien").replace(".", "").replace(",", "") or 0) if lay("so_tien").replace(".", "").replace(",", "").isdigit() else 0,
                                "dien_giai": lay("dg"), "doi_tuong_no": lay("dt"), "doi_tuong_co": ""})
        dstk = "".join(f'<option value="{e(t["so_tk"])}">{e(t["ten"])}</option>' for t in
                       con.execute("SELECT so_tk, ten FROM tai_khoan WHERE cong_ty_id=? ORDER BY so_tk", (cid,)))
        nd = f"""<div class="the"><h1>Nhập chứng từ</h1>{thong_bao}<form method="post">
<div class="ngang" style="margin-bottom:12px">
<label>Loại<select name="loai">{loai}</select></label>
<label>Số chứng từ<input name="so_ct" required value="{g('so_ct')}"></label>
<label>Ngày hạch toán<input type="date" name="ngay_ht" value="{g('ngay_ht', hom_nay)}" required></label>
<label>Ngày chứng từ<input type="date" name="ngay_ct" value="{g('ngay_ct', hom_nay)}"></label>
<label>Diễn giải<input name="dien_giai" size="50" value="{g('dien_giai')}"></label></div>
{bang_nhap_dong([d for d in dong_cu if d['tk_no'] or d['tk_co']])}
<p class="mo">Cột Đối tượng: điền mã khách hàng / nhà cung cấp / nhân viên cho dòng có TK 131, 331, 1388, 141, 334, 338 để theo dõi công nợ chi tiết.</p>
<datalist id="dstk">{dstk}</datalist><datalist id="dsdt">{ds_doi_tuong(con, cid)}</datalist>
<div class="dong-nut"><button>Ghi sổ</button><a class="nut phu" href="/cty/{cid}/chungtu">Danh sách chứng từ</a></div></form></div>"""
        self.gui(trang("Nhập chứng từ", nd, cid, ct["ten"]))

    def nhap_misa(self, pt, con, ct, q, _):
        cid = ct["id"]
        kq = ""
        mac_dinh = {"nkc": "", "socai": "",
                    "ngay": f"{date.today().year - 1}-01-01", "den": f"{date.today().year - 1}-12-31"}
        if pt == "POST":
            if self.headers.get("Content-Type", "").startswith("multipart/"):
                from .trang_hoa_don import doc_multipart
                truong, tep = doc_multipart(self, theo_truong=True)
                f = {k: v.strip().strip('"') for k, v in truong.items()}
                tm = THU_MUC_DL / "nap" / str(cid)
                tm.mkdir(parents=True, exist_ok=True)
                for k in ("nkc", "socai"):
                    if tep.get("tep_" + k):
                        duong = tm / f"{k}_{datetime.now():%Y%m%d%H%M%S}.xlsx"
                        duong.write_bytes(tep["tep_" + k][0][1])
                        f[k] = str(duong)
            else:
                f = {k: v[0].strip().strip('"') for k, v in self.doc_form().items()}
            mac_dinh.update({k: v for k, v in f.items() if k in ("ngay", "den") or not str(v).startswith(str(THU_MUC_DL))})
            if not f.get("nkc") or not f.get("socai"):
                raise ValueError("Chưa chọn đủ hai file: Sổ nhật ký chung và Sổ cái.")
            bc = nhap_misa.nhap(con, cid, f["nkc"], f["socai"], f["ngay"])
            khop, tong, lech = doi_chieu.voi_so_cai_misa(con, cid, f["socai"], f["ngay"], f["den"])
            bang = "".join(
                f'<tr><td>{e(x["so_tk"])}</td><td>{e(x["ten"])}</td><td>{e(x["truong"])}</td><td class="s">{so(x["misa"])}</td>'
                f'<td class="s">{so(x["he_thong"])}</td><td class="s">{so(x["chenh"])}</td></tr>' for x in lech)
            kq = f"""<div class="the"><h2>Kết quả</h2><p>Đã nạp {bc['so_chung_tu']} chứng từ, {bc['so_dinh_khoan']}
định khoản, {bc['so_tai_khoan']} tài khoản.</p>
<p class="{'ok' if not lech else 'loi'}">Đối chiếu với sổ cái MISA: {khop}/{tong} tài khoản khớp hoàn toàn.</p>
{'<p class="loi">Có ' + str(bc['dong_khong_doi_xung']) + ' dòng NKC không có dòng đối xứng.</p>' if bc['dong_khong_doi_xung'] else ''}
{'<table><tr><th>TK</th><th>Tên</th><th>Chỉ tiêu</th><th>MISA</th><th>Hệ thống</th><th>Chênh</th></tr>' + bang + '</table>' if lech else ''}</div>"""
        nd = f"""<div class="the"><h1>Nạp dữ liệu từ MISA</h1>
<p class="mo">Xuất từ MISA hai file Excel: Sổ nhật ký chung (S03a-DNN) và Sổ cái (S03b-DNN) của cả năm.
Nạp lại sẽ thay toàn bộ chứng từ cũ có nguồn MISA, không đụng chứng từ nhập tay.</p>
<form method="post" enctype="multipart/form-data" style="display:grid;gap:10px;max-width:900px">
<div class="ngang"><label>Chọn file sổ nhật ký chung<input type="file" name="tep_nkc" accept=".xlsx"></label>
<label>hoặc gõ đường dẫn<input name="nkc" size="70" value="{e(mac_dinh['nkc'])}"></label></div>
<div class="ngang"><label>Chọn file sổ cái<input type="file" name="tep_socai" accept=".xlsx"></label>
<label>hoặc gõ đường dẫn<input name="socai" size="70" value="{e(mac_dinh['socai'])}"></label></div>
<div class="ngang" style="display:flex;gap:10px"><label>Ngày của số dư đầu kỳ trên sổ cái<input type="date" name="ngay" value="{e(mac_dinh['ngay'])}"></label>
<label>Đến ngày (cuối kỳ sổ cái)<input type="date" name="den" value="{e(mac_dinh['den'])}"></label></div>
<div><button>Nạp và đối chiếu</button></div></form></div>{kq}"""
        self.gui(trang("Nạp dữ liệu MISA", nd, cid, ct["ten"]))

    def xuat(self, pt, con, ct, q, rest):
        cid = ct["id"]
        tu, den = ky_mac_dinh(q)
        loai = rest[0] if rest else "cdtk"
        thu_muc = THU_MUC_DL / "xuat"
        thu_muc.mkdir(parents=True, exist_ok=True)
        ten = {"cdtk": "Can_doi_tai_khoan", "nkc": "So_nhat_ky_chung", "socai": "So_cai"}[loai]
        duong = thu_muc / f"{ten}_{ct['mst']}_{tu}_{den}.xlsx"
        {"cdtk": xuat_excel.can_doi_tai_khoan, "nkc": xuat_excel.so_nhat_ky_chung,
         "socai": xuat_excel.so_cai}[loai](con, cid, tu, den, duong)
        b = duong.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quote(duong.name)}")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)


def sao_luu(giu_lai=30, ly_do=""):
    """Sao luu file du lieu (trong may va thu muc ngoai neu da cai)."""
    cai_dat.FILE_DL = FILE_DL
    return cai_dat.sao_luu(giu_lai, ly_do)


_CHAY_AN = False
_KHOI_DONG_LAI = False


def _dang_chay(url):
    """Da co So ke toan chay o cong nay chua."""
    import urllib.request
    try:
        with urllib.request.urlopen(url + "ping", timeout=1.5) as r:
            return r.read(20) == b"so-ke-toan"
    except Exception:
        return False


def _bao_loi(thong_bao):
    """Hien hop thoai loi khi chay an (pythonw, khong co cua so den)."""
    print(thong_bao)
    if _CHAY_AN and sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, thong_bao, "iFix Kế toán", 0x10)
        except Exception:
            pass


def chay(mo_trinh_duyet=True):
    THU_MUC_DL.mkdir(parents=True, exist_ok=True)
    if sys.stdout is None:  # chay an bang pythonw: ghi thong bao ra file
        global _CHAY_AN
        _CHAY_AN = True
        f = open(THU_MUC_DL / "nhat_ky_chay.txt", "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = f
        print(f"\n--- {datetime.now():%d/%m/%Y %H:%M:%S}")
    url = f"http://127.0.0.1:{CONG}/"
    if _dang_chay(url):  # mo lai khi dang chay: chi mo trinh duyet
        if mo_trinh_duyet:
            webbrowser.open(url)
        return
    cai_dat.ap_dung_tham_so()
    da, loi = sao_luu()
    for x in loi:
        print("Chưa sao lưu được:", x)
    c = db.mo(FILE_DL)
    cai_dat.chuan_bi(c)
    lan = bool(cai_dat.doc().get("lan")) and cai_dat.co_nguoi_dung(c)
    c.close()
    try:
        may = ThreadingHTTPServer(("0.0.0.0" if lan else "127.0.0.1", CONG), XuLy)
    except OSError as ex:
        return _bao_loi(f"Không mở được cổng {CONG}: có chương trình khác đang dùng cổng này.\n{ex}")
    may.lan = lan
    print(f"iFix Kế toán {PHIEN_BAN} đang chạy tại {url}  (tắt bằng nút Tắt ở góc trên bên phải)")
    if lan:
        print(f"Máy khác trong mạng LAN mở: http://{cai_dat.dia_chi_lan()}:{CONG}/")
    if mo_trinh_duyet:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    from . import cap_nhat
    cap_nhat.kiem_tra_dinh_ky()
    from . import tu_tai_hd
    tu_tai_hd.chay_nen(lambda: FILE_DL)
    if os.environ.get("KETOAN_KHONG_TIM_CU") != "1":
        nhap_du_lieu_cu.quet_nen(FILE_DL, list((cai_dat.doc().get("du_lieu_cu_da_xu_ly") or {}).keys()))
    try:
        may.serve_forever()
    except KeyboardInterrupt:
        pass
    may.server_close()
    if _KHOI_DONG_LAI:
        _mo_lai()


def _mo_lai():
    """Mo lai ung dung bang tien trinh moi (sau khi cap nhat)."""
    import subprocess
    moi = dict(os.environ, PYTHONUTF8="1")
    co = 0
    if sys.platform == "win32" and not _CHAY_AN:
        co = subprocess.CREATE_NEW_CONSOLE
    subprocess.Popen([sys.executable, "-m", "ketoan.ung_dung", "--khong-mo"], cwd=str(GOC), env=moi, creationflags=co)


if __name__ == "__main__":
    chay("--khong-mo" not in sys.argv)
