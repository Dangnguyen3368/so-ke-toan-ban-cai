"""Trang So theo thong tu: so ke toan theo mau rieng cua ho kinh doanh (TT152) va doanh nghiep sieu nho (TT58),
lap tu so lieu da ghi so. Tron vao lop XuLy."""
from . import bao_cao, che_do, kho, so_sach
from . import giao_dien as G
from .giao_dien import e, ngay_vn, so


def _tl(v):
    return f"{v:g}".replace(".", ",")


def _so_thuc(s):
    try:
        return float((s or "0").replace(",", "."))
    except ValueError:
        return 0.0


class TrangCheDo:
    def sochedo(self, pt, con, ct, q, rest):
        cid = ct["id"]
        cd = che_do.ma(ct)
        ds_so = che_do.SO.get(cd)
        if not ds_so:
            return self.gui(G.trang("Sổ theo thông tư", f'<div class="the"><p>Công ty đang theo {e(che_do.ten_day_du(cd))}: '
                                    f'dùng Sổ nhật ký chung, Sổ cái và các sổ chi tiết trong menu Sổ sách.</p></div>', cid, ct["ten"]))
        tb = ""
        if pt == "POST":
            f = {k: v[0] for k, v in self.doc_form().items()}
            che_do.luu_ty_le(con, cid, {n: (_so_thuc(f.get(f"g_{n}")), _so_thuc(f.get(f"t_{n}"))) for n, *_ in che_do.NHOM})
            tb = '<p class="ok">Đã lưu tỷ lệ thuế trên doanh thu.</p>'
        ma = rest[0] if rest and any(rest[0] == m for m, *_ in ds_so) else ds_so[0][0]
        _, ten, loai, ap_dung = next(x for x in ds_so if x[0] == ma)
        nam = G.ky_mac_dinh(q)[0][:4]
        tu, den = q.get("tu", f"{nam}-01-01"), q.get("den", f"{nam}-12-31")
        tabs = G.tab([(m, f"/cty/{cid}/sochedo/{m}?tu={tu}&den={den}", m) for m, *_ in ds_so], ma)
        than = getattr(self, f"_scd_{loai}")(con, ct, tu, den, q)
        nd = f"""<div class="the"><h1>Sổ kế toán theo {e(che_do.CHE_DO[cd]['ten'])}</h1>
<p class="mo">{e(che_do.CHE_DO[cd]['doi_tuong'])}. Sổ lập tự động từ chứng từ đã ghi; chọn sổ phù hợp với cách nộp thuế của đơn vị.</p>
{tb}{tabs}{G.form_ky(tu, den)}<p class="dong-nut"><button class="phu" onclick="window.print()">In sổ</button></p></div>
<div class="the"><div class="dong" style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">
<div><b>{e(ct['ten'])}</b><br><span class="mo">MST {e(ct['mst'])}{' · ' + e(ct['dia_chi']) if ct['dia_chi'] else ''}</span></div>
<div class="mo" style="text-align:right"><b>Mẫu số {e(ma)}</b><br>(Kèm theo {e(che_do.CHE_DO[cd]['ten'])})</div></div>
<h2 style="text-align:center;margin-top:12px">{e(ten.upper())}</h2><p class="mo" style="text-align:center">Từ {ngay_vn(tu)} đến {ngay_vn(den)}</p>
<p class="mo">{e(ap_dung)}</p>{than}</div>"""
        self.gui(G.trang(f"Sổ {ma}", nd, cid, ct["ten"]))

    # ---------------------------------------------------------------- cac loai so
    def _scd_doanh_thu(self, con, ct, tu, den, q):
        ds = che_do.doanh_thu(con, ct["id"], tu, den)
        dong = "".join(f'<tr><td>{ngay_vn(d["ngay_ht"])}</td><td>{e(d["so_ct"])}</td><td>{ngay_vn(d["ngay_ct"])}</td>'
                       f'<td>{e(d["dien_giai"])}</td><td class="s">{so(d["so_tien"]) or 0}</td></tr>' for d in ds)
        tong = sum(d["so_tien"] for d in ds)
        return (f'<table><tr><th>Ngày ghi sổ</th><th>Số chứng từ</th><th>Ngày chứng từ</th><th>Diễn giải</th><th class="s">Doanh thu</th></tr>'
                f'{dong}<tr class="tong"><td colspan="4">Tổng cộng</td><td class="s">{so(tong) or 0}</td></tr></table>')

    def _bang_nhom(self, con, ct, tu, den, gtgt_tt):
        cid = ct["id"]
        ds = che_do.doanh_thu(con, cid, tu, den)
        thue = che_do.thue_theo_nhom(con, cid, ds)
        ten_tt = "TNDN" if che_do.ma(ct) == "TT58" else "TNCN"
        h = ""
        tong = {"doanh_thu": 0, "gtgt": 0, "tndn_tncn": 0}
        for n, ten, *_ in che_do.NHOM:
            if n not in thue:
                continue
            k = thue[n]
            dong = "".join(f'<tr><td>{e(d["so_ct"])}</td><td>{ngay_vn(d["ngay_ct"])}</td><td>{e(d["dien_giai"])}</td>'
                           f'<td class="s">{so(d["so_tien"]) or 0}</td></tr>' for d in ds if d["nhom"] == n)
            h += f'<tr class="c1"><td colspan="4">Ngành nghề: {e(ten)}</td></tr>{dong}'
            h += f'<tr class="tong"><td colspan="3">Tổng cộng doanh thu</td><td class="s">{so(k["doanh_thu"]) or 0}</td></tr>'
            h += f'<tr><td colspan="3">Thuế GTGT phải nộp ({_tl(k["tl_gtgt"])}%)</td><td class="s">{so(k["gtgt"]) or 0}</td></tr>'
            if gtgt_tt:
                h += f'<tr><td colspan="3">Thuế {ten_tt} phải nộp ({_tl(k["tl_tt"])}%)</td><td class="s">{so(k["tndn_tncn"]) or 0}</td></tr>'
            for x in tong:
                tong[x] += k[x]
        h += (f'<tr class="tong"><td colspan="3">TỔNG DOANH THU CÁC NGÀNH NGHỀ</td><td class="s">{so(tong["doanh_thu"]) or 0}</td></tr>'
              f'<tr class="tong"><td colspan="3">Tổng thuế GTGT phải nộp</td><td class="s">{so(tong["gtgt"]) or 0}</td></tr>'
              + (f'<tr class="tong"><td colspan="3">Tổng thuế {ten_tt} phải nộp</td><td class="s">{so(tong["tndn_tncn"]) or 0}</td></tr>'
                 if gtgt_tt else ""))
        tl = che_do.ty_le(con, cid)
        o = "".join(f'<tr><td>{e(ten)}<br><span class="mo">TK doanh thu {tk}</span></td>'
                    f'<td><input name="g_{n}" value="{_tl(tl[n][0])}" size="5"></td><td><input name="t_{n}" value="{_tl(tl[n][1])}" size="5"></td></tr>'
                    for n, ten, tk, *_ in che_do.NHOM)
        form = (f'<details class="khong-in" style="margin-top:14px"><summary>Tỷ lệ thuế trên doanh thu (%)</summary><form method="post">'
                f'<table><tr><th>Nhóm ngành nghề</th><th>GTGT %</th><th>{ten_tt} %</th></tr>{o}</table>'
                '<p class="mo">Mặc định theo tỷ lệ của hộ kinh doanh (Thông tư 40/2021). Doanh nghiệp siêu nhỏ nhập tỷ lệ TNDN '
                'theo Luật thuế TNDN đang áp dụng. Doanh thu xếp nhóm theo tài khoản doanh thu cấp 2 (5111, 5112, 5113, 5118).</p>'
                '<button>Lưu tỷ lệ</button></form></details>')
        return (f'<table><tr><th>Số chứng từ</th><th>Ngày chứng từ</th><th>Diễn giải</th><th class="s">Số tiền</th></tr>{h}</table>{form}')

    def _scd_doanh_thu_thue(self, con, ct, tu, den, q):
        return self._bang_nhom(con, ct, tu, den, True)

    def _scd_doanh_thu_gtgt(self, con, ct, tu, den, q):
        return self._bang_nhom(con, ct, tu, den, False)

    def _scd_thu_chi(self, con, ct, tu, den, q):
        ds = che_do.thu_chi(con, ct["id"], tu, den)
        dong = "".join(f'<tr><td>{ngay_vn(d["ngay_ht"])}</td><td>{e(d["so_ct"])}</td><td>{ngay_vn(d["ngay_ct"])}</td><td>{e(d["dien_giai"])}</td>'
                       f'<td class="s">{so(d["doanh_thu"])}</td><td class="s">{so(d["chi_phi"])}</td></tr>' for d in ds)
        dt, cp = sum(d["doanh_thu"] for d in ds), sum(d["chi_phi"] for d in ds)
        return (f'<table><tr><th>Ngày ghi sổ</th><th>Số chứng từ</th><th>Ngày chứng từ</th><th>Diễn giải</th>'
                f'<th class="s">Doanh thu</th><th class="s">Chi phí</th></tr>{dong}'
                f'<tr class="tong"><td colspan="4">Tổng cộng</td><td class="s">{so(dt) or 0}</td><td class="s">{so(cp) or 0}</td></tr>'
                f'<tr class="tong"><td colspan="4">Chênh lệch doanh thu trừ chi phí</td><td class="s" colspan="2">{so(dt - cp) or 0}</td></tr></table>'
                '<p class="mo">Chi phí gồm giá vốn, chi phí tài chính, bán hàng, quản lý, sản xuất và chi phí khác đã ghi sổ. '
                'Loại bỏ khoản chi không có hóa đơn, chứng từ hợp lệ trước khi tính thu nhập chịu thuế.</p>')

    def _scd_vat_tu(self, con, ct, tu, den, q):
        cid = ct["id"]
        kho.chuan_bi(con)
        vts = con.execute("SELECT * FROM vat_tu WHERE cong_ty_id=? ORDER BY ma", (cid,)).fetchall()
        dau, cuoi = kho._ton(con, cid, tu), kho._ton(con, cid, bao_cao.ngay_sau(den))
        ps = {}
        for r in con.execute("SELECT * FROM kho_dong WHERE cong_ty_id=? AND ngay BETWEEN ? AND ? AND NOT (loai='D' AND ngay=?)",
                             (cid, tu, den, tu)):
            x = ps.setdefault(r["ma_vt"], [0, 0, 0, 0])
            i = 2 if r["loai"] == "X" else 0
            x[i] += r["so_luong"]
            x[i + 1] += r["thanh_tien"] or 0
        dong = ""
        for v in vts:
            d, c, p = dau.get(v["ma"], [0, 0]), cuoi.get(v["ma"], [0, 0]), ps.get(v["ma"], [0, 0, 0, 0])
            if not (any(d) or any(c) or any(p)):
                continue
            dong += (f'<tr><td>{e(v["ma"])}</td><td>{e(v["ten"])}</td><td>{e(v["dvt"] or "")}</td>'
                     f'<td class="s">{d[0]:g}</td><td class="s">{so(d[1])}</td><td class="s">{p[0]:g}</td><td class="s">{so(p[1])}</td>'
                     f'<td class="s">{p[2]:g}</td><td class="s">{so(p[3])}</td><td class="s">{c[0]:g}</td><td class="s">{so(c[1])}</td></tr>')
        return ('<table><tr><th>Mã</th><th>Tên vật liệu, dụng cụ, hàng hóa</th><th>ĐVT</th><th class="s">SL đầu kỳ</th><th class="s">Giá trị đầu kỳ</th>'
                '<th class="s">SL nhập</th><th class="s">Giá trị nhập</th><th class="s">SL xuất</th><th class="s">Giá trị xuất</th>'
                f'<th class="s">SL tồn</th><th class="s">Giá trị tồn</th></tr>{dong}</table>'
                f'<p class="mo khong-in">Xem chi tiết từng lần nhập, xuất ở <a href="/cty/{cid}/so/vattu?tu={tu}&den={den}">Sổ chi tiết vật tư</a>.</p>')

    def _scd_tien(self, con, ct, tu, den, q):
        cid = ct["id"]
        th = {r["so_tk"]: r for r in so_sach.tong_hop_tai_khoan(con, cid, tu, den)}
        h = ""
        for tk, ten in (("111", "Tiền mặt"), ("112", "Tiền gửi không kỳ hạn")):
            r = th.get(tk)
            du = (r["dau_no"] - r["dau_co"]) if r else 0
            h += f'<tr class="c1"><td colspan="4">{ten} (TK {tk})</td><td></td><td></td><td class="s">{so(du) or 0}</td></tr>'
            for d in so_sach.so_cai(con, cid, tk, tu, den):
                if d["tk_du"].startswith(("111", "112")) and d["tk_du"][:3] == tk:
                    continue
                du += d["no"] - d["co"]
                h += (f'<tr><td>{ngay_vn(d["ngay_ht"])}</td><td>{e(d["so_ct"])}</td><td>{e(d["dien_giai"])}</td><td>{e(d["tk_du"])}</td>'
                      f'<td class="s">{so(d["no"])}</td><td class="s">{so(d["co"])}</td><td class="s">{so(du) or 0}</td></tr>')
            h += f'<tr class="tong"><td colspan="6">Số dư cuối kỳ</td><td class="s">{so(du) or 0}</td></tr>'
        return ('<table><tr><th>Ngày</th><th>Số chứng từ</th><th>Diễn giải</th><th>Đối ứng</th><th class="s">Thu / gửi vào</th>'
                f'<th class="s">Chi / rút ra</th><th class="s">Tồn</th></tr>{h}</table>')

    def _bang_theo_doi(self, con, ct, tien_to, tu, den, nhan_tang, nhan_giam):
        dau, ds, cuoi = che_do.theo_doi_tk(con, ct["id"], tien_to, tu, den)
        dong = "".join(f'<tr><td>{ngay_vn(d["ngay_ht"])}</td><td>{e(d["so_ct"])}</td><td>{e(d["dien_giai"])}</td><td>{e(d["tk"])}</td>'
                       f'<td class="s">{so(d["tang"])}</td><td class="s">{so(d["giam"])}</td></tr>' for d in ds)
        return (f'<table><tr><th>Ngày</th><th>Số chứng từ</th><th>Diễn giải</th><th>Tài khoản</th><th class="s">{nhan_tang}</th>'
                f'<th class="s">{nhan_giam}</th></tr><tr class="c1"><td colspan="4">Số còn phải nộp / số dư đầu kỳ</td>'
                f'<td class="s" colspan="2">{so(dau) or 0}</td></tr>{dong}'
                f'<tr class="tong"><td colspan="4">Cộng phát sinh</td><td class="s">{so(sum(d["tang"] for d in ds)) or 0}</td>'
                f'<td class="s">{so(sum(d["giam"] for d in ds)) or 0}</td></tr>'
                f'<tr class="tong"><td colspan="4">Số dư cuối kỳ</td><td class="s" colspan="2">{so(cuoi) or 0}</td></tr></table>')

    def _scd_thue_khac(self, con, ct, tu, den, q):
        return self._bang_theo_doi(con, ct, che_do.THUE_KHAC, tu, den, "Số phải nộp", "Số đã nộp")

    def _scd_von(self, con, ct, tu, den, q):
        return self._bang_theo_doi(con, ct, che_do.VON, tu, den, "Tăng", "Giảm")

    def _scd_gtgt_khau_tru(self, con, ct, tu, den, q):
        cid = ct["id"]
        th = {r["so_tk"]: r for r in so_sach.tong_hop_tai_khoan(con, cid, tu, den)}
        g = lambda tk, k: th[tk][k] if tk in th else 0
        dau_kt = g("133", "dau_no")
        vao = g("133", "ps_no")
        ra = g("33311", "ps_co")
        dau_pn = g("3331", "dau_co") - g("3331", "dau_no")
        da_nop = sum(d["no"] for d in so_sach.so_cai(con, cid, "3331", tu, den) if d["tk_du"].startswith(("111", "112")))
        con_kt = max(dau_kt + vao - ra, 0)
        phai_nop = max(ra - vao - dau_kt, 0)
        dong = [("Thuế GTGT còn được khấu trừ đầu kỳ", dau_kt), ("Thuế GTGT đầu vào được khấu trừ phát sinh trong kỳ", vao),
                ("Thuế GTGT đầu ra phát sinh trong kỳ", ra), ("Thuế GTGT phải nộp trong kỳ", phai_nop),
                ("Thuế GTGT còn được khấu trừ chuyển kỳ sau", con_kt), ("Thuế GTGT còn phải nộp đầu kỳ", dau_pn),
                ("Thuế GTGT đã nộp trong kỳ", da_nop)]
        return ("<table><tr><th>Chỉ tiêu</th><th class='s'>Số tiền</th></tr>"
                + "".join(f'<tr><td>{e(t)}</td><td class="s">{so(v) or 0}</td></tr>' for t, v in dong) + "</table>"
                f'<p class="mo khong-in">Chi tiết theo hóa đơn xem ở <a href="/cty/{cid}/baocao?muc=gtgt">Tờ khai 01/GTGT</a>.</p>')

    def _scd_cong_no(self, con, ct, tu, den, q):
        return (f'<p>Sổ chi tiết thanh toán với người mua, người bán theo từng đối tượng: '
                f'<a class="nut phu" href="/cty/{ct["id"]}/congno">Mở Công nợ</a></p>')

    def _scd_tai_san(self, con, ct, tu, den, q):
        return (f'<p>Sổ tài sản cố định (nguyên giá, khấu hao, giá trị còn lại): '
                f'<a class="nut phu" href="/cty/{ct["id"]}/taisan">Mở Tài sản, CCDC</a></p>')
