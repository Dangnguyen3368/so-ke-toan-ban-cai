"""Nap du lieu xuat tu MISA SME (file Excel) vao so ke toan moi.

- So cai S03b-DNN: lay danh muc tai khoan dang dung va so du dau ky.
- So Nhat ky chung S03a-DNN: lay toan bo dinh khoan.

MISA in moi dinh khoan hai lan trong so NKC (mot dong ben No, mot dong ben
Co). Ta chi lay dong ben No (Phat sinh No > 0) va kiem tra dong ben Co khop.
"""
import re
from collections import Counter, defaultdict
from datetime import datetime

import openpyxl

from . import db

_RE_NGAY = re.compile(r"^\d{2}/\d{2}/\d{4}$")


def _ngay(s):
    return datetime.strptime(s, "%d/%m/%Y").strftime("%Y-%m-%d")


def _so(v):
    if v is None or v == "":
        return 0
    if isinstance(v, (int, float)):
        return int(round(v))
    s = str(v).replace(".", "").replace(",", "").strip()
    neg = s.startswith("(") or s.startswith("-")
    s = s.strip("()-")
    return -int(s) if neg else int(s or 0)


def _vals(r):
    return [c for c in r if c is not None and c != ""]


def _doc_dong(duong_dan):
    """Doc het cac dong cua sheet dau tien roi dong file (de Windows khong khoa file)."""
    wb = openpyxl.load_workbook(duong_dan, read_only=True)
    try:
        return list(wb.active.iter_rows(values_only=True))
    finally:
        wb.close()


def doc_so_cai(duong_dan):
    """Doc so cai MISA. Tra ve dict so_tk -> thong tin tong hop cua tai khoan."""
    kq = {}
    tk = None
    for r in _doc_dong(duong_dan):
        v = _vals(r)
        if not v:
            continue
        if v[0] == "Tài khoản:":
            so, _, ten = str(v[1]).partition(" - ")
            tk = so.strip()
            kq[tk] = {"ten": ten.strip(), "dau_no": 0, "dau_co": 0, "ps_no": 0,
                      "ps_co": 0, "cuoi_no": 0, "cuoi_co": 0, "luy_ke_no": 0, "luy_ke_co": 0}
            continue
        if tk is None or not isinstance(v[0], str):
            continue
        nhan = {"- Số dư đầu kỳ": "dau", "- Cộng số phát sinh": "ps",
                "- Số dư cuối kỳ": "cuoi", "- Cộng lũy kế từ đầu năm": "luy_ke"}.get(v[0])
        if nhan and len(v) >= 3:
            kq[tk][nhan + "_no"] = _so(v[1])
            kq[tk][nhan + "_co"] = _so(v[2])
    return kq


def doc_nkc(duong_dan):
    """Doc so NKC MISA. Tra ve list dong (ngay_ht, ngay_ct, so_ct, dien_giai, tk, tk_du, no, co)."""
    hdr = None
    dong = []
    for r in _doc_dong(duong_dan):
        if hdr is None:
            if r and r[0] == "Ngày hạch toán":
                hdr = {str(c).strip(): i for i, c in enumerate(r) if c}
            continue
        if not r or not isinstance(r[0], str) or not _RE_NGAY.match(r[0].strip()):
            continue
        g = lambda k: r[hdr[k]]
        dong.append((
            _ngay(g("Ngày hạch toán")), _ngay(g("Ngày chứng từ")), str(g("Số chứng từ")).strip(),
            (g("Diễn giải") or "").strip(), str(g("Tài khoản")).strip(), str(g("TK đối ứng")).strip(),
            _so(g("Phát sinh Nợ")), _so(g("Phát sinh Có")),
        ))
    return dong


def nhap(con, cid, duong_nkc, duong_so_cai, ngay_so_du):
    """Nap danh muc tai khoan, so du dau ky va but toan tu MISA. Tra ve bao cao ngan."""
    so_cai = doc_so_cai(duong_so_cai)
    for tk in sorted(so_cai, key=len):
        db.them_tai_khoan(con, cid, tk, so_cai[tk]["ten"])

    # So du dau ky ghi o tai khoan chi tiet nhat (khong co tai khoan con trong so cai)
    la = [tk for tk in so_cai if not any(o != tk and o.startswith(tk) for o in so_cai)]
    con.execute("DELETE FROM so_du_dau_ky WHERE cong_ty_id=? AND ngay=?", (cid, ngay_so_du))
    for tk in la:
        s = so_cai[tk]
        if s["dau_no"] or s["dau_co"]:
            con.execute(
                "INSERT INTO so_du_dau_ky (cong_ty_id, ngay, so_tk, du_no, du_co) VALUES (?,?,?,?,?)",
                (cid, ngay_so_du, tk, s["dau_no"], s["dau_co"]),
            )

    dong = doc_nkc(duong_nkc)
    ben_no = [d for d in dong if d[6] > 0]
    ben_co = [d for d in dong if d[7] > 0]
    # Kiem tra: moi dong No phai co dong Co doi xung
    dem_no = Counter((d[2], d[0], d[5], d[4], d[6]) for d in ben_no)
    dem_co = Counter((d[2], d[0], d[4], d[5], d[7]) for d in ben_co)
    lech = (dem_no - dem_co) + (dem_co - dem_no)

    nhom = defaultdict(list)
    for d in ben_no:
        nhom[(d[2], d[0])].append(d)
    con.execute("DELETE FROM chung_tu WHERE cong_ty_id=? AND nguon='misa'", (cid,))
    for tk in {d[4] for d in dong} | {d[5] for d in dong}:
        db.them_tai_khoan(con, cid, tk, f"TK {tk}")
    for (so_ct, ngay_ht), ds in nhom.items():
        db.ghi_chung_tu(
            con, cid, so_ct, ds[0][1], ngay_ht,
            [{"tk_no": d[4], "tk_co": d[5], "so_tien": d[6], "dien_giai": d[3]} for d in ds],
            loai=re.sub(r"\d+$", "", so_ct), dien_giai=ds[0][3], nguon="misa",
        )
    con.commit()
    return {
        "so_tai_khoan": len(so_cai),
        "so_dong_nkc": len(dong),
        "so_chung_tu": len(nhom),
        "so_dinh_khoan": len(ben_no),
        "dong_khong_doi_xung": sum(lech.values()),
    }
