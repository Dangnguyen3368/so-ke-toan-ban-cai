"""File Excel mau de nhap nhanh (tai ve tu ung dung) va bo doc tuong ung.

Moi mau co sheet HuongDan. Mau duoc dien san danh muc hien co cua cong ty
(vat tu, nhan vien) de nguoi dung chi viec them so lieu.
"""
import io
import re
from datetime import date, datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation

from . import kho, luong, tai_san

_DAM = Font(bold=True)
_NEN = PatternFill("solid", fgColor="DDEBF7")


def _sheet(wb, ten, cot, rong=None, dau=False):
    ws = wb.active if dau else wb.create_sheet(ten)
    ws.title = ten
    ws.append(cot)
    for i, c in enumerate(ws[1], 1):
        c.font, c.fill = _DAM, _NEN
        ws.column_dimensions[c.column_letter].width = (rong[i - 1] if rong else max(12, len(str(cot[i - 1])) + 4))
    ws.freeze_panes = "A2"
    return ws


def _huong_dan(wb, dong):
    ws = wb.create_sheet("HuongDan")
    ws.column_dimensions["A"].width = 110
    for d in dong:
        ws.append([d])
    ws["A1"].font = Font(bold=True, size=13)


def _luu(wb):
    b = io.BytesIO()
    wb.save(b)
    return b.getvalue()


# ------------------------------------------------------------------ mau
def mau_kho(con, cid):
    wb = Workbook()
    ws = _sheet(wb, "PhieuXuat", ["Ngày", "Số phiếu", "Mã vật tư", "Tên vật tư", "Số lượng", "TK Nợ",
                                  "Xuất cho (công trình / khách hàng)", "Diễn giải"],
                [12, 12, 12, 34, 12, 8, 34, 34], dau=True)
    ws.append([date.today().strftime("%d/%m/%Y"), "PX001", "", "Gạch đặc A0", 5000, "154", "Công trình nhà ông A", ""])
    dv = DataValidation(type="list", formula1='"154,632,621,623,627,6421,6422,241"', allow_blank=True)
    ws.add_data_validation(dv)
    dv.add("F2:F2000")
    td = _sheet(wb, "TonDau", ["Ngày", "Mã vật tư", "Tên vật tư", "ĐVT", "TK kho", "Số lượng", "Giá trị"],
                [12, 12, 34, 8, 8, 12, 16])
    dm = _sheet(wb, "DanhMucVatTu", ["Mã vật tư", "Tên vật tư", "ĐVT", "TK kho"], [12, 40, 8, 8])
    for r in con.execute("SELECT * FROM vat_tu WHERE cong_ty_id=? ORDER BY ma", (cid,)):
        dm.append([r["ma"], r["ten"], r["dvt"], r["tk_kho"]])
    _huong_dan(wb, [
        "Hướng dẫn nhập phiếu xuất kho",
        "Sheet PhieuXuat: mỗi dòng là một mặt hàng xuất. Chỉ cần Ngày, Tên (hoặc Mã) vật tư, Số lượng, TK Nợ.",
        "Không cần nhập đơn giá: cuối tháng bấm Tính giá xuất, máy tính giá bình quân và ghi sổ.",
        "TK Nợ: 154 xuất cho công trình / chi phí sản xuất, 632 xuất bán, 6421/6422 dùng cho bán hàng / quản lý.",
        "Nhiều dòng cùng Số phiếu là một phiếu. Bỏ trống Số phiếu thì máy tự đánh số.",
        "Tên vật tư phải trùng với danh mục (sheet DanhMucVatTu); máy so khớp không phân biệt hoa thường, dấu cách.",
        "Sheet TonDau (tùy chọn): tồn kho đầu kỳ khi mới chuyển sang ứng dụng.",
        "Phiếu nhập kho: không cần nhập tay. Máy tự tạo khi ghi sổ hóa đơn mua vào vào TK 152/153/156.",
    ])
    return _luu(wb)


def mau_luong(con, cid, thang):
    wb = Workbook()
    nv = _sheet(wb, "NhanVien", ["Mã NV", "Họ tên", "MST cá nhân", "Số CCCD", "Ngày sinh", "Bộ phận",
                                 "Lương đóng BH", "Đóng BH (C/K)", "Loại HĐ (DH/NH)", "Cư trú (C/K)", "TK chi phí"],
                [10, 28, 14, 15, 12, 16, 15, 12, 14, 12, 11], dau=True)
    ds = con.execute("SELECT * FROM nhan_vien WHERE cong_ty_id=? ORDER BY ma", (cid,)).fetchall()
    for r in ds:
        nv.append([r["ma"], r["ho_ten"], r["mst"], r["cccd"], r["ngay_sinh"], r["bo_phan"], r["luong_bh"],
                   "C" if r["dong_bh"] else "K", r["hop_dong"], "C" if r["cu_tru"] else "K", r["tk_chi_phi"]])
    if not ds:
        nv.append(["NV001", "Nguyễn Văn A", "", "", "", "Văn phòng", 5_000_000, "C", "DH", "C", "6422"])
    npt = _sheet(wb, "NguoiPhuThuoc", ["Mã NV", "Họ tên người phụ thuộc", "Ngày sinh", "MST", "Số CCCD",
                                       "Quan hệ", "Từ tháng (MM/YYYY)", "Đến tháng (MM/YYYY)"],
                 [10, 28, 12, 14, 15, 12, 18, 18])
    for r in con.execute("SELECT * FROM nguoi_phu_thuoc WHERE cong_ty_id=? ORDER BY ma_nv", (cid,)):
        npt.append([r["ma_nv"], r["ho_ten"], r["ngay_sinh"], r["mst"], r["cccd"], r["quan_he"],
                    f"{r['tu_thang'][5:]}/{r['tu_thang'][:4]}",
                    f"{r['den_thang'][5:]}/{r['den_thang'][:4]}" if r["den_thang"] else ""])
    bl = _sheet(wb, "BangLuong", ["Tháng (MM/YYYY)", "Mã NV", "Họ tên", "Ngày công", "Công chuẩn",
                                  "Lương cơ bản", "Phụ cấp chịu thuế", "Phụ cấp miễn thuế (ăn trưa...)",
                                  "Thưởng", "Khấu trừ khác"], [14, 10, 28, 11, 11, 14, 16, 18, 12, 14])
    t = f"{thang[5:]}/{thang[:4]}"
    for r in ds or [{"ma": "NV001", "ho_ten": "Nguyễn Văn A", "luong_bh": 5_000_000}]:
        cu = con.execute("SELECT * FROM bang_luong WHERE cong_ty_id=? AND ma_nv=? ORDER BY thang DESC LIMIT 1",
                         (cid, r["ma"])).fetchone()
        bl.append([t, r["ma"], r["ho_ten"], 26, cu["cong_chuan"] if cu else 26,
                   cu["luong_co_ban"] if cu else r["luong_bh"], cu["phu_cap_chiu_thue"] if cu else 0,
                   cu["phu_cap_mien_thue"] if cu else 0, 0, 0])
    _huong_dan(wb, [
        "Hướng dẫn bảng lương",
        "NhanVien: khai một lần, chỉ sửa khi có thay đổi. Loại HĐ: DH = từ 3 tháng trở lên (thuế lũy tiến), "
        "NH = dưới 3 tháng / thời vụ (khấu trừ 10% nếu thu nhập từ 2 triệu). Cư trú K = người không cư trú (20%).",
        "TK chi phí: 6421 bộ phận bán hàng, 6422 quản lý, 154 công nhân trực tiếp công trình.",
        "NguoiPhuThuoc: mỗi người một dòng, ghi rõ MST hoặc CCCD và tháng bắt đầu giảm trừ. Họ tên viết trên một dòng.",
        "BangLuong: mỗi tháng mỗi nhân viên một dòng. Lương tháng = Lương cơ bản × Ngày công / Công chuẩn.",
        "Máy tự tính BHXH 8% + BHYT 1,5% + BHTN 1% (người lao động), 17,5% + 3% + 1% (doanh nghiệp) trên Lương đóng BH,",
        "giảm trừ gia cảnh, thuế TNCN, thực lĩnh; sau đó bấm Ghi sổ.",
        "Có thể để nhiều tháng trong cùng một file.",
    ])
    return _luu(wb)


def mau_tai_san(con, cid):
    wb = Workbook()
    ws = _sheet(wb, "TaiSan", ["Loại (TSCD/CCDC)", "Mã", "Tên tài sản", "Nhóm TT45 / loại CCDC", "Bộ phận",
                               "Ngày ghi tăng", "Ngày bắt đầu khấu hao", "Nguyên giá", "Số tháng khấu hao/phân bổ",
                               "TK tài sản", "TK hao mòn / chờ phân bổ", "TK chi phí",
                               "Đã khấu hao trước (lũy kế)", "Tính đến tháng (MM/YYYY)"],
                [10, 10, 34, 30, 16, 13, 13, 15, 12, 10, 12, 10, 16, 14], dau=True)
    ws.append(["TSCD", "TS005", "Xe ô tô tải", "Phương tiện vận tải đường bộ", "Bán hàng",
               date.today().strftime("%d/%m/%Y"), "", 500_000_000, 96, "21113", "2141", "6421", 0, ""])
    dv = DataValidation(type="list", formula1='"' + ",".join(tai_san.KHUNG_TT45) + '"', allow_blank=True)
    ws.add_data_validation(dv)
    dv.add("D2:D500")
    _huong_dan(wb, [
        "Hướng dẫn khai báo TSCĐ và CCDC",
        "Mỗi tài sản một dòng, khai một lần. Hàng tháng bấm Trích khấu hao trong ứng dụng.",
        "TSCĐ: nguyên giá từ 30 triệu. Chọn Nhóm TT45 để máy kiểm tra khung thời gian khấu hao.",
        "CCDC: TK tài sản và TK chờ phân bổ đều là 242, phân bổ tối đa 36 tháng.",
        "Tài sản đã khấu hao một phần ở phần mềm cũ: ghi Đã khấu hao trước và Tính đến tháng.",
        "Hợp đồng, hóa đơn, giấy sang tên xe: đính kèm từng tài sản trên ứng dụng.",
        "Khung TT45 có sẵn (tháng): " + "; ".join(f"{k} {a}–{b}" for k, (a, b) in tai_san.KHUNG_TT45.items()),
    ])
    return _luu(wb)


# ------------------------------------------------------------------ doc
def _bang(wb, ten_sheet, bat_buoc):
    """Doc sheet thanh list dict theo tieu de (tim dong tieu de chua cac cot bat buoc)."""
    if ten_sheet not in wb.sheetnames:
        return []
    dong = list(wb[ten_sheet].iter_rows(values_only=True))
    for i, r in enumerate(dong):
        td = [str(c or "").strip() for c in r]
        if all(any(t.startswith(b) for t in td) for b in bat_buoc):
            kq = []
            for x in dong[i + 1:]:
                if not any(c not in (None, "") for c in x):
                    continue
                kq.append({td[j]: x[j] for j in range(min(len(td), len(x))) if td[j]})
            return kq
    return []


def _g(d, *ten):
    for k, v in d.items():
        if any(k.startswith(t) for t in ten):
            return v
    return None


def ngay(v):
    if v in (None, ""):
        return None
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    s = str(v).strip()
    for f in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%d.%m.%Y"):
        try:
            return datetime.strptime(s[:10], f).date().isoformat()
        except ValueError:
            pass
    raise ValueError(f"Ngày không đúng dạng: {s}")


def thang(v):
    if v in (None, ""):
        return None
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y-%m")
    s = str(v).strip()
    m = re.fullmatch(r"(\d{1,2})[/-](\d{4})", s)
    if m:
        return f"{m.group(2)}-{int(m.group(1)):02d}"
    m = re.fullmatch(r"(\d{4})-(\d{1,2})", s)
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}"
    return ngay(s)[:7]


def _so(v):
    if v in (None, ""):
        return 0
    if isinstance(v, (int, float)):
        return v
    return float(str(v).replace(".", "").replace(",", "."))


def _mo(du_lieu):
    return load_workbook(io.BytesIO(du_lieu), data_only=True)


def doc_kho(con, cid, du_lieu):
    """Nap phieu xuat + ton dau tu mau kho. Tra ve (so dong xuat, so dong ton dau, list loi)."""
    wb = _mo(du_lieu)
    loi = []
    n_td = 0
    for i, r in enumerate(_bang(wb, "TonDau", ["Ngày", "Số lượng"]), 2):
        try:
            ma = kho.them_vat_tu(con, cid, str(_g(r, "Tên") or _g(r, "Mã") or ""), _g(r, "ĐVT"),
                                 str(_g(r, "TK kho") or "156"), _g(r, "Mã vật tư"))
            con.execute("DELETE FROM kho_dong WHERE cong_ty_id=? AND loai='D' AND ma_vt=?", (cid, ma))
            kho.them_dong(con, cid, "D", "TONDAU", ngay(_g(r, "Ngày")), ma, _so(_g(r, "Số lượng")),
                          int(_so(_g(r, "Giá trị"))), dien_giai="Tồn đầu kỳ")
            n_td += 1
        except Exception as ex:
            loi.append(f"TonDau dòng {i}: {ex}")
    n_x = 0
    tu_dong = 0
    for i, r in enumerate(_bang(wb, "PhieuXuat", ["Ngày", "Số lượng"]), 2):
        try:
            vt = kho.tim_vat_tu(con, cid, _g(r, "Mã"), _g(r, "Tên"))
            if not vt:
                raise ValueError(f"không tìm thấy vật tư '{_g(r, 'Tên') or _g(r, 'Mã')}' trong danh mục")
            sl = _so(_g(r, "Số lượng"))
            if sl <= 0:
                raise ValueError("số lượng phải lớn hơn 0")
            so_phieu = str(_g(r, "Số phiếu") or "").strip()
            if not so_phieu:
                tu_dong += 1
                so_phieu = f"PX-{ngay(_g(r, 'Ngày'))}-{tu_dong}"
            tk = str(_g(r, "TK Nợ") or "154").strip()
            if not con.execute("SELECT 1 FROM tai_khoan WHERE cong_ty_id=? AND so_tk=?", (cid, tk)).fetchone():
                raise ValueError(f"TK {tk} chưa có trong danh mục")
            kho.them_dong(con, cid, "X", so_phieu, ngay(_g(r, "Ngày")), vt["ma"], sl, None, tk,
                          _g(r, "Xuất cho"), _g(r, "Diễn giải"))
            n_x += 1
        except Exception as ex:
            loi.append(f"PhieuXuat dòng {i}: {ex}")
    con.commit()
    return n_x, n_td, loi


def doc_ton_kho_misa(con, cid, du_lieu, ngay_ton):
    """Lay so ton cuoi ky tu bao cao Tong hop ton kho cua MISA lam ton dau."""
    wb = _mo(du_lieu)
    n = 0
    for r in wb.active.iter_rows(values_only=True):
        v = [c for c in r if c is not None]
        if len(v) >= 11 and isinstance(v[0], str) and re.fullmatch(r"[A-Za-z]{1,4}\d+", v[0]):
            sl, gt = v[-2], v[-1]
            ma = kho.them_vat_tu(con, cid, v[1], v[2], "156", v[0])
            con.execute("DELETE FROM kho_dong WHERE cong_ty_id=? AND loai='D' AND ma_vt=?", (cid, ma))
            if sl or gt:
                kho.them_dong(con, cid, "D", "TONDAU", ngay_ton, ma, float(sl), int(gt), dien_giai="Tồn đầu (MISA)")
                n += 1
    con.commit()
    return n


def doc_luong(con, cid, du_lieu):
    """Nap nhan vien, nguoi phu thuoc, bang luong. Tra ve (dem dict, list loi)."""
    wb = _mo(du_lieu)
    loi = []
    dem = {"nhan_vien": 0, "nguoi_phu_thuoc": 0, "bang_luong": 0, "thang": set()}
    ck = lambda v, md=True: md if v in (None, "") else str(v).strip().upper().startswith("C")
    for i, r in enumerate(_bang(wb, "NhanVien", ["Mã NV", "Họ tên"]), 2):
        try:
            ma = str(_g(r, "Mã NV")).strip()
            hd = str(_g(r, "Loại HĐ") or "DH").strip().upper()
            con.execute("INSERT OR REPLACE INTO nhan_vien VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (
                cid, ma, luong.lam_sach_ten(_g(r, "Họ tên")), str(_g(r, "MST") or "").strip() or None,
                str(_g(r, "Số CCCD") or "").strip() or None, ngay(_g(r, "Ngày sinh")), _g(r, "Bộ phận"),
                int(_so(_g(r, "Lương đóng BH"))), int(ck(_g(r, "Đóng BH"))), "NH" if hd.startswith("N") else "DH",
                int(ck(_g(r, "Cư trú"))), str(_g(r, "TK chi phí") or "6422").strip()))
            dem["nhan_vien"] += 1
        except Exception as ex:
            loi.append(f"NhanVien dòng {i}: {ex}")
    for i, r in enumerate(_bang(wb, "NguoiPhuThuoc", ["Mã NV", "Họ tên"]), 2):
        try:
            mst, cccd = str(_g(r, "MST") or "").strip(), str(_g(r, "Số CCCD") or "").strip()
            if not mst and not cccd:
                loi.append(f"NguoiPhuThuoc dòng {i}: thiếu cả MST và CCCD (cơ quan thuế sẽ không chấp nhận giảm trừ).")
            con.execute(
                "INSERT INTO nguoi_phu_thuoc (cong_ty_id, ma_nv, ho_ten, ngay_sinh, mst, cccd, quan_he, tu_thang, den_thang) "
                "VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT (cong_ty_id, ma_nv, ho_ten) DO UPDATE SET ngay_sinh=excluded.ngay_sinh, "
                "mst=excluded.mst, cccd=excluded.cccd, quan_he=excluded.quan_he, tu_thang=excluded.tu_thang, den_thang=excluded.den_thang",
                (cid, str(_g(r, "Mã NV")).strip(), luong.lam_sach_ten(_g(r, "Họ tên")), ngay(_g(r, "Ngày sinh")),
                 mst or None, cccd or None, _g(r, "Quan hệ"), thang(_g(r, "Từ tháng")), thang(_g(r, "Đến tháng"))))
            dem["nguoi_phu_thuoc"] += 1
        except Exception as ex:
            loi.append(f"NguoiPhuThuoc dòng {i}: {ex}")
    for i, r in enumerate(_bang(wb, "BangLuong", ["Tháng", "Mã NV"]), 2):
        try:
            t = thang(_g(r, "Tháng"))
            con.execute("INSERT OR REPLACE INTO bang_luong VALUES (?,?,?,?,?,?,?,?,?,?,NULL)", (
                cid, t, str(_g(r, "Mã NV")).strip(), _so(_g(r, "Ngày công")), _so(_g(r, "Công chuẩn")) or 26,
                int(_so(_g(r, "Lương cơ bản"))), int(_so(_g(r, "Phụ cấp chịu"))), int(_so(_g(r, "Phụ cấp miễn"))),
                int(_so(_g(r, "Thưởng"))), int(_so(_g(r, "Khấu trừ")))))
            dem["bang_luong"] += 1
            dem["thang"].add(t)
        except Exception as ex:
            loi.append(f"BangLuong dòng {i}: {ex}")
    con.commit()
    dem["thang"] = sorted(dem["thang"])
    return dem, loi


def doc_tai_san(con, cid, du_lieu):
    """Nap tai san tu mau TaiSan, hoac tu So TSCD / So theo doi CCDC cua MISA."""
    wb = _mo(du_lieu)
    loi, n = [], 0
    ds = _bang(wb, "TaiSan", ["Loại", "Mã", "Tên"])
    if ds:
        for i, r in enumerate(ds, 2):
            try:
                loai = "CCDC" if str(_g(r, "Loại")).strip().upper().startswith("C") else "TSCD"
                tai_san.luu(con, cid, {
                    "loai": loai, "ma": str(_g(r, "Mã")).strip(), "ten": str(_g(r, "Tên")).strip(),
                    "nhom": _g(r, "Nhóm"), "bo_phan": _g(r, "Bộ phận"), "ngay_tang": ngay(_g(r, "Ngày ghi tăng")),
                    "ngay_bat_dau": ngay(_g(r, "Ngày bắt đầu")) or ngay(_g(r, "Ngày ghi tăng")),
                    "nguyen_gia": int(_so(_g(r, "Nguyên giá"))), "so_thang": int(_so(_g(r, "Số tháng"))),
                    "tk_tai_san": str(_g(r, "TK tài sản") or "").strip() or None,
                    "tk_hao_mon": str(_g(r, "TK hao mòn") or "").strip() or None,
                    "tk_chi_phi": str(_g(r, "TK chi phí") or "").strip() or None,
                    "luy_ke_dau": int(_so(_g(r, "Đã khấu hao"))), "den_thang_dau": thang(_g(r, "Tính đến")),
                })
                n += 1
            except Exception as ex:
                loi.append(f"TaiSan dòng {i}: {ex}")
        con.commit()
        return n, loi
    # File MISA: So tai san co dinh / So theo doi CCDC
    ws = wb.active
    dong = list(ws.iter_rows(values_only=True))
    nam = next((re.search(r"\d{4}", str(c)).group() for r in dong[:8] for c in r
                if c and re.fullmatch(r"(Năm:?\s*)\d{4}", str(c).strip())), None)
    den = f"{nam}-12" if nam else None
    misa = _bang(wb, ws.title, ["Mã TSCĐ", "Tên TSCĐ"])
    if misa:
        for r in misa:
            if not _g(r, "Mã TSCĐ") or not isinstance(_g(r, "Nguyên giá"), (int, float)) \
                    or str(_g(r, "Mã TSCĐ")).startswith("Tổng"):
                continue
            nhom = "Phương tiện vận tải đường bộ" if "vận tải" in str(_g(r, "Loại TSCĐ")).lower() else (
                "Máy móc, thiết bị xây dựng" if "máy" in str(_g(r, "Loại TSCĐ")).lower() else None)
            tai_san.luu(con, cid, {
                "loai": "TSCD", "ma": str(_g(r, "Mã TSCĐ")), "ten": _g(r, "Tên TSCĐ"), "nhom": nhom,
                "bo_phan": _g(r, "Đơn vị sử dụng"), "ngay_tang": ngay(_g(r, "Ngày ghi tăng")),
                "ngay_bat_dau": ngay(_g(r, "Ngày bắt đầu")), "nguyen_gia": int(_so(_g(r, "Nguyên giá"))),
                "so_thang": int(_so(_g(r, "Thời gian SD (tháng)"))), "tk_tai_san": str(_g(r, "TK nguyên giá")),
                "tk_hao_mon": str(_g(r, "TK khấu hao") or "2141"),
                "tk_chi_phi": "6421" if "bán hàng" in str(_g(r, "Đơn vị sử dụng")).lower() else "6422",
                "luy_ke_dau": int(_so(_g(r, "Hao mòn lũy kế"))), "den_thang_dau": den,
            })
            n += 1
    misa = _bang(wb, ws.title, ["Mã CCDC", "Tên CCDC"])
    for r in misa:
        if not _g(r, "Mã CCDC") or not isinstance(_g(r, "Giá trị CCDC"), (int, float)) \
                or str(_g(r, "Mã CCDC")).startswith("Tổng"):
            continue
        tai_san.luu(con, cid, {
            "loai": "CCDC", "ma": str(_g(r, "Mã CCDC")), "ten": _g(r, "Tên CCDC"), "nhom": _g(r, "Loại CCDC"),
            "ngay_tang": ngay(_g(r, "Ngày ghi tăng")), "nguyen_gia": int(_so(_g(r, "Giá trị CCDC"))),
            "so_thang": int(_so(_g(r, "Số kỳ phân bổ"))), "tk_tai_san": str(_g(r, "TK chờ phân bổ") or "242"),
            "tk_hao_mon": str(_g(r, "TK chờ phân bổ") or "242"), "tk_chi_phi": str(_g(r, "Tài khoản chi phí") or "6422"),
            "luy_ke_dau": int(_so(_g(r, "Lũy kế đã PB"))), "den_thang_dau": den,
        })
        n += 1
    if not n:
        loi.append("Không nhận ra file: dùng mẫu tài sản của ứng dụng, hoặc Sổ TSCĐ / Sổ theo dõi CCDC xuất từ MISA.")
    con.commit()
    return n, loi
