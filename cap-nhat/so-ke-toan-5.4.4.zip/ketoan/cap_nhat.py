"""Cap nhat phien ban qua mang.

Nha phat hanh dat file phien-ban.json va goi cap nhat (zip) tren kho GitHub cong khai. Ung dung:
1. Tai phien-ban.json, kiem chu ky RSA cua nha phat hanh (cung khoa cong khai voi key ban quyen).
2. Neu co ban moi hon: tai goi zip, kiem SHA-256 khop voi ban ke khai da ky.
3. Sao luu du lieu va ma cu, thay thu muc ketoan va cac file chay, roi khoi dong lai.
Du lieu (du_lieu), key ban quyen, thu muc python khong bi dung toi.
"""
import base64
import hashlib
import io
import json
import os
import shutil
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

from . import PHIEN_BAN, ban_quyen

KHO = os.environ.get("KETOAN_KHO_CAP_NHAT") or "https://raw.githubusercontent.com/Dangnguyen3368/so-ke-toan-ban-cai/main/"
URL_KE_KHAI = KHO + "phien-ban.json"
GOC = Path(__file__).resolve().parent.parent
# Chi cho phep goi cap nhat ghi cac muc nay (khong bao gio ghi du_lieu, python)
DUOC_GHI = ("ketoan/",)
TEP_GOC_DUOC_GHI = {"chay.bat", "chay_an.vbs", "tat_so_ke_toan.vbs", "tao_loi_tat.vbs", "cai_dat.bat", "so_ke_toan.ico",
                    "requirements.txt", "HUONG_DAN.md", "DOC_TRUOC.txt"}

TRANG_THAI = {"luc": 0, "ban_moi": None, "loi": ""}
_KHOA = threading.Lock()


def so_phien_ban(s):
    return tuple(int(x) for x in str(s).split(".") if x.isdigit())


def thong_diep_ky(kk):
    """Noi dung duoc ky trong ban ke khai."""
    return f"so-ke-toan|{kk['phien_ban']}|{kk['tep']}|{kk['sha256']}|{kk.get('kich_thuoc', 0)}".encode()


def kiem_ke_khai(kk, n=None):
    """Kiem chu ky cua ban ke khai. Raise ValueError neu sai."""
    for k in ("phien_ban", "tep", "sha256", "chu_ky"):
        if not kk.get(k):
            raise ValueError(f"Bản kê khai cập nhật thiếu mục {k}.")
    if ".." in kk["tep"] or kk["tep"].startswith(("/", "\\")) or "://" in kk["tep"]:
        raise ValueError("Đường dẫn gói cập nhật không hợp lệ.")
    ck = base64.urlsafe_b64decode(kk["chu_ky"] + "=" * (-len(kk["chu_ky"]) % 4))
    if not ban_quyen.kiem_chu_ky(thong_diep_ky(kk), ck, n):
        raise ValueError("Chữ ký bản cập nhật không đúng. Không cài để đảm bảo an toàn.")
    return kk


def _tai(url, gioi_han=60 * 1024 * 1024, cho=20):
    req = urllib.request.Request(url, headers={"User-Agent": f"SoKeToan/{PHIEN_BAN}", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=cho) as r:
        b = r.read(gioi_han + 1)
    if len(b) > gioi_han:
        raise ValueError("File tải về quá lớn.")
    return b


def kiem_tra(url=URL_KE_KHAI, n=None):
    """Tai va kiem ban ke khai. Tra ve dict ban moi (neu moi hon ban dang chay) hoac None."""
    with _KHOA:
        try:
            kk = kiem_ke_khai(json.loads(_tai(url, 256 * 1024, 10).decode("utf-8")), n)
            moi = kk if so_phien_ban(kk["phien_ban"]) > so_phien_ban(PHIEN_BAN) else None
            TRANG_THAI.update(luc=time.time(), ban_moi=moi, loi="", moi_nhat=kk["phien_ban"])
            return moi
        except Exception as ex:  # mang loi, chua co kho... khong lam phien nguoi dung
            TRANG_THAI.update(luc=time.time(), loi=str(ex))
            return None


def kiem_tra_dinh_ky(khoang=12 * 3600):
    """Chay nen: kiem tra luc mo ung dung va moi 12 gio."""
    def chay():
        time.sleep(5)
        while True:
            kiem_tra()
            time.sleep(khoang)
    threading.Thread(target=chay, daemon=True).start()


def kiem_goi(du_lieu, kk):
    """Kiem SHA-256, kich thuoc va noi dung goi zip. Tra ve ZipFile."""
    if hashlib.sha256(du_lieu).hexdigest() != kk["sha256"].lower():
        raise ValueError("Gói cập nhật tải về không khớp mã kiểm tra (SHA-256). Có thể tải lỗi, thử lại sau.")
    if kk.get("kich_thuoc") and len(du_lieu) != int(kk["kich_thuoc"]):
        raise ValueError("Gói cập nhật tải về sai kích thước.")
    z = zipfile.ZipFile(io.BytesIO(du_lieu))
    ten = [i.filename for i in z.infolist() if not i.is_dir()]
    if not any(t == "ketoan/__init__.py" for t in ten):
        raise ValueError("Gói cập nhật không có thư mục ketoan.")
    for t in ten:
        if ".." in t.split("/") or t.startswith("/") or ":" in t or "\\" in t:
            raise ValueError(f"Gói cập nhật có đường dẫn không hợp lệ: {t}")
        if not (t.startswith(DUOC_GHI) or t in TEP_GOC_DUOC_GHI):
            raise ValueError(f"Gói cập nhật có file không được phép: {t}")
    return z


def ap_dung(z, goc=GOC, sao_luu=None):
    """Thay ma bang noi dung goi. Sao luu ma cu vao du_lieu/ma_cu/<phien ban>. Loi giua chung thi tra lai ma cu."""
    goc = Path(goc)
    from .giao_dien import THU_MUC_DL
    if sao_luu:
        sao_luu()
    cu = THU_MUC_DL / "ma_cu" / f"{PHIEN_BAN}-{time.strftime('%Y%m%d-%H%M%S')}"
    cu.mkdir(parents=True, exist_ok=True)
    shutil.copytree(goc / "ketoan", cu / "ketoan", ignore=shutil.ignore_patterns("__pycache__"))
    for t in TEP_GOC_DUOC_GHI:
        if (goc / t).exists():
            shutil.copy2(goc / t, cu / t)
    tam = goc / "_cap_nhat_moi"
    shutil.rmtree(tam, ignore_errors=True)
    z.extractall(tam)
    doi = goc / "_ketoan_cu"
    shutil.rmtree(doi, ignore_errors=True)
    try:
        (goc / "ketoan").rename(doi)
        (tam / "ketoan").rename(goc / "ketoan")
        for t in TEP_GOC_DUOC_GHI:
            if (tam / t).exists():
                shutil.copy2(tam / t, goc / t)
    except Exception:
        if doi.exists() and not (goc / "ketoan").exists():
            doi.rename(goc / "ketoan")
        raise
    shutil.rmtree(doi, ignore_errors=True)
    shutil.rmtree(tam, ignore_errors=True)
    return cu


def tai_va_cai(kk, goc=GOC, sao_luu=None, kho=KHO):
    du_lieu = _tai(kho + kk["tep"])
    return ap_dung(kiem_goi(du_lieu, kk), goc, sao_luu)
