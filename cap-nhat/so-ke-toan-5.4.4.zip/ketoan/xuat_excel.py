"""Xuat so sach ra Excel theo mau TT133 (S03a-DNN, S03b-DNN, bang can doi tai khoan)."""
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, Side
from openpyxl.utils import get_column_letter

from . import so_sach

_MONG = Side(style="thin")
_KHUNG = Border(left=_MONG, right=_MONG, top=_MONG, bottom=_MONG)
_DAM = Font(bold=True)
_SO = "#,##0;(#,##0);"


def _d(s):
    return datetime.strptime(s, "%Y-%m-%d").strftime("%d/%m/%Y") if s else ""


def _cong_ty(con, cid):
    return con.execute("SELECT * FROM cong_ty WHERE id=?", (cid,)).fetchone()


def _dau_trang(ws, ct, mau, tieu_de, ky, so_cot):
    ws.append([ct["ten"]] + [None] * (so_cot - 2) + [f"Mẫu số: {mau}"] if mau else [ct["ten"]])
    ws.append([ct["dia_chi"] or ""])
    ws.append([f"MST: {ct['mst']}"] + [None] * (so_cot - 2) +
              ["(Ban hành theo Thông tư số 133/2016/TT-BTC)"] if mau else [f"MST: {ct['mst']}"])
    ws.append([])
    ws.append([tieu_de])
    ws.cell(ws.max_row, 1).font = Font(bold=True, size=14)
    ws.merge_cells(start_row=ws.max_row, start_column=1, end_row=ws.max_row, end_column=so_cot)
    ws.cell(ws.max_row, 1).alignment = Alignment(horizontal="center")
    ws.append([ky])
    ws.merge_cells(start_row=ws.max_row, start_column=1, end_row=ws.max_row, end_column=so_cot)
    ws.cell(ws.max_row, 1).alignment = Alignment(horizontal="center")
    ws.append([])


def _tieu_de_cot(ws, cot, rong):
    ws.append(cot)
    for i, w in enumerate(rong, 1):
        c = ws.cell(ws.max_row, i)
        c.font, c.border = _DAM, _KHUNG
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = w


def _dong(ws, gia_tri, cot_so=(), dam=False):
    ws.append(gia_tri)
    for i in range(1, len(gia_tri) + 1):
        c = ws.cell(ws.max_row, i)
        c.border = _KHUNG
        if i in cot_so:
            c.number_format = _SO
        if dam:
            c.font = _DAM


def _ky(tu, den):
    return f"Từ ngày {_d(tu)} đến ngày {_d(den)}"


def can_doi_tai_khoan(con, cid, tu, den, duong_dan):
    ct = _cong_ty(con, cid)
    wb = Workbook()
    ws = wb.active
    ws.title = "CDTK"
    _dau_trang(ws, ct, None, "BẢNG CÂN ĐỐI TÀI KHOẢN", _ky(tu, den), 8)
    _tieu_de_cot(ws, ["Số hiệu TK", "Tên tài khoản", "Dư Nợ đầu kỳ", "Dư Có đầu kỳ",
                      "Phát sinh Nợ", "Phát sinh Có", "Dư Nợ cuối kỳ", "Dư Có cuối kỳ"],
                 [10, 45, 17, 17, 17, 17, 17, 17])
    ds = so_sach.tong_hop_tai_khoan(con, cid, tu, den)
    tong = [0] * 6
    k = ["dau_no", "dau_co", "ps_no", "ps_co", "cuoi_no", "cuoi_co"]
    for r in ds:
        cap1 = r["cap"] == 1
        _dong(ws, [r["so_tk"], r["ten"]] + [r[x] for x in k], range(3, 9), dam=cap1)
        if cap1:
            tong = [a + r[x] for a, x in zip(tong, k)]
    _dong(ws, ["", "Tổng cộng"] + tong, range(3, 9), dam=True)
    ws.freeze_panes = "C9"
    wb.save(duong_dan)
    return ds


def so_nhat_ky_chung(con, cid, tu, den, duong_dan):
    ct = _cong_ty(con, cid)
    wb = Workbook()
    ws = wb.active
    ws.title = "S03a-DNN"
    _dau_trang(ws, ct, "S03a-DNN", "SỔ NHẬT KÝ CHUNG", _ky(tu, den), 8)
    _tieu_de_cot(ws, ["Ngày hạch toán", "Ngày chứng từ", "Số chứng từ", "Diễn giải",
                      "Tài khoản", "TK đối ứng", "Phát sinh Nợ", "Phát sinh Có"],
                 [12, 12, 13, 50, 10, 10, 17, 17])
    tn = tc = 0
    for r in so_sach.so_nhat_ky_chung(con, cid, tu, den):
        a = [_d(r["ngay_ht"]), _d(r["ngay_ct"]), r["so_ct"], r["dien_giai"]]
        _dong(ws, a + [r["tk_no"], r["tk_co"], r["so_tien"], 0], (7, 8))
        _dong(ws, a + [r["tk_co"], r["tk_no"], 0, r["so_tien"]], (7, 8))
        tn += r["so_tien"]
        tc += r["so_tien"]
    _dong(ws, ["", "", "", "Cộng", "", "", tn, tc], (7, 8), dam=True)
    ws.freeze_panes = "A9"
    wb.save(duong_dan)


def so_cai(con, cid, tu, den, duong_dan, chi_cap_1=False):
    """So cai S03b-DNN, moi tai khoan mot phan lien tiep tren cung mot sheet."""
    ct = _cong_ty(con, cid)
    wb = Workbook()
    ws = wb.active
    ws.title = "S03b-DNN"
    _dau_trang(ws, ct, "S03b-DNN", "SỔ CÁI", _ky(tu, den), 7)
    rong = [12, 13, 12, 50, 10, 17, 17]
    for r in so_sach.tong_hop_tai_khoan(con, cid, tu, den):
        if chi_cap_1 and r["cap"] != 1:
            continue
        ws.append([f"Tài khoản: {r['so_tk']} - {r['ten']}"])
        ws.cell(ws.max_row, 1).font = _DAM
        _tieu_de_cot(ws, ["Ngày ghi sổ", "Số chứng từ", "Ngày chứng từ", "Diễn giải",
                          "TK đối ứng", "Nợ", "Có"], rong)
        _dong(ws, ["", "", "", "- Số dư đầu kỳ", "", r["dau_no"], r["dau_co"]], (6, 7), dam=True)
        for d in so_sach.so_cai(con, cid, r["so_tk"], tu, den):
            _dong(ws, [_d(d["ngay_ht"]), d["so_ct"], _d(d["ngay_ct"]), d["dien_giai"],
                       d["tk_du"], d["no"], d["co"]], (6, 7))
        _dong(ws, ["", "", "", "- Cộng số phát sinh", "", r["ps_no"], r["ps_co"]], (6, 7), dam=True)
        _dong(ws, ["", "", "", "- Số dư cuối kỳ", "", r["cuoi_no"], r["cuoi_co"]], (6, 7), dam=True)
        ws.append([])
    wb.save(duong_dan)
