"""Kho vat tu, hang hoa: phieu nhap, phieu xuat, gia xuat binh quan cuoi thang.

- Phieu nhap tao tu dong tu chi tiet hang hoa trong XML hoa don mua vao
  (khi ghi so hoa don vao TK 152/153/156). Gia tri da nam trong chung tu
  hoa don nen phieu nhap khong ghi so them.
- Phieu xuat nhap tu file Excel mau (hoac tu hoa don ban hang hoa).
- Cuoi thang bam "Tinh gia xuat": gia binh quan ca thang cho tung mat hang,
  roi ghi mot chung tu Nợ TK doi ung / Có TK kho.
"""
import calendar
import json
import re
import unicodedata
from datetime import date

from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS vat_tu (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    ma TEXT NOT NULL,
    ten TEXT NOT NULL,
    dvt TEXT,
    tk_kho TEXT NOT NULL DEFAULT '156',
    ten_chuan TEXT NOT NULL,             -- ten viet thuong bo dau de doi chieu
    PRIMARY KEY (cong_ty_id, ma)
);
CREATE TABLE IF NOT EXISTS kho_dong (
    id INTEGER PRIMARY KEY,
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    loai TEXT NOT NULL,                  -- 'D' ton dau, 'N' nhap, 'X' xuat
    so_phieu TEXT NOT NULL,
    ngay TEXT NOT NULL,
    ma_vt TEXT NOT NULL,
    so_luong REAL NOT NULL,
    thanh_tien INTEGER,                  -- phieu xuat: NULL cho den khi tinh gia
    tk_doi_ung TEXT,                     -- phieu xuat: 154, 632, 621, 6422...
    doi_tuong TEXT,                      -- cong trinh / khach hang
    dien_giai TEXT,
    hoa_don_id INTEGER,
    chung_tu_id INTEGER REFERENCES chung_tu(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS ix_kho ON kho_dong(cong_ty_id, ma_vt, ngay);
"""


def chuan_bi(con):
    con.executescript(SCHEMA)


def ten_chuan(s):
    s = unicodedata.normalize("NFD", str(s or "").lower().replace("đ", "d"))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", s)).strip()


def tim_vat_tu(con, cid, ma=None, ten=None):
    if ma:
        r = con.execute("SELECT * FROM vat_tu WHERE cong_ty_id=? AND ma=?", (cid, str(ma).strip())).fetchone()
        if r:
            return r
    if ten:
        return con.execute("SELECT * FROM vat_tu WHERE cong_ty_id=? AND ten_chuan=?", (cid, ten_chuan(ten))).fetchone()
    return None


def them_vat_tu(con, cid, ten, dvt=None, tk_kho="156", ma=None):
    r = tim_vat_tu(con, cid, ma, ten)
    if r:
        return r["ma"]
    if not ma:
        n = con.execute("SELECT COUNT(*) n FROM vat_tu WHERE cong_ty_id=?", (cid,)).fetchone()["n"]
        ma = f"VT{n + 1:04d}"
        while con.execute("SELECT 1 FROM vat_tu WHERE cong_ty_id=? AND ma=?", (cid, ma)).fetchone():
            n += 1
            ma = f"VT{n + 1:04d}"
    con.execute("INSERT INTO vat_tu VALUES (?,?,?,?,?,?)", (cid, str(ma).strip(), ten.strip(), dvt, tk_kho, ten_chuan(ten)))
    return ma


def nhap_tu_hoa_don(con, cid, h, tk_kho, chung_tu_id):
    """Tao dong nhap kho tu chi tiet hang hoa cua hoa don mua vao. Tra ve so dong."""
    dong = [d for d in json.loads(h["dong_hang"] or "[]") if d.get("tinh_chat") in ("1", "", None)
            and d.get("so_luong")]
    so_phieu = f"NK-{h['khhdon']}-{h['shdon']}"
    con.execute("DELETE FROM kho_dong WHERE cong_ty_id=? AND so_phieu=?", (cid, so_phieu))
    for d in dong:
        ma = them_vat_tu(con, cid, d["ten"], d.get("dvt"), tk_kho, None)
        con.execute(
            "INSERT INTO kho_dong (cong_ty_id, loai, so_phieu, ngay, ma_vt, so_luong, thanh_tien, dien_giai, "
            "hoa_don_id, chung_tu_id) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (cid, "N", so_phieu, h["ngay_lap"], ma, d["so_luong"], d["thanh_tien"],
             f"Nhập theo HĐ {h['khhdon']}-{h['shdon']} {h['nb_ten'] or ''}", h["id"], chung_tu_id))
    return len(dong)


def xuat_tu_hoa_don_ban(con, cid, h):
    """Tao dong xuat kho (gia von 632) cho hang hoa ban ra co trong danh muc. Tra ve so dong."""
    so_phieu = f"XK-{h['khhdon']}-{h['shdon']}"
    con.execute("DELETE FROM kho_dong WHERE cong_ty_id=? AND so_phieu=?", (cid, so_phieu))
    n = 0
    for d in json.loads(h["dong_hang"] or "[]"):
        vt = tim_vat_tu(con, cid, d.get("ma"), d.get("ten"))
        if vt and d.get("so_luong") and d.get("tinh_chat") in ("1", "", None):
            con.execute(
                "INSERT INTO kho_dong (cong_ty_id, loai, so_phieu, ngay, ma_vt, so_luong, tk_doi_ung, doi_tuong, "
                "dien_giai, hoa_don_id) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (cid, "X", so_phieu, h["ngay_lap"], vt["ma"], d["so_luong"], "632", h["nm_ten"],
                 f"Xuất bán theo HĐ {h['khhdon']}-{h['shdon']}", h["id"]))
            n += 1
    return n


def them_dong(con, cid, loai, so_phieu, ngay, ma_vt, so_luong, thanh_tien=None, tk_doi_ung=None,
              doi_tuong=None, dien_giai=None):
    con.execute(
        "INSERT INTO kho_dong (cong_ty_id, loai, so_phieu, ngay, ma_vt, so_luong, thanh_tien, tk_doi_ung, "
        "doi_tuong, dien_giai) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (cid, loai, so_phieu, ngay, ma_vt, so_luong, thanh_tien, tk_doi_ung, doi_tuong, dien_giai))


def _ton(con, cid, truoc_ngay):
    """Ton kho (so luong, gia tri) tung mat hang truoc ngay `truoc_ngay`."""
    ton = {}
    for r in con.execute("SELECT ma_vt, loai, SUM(so_luong) sl, SUM(COALESCE(thanh_tien,0)) gt FROM kho_dong "
                         "WHERE cong_ty_id=? AND (ngay<? OR (loai='D' AND ngay=?)) GROUP BY ma_vt, loai",
                         (cid, truoc_ngay, truoc_ngay)):
        t = ton.setdefault(r["ma_vt"], [0.0, 0])
        dau = -1 if r["loai"] == "X" else 1
        t[0] += dau * r["sl"]
        t[1] += dau * r["gt"]
    return ton


def tinh_gia_xuat(con, cid, thang):
    """Tinh gia xuat binh quan thang va ghi so. Tra ve (chung_tu_id, list canh bao)."""
    y, m = int(thang[:4]), int(thang[5:])
    tu = f"{thang}-01"
    den = date(y, m, calendar.monthrange(y, m)[1]).isoformat()
    ton = _ton(con, cid, tu)
    canh_bao = []
    so_ct = f"XK-{thang.replace('-', '')}"
    cu = con.execute("SELECT id FROM chung_tu WHERE cong_ty_id=? AND so_ct=?", (cid, so_ct)).fetchone()
    if cu:
        con.execute("DELETE FROM chung_tu WHERE id=?", (cu["id"],))

    tong = {}  # (tk_no, tk_co) -> tien
    vts = {r["ma"]: r for r in con.execute("SELECT * FROM vat_tu WHERE cong_ty_id=?", (cid,))}
    for ma in {r["ma_vt"] for r in con.execute(
            "SELECT DISTINCT ma_vt FROM kho_dong WHERE cong_ty_id=? AND loai='X' AND ngay BETWEEN ? AND ?",
            (cid, tu, den))}:
        sl0, gt0 = ton.get(ma, [0.0, 0])
        n = con.execute("SELECT COALESCE(SUM(so_luong),0) sl, COALESCE(SUM(thanh_tien),0) gt FROM kho_dong "
                        "WHERE cong_ty_id=? AND ma_vt=? AND (loai='N' OR (loai='D' AND ngay>?)) AND ngay BETWEEN ? AND ?",
                        (cid, ma, tu, tu, den)).fetchone()
        sl, gt = sl0 + n["sl"], gt0 + n["gt"]
        xs = con.execute("SELECT id, so_luong, tk_doi_ung, doi_tuong FROM kho_dong WHERE cong_ty_id=? AND ma_vt=? AND loai='X' "
                         "AND ngay BETWEEN ? AND ? ORDER BY ngay, id", (cid, ma, tu, den)).fetchall()
        sl_x = sum(x["so_luong"] for x in xs)
        if sl <= 0:
            canh_bao.append(f"{ma} {vts[ma]['ten'] if ma in vts else ''}: xuất {sl_x:g} nhưng không có tồn.")
            continue
        if sl_x > sl + 1e-9:
            canh_bao.append(f"{ma} {vts[ma]['ten'] if ma in vts else ''}: xuất {sl_x:g} vượt tồn {sl:g} (tồn âm).")
        gia = gt / sl
        con_lai = gt
        for i, x in enumerate(xs):
            tien = round(x["so_luong"] * gia)
            if abs(sl_x - sl) < 1e-9 and i == len(xs) - 1:
                tien = con_lai           # xuat het: lay tron gia tri con lai
            con_lai -= tien
            con.execute("UPDATE kho_dong SET thanh_tien=? WHERE id=?", (tien, x["id"]))
            tk_no = x["tk_doi_ung"] or "632"
            # Xuat cho cong trinh / san pham (154, 621...): giu ma doi tuong de tinh gia thanh
            dt = (x["doi_tuong"] or "").strip() if tk_no.startswith(("154", "621", "623", "627")) else ""
            k = (tk_no, vts[ma]["tk_kho"] if ma in vts else "156", dt)
            tong[k] = tong.get(k, 0) + tien

    ct = None
    dong = [{"tk_no": a, "tk_co": b, "so_tien": t, "doi_tuong_no": dt,
             "dien_giai": f"Xuất kho tháng {m:02d}/{y}" + (f" cho {dt}" if dt else "") if a[:3] != "632" else f"Giá vốn xuất kho tháng {m:02d}/{y}"}
            for (a, b, dt), t in sorted(tong.items()) if t > 0]
    if dong:
        for d in dong:
            db.them_tai_khoan(con, cid, d["tk_no"], f"TK {d['tk_no']}")
        ct = db.ghi_chung_tu(con, cid, so_ct, den, den, dong, loai="XK",
                             dien_giai=f"Xuất kho tháng {m:02d}/{y}", nguon="kho")
        con.execute("UPDATE kho_dong SET chung_tu_id=? WHERE cong_ty_id=? AND loai='X' AND ngay BETWEEN ? AND ?",
                    (ct, cid, tu, den))
    con.commit()
    return ct, canh_bao


def tong_hop_ton(con, cid, tu, den):
    """Bang tong hop nhap xuat ton: list dict ma, ten, dvt, dau_sl, dau_gt, nhap_sl, nhap_gt, xuat_sl, xuat_gt, cuoi_sl, cuoi_gt."""
    dau = _ton(con, cid, tu)
    ps = {}
    for r in con.execute("SELECT ma_vt, loai, SUM(so_luong) sl, SUM(COALESCE(thanh_tien,0)) gt FROM kho_dong "
                         "WHERE cong_ty_id=? AND ngay BETWEEN ? AND ? AND NOT (loai='D' AND ngay=?) "
                         "GROUP BY ma_vt, loai", (cid, tu, den, tu)):
        p = ps.setdefault(r["ma_vt"], {"N": [0, 0], "X": [0, 0]})
        k = "X" if r["loai"] == "X" else "N"
        p[k][0] += r["sl"]
        p[k][1] += r["gt"]
    kq = []
    for v in con.execute("SELECT * FROM vat_tu WHERE cong_ty_id=? ORDER BY ma", (cid,)):
        d = dau.get(v["ma"], [0, 0])
        p = ps.get(v["ma"], {"N": [0, 0], "X": [0, 0]})
        if not any(d) and not any(p["N"]) and not any(p["X"]):
            continue
        kq.append({"ma": v["ma"], "ten": v["ten"], "dvt": v["dvt"], "dau_sl": d[0], "dau_gt": d[1],
                   "nhap_sl": p["N"][0], "nhap_gt": p["N"][1], "xuat_sl": p["X"][0], "xuat_gt": p["X"][1],
                   "cuoi_sl": d[0] + p["N"][0] - p["X"][0], "cuoi_gt": d[1] + p["N"][1] - p["X"][1]})
    return kq
