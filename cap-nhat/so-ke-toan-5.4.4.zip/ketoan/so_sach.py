"""Tinh so lieu so sach: so du, phat sinh, so cai, so Nhat ky chung."""


def _ngay_so_du(con, cid, tu):
    r = con.execute(
        "SELECT MAX(ngay) AS n FROM so_du_dau_ky WHERE cong_ty_id=? AND ngay<=?", (cid, tu)
    ).fetchone()
    return r["n"] if r and r["n"] else "0000-00-00"


def _tach(so):
    return (so, 0) if so >= 0 else (0, -so)


def tong_hop_tai_khoan(con, cid, tu, den):
    """Bang can doi tai khoan tu ngay `tu` den ngay `den` (YYYY-MM-DD).

    Tra ve list dict theo thu tu so tai khoan: so_tk, ten, cap, dau_no, dau_co,
    ps_no, ps_co, cuoi_no, cuoi_co. Tai khoan tong hop = cong cac tai khoan con.
    """
    ngay_sd = _ngay_so_du(con, cid, tu)
    tks = con.execute(
        "SELECT so_tk, ten, tk_cha, tinh_chat FROM tai_khoan WHERE cong_ty_id=? ORDER BY so_tk",
        (cid,),
    ).fetchall()

    sd = {}  # so_tk -> so du No tru Co tai ngay_sd
    for r in con.execute(
        "SELECT so_tk, SUM(du_no - du_co) AS s FROM so_du_dau_ky WHERE cong_ty_id=? AND ngay=? "
        "GROUP BY so_tk", (cid, ngay_sd)):
        sd[r["so_tk"]] = r["s"]

    def ps(tu_ngay, den_ngay, loai_den="<="):
        no, co = {}, {}
        q = ("SELECT b.tk_no, b.tk_co, b.so_tien FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id "
             f"WHERE c.cong_ty_id=? AND c.ngay_ht>=? AND c.ngay_ht{loai_den}?")
        for r in con.execute(q, (cid, tu_ngay, den_ngay)):
            no[r["tk_no"]] = no.get(r["tk_no"], 0) + r["so_tien"]
            co[r["tk_co"]] = co.get(r["tk_co"], 0) + r["so_tien"]
        return no, co

    # Phat sinh tu ngay so du den truoc ky -> cong vao so du dau ky
    no0, co0 = ps(ngay_sd, tu, "<")
    no1, co1 = ps(tu, den)

    def cong(d, tk):
        return sum(v for k, v in d.items() if k.startswith(tk))

    kq = []
    for t in tks:
        tk = t["so_tk"]
        dau = cong(sd, tk) + cong(no0, tk) - cong(co0, tk)
        pn, pc = cong(no1, tk), cong(co1, tk)
        cuoi = dau + pn - pc
        if not (dau or pn or pc):
            continue
        dn, dc = _tach(dau)
        cn, cc = _tach(cuoi)
        kq.append({
            "so_tk": tk, "ten": t["ten"], "cap": len(tk) - 2, "tk_cha": t["tk_cha"],
            "dau_no": dn, "dau_co": dc, "ps_no": pn, "ps_co": pc, "cuoi_no": cn, "cuoi_co": cc,
        })
    return kq


def so_nhat_ky_chung(con, cid, tu, den):
    """Cac dong so NKC (moi dinh khoan hai dong: No roi Co), theo ngay hach toan."""
    q = ("SELECT c.ngay_ht, c.ngay_ct, c.so_ct, b.dien_giai, b.tk_no, b.tk_co, b.so_tien "
         "FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id "
         "WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ? ORDER BY c.ngay_ht, c.so_ct, b.stt")
    for r in con.execute(q, (cid, tu, den)):
        yield dict(r)


def so_cai(con, cid, so_tk, tu, den):
    """Cac dong so cai cua mot tai khoan (gom ca tai khoan con)."""
    q = ("SELECT c.ngay_ht, c.ngay_ct, c.so_ct, b.dien_giai, b.tk_no, b.tk_co, b.so_tien "
         "FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id "
         "WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ? "
         "AND (b.tk_no LIKE ? OR b.tk_co LIKE ?) ORDER BY c.ngay_ht, c.so_ct, b.stt")
    for r in con.execute(q, (cid, tu, den, so_tk + "%", so_tk + "%")):
        r = dict(r)
        ben_no = r["tk_no"].startswith(so_tk)
        ben_co = r["tk_co"].startswith(so_tk)
        if ben_no:
            yield {**r, "tk_du": r["tk_co"], "no": r["so_tien"], "co": 0}
        if ben_co:
            yield {**r, "tk_du": r["tk_no"], "no": 0, "co": r["so_tien"]}
