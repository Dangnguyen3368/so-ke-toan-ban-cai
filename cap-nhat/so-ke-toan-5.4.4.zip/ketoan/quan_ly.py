"""Cac chuc nang quan ly so: cong no chi tiet, tuoi no, khoa so, lich su sua, doi chieu so cai voi
so chi tiet, viec can lam, luu chuyen tien te, so tien bang chu."""
import calendar
import json
from datetime import date, datetime, timedelta

from . import bao_cao

SCHEMA = """
CREATE TABLE IF NOT EXISTS khoa_so (
    cong_ty_id INTEGER PRIMARY KEY REFERENCES cong_ty(id),
    den_ngay TEXT NOT NULL,              -- khong them/sua/xoa chung tu co ngay_ht <= den_ngay
    nguoi TEXT, luc TEXT
);
CREATE TABLE IF NOT EXISTS nhat_ky_sua (
    id INTEGER PRIMARY KEY,
    cong_ty_id INTEGER NOT NULL,
    luc TEXT NOT NULL,
    nguoi TEXT,
    hanh_dong TEXT NOT NULL,             -- 'sua', 'xoa', 'khoa', 'mo_khoa', 'khoi_phuc'...
    so_ct TEXT,
    noi_dung TEXT                        -- JSON du lieu cu
);
CREATE TRIGGER IF NOT EXISTS khoa_them BEFORE INSERT ON chung_tu
WHEN NEW.ngay_ht <= COALESCE((SELECT den_ngay FROM khoa_so WHERE cong_ty_id = NEW.cong_ty_id), '')
BEGIN SELECT RAISE(ABORT, 'Kỳ này đã khóa sổ, không thêm chứng từ được. Mở khóa ở trang Khóa sổ nếu thật sự cần.'); END;
CREATE TRIGGER IF NOT EXISTS khoa_xoa BEFORE DELETE ON chung_tu
WHEN OLD.ngay_ht <= COALESCE((SELECT den_ngay FROM khoa_so WHERE cong_ty_id = OLD.cong_ty_id), '')
BEGIN SELECT RAISE(ABORT, 'Kỳ này đã khóa sổ, không xóa chứng từ được.'); END;
CREATE TRIGGER IF NOT EXISTS khoa_sua BEFORE UPDATE ON chung_tu
WHEN OLD.ngay_ht <= COALESCE((SELECT den_ngay FROM khoa_so WHERE cong_ty_id = OLD.cong_ty_id), '')
  OR NEW.ngay_ht <= COALESCE((SELECT den_ngay FROM khoa_so WHERE cong_ty_id = NEW.cong_ty_id), '')
BEGIN SELECT RAISE(ABORT, 'Kỳ này đã khóa sổ, không sửa chứng từ được.'); END;
CREATE TRIGGER IF NOT EXISTS khoa_bt_them BEFORE INSERT ON but_toan
WHEN (SELECT c.ngay_ht FROM chung_tu c WHERE c.id = NEW.chung_tu_id) <=
     COALESCE((SELECT k.den_ngay FROM khoa_so k JOIN chung_tu c ON c.cong_ty_id = k.cong_ty_id WHERE c.id = NEW.chung_tu_id), '')
BEGIN SELECT RAISE(ABORT, 'Kỳ này đã khóa sổ.'); END;
CREATE TRIGGER IF NOT EXISTS khoa_bt_xoa BEFORE DELETE ON but_toan
WHEN (SELECT c.ngay_ht FROM chung_tu c WHERE c.id = OLD.chung_tu_id) <=
     COALESCE((SELECT k.den_ngay FROM khoa_so k JOIN chung_tu c ON c.cong_ty_id = k.cong_ty_id WHERE c.id = OLD.chung_tu_id), '')
BEGIN SELECT RAISE(ABORT, 'Kỳ này đã khóa sổ.'); END;
"""


def chuan_bi(con):
    bao_cao.chuan_bi(con)
    con.executescript(SCHEMA)


def _f(v):
    return f"{v:,.0f}".replace(",", ".")


def ghi_nhat_ky(con, cid, hanh_dong, so_ct=None, noi_dung=None, nguoi=None):
    con.execute("INSERT INTO nhat_ky_sua (cong_ty_id, luc, nguoi, hanh_dong, so_ct, noi_dung) VALUES (?,?,?,?,?,?)",
                (cid, datetime.now().isoformat(timespec="seconds"), nguoi, hanh_dong, so_ct,
                 json.dumps(noi_dung, ensure_ascii=False, default=str) if noi_dung is not None else None))


# ================================================================ khoa so, sua/xoa chung tu

def ngay_khoa(con, cid):
    r = con.execute("SELECT den_ngay FROM khoa_so WHERE cong_ty_id=?", (cid,)).fetchone()
    return r["den_ngay"] if r else None


def khoa(con, cid, den_ngay, nguoi=None):
    cu = ngay_khoa(con, cid)
    if den_ngay:
        con.execute("INSERT OR REPLACE INTO khoa_so VALUES (?,?,?,?)",
                    (cid, den_ngay, nguoi, datetime.now().isoformat(timespec="seconds")))
    else:
        con.execute("DELETE FROM khoa_so WHERE cong_ty_id=?", (cid,))
    ghi_nhat_ky(con, cid, "khoa" if den_ngay else "mo_khoa", None, {"truoc": cu, "sau": den_ngay}, nguoi)
    con.commit()


def chung_tu(con, cid, ct_id):
    c = con.execute("SELECT * FROM chung_tu WHERE id=? AND cong_ty_id=?", (ct_id, cid)).fetchone()
    if not c:
        return None, []
    return c, con.execute("SELECT * FROM but_toan WHERE chung_tu_id=? ORDER BY stt", (ct_id,)).fetchall()


def _anh(c, dong):
    return {"chung_tu": dict(c), "dong": [dict(d) for d in dong]}


def xoa_chung_tu(con, cid, ct_id, nguoi=None):
    c, dong = chung_tu(con, cid, ct_id)
    if not c:
        raise ValueError("Không có chứng từ này.")
    try:
        if con.execute("SELECT 1 FROM sqlite_master WHERE name='sao_ke'").fetchone():
            con.execute("UPDATE sao_ke SET trang_thai='moi', chung_tu_id=NULL WHERE chung_tu_id=?", (ct_id,))
        con.execute("DELETE FROM chung_tu WHERE id=?", (ct_id,))
        ghi_nhat_ky(con, cid, "xoa", c["so_ct"], _anh(c, dong), nguoi)
        con.commit()
    except Exception:
        con.rollback()
        raise


def sua_chung_tu(con, cid, ct_id, dau, dong_moi, nguoi=None):
    """Sua chung tu tai cho (giu nguyen id nen lien ket hoa don, sao ke, kho, khau hao van con).

    dau: dict so_ct, ngay_ct, ngay_ht, loai, dien_giai. dong_moi: list but toan nhu db.ghi_chung_tu."""
    c, dong = chung_tu(con, cid, ct_id)
    if not c:
        raise ValueError("Không có chứng từ này.")
    if not dong_moi:
        raise ValueError("Chứng từ phải có ít nhất một dòng định khoản.")
    for d in dong_moi:
        for k in ("tk_no", "tk_co"):
            if not con.execute("SELECT 1 FROM tai_khoan WHERE cong_ty_id=? AND so_tk=?", (cid, d[k])).fetchone():
                raise ValueError(f"Tài khoản {d[k]} chưa có trong danh mục")
        if int(d["so_tien"]) <= 0:
            raise ValueError("Số tiền phải lớn hơn 0")
    anh = _anh(c, dong)
    try:
        con.execute("UPDATE chung_tu SET so_ct=?, ngay_ct=?, ngay_ht=?, loai=?, dien_giai=? WHERE id=?",
                    (dau["so_ct"], dau.get("ngay_ct") or dau["ngay_ht"], dau["ngay_ht"], dau.get("loai"),
                     dau.get("dien_giai"), ct_id))
        con.execute("DELETE FROM but_toan WHERE chung_tu_id=?", (ct_id,))
        for i, d in enumerate(dong_moi, 1):
            con.execute("INSERT INTO but_toan (chung_tu_id, stt, dien_giai, tk_no, tk_co, so_tien, doi_tuong_no, "
                        "doi_tuong_co) VALUES (?,?,?,?,?,?,?,?)",
                        (ct_id, i, d.get("dien_giai"), d["tk_no"], d["tk_co"], int(d["so_tien"]),
                         d.get("doi_tuong_no", ""), d.get("doi_tuong_co", "")))
        ghi_nhat_ky(con, cid, "sua", c["so_ct"], anh, nguoi)
        con.commit()
        return ct_id
    except Exception:
        con.rollback()
        raise


# ================================================================ cong no chi tiet, tuoi no

def ten_doi_tuong(con, cid):
    """{ma/mst: ten} tu danh muc doi tuong, hoa don, bang cong no da nap."""
    ten = {}
    if con.execute("SELECT 1 FROM sqlite_master WHERE name='doi_tuong'").fetchone():
        for r in con.execute("SELECT ma, ten FROM doi_tuong WHERE cong_ty_id=?", (cid,)):
            ten[r["ma"]] = r["ten"]
    if con.execute("SELECT 1 FROM sqlite_master WHERE name='hoa_don'").fetchone():
        for r in con.execute("SELECT nbmst m, nb_ten t FROM hoa_don WHERE cong_ty_id=? UNION "
                             "SELECT nmmst, nm_ten FROM hoa_don WHERE cong_ty_id=?", (cid, cid)):
            if r["m"]:
                ten.setdefault(r["m"], r["t"])
    for r in con.execute("SELECT ma, ten FROM cong_no_doi_tuong WHERE cong_ty_id=?", (cid,)):
        ten.setdefault(r["ma"], r["ten"])
    return ten


def _goc_doi_tuong(con, cid, tk, ngay):
    """Moc so du theo doi tuong cho TK `tk` dau ngay `ngay`: (ngay moc, {ma: No-Co}).

    Lay bang cong no nap tu MISA neu no moi hon so du dau ky (vi so MISA khong ghi doi tuong
    tren tung dinh khoan), nguoc lai lay so du dau ky."""
    ns = bao_cao._snap(con, cid, ngay)
    r = con.execute("SELECT MAX(ngay) n FROM cong_no_doi_tuong WHERE cong_ty_id=? AND so_tk LIKE ? AND ngay<=?",
                    (cid, tk + "%", ngay)).fetchone()
    if r and r["n"] and (not ns or r["n"] > ns):
        d = {}
        for x in con.execute("SELECT ma, du_no - du_co s FROM cong_no_doi_tuong WHERE cong_ty_id=? AND ngay=? AND so_tk LIKE ?",
                             (cid, r["n"], tk + "%")):
            d[x["ma"] or ""] = d.get(x["ma"] or "", 0) + x["s"]
        return r["n"], d
    d = {}
    for x in con.execute("SELECT doi_tuong, du_no - du_co s FROM so_du_dau_ky WHERE cong_ty_id=? AND ngay=? AND so_tk LIKE ?",
                         (cid, ns, tk + "%")):
        d[x["doi_tuong"] or ""] = d.get(x["doi_tuong"] or "", 0) + x["s"]
    return ns, d


def _ps_doi_tuong(con, cid, tk, tu, den_truoc):
    """Phat sinh theo doi tuong trong [tu, den_truoc): {ma: [no, co]}, kem list (ngay, ma, no, co)."""
    ps, ds = {}, []
    q = ("SELECT c.ngay_ht, b.tk_no, b.doi_tuong_no, b.tk_co, b.doi_tuong_co, b.so_tien FROM but_toan b JOIN chung_tu c "
         "ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? AND c.ngay_ht>=? AND c.ngay_ht<? ORDER BY c.ngay_ht, c.id, b.stt")
    for r in con.execute(q, (cid, tu or "0000", den_truoc)):
        if r["tk_no"].startswith(tk) and not r["tk_co"].startswith(tk):
            m = r["doi_tuong_no"] or ""
            ps.setdefault(m, [0, 0])[0] += r["so_tien"]
            ds.append((r["ngay_ht"], m, r["so_tien"], 0))
        if r["tk_co"].startswith(tk) and not r["tk_no"].startswith(tk):
            m = r["doi_tuong_co"] or ""
            ps.setdefault(m, [0, 0])[1] += r["so_tien"]
            ds.append((r["ngay_ht"], m, 0, r["so_tien"]))
    return ps, ds


def du_doi_tuong(con, cid, tk, ngay):
    """{ma doi tuong: No - Co} cua TK `tk` dau ngay `ngay`."""
    goc, d = _goc_doi_tuong(con, cid, tk, ngay)
    ps, _ = _ps_doi_tuong(con, cid, tk, goc, ngay)
    for m, (n, c) in ps.items():
        d[m] = d.get(m, 0) + n - c
    return d


def cong_no(con, cid, tk, tu, den):
    """So tong hop cong no theo doi tuong: list dict ma, ten, dau_no, dau_co, ps_no, ps_co, cuoi_no, cuoi_co."""
    d0 = du_doi_tuong(con, cid, tk, tu)
    d1 = du_doi_tuong(con, cid, tk, bao_cao.ngay_sau(den))
    ps, _ = _ps_doi_tuong(con, cid, tk, tu, bao_cao.ngay_sau(den))
    ten = ten_doi_tuong(con, cid)
    kq = []
    for m in sorted(set(d0) | set(d1) | set(ps), key=lambda x: (x == "", ten.get(x) or x)):
        a, b = d0.get(m, 0), d1.get(m, 0)
        p = ps.get(m, [0, 0])
        if not (a or b or p[0] or p[1]):
            continue
        kq.append({"ma": m, "ten": ten.get(m) or ("(chưa gắn đối tượng)" if not m else ""),
                   "dau_no": max(a, 0), "dau_co": max(-a, 0), "ps_no": p[0], "ps_co": p[1],
                   "cuoi_no": max(b, 0), "cuoi_co": max(-b, 0)})
    return kq


def chi_tiet_doi_tuong(con, cid, tk, ma, tu, den):
    """So chi tiet mot doi tuong: (so du dau, list dong ngay, so_ct, dien_giai, tk_du, no, co, du)."""
    dau = du_doi_tuong(con, cid, tk, tu).get(ma, 0)
    q = ("SELECT c.id, c.ngay_ht, c.so_ct, COALESCE(b.dien_giai, c.dien_giai) dg, b.tk_no, b.doi_tuong_no, b.tk_co, "
         "b.doi_tuong_co, b.so_tien FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id "
         "WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ? ORDER BY c.ngay_ht, c.id, b.stt")
    du, ds = dau, []
    for r in con.execute(q, (cid, tu, den)):
        no = r["so_tien"] if r["tk_no"].startswith(tk) and (r["doi_tuong_no"] or "") == ma and not r["tk_co"].startswith(tk) else 0
        co = r["so_tien"] if r["tk_co"].startswith(tk) and (r["doi_tuong_co"] or "") == ma and not r["tk_no"].startswith(tk) else 0
        if no or co:
            du += no - co
            ds.append({"id": r["id"], "ngay": r["ngay_ht"], "so_ct": r["so_ct"], "dien_giai": r["dg"],
                       "tk_du": r["tk_co"] if no else r["tk_no"], "no": no, "co": co, "du": du})
    return dau, ds


def tuoi_no(con, cid, tk, ngay):
    """Tuoi no dau ngay `ngay` (TK 131: phai thu; 331: phai tra), tru dan theo thu tu phat sinh truoc tra truoc.

    So du lay tu moc (so du dau ky hoac bang cong no nap) duoc tinh tuoi tu ngay moc."""
    dau_no = tk.startswith("131") or tk.startswith("1388") or tk.startswith("141")
    goc, d = _goc_doi_tuong(con, cid, tk, ngay)
    phat, tra = {}, {}
    for m, v in d.items():
        v = v if dau_no else -v
        if v > 0:
            phat.setdefault(m, []).append([goc, v])
        elif v < 0:
            tra[m] = tra.get(m, 0) - v
    _, ds = _ps_doi_tuong(con, cid, tk, goc, ngay)
    for ng, m, no, co in ds:
        tang, giam = (no, co) if dau_no else (co, no)
        if tang:
            phat.setdefault(m, []).append([ng, tang])
        if giam:
            tra[m] = tra.get(m, 0) + giam
    ten = ten_doi_tuong(con, cid)
    nd = date.fromisoformat(ngay)
    kq = []
    for m in set(phat) | set(tra):
        con_tra = tra.get(m, 0)
        nhom = [0, 0, 0, 0]
        cu_nhat = None
        for ps in phat.get(m, []):
            tru = min(ps[1], con_tra)
            ps[1] -= tru
            con_tra -= tru
            if ps[1]:
                tuoi = (nd - date.fromisoformat(ps[0])).days
                cu_nhat = cu_nhat if cu_nhat is not None else tuoi
                nhom[0 if tuoi <= 30 else 1 if tuoi <= 60 else 2 if tuoi <= 90 else 3] += ps[1]
        if any(nhom) or con_tra:
            kq.append({"ma": m, "ten": ten.get(m) or ("(chưa gắn đối tượng)" if not m else ""), "nhom": nhom,
                       "tong": sum(nhom), "tra_truoc": con_tra, "lau_nhat": cu_nhat})
    return sorted(kq, key=lambda x: -x["tong"]), goc


# ================================================================ doi chieu so cai voi so chi tiet

def doi_chieu(con, cid, ngay_cuoi):
    """Danh sach (noi dung, so cai, so chi tiet, chenh, ghi chu) tai cuoi ngay `ngay_cuoi`."""
    from . import kho, tai_san
    bang, _ = bao_cao.phan_hai_ben(con, cid, bao_cao.ngay_sau(ngay_cuoi))
    rong = lambda tt: sum(n - c for k, (n, c) in bang.items() if k.startswith(tt))
    kq = []
    thang = ngay_cuoi[:7]
    tscd = con.execute("SELECT * FROM tai_san WHERE cong_ty_id=? AND loai='TSCD' AND ngay_tang<=? "
                       "AND (ngung_tu IS NULL OR ngung_tu='' OR ngung_tu>?)", (cid, ngay_cuoi, thang)).fetchall()
    if tscd or rong("211"):
        ng = sum(t["nguyen_gia"] for t in tscd)
        kq.append(("Nguyên giá TSCĐ: TK 211 và sổ tài sản", rong("211"), ng, ""))
        lk = sum(tai_san.luy_ke(con, t, thang) for t in tscd)
        kq.append(("Hao mòn lũy kế: TK 214 và sổ tài sản", -rong("214"), lk, "Sổ tài sản tính đến tháng đã trích"))
    ccdc = con.execute("SELECT * FROM tai_san WHERE cong_ty_id=? AND loai='CCDC' AND ngay_tang<=?", (cid, ngay_cuoi)).fetchall()
    if ccdc:
        con_lai = sum(t["nguyen_gia"] - tai_san.luy_ke(con, t, thang) for t in ccdc)
        kq.append(("Chi phí trả trước: TK 242 và giá trị CCDC còn lại", rong("242"), con_lai,
                   "TK 242 có thể gồm chi phí trả trước khác ngoài CCDC"))
    if con.execute("SELECT 1 FROM kho_dong WHERE cong_ty_id=? LIMIT 1", (cid,)).fetchone():
        ton = kho.tong_hop_ton(con, cid, ngay_cuoi, ngay_cuoi)
        gt = sum(r["cuoi_gt"] for r in ton)
        if ton:
            kq.append(("Hàng tồn kho: TK 152, 153, 156 và sổ kho", rong("152") + rong("153") + rong("156"), gt,
                       "Phiếu xuất chưa tính giá thì sổ kho chưa có giá trị"))
    for tk, ten, dau in (("131", "Phải thu khách hàng (dư Nợ - dư Có)", 1), ("331", "Phải trả người bán (dư Có - dư Nợ)", -1)):
        dt = du_doi_tuong(con, cid, tk, bao_cao.ngay_sau(ngay_cuoi))
        chua = dt.get("", 0)
        if rong(tk) or dt:
            kq.append((f"{ten}: TK {tk} và tổng chi tiết đối tượng", dau * rong(tk), dau * (sum(dt.values()) - chua),
                       f"Phần chưa gắn đối tượng: {_f(dau * chua)} đ" if chua else ""))
    if con.execute("SELECT 1 FROM sqlite_master WHERE name='bang_luong'").fetchone():
        nam = ngay_cuoi[:4]
        bl = 0
        for r in con.execute("SELECT ket_qua FROM bang_luong WHERE cong_ty_id=? AND thang LIKE ? AND thang<=? AND ket_qua IS NOT NULL",
                             (cid, f"{nam}-%", thang)):
            bl += json.loads(r["ket_qua"])["tong_thu_nhap"]
        if bl:
            ps = bao_cao.phat_sinh(con, cid, f"{nam}-01-01", ngay_cuoi)
            co334 = sum(c for k, (n, c) in ps.items() if k.startswith("334"))
            kq.append((f"Lương phải trả năm {nam}: phát sinh Có 334 và bảng lương", co334, bl,
                       "Có 334 có thể gồm khoản ngoài bảng lương"))
    if con.execute("SELECT 1 FROM sqlite_master WHERE name='sao_ke'").fetchone():
        from . import sao_ke
        for r in sao_ke.doi_chieu(con, cid, "0000-01-01", ngay_cuoi):
            if r["so_du_nh"] is not None:
                kq.append((f"Tiền gửi TK {r['tk']} và sao kê ({r['tai_khoan']})", r["so_du_so"], r["so_du_nh"],
                           f"{r['dem'].get('moi', 0)} dòng sao kê chưa ghi sổ" if r["dem"].get("moi") else ""))
    if con.execute("SELECT 1 FROM sqlite_master WHERE name='hoa_don'").fetchone():
        tu = f"{ngay_cuoi[:4]}-01-01"
        ps = bao_cao.phat_sinh(con, cid, tu, ngay_cuoi)
        hd = con.execute("SELECT COALESCE(SUM(tien_thue),0) s, COUNT(*) n FROM hoa_don WHERE cong_ty_id=? AND chieu='mua' "
                         "AND ngay_lap BETWEEN ? AND ? AND trang_thai NOT IN (4,6)", (cid, tu, ngay_cuoi)).fetchone()
        if hd["n"]:
            kq.append(("Thuế GTGT đầu vào năm nay: Nợ 133 và hóa đơn mua", sum(n for k, (n, c) in ps.items() if k.startswith("133")),
                       hd["s"], ""))
        hd = con.execute("SELECT COALESCE(SUM(tien_thue),0) s, COUNT(*) n FROM hoa_don WHERE cong_ty_id=? AND chieu='ban' "
                         "AND ngay_lap BETWEEN ? AND ? AND trang_thai NOT IN (4,6)", (cid, tu, ngay_cuoi)).fetchone()
        if hd["n"]:
            kq.append(("Thuế GTGT đầu ra năm nay: Có 33311 và hóa đơn bán",
                       sum(c for k, (n, c) in ps.items() if k.startswith("33311")), hd["s"],
                       "Có 33311 không gồm bút toán khấu trừ (Nợ 33311)"))
    return [(nd, a, b, a - b, gc) for nd, a, b, gc in kq]


def hoa_don_can_xem(con, cid):
    """Hoa don chua ghi so va hoa don da ghi so nhung sau do bi huy/thay the."""
    if not con.execute("SELECT 1 FROM sqlite_master WHERE name='hoa_don'").fetchone():
        return [], []
    chua = con.execute("SELECT * FROM hoa_don WHERE cong_ty_id=? AND chung_tu_id IS NULL AND trang_thai NOT IN (4,6) "
                       "ORDER BY ngay_lap", (cid,)).fetchall()
    huy = con.execute("SELECT * FROM hoa_don WHERE cong_ty_id=? AND chung_tu_id IS NOT NULL AND trang_thai IN (4,6) "
                      "ORDER BY ngay_lap", (cid,)).fetchall()
    return chua, huy


# ================================================================ viec can lam, han nop

def han_nop(ct, hom_nay=None):
    """Cac han nop sap toi trong 45 ngay: list (ngay, noi dung)."""
    hn = hom_nay or date.today()
    ds = []
    for y in (hn.year - 1, hn.year):
        for m in range(1, 13):
            if ct["ky_ke_khai_gtgt"] == "Q":
                if m % 3:
                    continue
                q = m // 3
                han_m, han_y = (m % 12) + 1, y + (m == 12)
                han = date(han_y, han_m, calendar.monthrange(han_y, han_m)[1])
                ds.append((han, f"Tờ khai 01/GTGT quý {q}/{y}"))
            else:
                han_m, han_y = (m % 12) + 1, y + (m == 12)
                ds.append((date(han_y, han_m, 20), f"Tờ khai 01/GTGT tháng {m:02d}/{y}"))
        if y == hn.year - 1 or True:
            han = date(y + 1, 3, 31)
            ds.append((han, f"BCTC, quyết toán TNDN, quyết toán TNCN năm {y}"))
            ds.append((date(y + 1, 1, 30), f"Lệ phí môn bài năm {y + 1}"))
    return sorted((d, t) for d, t in ds if hn <= d <= hn + timedelta(days=45))


def viec_can_lam(con, ct, hom_nay=None):
    """Danh sach (muc do, noi dung, duong dan) cho mot cong ty."""
    from . import tai_san
    cid = ct["id"]
    hn = hom_nay or date.today()
    v = []
    for d, t in han_nop(ct, hn):
        con_ngay = (d - hn).days
        v.append(("do" if con_ngay <= 7 else "vang", f"{t}: hạn {d:%d/%m/%Y} (còn {con_ngay} ngày)", "baocao"))
    chua, huy = hoa_don_can_xem(con, cid)
    if chua:
        v.append(("vang", f"{len(chua)} hóa đơn chưa ghi sổ", "hoadon"))
    if huy:
        v.append(("do", f"{len(huy)} hóa đơn đã ghi sổ nhưng sau đó bị hủy hoặc thay thế: cần xóa hoặc điều chỉnh bút toán",
                  "doichieu"))
    if con.execute("SELECT 1 FROM sqlite_master WHERE name='sao_ke'").fetchone():
        n = con.execute("SELECT COUNT(*) n FROM sao_ke WHERE cong_ty_id=? AND trang_thai='moi'", (cid,)).fetchone()["n"]
        if n:
            v.append(("vang", f"{n} dòng sao kê ngân hàng chưa ghi sổ", "nganhang"))
    thang_truoc = (hn.replace(day=1) - timedelta(days=1)).strftime("%Y-%m")
    co_ts = con.execute("SELECT COUNT(*) n FROM tai_san WHERE cong_ty_id=? AND ngay_bat_dau<=? AND "
                        "(ngung_tu IS NULL OR ngung_tu='' OR ngung_tu>?)", (cid, thang_truoc + "-31", thang_truoc)).fetchone()["n"]
    if co_ts and not con.execute("SELECT 1 FROM khau_hao k JOIN tai_san t ON t.id=k.tai_san_id WHERE t.cong_ty_id=? "
                                 "AND k.thang=?", (cid, thang_truoc)).fetchone():
        v.append(("vang", f"Chưa trích khấu hao, phân bổ tháng {thang_truoc[5:]}/{thang_truoc[:4]}", "taisan"))
    if con.execute("SELECT 1 FROM kho_dong WHERE cong_ty_id=? AND loai='X' AND thanh_tien IS NULL AND ngay<=?",
                   (cid, thang_truoc + "-31")).fetchone():
        v.append(("vang", "Có phiếu xuất kho chưa tính giá xuất", "kho"))
    ky_cuoi = con.execute("SELECT MAX(ngay_ht) n FROM chung_tu WHERE cong_ty_id=?", (cid,)).fetchone()["n"]
    if ky_cuoi and ky_cuoi[:7] <= thang_truoc and ky_cuoi[:7] >= (hn.replace(day=1) - timedelta(days=62)).strftime("%Y-%m"):
        if not con.execute("SELECT 1 FROM chung_tu WHERE cong_ty_id=? AND nguon='ket_chuyen' AND ngay_ht LIKE ?",
                           (cid, thang_truoc + "%")).fetchone() and con.execute(
                "SELECT 1 FROM chung_tu WHERE cong_ty_id=? AND ngay_ht LIKE ? AND nguon!='misa'", (cid, thang_truoc + "%")).fetchone():
            v.append(("vang", f"Chưa kết chuyển cuối tháng {thang_truoc[5:]}/{thang_truoc[:4]}", "baocao?muc=ketchuyen"))
    canh = sum(1 for t in con.execute("SELECT * FROM tai_san WHERE cong_ty_id=?", (cid,)).fetchall() if tai_san.canh_bao(t))
    if canh:
        v.append(("do", f"{canh} tài sản có cảnh báo (khấu hao ngoài khung, lũy kế lệch...)", "taisan"))
    if con.execute("SELECT 1 FROM sqlite_master WHERE name='nguoi_phu_thuoc'").fetchone():
        n = con.execute("SELECT COUNT(*) n FROM nguoi_phu_thuoc WHERE cong_ty_id=? AND COALESCE(mst,'')='' AND COALESCE(cccd,'')=''",
                        (cid,)).fetchone()["n"]
        if n:
            v.append(("vang", f"{n} người phụ thuộc thiếu MST/CCCD", "luong"))
    from . import vay
    v += vay.viec(con, cid, hn)
    from . import hop_dong
    v += hop_dong.viec(con, cid, hn)
    from . import tu_tai_hd
    v += tu_tai_hd.viec(cid)
    k = ngay_khoa(con, cid)
    if not k or k < (hn.replace(day=1) - timedelta(days=100)).isoformat():
        v.append(("xanh", f"Sổ đang khóa đến {k[8:]}/{k[5:7]}/{k[:4]}" if k else "Chưa khóa sổ kỳ nào; nên khóa các kỳ đã nộp tờ khai",
                  "khoaso"))
    return v


# ================================================================ luu chuyen tien te (B03-DNN, truc tiep)

B03 = [
    ("01", "1. Tiền thu từ bán hàng, cung cấp dịch vụ và doanh thu khác"),
    ("02", "2. Tiền chi trả cho người cung cấp hàng hóa, dịch vụ"), ("03", "3. Tiền chi trả cho người lao động"),
    ("04", "4. Tiền lãi vay đã trả"), ("05", "5. Thuế thu nhập doanh nghiệp đã nộp"),
    ("06", "6. Tiền thu khác từ hoạt động kinh doanh"), ("07", "7. Tiền chi khác cho hoạt động kinh doanh"),
    ("20", "Lưu chuyển tiền thuần từ hoạt động kinh doanh"),
    ("21", "1. Tiền chi để mua sắm, xây dựng TSCĐ, BĐSĐT và tài sản dài hạn khác"),
    ("22", "2. Tiền thu từ thanh lý, nhượng bán TSCĐ, BĐSĐT và tài sản dài hạn khác"),
    ("23", "3. Tiền chi cho vay, đầu tư góp vốn vào đơn vị khác"),
    ("24", "4. Tiền thu hồi cho vay, đầu tư góp vốn vào đơn vị khác"),
    ("25", "5. Tiền thu lãi cho vay, cổ tức và lợi nhuận được chia"),
    ("30", "Lưu chuyển tiền thuần từ hoạt động đầu tư"),
    ("31", "1. Tiền thu từ phát hành cổ phiếu, nhận vốn góp của chủ sở hữu"),
    ("32", "2. Tiền trả lại vốn góp cho các chủ sở hữu"), ("33", "3. Tiền thu từ đi vay"),
    ("34", "4. Tiền trả nợ gốc vay và nợ thuê tài chính"), ("35", "5. Cổ tức, lợi nhuận đã trả cho chủ sở hữu"),
    ("40", "Lưu chuyển tiền thuần từ hoạt động tài chính"),
    ("50", "Lưu chuyển tiền thuần trong kỳ (50 = 20 + 30 + 40)"), ("60", "Tiền và tương đương tiền đầu kỳ"),
    ("61", "Ảnh hưởng của thay đổi tỷ giá hối đoái quy đổi ngoại tệ"),
    ("70", "Tiền và tương đương tiền cuối kỳ (70 = 50 + 60 + 61)"),
]
# Tien vao theo TK doi ung (thu tu uu tien), tien ra theo TK doi ung
_VAO = [("411", "31"), ("341", "33"), ("228", "24"), ("128", "24"), ("515", "25"), ("711", "22"),
        ("511", "01"), ("131", "01"), ("3331", "01")]
_RA = [("211", "21"), ("213", "21"), ("217", "21"), ("241", "21"), ("228", "23"), ("128", "23"), ("411", "32"),
       ("419", "32"), ("341", "34"), ("421", "35"), ("334", "03"), ("3334", "05"), ("635", "04"), ("335", "04"),
       ("331", "02"), ("15", "02"), ("133", "02"), ("632", "02"), ("154", "02")]


def luu_chuyen_tien(con, cid, tu, den):
    """B03-DNN phuong phap truc tiep: phan loai tien vao/ra TK 111, 112 theo TK doi ung."""
    kq = {m: 0 for m, _ in B03}
    q = ("SELECT b.tk_no, b.tk_co, b.so_tien FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id "
         "WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ?")
    tien = ("111", "112", "113")
    for r in con.execute(q, (cid, tu, den)):
        vao, ra = r["tk_no"].startswith(tien), r["tk_co"].startswith(tien)
        if vao == ra:
            continue
        du = r["tk_co"] if vao else r["tk_no"]
        bang = _VAO if vao else _RA
        ma = next((m for tt, m in bang if du.startswith(tt)), "06" if vao else "07")
        kq[ma] += r["so_tien"] if vao else -r["so_tien"]
    kq["20"] = sum(kq[m] for m in ("01", "02", "03", "04", "05", "06", "07"))
    kq["30"] = sum(kq[m] for m in ("21", "22", "23", "24", "25"))
    kq["40"] = sum(kq[m] for m in ("31", "32", "33", "34", "35"))
    kq["50"] = kq["20"] + kq["30"] + kq["40"]
    dau, _ = bao_cao.phan_hai_ben(con, cid, tu)
    kq["60"] = sum(n - c for k, (n, c) in dau.items() if k.startswith(tien))
    kq["70"] = kq["50"] + kq["60"] + kq["61"]
    return kq


# ================================================================ so tien bang chu

_SO = ["không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"]
_DON_VI = ["", "nghìn", "triệu", "tỷ", "nghìn tỷ", "triệu tỷ"]


def _ba_so(n, day_du):
    """Doc nhom 3 chu so. day_du=True: doc ca 'khong tram', 'le' (nhom khong dung dau)."""
    tr, ch, dv = n // 100, n // 10 % 10, n % 10
    t = []
    if tr or day_du:
        t.append(_SO[tr] + " trăm")
    if ch == 0:
        if dv and t:
            t.append("lẻ")
    elif ch == 1:
        t.append("mười")
    else:
        t.append(_SO[ch] + " mươi")
    if dv:
        if dv == 1 and ch >= 2:
            t.append("mốt")
        elif dv == 5 and ch >= 1:
            t.append("lăm")
        else:
            t.append(_SO[dv])
    return " ".join(t)


def bang_chu(so):
    """1234567 -> 'Một triệu hai trăm ba mươi bốn nghìn năm trăm sáu mươi bảy đồng'."""
    so = int(round(so))
    if so == 0:
        return "Không đồng"
    am, so = so < 0, abs(so)
    nhom = []
    while so:
        nhom.append(so % 1000)
        so //= 1000
    t = []
    for i in range(len(nhom) - 1, -1, -1):
        if nhom[i] == 0:
            continue
        t.append(_ba_so(nhom[i], i != len(nhom) - 1))
        if _DON_VI[i]:
            t.append(_DON_VI[i])
    s = " ".join(t)
    s = ("âm " + s) if am else s
    return s[0].upper() + s[1:] + " đồng"
