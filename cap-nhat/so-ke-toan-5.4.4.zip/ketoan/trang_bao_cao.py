"""Trang Bao cao & To khai: BCTC, 01/GTGT, 03/TNDN, 05/QTT-TNCN, mau XML HTKK, ket chuyen."""
from datetime import date
from urllib.parse import quote, urlencode

from . import bao_cao, che_do, htkk, to_khai
from . import giao_dien as G
from .trang_hoa_don import doc_multipart

e, so = G.e, G.so

MUC = [("bctc", "Báo cáo tài chính"), ("kqkd", "Kết quả kinh doanh"), ("gtgt", "Tờ khai 01/GTGT"), ("tndn", "Quyết toán 03/TNDN"),
       ("tncn", "Quyết toán 05/QTT-TNCN"), ("mau", "Mẫu XML và công nợ"), ("ketchuyen", "Kết chuyển")]

B02_DN = [
    ("01", "1. Doanh thu bán hàng và cung cấp dịch vụ"), ("02", "2. Các khoản giảm trừ doanh thu"),
    ("10", "3. Doanh thu thuần về bán hàng và cung cấp dịch vụ (10 = 01 - 02)"), ("11", "4. Giá vốn hàng bán"),
    ("20", "5. Lợi nhuận gộp (20 = 10 - 11)"), ("21", "6. Doanh thu hoạt động tài chính"), ("22", "7. Chi phí tài chính"),
    ("23", "- Trong đó: Chi phí lãi vay"), ("25", "8. Chi phí bán hàng"), ("26", "9. Chi phí quản lý doanh nghiệp"),
    ("30", "10. Lợi nhuận thuần từ hoạt động kinh doanh (30 = 20 + 21 - 22 - 25 - 26)"), ("31", "11. Thu nhập khác"),
    ("32", "12. Chi phí khác"), ("40", "13. Lợi nhuận khác (40 = 31 - 32)"),
    ("50", "14. Tổng lợi nhuận kế toán trước thuế (50 = 30 + 40)"), ("51", "15. Chi phí thuế TNDN hiện hành"),
    ("52", "16. Chi phí thuế TNDN hoãn lại"), ("60", "17. Lợi nhuận sau thuế thu nhập doanh nghiệp (60 = 50 - 51 - 52)"),
]

TEN_GTGT = [
    ("21", "[21] Không phát sinh hoạt động mua bán (1 = có đánh dấu)"),
    ("22", "[22] Thuế GTGT còn được khấu trừ kỳ trước chuyển sang"),
    ("23", "[23] Giá trị HHDV mua vào"), ("24", "[24] Thuế GTGT HHDV mua vào"),
    ("25", "[25] Thuế GTGT được khấu trừ kỳ này"),
    ("26", "[26] HHDV bán ra không chịu thuế"), ("27", "[27] HHDV bán ra chịu thuế"), ("28", "[28] Thuế GTGT bán ra"),
    ("29", "[29] Thuế suất 0%"), ("30", "[30] Thuế suất 5% (doanh thu)"), ("31", "[31] Thuế suất 5% (thuế)"),
    ("32", "[32] Thuế suất 10% và 8% (doanh thu)"), ("33", "[33] Thuế suất 10% và 8% (thuế)"),
    ("32a", "[32a] Không phải kê khai, tính nộp thuế"), ("34", "[34] Tổng doanh thu"), ("35", "[35] Tổng thuế bán ra"),
    ("36", "[36] Thuế GTGT phát sinh trong kỳ"), ("37", "[37] Điều chỉnh giảm"), ("38", "[38] Điều chỉnh tăng"),
    ("39a", "[39a] Thuế nhận bàn giao được khấu trừ"), ("40a", "[40a] Thuế phải nộp của HĐSXKD"),
    ("40b", "[40b] Thuế mua vào của dự án đầu tư được bù trừ"), ("40", "[40] Thuế GTGT còn phải nộp"),
    ("41", "[41] Thuế GTGT chưa khấu trừ hết"), ("42", "[42] Đề nghị hoàn"), ("43", "[43] Chuyển kỳ sau"),
]
TEN_TNDN = [
    ("A1", "A1. Lợi nhuận kế toán trước thuế"), ("B1", "B1. Điều chỉnh tăng (B2..B7)"),
    ("B2", "B2. Điều chỉnh tăng doanh thu"), ("B3", "B3. Chi phí của phần doanh thu điều chỉnh giảm"),
    ("B4", "B4. Chi phí không được trừ"), ("B5", "B5. Thuế đã nộp cho thu nhập ở nước ngoài"),
    ("B6", "B6. Điều chỉnh tăng do giao dịch liên kết"), ("B7", "B7. Điều chỉnh tăng khác"),
    ("B8", "B8. Điều chỉnh giảm (B9..B12)"), ("B9", "B9. Giảm trừ doanh thu đã tính thuế năm trước"),
    ("B10", "B10. Chi phí của phần doanh thu điều chỉnh tăng"), ("B11", "B11. Chi phí lãi vay năm trước chuyển sang"),
    ("B12", "B12. Điều chỉnh giảm khác"), ("B13", "B13. Tổng thu nhập chịu thuế"),
    ("B14", "B14. Thu nhập chịu thuế từ SXKD"), ("C1", "C1. Thu nhập chịu thuế"), ("C2", "C2. Thu nhập miễn thuế"),
    ("C3a", "C3a. Lỗ được chuyển trong kỳ"), ("C4", "C4. Thu nhập tính thuế"), ("C6", "C6. TNTT sau trích quỹ KH&CN"),
    ("C7_thueSuat", "Thuế suất (%)"), ("thue_phai_nop", "Thuế TNDN phải nộp (hệ thống tính)"),
    ("tam_nop_trong_nam", "Đã nộp TK 3334 trong năm (để đối chiếu)"),
]
TEN_031A = [("ct04", "[04] Doanh thu bán hàng"), ("ct06", "[06] Giảm trừ doanh thu"), ("ct11", "[11] Doanh thu tài chính"),
            ("ct12", "[12] Chi phí SXKD"), ("ct13", "[13] Giá vốn"), ("ct14", "[14] Chi phí bán hàng"),
            ("ct15", "[15] Chi phí quản lý"), ("ct16", "[16] Chi phí tài chính"), ("ct17", "[17] Trong đó lãi vay"),
            ("ct18", "[18] Lợi nhuận thuần"), ("ct19", "[19] Thu nhập khác"), ("ct20", "[20] Chi phí khác"),
            ("ct21", "[21] Lợi nhuận khác"), ("ct22", "[22] Tổng lợi nhuận trước thuế")]


def _cb(ds, lop="loi"):
    return "".join(f'<p class="{lop}">{e(x)}</p>' for x in ds)


def _bang(dong, cot):
    h = "".join(f"<th>{e(c)}</th>" for c in cot)
    return f"<table><tr>{h}</tr>{dong}</table>"


class TrangBaoCao:
    def baocao(self, pt, con, ct, q, rest):
        to_khai.chuan_bi(con)
        cid = ct["id"]
        if rest and rest[0] == "xml":
            if not G.muc_duoc_dung("bc:" + (rest[1] if len(rest) > 1 else "")):
                return self.gui(G.trang("Không áp dụng", '<p class="loi">Không áp dụng cho chế độ kế toán này.</p>', cid, ct["ten"]), 404)
            return self._xml(con, ct, rest[1] if len(rest) > 1 else "", q)
        muc = q.get("muc") or G.muc_bao_cao_dau()
        if not G.muc_duoc_dung("bc:" + muc):
            return self.gui(G.trang("Không áp dụng", '<div class="the"><p class="loi">Mục này không áp dụng cho chế độ kế toán '
                                    f'của công ty. <a href="/cty/{cid}/baocao">Về Báo cáo, tờ khai</a></p></div>', cid, ct["ten"]), 404)
        nam = int(q.get("nam") or date.today().year - 1)
        tb = ""
        if pt == "POST":
            if self.headers.get("Content-Type", "").startswith("multipart/"):
                f, tep = doc_multipart(self)
            else:
                f, tep = {k: v[0] for k, v in self.doc_form().items()}, []
            try:
                tb = self._xu_ly(con, ct, muc, nam, f, tep)
            except Exception as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        tab = " ".join(
            f'<a class="nut{"" if m == muc else " phu"}" href="/cty/{cid}/baocao?muc={m}&nam={nam}">{t}</a>' for m, t in MUC
            if G.muc_duoc_dung("bc:" + m))
        nd = getattr(self, f"_bc_{muc}")(con, ct, nam, q)
        noi = f"""<div class="the"><h1>Báo cáo và tờ khai</h1><p>{tab}</p>
<p class="mo">Hệ thống chỉ lập số và xuất file. Việc ký và nộp lên cổng thuế luôn do anh/chị tự làm sau khi kiểm tra.</p>{tb}</div>{nd}"""
        self.gui(G.trang("Báo cáo và tờ khai", noi, cid, ct["ten"]))

    # ------------------------------------------------------------ xu ly POST
    def _xu_ly(self, con, ct, muc, nam, f, tep):
        cid = ct["id"]
        hd = f.get("hanh_dong", "")
        if hd == "mau":
            kq = []
            for ten, b in tep:
                if ten.lower().endswith(".xml"):
                    tt = htkk.luu_mau(G.THU_MUC_DL, cid, b)
                    kq.append(f"{ten}: mẫu {tt['loai']} kỳ {tt['ky']} (phiên bản {tt['phien_ban']})")
                    if tt["loai"] == "03/TNDN":
                        y, lo = htkk.doc_lo_03(b)
                        to_khai.nap_lo_tu_mau(con, cid, y, lo)
                        kq.append(f"Đã lấy bảng chuyển lỗ từ tờ khai 03/TNDN năm {y}.")
                    kq += to_khai.kiem_tra_mau(ct, tt)
                elif ten.lower().endswith((".xlsx", ".xls")):
                    tk, den, n = bao_cao.nap_cong_no_misa(con, cid, b)
                    kq.append(f"{ten}: {n} đối tượng còn số dư TK {tk} ngày {G.ngay_vn(den)}")
            return _cb(kq, "ok") or '<p class="loi">Chưa chọn file.</p>'
        if hd == "luu_gtgt":
            v, pl, cb, tt = self._gtgt_tinh(con, ct, f)
            to_khai.luu(con, cid, "01/GTGT", tt["ky"], v)
            return f'<p class="ok">Đã lưu tờ khai 01/GTGT kỳ {e(tt["ky"])}. Kỳ sau sẽ lấy [43] = {so(v["43"]) or 0} làm [22].</p>'
        if hd == "them_dc":
            con.execute("INSERT INTO dieu_chinh_tndn (cong_ty_id, nam, chi_tieu, noi_dung, so_tien) VALUES (?,?,?,?,?)",
                        (cid, nam, f["chi_tieu"], f["noi_dung"].strip() or "Không ghi", int(f["so_tien"] or 0)))
            con.commit()
            return '<p class="ok">Đã thêm khoản điều chỉnh.</p>'
        if hd == "xoa_dc":
            con.execute("DELETE FROM dieu_chinh_tndn WHERE cong_ty_id=? AND id=?", (cid, int(f["id"])))
            con.commit()
            return '<p class="ok">Đã xóa.</p>'
        if hd == "luu_tndn":
            v, p, lo, cb, _ = to_khai.tndn(con, cid, nam, {"thue_suat": f.get("thue_suat")})
            to_khai.luu_tndn(con, cid, nam, v, lo)
            return '<p class="ok">Đã lưu quyết toán TNDN, cập nhật số lỗ đã chuyển.</p>'
        if hd == "uy_quyen":
            con.execute("UPDATE nhan_vien SET uy_quyen_qt=0 WHERE cong_ty_id=?", (cid,))
            for k in f:
                if k.startswith("uq_"):
                    con.execute("UPDATE nhan_vien SET uy_quyen_qt=1 WHERE cong_ty_id=? AND ma=?", (cid, k[3:]))
            con.commit()
            return '<p class="ok">Đã lưu danh sách ủy quyền quyết toán.</p>'
        if hd == "ket_chuyen":
            ctid, ln = bao_cao.ket_chuyen(con, cid, f["tu"], f["den"])
            if not ctid:
                return '<p class="ok">Không còn số dư loại 5 đến 8 cần kết chuyển (đã kết chuyển rồi).</p>'
            return f'<p class="ok">Đã kết chuyển đến {G.ngay_vn(f["den"])}: {"lãi" if ln >= 0 else "lỗ"} {so(abs(ln)) or 0} đ.</p>'
        if hd == "chuyen_nam":
            ctid = bao_cao.chuyen_nam(con, cid, int(f["nam_kc"]))
            return '<p class="ok">Đã chuyển 4212 sang 4211 đầu năm sau.</p>' if ctid else '<p class="ok">TK 4212 không có số dư.</p>'
        return ""

    # ------------------------------------------------------------ Ket qua kinh doanh (TT99, TT58)
    def _bc_kqkd(self, con, ct, nam, q):
        cid = ct["id"]
        cd = che_do.ma(ct)
        nay = bao_cao.b02(con, cid, f"{nam}-01-01", f"{nam}-12-31")
        truoc = bao_cao.b02(con, cid, f"{nam - 1}-01-01", f"{nam - 1}-12-31")
        dong = "".join(f'<tr{" class=c1" if ma in ("10", "20", "30", "50", "60") else ""}><td>{ma}</td><td>{e(t)}</td>'
                       f'<td class="s">{so(nay.get(ma, 0))}</td><td class="s">{so(truoc.get(ma, 0))}</td></tr>' for ma, t in B02_DN)
        mau = "B02-DN" if cd == "TT99" else "B02-DNSN"
        ghi_chu = ("Theo Thông tư 99/2025/TT-BTC: chi phí bán hàng lấy TK 641, quản lý doanh nghiệp TK 642."
                   if cd == "TT99" else
                   "Doanh nghiệp siêu nhỏ nộp TNDN theo thu nhập tính thuế lập B01-DNSN và B02-DNSN (Thông tư 58/2026/TT-BTC). "
                   "Bảng dưới lập từ sổ để theo dõi; đối chiếu chỉ tiêu với mẫu chính thức trước khi nộp.")
        return f"""<div class="the"><form class="ngang"><input type="hidden" name="muc" value="kqkd">
<label>Năm<input type="number" name="nam" value="{nam}"></label><button>Lập</button></form>
<p class="mo">{e(ghi_chu)} Mẫu XML nộp qua HTKK cho chế độ này chưa có trong ứng dụng; số liệu dùng để nhập tay vào HTKK.</p></div>
<div class="the"><h2>Báo cáo kết quả hoạt động kinh doanh ({mau}) năm {nam}</h2>
{_bang(dong, ["Mã", "Chỉ tiêu", f"Năm {nam}", f"Năm {nam - 1}"])}</div>"""

    # ------------------------------------------------------------ BCTC
    def _bc_bctc(self, con, ct, nam, q):
        cid = ct["id"]
        nguon = q.get("dau", "tu_dong")
        mau = htkk.doc_mau(G.THU_MUC_DL, cid, "BCTC")
        r = to_khai.bctc(con, cid, nam, mau, nguon)
        b01 = []
        for ma in bao_cao.THU_TU_B01:
            ten = bao_cao.TEN_TONG.get(ma) or next(t for m, t, _ in bao_cao.B01 if m == ma)
            dam = ' class="c1"' if ma in bao_cao.TEN_TONG or ma in ("110", "170") else ""
            b01.append(f'<tr{dam}><td>{ma}</td><td>{e(ten)}</td><td class="s">{so(r["cuoi"][ma])}</td>'
                       f'<td class="s">{so(r["dau"].get(ma, 0))}</td></tr>')
        b02 = "".join(f'<tr><td>{ma}</td><td>{e(t)}</td><td class="s">{so(r["kq_nay"][ma])}</td>'
                      f'<td class="s">{so((r["kq_truoc"] or {}).get(ma, 0))}</td></tr>' for ma, t in bao_cao.THU_TU_B02)
        chon = "".join(f'<option value="{k}"{" selected" if k == nguon else ""}>{t}</option>' for k, t in
                       [("tu_dong", "Theo BCTC đã nộp (nếu có mẫu)"), ("so", "Tính từ sổ")])
        nut = (f'<a class="nut" href="/cty/{cid}/baocao/xml/bctc?nam={nam}&dau={nguon}">Tải XML BCTC cho HTKK</a>' if mau else
               '<span class="mo">Chưa có mẫu XML BCTC: nạp một file BCTC đã xuất từ HTKK ở mục "Mẫu XML và công nợ".</span>')
        return f"""<div class="the"><form class="ngang"><input type="hidden" name="muc" value="bctc">
<label>Năm<input type="number" name="nam" value="{nam}"></label><label>Số đầu năm, năm trước<select name="dau">{chon}</select></label>
<button>Lập</button></form><p class="mo">Số đầu năm lấy từ: {e(r['nguon_dau'])}</p>{_cb(r['canh_bao'])}<p>{nut}</p></div>
<div class="the"><h2>Báo cáo tình hình tài chính (B01a-DNN)</h2>{_bang("".join(b01), ["Mã", "Chỉ tiêu", "Số cuối năm", "Số đầu năm"])}</div>
<div class="the"><h2>Báo cáo kết quả hoạt động kinh doanh (B02-DNN)</h2>{_bang(b02, ["Mã", "Chỉ tiêu", "Năm nay", "Năm trước"])}</div>"""

    # ------------------------------------------------------------ GTGT
    def _gtgt_tinh(self, con, ct, f):
        nam = int(f.get("nam") or date.today().year)
        ky = f.get("ky") or ""
        quy = thang = None
        if ky.startswith("Q"):
            quy = int(ky[1:])
        elif ky:
            thang = int(ky)
        else:
            m = date.today().month
            if ct["ky_ke_khai_gtgt"] == "Q":
                quy = (m - 1) // 3 or 4
            else:
                thang = m - 1 or 12
        nhap = {k: f.get(k, "") for k in ("22", "37", "38", "39a", "40b", "42", "giam_25")}
        return to_khai.gtgt(con, ct["id"], nam, quy, thang, nhap)

    def _bc_gtgt(self, con, ct, nam, q):
        cid = ct["id"]
        v, pl, cb, tt = self._gtgt_tinh(con, ct, {**q, "nam": q.get("nam", nam)})
        ky_hien = tt["ky"].split("-")[1]
        ds_ky = [f"Q{i}" for i in range(1, 5)] if ct["ky_ke_khai_gtgt"] == "Q" else [f"{i:02d}" for i in range(1, 13)]
        chon = "".join(f'<option value="{k if k.startswith("Q") else int(k)}"{" selected" if k == ky_hien else ""}>'
                       f'{"Quý " + k[1:] if k.startswith("Q") else "Tháng " + k}</option>' for k in ds_ky)
        nam_tk = tt["ky"][:4]
        o = lambda k, t: f'<label>{t}<input name="{k}" value="{e(q.get(k, ""))}" size="12"></label>'
        dong = "".join(f'<tr><td>{e(t)}</td><td class="s">{so(v.get(k, 0)) or 0}</td></tr>' for k, t in TEN_GTGT)
        r = con.execute("SELECT ngay_lap FROM to_khai WHERE cong_ty_id=? AND loai='01/GTGT' AND ky=?", (cid, tt["ky"])).fetchone()
        da_luu = r["ngay_lap"] if r else None
        mau = htkk.doc_mau(G.THU_MUC_DL, cid, "01/GTGT")
        qs = urlencode({k: q.get(k, "") for k in ("ky", "22", "37", "38", "39a", "40b", "42", "giam_25")})
        nut = (f'<a class="nut phu" href="/cty/{cid}/baocao/xml/gtgt?nam={nam_tk}&{qs}">Tải XML 01/GTGT</a>' if mau else
               '<span class="mo">Chưa có mẫu XML 01/GTGT. Xuất một tờ khai 01/GTGT bất kỳ từ HTKK (Xuất XML) rồi nạp ở mục '
               '"Mẫu XML và công nợ" để tải được XML. Trong lúc chờ, nhập các số dưới đây vào HTKK.</span>')
        return f"""<div class="the"><form class="ngang"><input type="hidden" name="muc" value="gtgt">
<label>Năm<input type="number" name="nam" value="{nam_tk}"></label><label>Kỳ<select name="ky">{chon}</select></label>
{o("22", "[22] (để trống: lấy [43] kỳ trước)")}{o("37", "[37]")}{o("38", "[38]")}{o("39a", "[39a]")}{o("40b", "[40b]")}
{o("42", "[42] đề nghị hoàn")}{o("giam_25", "Thuế đầu vào không được khấu trừ")}<button>Tính</button></form>
<p class="mo">Nguồn số liệu: {e(tt['nguon'])}{', ' + e(tt.get('nguon_22')) if tt.get('nguon_22') else ''} · kỳ {G.ngay_vn(tt['tu'])} đến {G.ngay_vn(tt['den'])}
{(' · đã lưu ngày ' + G.ngay_vn(da_luu)) if da_luu else ''}</p>
{_cb(cb)}
<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="luu_gtgt"><input type="hidden" name="nam" value="{nam_tk}">
<input type="hidden" name="ky" value="{e(q.get('ky', ''))}">{''.join(f'<input type="hidden" name="{k}" value="{e(q.get(k, ""))}">' for k in ("22", "37", "38", "39a", "40b", "42", "giam_25"))}
<button>Lưu tờ khai kỳ này</button> {nut}</form></div>
<div class="the"><h2>Tờ khai 01/GTGT kỳ {e(tt['ky'])}</h2>{_bang(dong, ["Chỉ tiêu", "Số tiền"])}</div>
<div class="the"><h2>Phụ lục giảm thuế GTGT (thuế suất 10% giảm còn 8%)</h2>
<p>Doanh thu hàng hóa, dịch vụ áp dụng 8%: <b>{so(pl['giam_8']) or 0}</b> đ · Thuế được giảm (2%): <b>{so(pl['giam_thue']) or 0}</b> đ</p></div>"""

    # ------------------------------------------------------------ TNDN
    def _bc_tndn(self, con, ct, nam, q):
        cid = ct["id"]
        v, p, lo, cb, gy = to_khai.tndn(con, cid, nam, {"thue_suat": q.get("thue_suat")})
        dong = "".join(f'<tr><td>{e(t)}</td><td class="s">{so(v.get(k, 0)) or 0}</td></tr>' for k, t in TEN_TNDN)
        dong1a = "".join(f'<tr><td>{e(t)}</td><td class="s">{so(p.get(k, 0)) or 0}</td></tr>' for k, t in TEN_031A)
        dc = con.execute("SELECT * FROM dieu_chinh_tndn WHERE cong_ty_id=? AND nam=? ORDER BY chi_tieu, id", (cid, nam)).fetchall()
        dong_dc = "".join(
            f'<tr><td>{e(r["chi_tieu"])}</td><td>{e(r["noi_dung"])}</td><td class="s">{so(r["so_tien"])}</td>'
            f'<td><form method="post"><input type="hidden" name="hanh_dong" value="xoa_dc"><input type="hidden" name="id" value="{r["id"]}">'
            f'<button class="nut phu">Xóa</button></form></td></tr>' for r in dc) or '<tr><td colspan="4" class="mo">Chưa có.</td></tr>'
        dong_gy = "".join(
            f'<tr><td>{e(c)}</td><td>{e(nd)}</td><td class="s">{so(t)}</td><td><form method="post">'
            f'<input type="hidden" name="hanh_dong" value="them_dc"><input type="hidden" name="chi_tieu" value="{c}">'
            f'<input type="hidden" name="noi_dung" value="{e(nd)}"><input type="hidden" name="so_tien" value="{t}">'
            f'<button class="nut phu">Đưa vào</button></form></td></tr>' for c, nd, t in gy)
        dong_lo = "".join(f'<tr><td>{x["nam_lo"]}</td><td class="s">{so(x["so_lo"])}</td><td class="s">{so(x["da_chuyen"])}</td>'
                          f'<td class="s">{so(x.get("chuyen", 0))}</td><td class="s">{so(x.get("con_sau", 0))}</td></tr>' for x in lo) \
            or '<tr><td colspan="5" class="mo">Không có lỗ được chuyển.</td></tr>'
        chon_ct = "".join(f'<option>{k}</option>' for k in ["B4", "B2", "B3", "B5", "B6", "B7", "B9", "B10", "B11", "B12", "C2"])
        mau = htkk.doc_mau(G.THU_MUC_DL, cid, "03/TNDN")
        nut = (f'<a class="nut phu" href="/cty/{cid}/baocao/xml/tndn?nam={nam}&thue_suat={v["C7_thueSuat"]}">Tải XML 03/TNDN</a>'
               if mau else '<span class="mo">Chưa có mẫu XML 03/TNDN (nạp ở mục "Mẫu XML và công nợ").</span>')
        canh_thue = ('<p class="loi">Có thuế phải nộp: sau khi nhập XML vào HTKK, kiểm tra các chỉ tiêu từ C8 trở đi '
                     f'(HTKK tự tính). Số thuế theo hệ thống: {so(v["thue_phai_nop"])} đ.</p>' if v["thue_phai_nop"] else "")
        return f"""<div class="the"><form class="ngang"><input type="hidden" name="muc" value="tndn">
<label>Năm<input type="number" name="nam" value="{nam}"></label><label>Thuế suất %<input name="thue_suat" value="{v['C7_thueSuat']}" size="4"></label>
<button>Tính</button></form>{_cb(cb)}{canh_thue}
<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="luu_tndn"><input type="hidden" name="thue_suat" value="{v['C7_thueSuat']}">
<button>Lưu quyết toán năm {nam}</button> {nut}</form></div>
<div class="luoi"><div class="the"><h2>Tờ khai 03/TNDN</h2>{_bang(dong, ["Chỉ tiêu", "Số tiền"])}</div>
<div class="the"><h2>Phụ lục 03-1A</h2>{_bang(dong1a, ["Chỉ tiêu", "Số tiền"])}</div></div>
<div class="the"><h2>Các khoản điều chỉnh (chi phí không được trừ...)</h2>{_bang(dong_dc, ["Chỉ tiêu", "Nội dung", "Số tiền", ""])}
<form method="post" class="ngang" style="margin-top:10px"><input type="hidden" name="hanh_dong" value="them_dc">
<label>Chỉ tiêu<select name="chi_tieu">{chon_ct}</select></label><label>Nội dung<input name="noi_dung" size="50"></label>
<label>Số tiền<input name="so_tien" type="number"></label><button>Thêm</button></form>
{('<h2 style="margin-top:14px">Gợi ý nên xem xét</h2>' + _bang(dong_gy, ["Chỉ tiêu", "Nội dung", "Số tiền", ""])) if gy else ''}</div>
<div class="the"><h2>Chuyển lỗ (phụ lục 03-2)</h2>{_bang(dong_lo, ["Năm lỗ", "Số lỗ", "Đã chuyển các năm trước", "Chuyển năm nay", "Còn được chuyển"])}</div>"""

    # ------------------------------------------------------------ TNCN
    def _bc_tncn(self, con, ct, nam, q):
        cid = ct["id"]
        chinh, ds1, t1, ds3, cb = to_khai.tncn(con, cid, nam)
        dong1 = "".join(
            f'<tr><td><input type="checkbox" name="uq_{e(d["ma"])}"{" checked" if d["uy_quyen"] else ""}></td><td>{e(d["ho_ten"])}</td>'
            f'<td>{e(d["mst"] or d["cccd"])}</td><td class="s">{d["thang"]}</td><td class="s">{so(d["tnct"])}</td>'
            f'<td class="s">{d["npt"]}</td><td class="s">{so(d["gt_gc"])}</td><td class="s">{so(d["bh"])}</td>'
            f'<td class="s">{so(d["tntt"])}</td><td class="s">{so(d["thue"])}</td></tr>' for d in ds1) \
            or '<tr><td colspan="10" class="mo">Chưa có bảng lương năm này.</td></tr>'
        dong3 = "".join(f'<tr><td>{e(d["nv_ten"])}</td><td>{e(d["ho_ten"])}</td><td>{e(d["ngay_sinh"])}</td>'
                        f'<td>{e(d["mst"] or d["cccd"])}</td><td>{e(d["qh_ten"])}</td><td>{e(d["tu"])} – {e(d["den"])}</td></tr>'
                        for d in ds3) or '<tr><td colspan="6" class="mo">Không có.</td></tr>'
        tom = (f"Số người lao động [16] {chinh['ct16']} · cư trú có HĐLĐ [17] {chinh['ct17']} · tổng TNCT [23] "
               f"{so(chinh['ct23']) or 0} đ · thuế đã khấu trừ [28] {so(chinh['ct28']) or 0} đ · ủy quyền quyết toán {chinh['ct35']}")
        mau = htkk.doc_mau(G.THU_MUC_DL, cid, "05/QTT")
        nut = (f'<a class="nut phu" href="/cty/{cid}/baocao/xml/tncn?nam={nam}">Tải XML 05/QTT-TNCN</a>'
               if mau else '<span class="mo">Chưa có mẫu XML 05/QTT-TNCN (nạp ở mục "Mẫu XML và công nợ").</span>')
        return f"""<div class="the"><form class="ngang"><input type="hidden" name="muc" value="tncn">
<label>Năm<input type="number" name="nam" value="{nam}"></label><button>Lập</button></form>
<p>{e(tom)}</p>{_cb(cb)}<p>{nut}</p></div>
<div class="the"><h2>Phụ lục 05-1 (cá nhân cư trú có HĐLĐ từ 3 tháng)</h2>
<form method="post"><input type="hidden" name="hanh_dong" value="uy_quyen">
{_bang(dong1, ["Ủy quyền QT", "Họ tên", "MST/CCCD", "Số tháng", "TN chịu thuế", "Số NPT", "Giảm trừ gia cảnh", "Bảo hiểm", "TN tính thuế", "Thuế đã khấu trừ"])}
<p><button>Lưu danh sách ủy quyền</button></p></form></div>
<div class="the"><h2>Phụ lục 05-3 (người phụ thuộc)</h2>{_bang(dong3, ["Người nộp thuế", "Người phụ thuộc", "Ngày sinh", "MST/CCCD", "Quan hệ", "Thời gian tính giảm trừ"])}</div>"""

    # ------------------------------------------------------------ mau
    def _bc_mau(self, con, ct, nam, q):
        cid = ct["id"]
        dong = []
        for loai in ("BCTC", "01/GTGT", "03/TNDN", "05/QTT"):
            b = htkk.doc_mau(G.THU_MUC_DL, cid, loai)
            if b:
                tt = htkk.thong_tin(htkk.doc(b))
                cb = to_khai.kiem_tra_mau(ct, tt)
                dong.append(f'<tr><td>{loai}</td><td>{e(tt["ky"])}</td><td>{e(tt["phien_ban"])}</td><td>{e(tt["ten_nnt"])}</td>'
                            f'<td>{_cb(cb) or "<span class=ok>Khớp</span>"}</td></tr>')
            else:
                dong.append(f'<tr><td>{loai}</td><td colspan="4" class="mo">Chưa có</td></tr>')
        cn = con.execute("SELECT ngay, so_tk, COUNT(*) n, SUM(du_no) no, SUM(du_co) co FROM cong_no_doi_tuong WHERE cong_ty_id=? "
                         "GROUP BY ngay, so_tk ORDER BY ngay DESC, so_tk", (cid,)).fetchall()
        dong_cn = "".join(f'<tr><td>{G.ngay_vn(bao_cao.ngay_truoc(r["ngay"]))}</td><td>{r["so_tk"]}</td><td class="s">{r["n"]}</td>'
                          f'<td class="s">{so(r["no"])}</td><td class="s">{so(r["co"])}</td></tr>' for r in cn) \
            or '<tr><td colspan="5" class="mo">Chưa nạp.</td></tr>'
        return f"""<div class="the"><h2>Nạp file</h2>
<p class="mo">Chọn một hoặc nhiều file: tờ khai XML đã xuất từ HTKK (BCTC, 01/GTGT, 03/TNDN, 05/QTT-TNCN) dùng làm mẫu, và bảng
"Tổng hợp công nợ phải thu/phải trả" của MISA (Excel) để tách số dư hai bên TK 131, 331 khi sổ chưa theo dõi từng đối tượng.</p>
<form method="post" enctype="multipart/form-data" class="ngang"><input type="hidden" name="hanh_dong" value="mau">
<input type="file" name="tep" multiple accept=".xml,.xlsx,.xls"><button>Nạp</button></form></div>
<div class="the"><h2>Mẫu XML đang có</h2>{_bang("".join(dong), ["Loại", "Kỳ của mẫu", "Phiên bản", "Tên người nộp trong mẫu", "Kiểm tra"])}</div>
<div class="the"><h2>Số dư công nợ theo đối tượng đã nạp</h2>{_bang(dong_cn, ["Ngày", "TK", "Số đối tượng", "Dư Nợ", "Dư Có"])}</div>"""

    # ------------------------------------------------------------ ket chuyen
    def _bc_ketchuyen(self, con, ct, nam, q):
        thang = date.today().strftime("%Y-%m")
        return f"""<div class="the"><h2>Kết chuyển doanh thu, chi phí sang 911 và lãi lỗ sang 4212</h2>
<p class="mo">Làm cuối mỗi tháng hoặc quý. Chạy lại sẽ thay chứng từ kết chuyển cũ của tháng đó.</p>
<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="ket_chuyen">
<label>Từ ngày<input type="date" name="tu" value="{thang}-01"></label><label>Đến ngày<input type="date" name="den" value="{thang}-28"></label>
<button>Kết chuyển</button></form></div>
<div class="the"><h2>Chuyển lợi nhuận năm nay sang năm trước (4212 → 4211)</h2>
<p class="mo">Làm một lần sau khi khóa sổ năm, chứng từ ghi ngày 01/01 năm sau.</p>
<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="chuyen_nam">
<label>Năm<input type="number" name="nam_kc" value="{nam}"></label><button>Chuyển</button></form></div>"""

    # ------------------------------------------------------------ tai XML
    def _xml(self, con, ct, loai, q):
        cid = ct["id"]
        nam = int(q.get("nam") or date.today().year - 1)
        can = {"bctc": "BCTC", "gtgt": "01/GTGT", "tndn": "03/TNDN", "tncn": "05/QTT"}.get(loai)
        if can and not htkk.doc_mau(G.THU_MUC_DL, cid, can):
            return self.gui(G.trang("Chưa có mẫu", f'<div class="the"><p class="loi">Chưa có mẫu XML {can}. Vào '
                                    f'<a href="/cty/{cid}/baocao?muc=mau">Mẫu XML và công nợ</a> để nạp một file {can} '
                                    'đã xuất từ HTKK.</p></div>', cid, ct["ten"]), 400)
        if loai == "bctc":
            mau = htkk.doc_mau(G.THU_MUC_DL, cid, "BCTC")
            r = to_khai.bctc(con, cid, nam, mau, q.get("dau", "tu_dong"))
            b = htkk.lap_bctc(mau, ct, nam, r["cuoi"], r["dau"], r["kq_nay"], r["kq_truoc"], r["cdtk"])
            ten = htkk.ten_file(ct["mst"], "BCTC", f"Y{nam}")
        elif loai == "gtgt":
            mau = htkk.doc_mau(G.THU_MUC_DL, cid, "01/GTGT")
            v, pl, cb, tt = self._gtgt_tinh(con, ct, q)
            ky = tt["ky"].split("-")[1]
            quy = int(ky[1:]) if ky.startswith("Q") else None
            b = htkk.lap_01gtgt(mau, ct, int(tt["ky"][:4]), quy, None if quy else int(ky), v)
            ten = htkk.ten_file(ct["mst"], "01/GTGT", f"{ky}{tt['ky'][:4]}")
        elif loai == "tndn":
            mau = htkk.doc_mau(G.THU_MUC_DL, cid, "03/TNDN")
            v, p, lo, cb, _ = to_khai.tndn(con, cid, nam, {"thue_suat": q.get("thue_suat")})
            b = htkk.lap_03(mau, ct, nam, v, p, lo)
            ten = htkk.ten_file(ct["mst"], "03/TNDN", f"Y{nam}")
        elif loai == "tncn":
            mau = htkk.doc_mau(G.THU_MUC_DL, cid, "05/QTT")
            chinh, ds1, t1, ds3, cb = to_khai.tncn(con, cid, nam)
            b = htkk.lap_05(mau, ct, nam, chinh, ds1, t1, ds3)
            ten = htkk.ten_file(ct["mst"], "05/QTT", f"Y{nam}")
        else:
            return self.gui("Không có loại này", 404)
        thu_muc = G.THU_MUC_DL / "xuat" / str(cid)
        thu_muc.mkdir(parents=True, exist_ok=True)
        (thu_muc / ten).write_bytes(b)
        self.send_response(200)
        self.send_header("Content-Type", "application/xml")
        self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quote(ten)}")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)
