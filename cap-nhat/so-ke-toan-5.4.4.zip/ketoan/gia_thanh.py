"""Gia thanh: tap hop chi phi san xuat, xay lap theo doi tuong (cong trinh, san pham, don hang) tren TK 154,
phan bo chi phi chung, tinh gia thanh va ket chuyen gia von khi hoan thanh.

- Chi phi cua doi tuong = cac dong No 154 co doi_tuong_no = ma doi tuong (phieu xuat kho cho cong trinh, luong
  cong nhan, khau hao may, dich vu mua ngoai...). Khoan muc xac dinh theo TK doi ung (ben Co).
- Chi phi 154 chua gan doi tuong = chi phi chung, phan bo theo ty le chi phi nguyen vat lieu hoac theo du toan:
  No 154 (doi tuong) / Co 154 (khong doi tuong).
- Doanh nghiep theo TT99 hach toan qua 621, 622, 623, 627: ket chuyen sang 154 theo doi tuong truoc khi tinh.
- Hoan thanh: No 632 (cong trinh, dich vu ban ngay) hoac No 155 (san pham nhap kho) / Co 154 (doi tuong).
"""
from datetime import date

from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS doi_tuong_gia_thanh (
    id INTEGER PRIMARY KEY,
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    ma TEXT NOT NULL,
    ten TEXT NOT NULL,
    loai TEXT NOT NULL DEFAULT 'cong_trinh',   -- cong_trinh | san_pham | don_hang
    du_toan INTEGER NOT NULL DEFAULT 0,
    ngay_bat_dau TEXT,
    ngay_hoan_thanh TEXT,
    trang_thai TEXT NOT NULL DEFAULT 'dang',   -- dang | xong
    UNIQUE (cong_ty_id, ma)
);
"""

LOAI = {"cong_trinh": "Công trình, hạng mục", "san_pham": "Sản phẩm", "don_hang": "Đơn hàng, dịch vụ"}
KHOAN_MUC = [("nvl", "Nguyên vật liệu trực tiếp"), ("nc", "Nhân công trực tiếp"), ("may", "Máy thi công"),
             ("sxc", "Chi phí sản xuất chung")]
TK_TRUNG_GIAN = {"621": "nvl", "622": "nc", "623": "may", "627": "sxc"}


def chuan_bi(con):
    con.executescript(SCHEMA)


def khoan_muc(tk_co):
    if tk_co.startswith(("152", "153", "156", "621", "1561")):
        return "nvl"
    if tk_co.startswith(("334", "338", "622")):
        return "nc"
    if tk_co.startswith("623"):
        return "may"
    return "sxc"


def them(con, cid, d):
    chuan_bi(con)
    ma, ten = (d.get("ma") or "").strip(), (d.get("ten") or "").strip()
    if not ma or not ten:
        raise ValueError("Cần mã và tên đối tượng tính giá thành.")
    if d.get("loai", "cong_trinh") not in LOAI:
        raise ValueError("Loại không đúng.")
    cur = con.execute("INSERT INTO doi_tuong_gia_thanh (cong_ty_id, ma, ten, loai, du_toan, ngay_bat_dau) VALUES (?,?,?,?,?,?)",
                      (cid, ma, ten, d.get("loai", "cong_trinh"), int(d.get("du_toan") or 0), d.get("ngay_bat_dau") or None))
    con.commit()
    return cur.lastrowid


def danh_sach(con, cid):
    chuan_bi(con)
    return con.execute("SELECT * FROM doi_tuong_gia_thanh WHERE cong_ty_id=? ORDER BY trang_thai, ma", (cid,)).fetchall()


def lay(con, cid, did):
    chuan_bi(con)
    return con.execute("SELECT * FROM doi_tuong_gia_thanh WHERE cong_ty_id=? AND id=?", (cid, did)).fetchone()


def _dong_154(con, cid, den, tu=None):
    q = ("SELECT c.ngay_ht, c.so_ct, COALESCE(b.dien_giai, c.dien_giai, '') dg, b.tk_no, b.tk_co, b.so_tien, b.doi_tuong_no, "
         "b.doi_tuong_co FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? AND c.ngay_ht<=? "
         "AND (b.tk_no LIKE '154%' OR b.tk_co LIKE '154%')")
    a = [cid, den]
    if tu:
        q, a = q + " AND c.ngay_ht>=?", a + [tu]
    return [dict(r) for r in con.execute(q + " ORDER BY c.ngay_ht, c.so_ct", a)]


def tinh(con, cid, ma, tu, den):
    """The tinh gia thanh cua doi tuong `ma` tu `tu` den `den`.
    Tra ve {'dau': {km}, 'ps': {km}, 'ra': tong ket chuyen ra, 'cuoi': du cuoi, 'dong': chi tiet phat sinh}."""
    dau = {k: 0 for k, _ in KHOAN_MUC}
    ps = {k: 0 for k, _ in KHOAN_MUC}
    ra_truoc = ra = 0
    dong = []
    for r in _dong_154(con, cid, den):
        trong_ky = r["ngay_ht"] >= tu
        if r["tk_no"].startswith("154") and r["doi_tuong_no"] == ma:
            km = "sxc" if r["tk_co"].startswith("154") else khoan_muc(r["tk_co"])
            (ps if trong_ky else dau)[km] += r["so_tien"]
            if trong_ky:
                dong.append({**r, "km": km, "no": r["so_tien"], "co": 0})
        if r["tk_co"].startswith("154") and r["doi_tuong_co"] == ma:
            if trong_ky:
                ra += r["so_tien"]
                dong.append({**r, "km": "", "no": 0, "co": r["so_tien"]})
            else:
                ra_truoc += r["so_tien"]
    # Phan da ket chuyen truoc ky tru vao do dang dau ky theo ty trong khoan muc
    tong_dau = sum(dau.values())
    if ra_truoc and tong_dau:
        for k in dau:
            dau[k] -= round(dau[k] * min(ra_truoc, tong_dau) / tong_dau)
    cuoi = sum(dau.values()) + sum(ps.values()) - ra
    return {"dau": dau, "ps": ps, "ra": ra, "cuoi": cuoi, "dong": dong}


def chi_phi_chung_chua_phan_bo(con, cid, tu, den):
    """Chi phi No 154 khong gan doi tuong trong ky, tru phan da phan bo (Co 154 khong doi tuong sang 154 co doi tuong)."""
    s = 0
    for r in _dong_154(con, cid, den, tu):
        if r["tk_no"].startswith("154") and not r["doi_tuong_no"] and not r["tk_co"].startswith("154"):
            s += r["so_tien"]
        if r["tk_co"].startswith("154") and not r["doi_tuong_co"] and r["tk_no"].startswith("154") and r["doi_tuong_no"]:
            s -= r["so_tien"]
    return s


def phan_bo(con, cid, tu, den, tieu_thuc="nvl", ngay=None):
    """Phan bo chi phi chung chua gan doi tuong cho cac doi tuong dang thuc hien. Tra ve {ma: so tien}."""
    tong = chi_phi_chung_chua_phan_bo(con, cid, tu, den)
    if tong <= 0:
        return {}
    ds = [d for d in danh_sach(con, cid) if d["trang_thai"] == "dang"]
    if tieu_thuc == "du_toan":
        co_so = {d["ma"]: d["du_toan"] for d in ds}
    else:
        co_so = {d["ma"]: tinh(con, cid, d["ma"], tu, den)["ps"]["nvl"] for d in ds}
    tong_cs = sum(v for v in co_so.values() if v > 0)
    if not tong_cs:
        raise ValueError("Không có cơ sở phân bổ: các đối tượng chưa có chi phí nguyên vật liệu trong kỳ (hoặc chưa nhập dự toán).")
    kq, con_lai = {}, tong
    ma_cuoi = [m for m, v in co_so.items() if v > 0][-1]
    for m, v in co_so.items():
        if v <= 0:
            continue
        kq[m] = con_lai if m == ma_cuoi else round(tong * v / tong_cs)
        con_lai -= kq[m] if m != ma_cuoi else 0
    so_ct = f"PBGT-{den.replace('-', '')}"
    if con.execute("SELECT 1 FROM chung_tu WHERE cong_ty_id=? AND so_ct=?", (cid, so_ct)).fetchone():
        raise ValueError(f"Kỳ này đã phân bổ ({so_ct}). Xóa chứng từ đó nếu cần phân bổ lại.")
    ngay = ngay or den
    db.ghi_chung_tu(con, cid, so_ct, ngay, ngay,
                    [{"tk_no": "154", "tk_co": "154", "so_tien": t, "doi_tuong_no": m,
                      "dien_giai": f"Phân bổ chi phí chung cho {m}"} for m, t in kq.items() if t > 0],
                    loai="NV", dien_giai="Phân bổ chi phí sản xuất chung", nguon="gia_thanh")
    con.commit()
    return kq


def ket_chuyen_trung_gian(con, cid, tu, den):
    """TT99: ket chuyen so du 621, 622, 623, 627 theo doi tuong sang 154. Tra ve so dong ghi."""
    gop = {}
    q = ("SELECT b.tk_no, b.tk_co, b.so_tien, b.doi_tuong_no, b.doi_tuong_co FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id "
         "WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ?")
    for r in con.execute(q, (cid, tu, den)):
        for tk, dt, dau in ((r["tk_no"], r["doi_tuong_no"], 1), (r["tk_co"], r["doi_tuong_co"], -1)):
            goc = tk[:3]
            if goc in TK_TRUNG_GIAN:
                gop[(tk, dt or "")] = gop.get((tk, dt or ""), 0) + dau * r["so_tien"]
    dong = [{"tk_no": "154", "tk_co": tk, "so_tien": v, "doi_tuong_no": dt, "doi_tuong_co": dt,
             "dien_giai": f"Kết chuyển {tk} sang 154" + (f" - {dt}" if dt else "")} for (tk, dt), v in sorted(gop.items()) if v > 0]
    if not dong:
        return 0
    so_ct = f"KC154-{den.replace('-', '')}"
    if con.execute("SELECT 1 FROM chung_tu WHERE cong_ty_id=? AND so_ct=?", (cid, so_ct)).fetchone():
        raise ValueError(f"Kỳ này đã kết chuyển ({so_ct}).")
    db.them_tai_khoan(con, cid, "154", "Chi phí sản xuất, kinh doanh dở dang")
    db.ghi_chung_tu(con, cid, so_ct, den, den, dong, loai="KC", dien_giai="Kết chuyển chi phí sản xuất sang 154", nguon="gia_thanh")
    con.commit()
    return len(dong)


def hoan_thanh(con, cid, did, ngay, tk_no=None, so_tien=None):
    """Ket chuyen gia thanh: No 632/155 / Co 154 (doi tuong). so_tien mac dinh = toan bo do dang den ngay."""
    d = lay(con, cid, did)
    if not d:
        raise ValueError("Không có đối tượng này.")
    tk_no = tk_no or ("155" if d["loai"] == "san_pham" else "632")
    du = tinh(con, cid, d["ma"], "0000-01-01", ngay)["cuoi"]
    tien = du if so_tien is None else int(so_tien)
    if tien <= 0:
        raise ValueError("Không còn chi phí dở dang để kết chuyển.")
    db.them_tai_khoan(con, cid, tk_no, f"TK {tk_no}")
    so_ct = f"GT-{d['ma']}-{ngay.replace('-', '')}"
    ct = db.ghi_chung_tu(con, cid, so_ct, ngay, ngay,
                         [{"tk_no": tk_no, "tk_co": "154", "so_tien": tien, "doi_tuong_co": d["ma"],
                           "dien_giai": f"Kết chuyển giá thành {d['ten']}"}], loai="KC", nguon="gia_thanh",
                         dien_giai=f"Giá thành {d['ten']}")
    if tien >= du:
        con.execute("UPDATE doi_tuong_gia_thanh SET trang_thai='xong', ngay_hoan_thanh=? WHERE id=?", (ngay, did))
    con.commit()
    return ct


def tong_hop(con, cid, tu, den):
    """Bang tong hop chi phi, gia thanh tat ca doi tuong trong ky."""
    return [(d, tinh(con, cid, d["ma"], tu, den)) for d in danh_sach(con, cid)]
