"""Cac viec AI lam tren so lieu cua mot cong ty (dung tro_ly_ai de goi hang AI khach da chon):

- hoi_dap: hoi dap tieng Viet tren so lieu (AI chi doc ban tom tat so lieu may tinh san, khong tu sua du lieu).
- doc_chung_tu: doc hoa don PDF / anh chup / bien lai thanh du lieu co cau truc + but toan goi y.
- kiem_tra_so (khong can AI) + soat_so: soat so truoc khi khoa so, canh bao rui ro thue.
- chuoi_thang + phan_tich: phan tich tai chinh 12 thang va du bao dong tien 3 thang.
- soan_nhac_no: soan tin nhac no cho khach qua han.
"""
import html
import json
import re
from datetime import date, timedelta

from . import bao_cao, quan_ly, so_sach, to_khai
from . import tro_ly_ai as AI


def _f(v):
    return f"{int(round(v or 0)):,}".replace(",", ".")


def ky_du_lieu(con, cid):
    """(tu, den) mac dinh: tu dau nam den ngay cuoi co chung tu (hoac hom nay)."""
    r = con.execute("SELECT MAX(ngay_ht) n FROM chung_tu WHERE cong_ty_id=?", (cid,)).fetchone()
    den = (r["n"] if r and r["n"] else date.today().isoformat())
    return f"{den[:4]}-01-01", den


def _cong_ty(con, cid):
    r = con.execute("SELECT * FROM cong_ty WHERE id=?", (cid,)).fetchone()
    return r


def _thang(tu, den):
    """Danh sach (thang 'YYYY-MM', ngay dau, ngay cuoi) trong ky."""
    ds = []
    d = date.fromisoformat(tu[:8] + "01")
    het = date.fromisoformat(den)
    while d <= het:
        sau = (d.replace(day=28) + timedelta(days=4)).replace(day=1)
        ds.append((d.isoformat()[:7], max(d.isoformat(), tu), min((sau - timedelta(days=1)).isoformat(), den)))
        d = sau
    return ds


# ================================================================ boi canh so lieu

def chuoi_thang(con, cid, den, so_thang=12):
    """Chuoi so lieu theo thang (so_thang thang ket thuc o thang cua `den`): doanh thu, chi phi, lai, thu, chi, tien cuoi."""
    d = date.fromisoformat(den[:8] + "01")
    for _ in range(so_thang - 1):
        d = (d - timedelta(days=1)).replace(day=1)
    kq = []
    for th, a, b in _thang(d.isoformat(), den):
        k = bao_cao.b02(con, cid, a, b)
        r = con.execute(
            "SELECT COALESCE(SUM(CASE WHEN (b.tk_no LIKE '111%' OR b.tk_no LIKE '112%') AND b.tk_co NOT LIKE '111%' "
            "AND b.tk_co NOT LIKE '112%' THEN b.so_tien END),0) thu, "
            "COALESCE(SUM(CASE WHEN (b.tk_co LIKE '111%' OR b.tk_co LIKE '112%') AND b.tk_no NOT LIKE '111%' "
            "AND b.tk_no NOT LIKE '112%' THEN b.so_tien END),0) chi "
            "FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ?",
            (cid, a, b)).fetchone()
        bang, _ = bao_cao.phan_hai_ben(con, cid, bao_cao.ngay_sau(b))
        tien = sum(n - c for t, (n, c) in bang.items() if t.startswith(("111", "112")))
        chi_phi = k["11"] + k["22"] + k["24"] + k["32"]
        kq.append({"thang": th, "doanh_thu": k["10"], "chi_phi": chi_phi, "lai": k["50"], "thu_tien": r["thu"],
                   "chi_tien": r["chi"], "tien_cuoi": tien})
    return kq


def _cong_no(con, cid, tk, ngay, n=15):
    ds, _ = quan_ly.tuoi_no(con, cid, tk, ngay)
    return [{"ma": x["ma"], "ten": x["ten"], "con_no": x["tong"], "0_30": x["nhom"][0], "31_60": x["nhom"][1],
             "61_90": x["nhom"][2], "tren_90": x["nhom"][3], "lau_nhat_ngay": x["lau_nhat"]} for x in ds[:n] if x["tong"]]


def boi_canh_so_lieu(con, cid, tu, den):
    """Ban tom tat so lieu (chu) de AI doc. Chi gom so lieu da tinh san, khong gom du lieu ca nhan nhan vien."""
    ct = _cong_ty(con, cid)
    phan = [f"Công ty: {ct['ten']} (MST {ct['mst']}). Chế độ kế toán TT133. Kỳ đang xem: {tu} đến {den}. "
            f"Đơn vị tiền: đồng. Hôm nay: {date.today().isoformat()}."]
    k = bao_cao.b02(con, cid, tu, den)
    ten = {"01": "Doanh thu bán hàng", "02": "Giảm trừ doanh thu", "10": "Doanh thu thuần", "11": "Giá vốn",
           "20": "Lợi nhuận gộp", "21": "Doanh thu tài chính", "22": "Chi phí tài chính", "24": "Chi phí quản lý kinh doanh",
           "30": "Lợi nhuận thuần từ HĐKD", "31": "Thu nhập khác", "32": "Chi phí khác", "50": "Lợi nhuận trước thuế",
           "51": "Chi phí thuế TNDN", "60": "Lợi nhuận sau thuế"}
    phan.append("KẾT QUẢ KINH DOANH CẢ KỲ:\n" + "\n".join(f"- {t}: {_f(k[m])}" for m, t in ten.items()))
    th = chuoi_thang(con, cid, den, min(12, len(_thang(tu, den))))
    phan.append("THEO THÁNG (doanh thu thuần | chi phí | lợi nhuận trước thuế | thu tiền | chi tiền | tiền cuối tháng):\n"
                + "\n".join(f"- {x['thang']}: {_f(x['doanh_thu'])} | {_f(x['chi_phi'])} | {_f(x['lai'])} | {_f(x['thu_tien'])} | "
                            f"{_f(x['chi_tien'])} | {_f(x['tien_cuoi'])}" for x in th))
    cd = so_sach.tong_hop_tai_khoan(con, cid, tu, den)
    dong = [f"- {r['so_tk']} {r['ten']}: đầu kỳ Nợ {_f(r['dau_no'])} Có {_f(r['dau_co'])}; phát sinh Nợ {_f(r['ps_no'])} "
            f"Có {_f(r['ps_co'])}; cuối kỳ Nợ {_f(r['cuoi_no'])} Có {_f(r['cuoi_co'])}"
            for r in cd if any(r[x] for x in ("dau_no", "dau_co", "ps_no", "ps_co", "cuoi_no", "cuoi_co")) and len(r["so_tk"]) <= 4]
    phan.append("BẢNG CÂN ĐỐI TÀI KHOẢN (tài khoản cấp 1, 2):\n" + "\n".join(dong[:200]))
    for tk, t in (("131", "PHẢI THU KHÁCH HÀNG"), ("331", "PHẢI TRẢ NHÀ CUNG CẤP")):
        cn = _cong_no(con, cid, tk, bao_cao.ngay_sau(den))
        if cn:
            phan.append(f"{t} lớn nhất tại {den} (còn nợ, theo tuổi nợ 0-30 / 31-60 / 61-90 / trên 90 ngày):\n" + "\n".join(
                f"- {x['ten']} ({x['ma'] or 'chưa gắn mã'}): {_f(x['con_no'])} = {_f(x['0_30'])} / {_f(x['31_60'])} / "
                f"{_f(x['61_90'])} / {_f(x['tren_90'])}" for x in cn))
    v = quan_ly.viec_can_lam(con, ct)
    if v:
        phan.append("VIỆC CẦN LÀM MÁY ĐÃ PHÁT HIỆN:\n" + "\n".join(f"- {x[1]}" for x in v))
    return "\n\n".join(phan)


# ================================================================ hoi dap

HE_THONG_HOI = (
    "Bạn là kế toán trưởng Việt Nam giỏi, trả lời chủ doanh nghiệp và kế toán viên bằng tiếng Việt, ngắn gọn, dễ hiểu, "
    "có số liệu cụ thể (định dạng 1.234.567 đ). Chỉ dùng số liệu được cung cấp; nếu không đủ số liệu để trả lời thì nói rõ "
    "cần xem thêm sổ nào trong phần mềm. Không bịa số. Có thể nêu căn cứ TT133, luật thuế khi liên quan, kèm lưu ý kiểm tra lại "
    "văn bản mới nhất. Dùng gạch đầu dòng và bảng Markdown khi giúp dễ đọc."
)
CAU_HOI_MAU = ["Kỳ này lãi hay lỗ bao nhiêu, vì sao?", "Khách nào nợ quá hạn nhiều nhất?",
               "Chi phí tháng nào tăng bất thường?", "Tiền mặt và tiền gửi còn bao nhiêu, đủ chi mấy tháng?",
               "Cần làm gì trước khi nộp tờ khai quý này?", "Tóm tắt tình hình tài chính để báo cáo giám đốc"]


def hoi_dap(con, cid, cau_hoi, tu, den, lich_su=None, cd=None):
    bc = boi_canh_so_lieu(con, cid, tu, den)
    return AI.hoi(HE_THONG_HOI + "\n\nSỐ LIỆU SỔ SÁCH:\n" + bc, cau_hoi, cd, toi_da=3000, lich_su=(lich_su or [])[-8:])


# ================================================================ doc chung tu (PDF / anh)

HE_THONG_DOC = (
    "Bạn là kế toán Việt Nam, đọc chứng từ (hóa đơn GTGT, hóa đơn bán hàng, phiếu thu/chi, biên lai, vé, hóa đơn bán lẻ) từ ảnh "
    "hoặc PDF và hạch toán theo TT133. Đọc chính xác từng chữ số; số tiền là số nguyên đồng, không dấu chấm phân cách. "
    "Ngày dạng YYYY-MM-DD. Chỉ dùng tài khoản có trong danh mục được cung cấp. Trả lời DUY NHẤT bằng JSON."
)


def doc_chung_tu(con, cid, ten_file, du_lieu, cd=None):
    """Doc mot chung tu. Tra ve dict da kiem tra: loai ('hoa_don' | 'chung_tu'), chieu, cac truong hoa don, dong_hang
    (kem tk goi y), but_toan goi y, canh_bao (list chu)."""
    import os
    duoi = os.path.splitext(ten_file.lower())[1]
    mime = AI.KIEU_TEP.get(duoi)
    if not mime:
        raise AI.LoiAI("Chỉ đọc được file PDF hoặc ảnh JPG, PNG, WEBP.")
    if len(du_lieu) > 15 * 1024 * 1024:
        raise AI.LoiAI("File lớn quá 15 MB, hãy chụp lại hoặc nén nhỏ hơn.")
    ct = _cong_ty(con, cid)
    dm = {r["so_tk"]: r["ten"] for r in con.execute("SELECT so_tk, ten FROM tai_khoan WHERE cong_ty_id=? ORDER BY so_tk", (cid,))}
    cau = (f"Công ty của chúng tôi: {ct['ten']}, MST {ct['mst']}. Nếu người bán là công ty chúng tôi thì đây là hóa đơn BÁN RA, "
           "nếu người mua là chúng tôi (hoặc không ghi người mua) thì là MUA VÀO.\n"
           f"Danh mục tài khoản:\n" + "\n".join(f"{k}: {v}" for k, v in dm.items()) + "\n\n"
           "Trả về JSON đúng mẫu sau (bỏ trống trường không có):\n"
           '{"loai": "hoa_don" nếu là hóa đơn GTGT/hóa đơn bán hàng có ký hiệu và số hóa đơn, ngược lại "chung_tu",\n'
           ' "chieu": "mua" | "ban", "mau_so": "1", "ky_hieu": "C25TAA", "so": "123", "ngay": "2025-06-30",\n'
           ' "nb_mst": "", "nb_ten": "", "nm_mst": "", "nm_ten": "", "tien_hang": 0, "tien_thue": 0, "tong_tien": 0,\n'
           ' "hinh_thuc_tt": "tiền mặt | chuyển khoản | chưa rõ", "dien_giai": "nội dung ngắn",\n'
           ' "dong_hang": [{"ten": "", "dvt": "", "so_luong": 0, "don_gia": 0, "thanh_tien": 0, "thue_suat": "10%", "tk": "156"}],\n'
           ' "but_toan": [{"tk_no": "6422", "tk_co": "1111", "so_tien": 0, "dien_giai": ""}],\n'
           ' "do_tin_cay": "cao | trung bình | thấp", "ghi_chu": "chỗ mờ, không chắc"}\n'
           "dong_hang[].tk: tài khoản Nợ (mua) hoặc Có doanh thu (bán) cho từng mặt hàng. but_toan: định khoản đầy đủ của chứng từ "
           "(gồm thuế 1331 / 33311, đối ứng 331 / 131 nếu chưa thanh toán, 111x / 112x nếu đã trả).")
    kq = AI.doc_json(AI.hoi(HE_THONG_DOC, cau, cd, toi_da=4000, tep=[(mime, du_lieu)]))
    if not isinstance(kq, dict):
        raise AI.LoiAI("AI trả lời không đúng định dạng, thử lại.")
    return chuan_hoa_doc(con, cid, kq, dm)


def _so(v):
    if isinstance(v, (int, float)):
        return int(round(v))
    s = re.sub(r"[^\d\-,.]", "", str(v or ""))
    if not s:
        return 0
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif s.count(".") > 1 or (s.count(".") == 1 and len(s.split(".")[1]) == 3):
        s = s.replace(".", "")
    elif "," in s:
        s = s.replace(",", "") if len(s.split(",")[-1]) == 3 else s.replace(",", ".")
    try:
        return int(round(float(s)))
    except ValueError:
        return 0


def chuan_hoa_doc(con, cid, kq, dm=None):
    """Kiem tra, lam sach ket qua AI doc chung tu."""
    if dm is None:
        dm = {r["so_tk"]: r["ten"] for r in con.execute("SELECT so_tk, ten FROM tai_khoan WHERE cong_ty_id=?", (cid,))}
    ct = _cong_ty(con, cid)
    canh_bao = []
    s = lambda k: str(kq.get(k) or "").strip()
    mst = lambda k: re.sub(r"[^\d\-]", "", s(k))
    ra = {"loai": "hoa_don" if s("loai") == "hoa_don" else "chung_tu", "mau_so": s("mau_so"), "ky_hieu": s("ky_hieu"),
          "so": s("so").lstrip("0") or s("so"), "ngay": s("ngay")[:10], "nb_mst": mst("nb_mst"), "nb_ten": s("nb_ten"),
          "nm_mst": mst("nm_mst"), "nm_ten": s("nm_ten"), "tien_hang": _so(kq.get("tien_hang")),
          "tien_thue": _so(kq.get("tien_thue")), "tong_tien": _so(kq.get("tong_tien")), "hinh_thuc_tt": s("hinh_thuc_tt"),
          "dien_giai": s("dien_giai")[:250], "do_tin_cay": s("do_tin_cay"), "ghi_chu": s("ghi_chu")[:300]}
    ra["chieu"] = "ban" if ra["nb_mst"] == ct["mst"] else ("mua" if s("chieu") != "ban" else "ban")
    try:
        date.fromisoformat(ra["ngay"])
    except ValueError:
        canh_bao.append("Không đọc được ngày chứng từ, hãy nhập lại.")
        ra["ngay"] = ""
    ra["dong_hang"] = []
    for d in kq.get("dong_hang") or []:
        if not isinstance(d, dict) or not str(d.get("ten") or "").strip():
            continue
        tk = str(d.get("tk") or "").strip()
        ra["dong_hang"].append({"ten": str(d["ten"]).strip()[:250], "dvt": str(d.get("dvt") or "")[:20],
                                "so_luong": d.get("so_luong") or "", "don_gia": _so(d.get("don_gia")),
                                "thanh_tien": _so(d.get("thanh_tien")), "thue_suat": str(d.get("thue_suat") or "")[:10],
                                "tk": tk if tk in dm else ""})
    ra["but_toan"] = []
    for d in kq.get("but_toan") or []:
        if not isinstance(d, dict):
            continue
        no, co, tien = str(d.get("tk_no") or "").strip(), str(d.get("tk_co") or "").strip(), _so(d.get("so_tien"))
        if tien <= 0:
            continue
        if no not in dm or co not in dm:
            canh_bao.append(f"AI đề nghị tài khoản {no if no not in dm else co} không có trong danh mục: đã bỏ trống, hãy chọn lại.")
            no, co = (no if no in dm else ""), (co if co in dm else "")
        ra["but_toan"].append({"tk_no": no, "tk_co": co, "so_tien": tien, "dien_giai": str(d.get("dien_giai") or ra["dien_giai"])[:250]})
    if ra["dong_hang"]:
        tong_dong = sum(d["thanh_tien"] for d in ra["dong_hang"])
        if ra["tien_hang"] and abs(tong_dong - ra["tien_hang"]) > max(2, len(ra["dong_hang"])):
            canh_bao.append(f"Tổng thành tiền các dòng ({_f(tong_dong)}) khác tiền hàng ({_f(ra['tien_hang'])}): kiểm tra lại.")
    if ra["tong_tien"] and ra["tien_hang"] and abs(ra["tien_hang"] + ra["tien_thue"] - ra["tong_tien"]) > 2:
        canh_bao.append("Tiền hàng + thuế khác tổng tiền thanh toán: kiểm tra lại.")
    if ra["but_toan"] and ra["tong_tien"]:
        no_tong = sum(d["so_tien"] for d in ra["but_toan"])
        if abs(no_tong - ra["tong_tien"]) > 2:
            canh_bao.append(f"Tổng định khoản ({_f(no_tong)}) khác tổng tiền chứng từ ({_f(ra['tong_tien'])}).")
    nguong = to_khai._nguong_tien_mat(ra["ngay"] or date.today().isoformat())
    if ra["chieu"] == "mua" and ra["tien_thue"] and ra["tong_tien"] >= nguong and "mặt" in ra["hinh_thuc_tt"].lower():
        canh_bao.append(f"Hóa đơn mua từ {_f(nguong)} đ trả tiền mặt: thuế GTGT đầu vào không được khấu trừ, "
                        "chi phí có thể bị loại khi quyết toán TNDN.")
    if ra["loai"] == "hoa_don" and not (ra["ky_hieu"] and ra["so"] and (ra["nb_mst"] if ra["chieu"] == "mua" else True)):
        canh_bao.append("Thiếu ký hiệu, số hóa đơn hoặc MST người bán: bổ sung trước khi lưu.")
    if ra["do_tin_cay"] and ra["do_tin_cay"] != "cao":
        canh_bao.append(f"AI tự đánh giá độ tin cậy: {ra['do_tin_cay']}. {ra['ghi_chu']}".strip())
    ra["canh_bao"] = canh_bao
    return ra


def luu_hoa_don_doc(con, cid, d):
    """Luu hoa don AI da doc (nguoi dung da sua) vao bang hoa_don, nho TK theo mat hang. Tra ve id hoa don.
    Khi sau nay nap XML that cua hoa don nay (cung MST, ky hieu, so), du lieu XML se thay the."""
    from . import hoa_don
    ct = _cong_ty(con, cid)
    if not (d["ky_hieu"] and d["so"] and d["ngay"]):
        raise ValueError("Cần ký hiệu, số và ngày hóa đơn.")
    mua = d["chieu"] == "mua"
    h = {"nbmst": d["nb_mst"] if mua else ct["mst"], "nb_ten": d["nb_ten"] if mua else ct["ten"],
         "nmmst": ct["mst"] if mua else d["nm_mst"], "nm_ten": ct["ten"] if mua else d["nm_ten"],
         "khmshdon": d["mau_so"] or "1", "khhdon": d["ky_hieu"], "shdon": d["so"], "ngay_lap": d["ngay"],
         "tien_hang": d["tien_hang"], "tien_thue": d["tien_thue"], "tong_tien": d["tong_tien"] or d["tien_hang"] + d["tien_thue"],
         "theo_thue_suat": [{"tsuat": (d["dong_hang"][0]["thue_suat"] if d["dong_hang"] else ""), "thtien": d["tien_hang"],
                             "tthue": d["tien_thue"]}]}
    if mua and not h["nbmst"]:
        raise ValueError("Cần MST người bán.")
    hoa_don.luu(con, cid, [h], "cong_thue_mua" if mua else "ai_doc")
    r = con.execute("SELECT id, co_xml FROM hoa_don WHERE cong_ty_id=? AND nbmst=? AND khmshdon=? AND khhdon=? AND shdon=?",
                    (cid, h["nbmst"], h["khmshdon"], h["khhdon"], h["shdon"])).fetchone()
    if not r:
        raise ValueError("Không lưu được hóa đơn (MST không khớp với công ty).")
    if not r["co_xml"]:
        con.execute("UPDATE hoa_don SET dong_hang=?, nguon='ai_doc' WHERE id=?",
                    (json.dumps([{k: x[k] for k in ("ten", "dvt", "so_luong", "don_gia", "thanh_tien", "thue_suat")}
                                 for x in d["dong_hang"]], ensure_ascii=False), r["id"]))
    for x in d["dong_hang"]:
        if x.get("tk"):
            hoa_don.dat_tk_mat_hang(con, cid, d["chieu"], x["ten"], x["tk"])
    con.commit()
    return r["id"]


# ================================================================ soat so truoc khi khoa so

SAI_DAU = [("111", "Tiền mặt bị âm (dư Có)", "co"), ("112", "Tiền gửi ngân hàng bị âm (dư Có)", "co"),
           ("152", "Nguyên vật liệu dư Có", "co"), ("153", "Công cụ dụng cụ dư Có", "co"), ("156", "Hàng hóa dư Có (xuất quá tồn)", "co"),
           ("211", "TSCĐ dư Có", "co"), ("214", "Hao mòn TSCĐ dư Nợ", "no"), ("242", "Chi phí trả trước dư Có", "co"),
           ("133", "Thuế GTGT được khấu trừ dư Có", "co"), ("334", "Phải trả người lao động dư Nợ (trả lương quá)", "no"),
           ("411", "Vốn góp chủ sở hữu dư Nợ", "no")]


def kiem_tra_so(con, cid, tu, den):
    """Kiem tra khong can AI. Tra ve list (muc do 'do'|'vang'|'xanh', noi dung)."""
    kq = []
    bang, _ = bao_cao.phan_hai_ben(con, cid, bao_cao.ngay_sau(den))
    for tt, nd, ben in SAI_DAU:
        du = sum(n - c for t, (n, c) in bang.items() if t.startswith(tt))
        if (ben == "co" and du < 0) or (ben == "no" and du > 0):
            kq.append(("do", f"TK {tt}: {nd}, số dư {_f(abs(du))} đ tại {den}."))
    for t, (n, c) in sorted(bang.items()):
        if t[:1] in "5678" and not t.startswith("911") and n != c and den[5:] == "12-31":
            kq.append(("vang", f"TK {t} còn số dư {_f(abs(n - c))} đ cuối năm: chưa kết chuyển sang 911."))
    for nd, a, b, ch, gc in quan_ly.doi_chieu(con, cid, den):
        if ch:
            kq.append(("vang", f"Lệch {nd}: sổ cái {_f(a)}, chi tiết {_f(b)}, chênh {_f(ch)}. {gc}".strip()))
    nguong = min(v for _, v in to_khai.THAM_SO["nguong_tien_mat"])
    for r in con.execute(
            "SELECT c.id, c.so_ct, c.ngay_ht, SUM(CASE WHEN b.tk_co LIKE '111%' THEN b.so_tien END) tm, "
            "SUM(CASE WHEN b.tk_no LIKE '133%' THEN b.so_tien END) vat FROM chung_tu c JOIN but_toan b ON b.chung_tu_id=c.id "
            "WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ? GROUP BY c.id HAVING vat > 0 AND tm >= ?", (cid, tu, den, nguong)):
        ng = to_khai._nguong_tien_mat(r["ngay_ht"])
        if r["tm"] < ng:
            continue
        kq.append(("do", f"Chứng từ {r['so_ct']} ngày {r['ngay_ht']}: trả tiền mặt {_f(r['tm'])} đ mà có khấu trừ thuế GTGT "
                         f"{_f(r['vat'])} đ (từ {_f(ng)} đ phải thanh toán không dùng tiền mặt)."))
    # cap tai khoan hiem gap: co the hach toan nham
    cap = con.execute(
        "SELECT substr(b.tk_no,1,3) a, substr(b.tk_co,1,3) b, COUNT(*) n, MIN(c.so_ct) so_ct, MIN(c.ngay_ht) ngay, SUM(b.so_tien) tien "
        "FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ? "
        "GROUP BY a, b", (cid, tu, den)).fetchall()
    tong = sum(r["n"] for r in cap)
    if tong >= 50:
        la = [r for r in cap if r["n"] == 1 and r["a"] != r["b"]][:15]
        for r in la:
            kq.append(("xanh", f"Cặp định khoản ít gặp Nợ {r['a']} / Có {r['b']} ({_f(r['tien'])} đ) ở chứng từ {r['so_ct']} "
                               f"ngày {r['ngay']}: xem có hạch toán nhầm không."))
    lon = con.execute(
        "SELECT c.so_ct, c.ngay_ht, COALESCE(c.dien_giai,'') dg, SUM(b.so_tien) t FROM chung_tu c JOIN but_toan b ON b.chung_tu_id=c.id "
        "WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ? AND (b.tk_no LIKE '642%' OR b.tk_no LIKE '811%' OR b.tk_no LIKE '635%') "
        "GROUP BY c.id ORDER BY t DESC LIMIT 5", (cid, tu, den)).fetchall()
    for r in lon:
        kq.append(("xanh", f"Chi phí lớn: {r['so_ct']} ngày {r['ngay_ht']} {r['dg'][:60]}: {_f(r['t'])} đ (xem có đủ hóa đơn, hợp đồng)."))
    ct = _cong_ty(con, cid)
    for muc, nd, _ in quan_ly.viec_can_lam(con, ct):
        kq.append(("do" if muc == "do" else "vang", nd))
    return kq


HE_THONG_SOAT = (
    "Bạn là kế toán trưởng kiêm chuyên gia thuế Việt Nam, soát sổ sách theo TT133 trước khi khóa sổ và nộp tờ khai. "
    "Viết báo cáo tiếng Việt bằng Markdown gồm: 1) Tóm tắt 2-3 câu; 2) Lỗi cần sửa ngay (xếp theo mức nghiêm trọng, nói cách sửa, "
    "định khoản điều chỉnh nếu có); 3) Rủi ro thuế (GTGT, TNDN, TNCN, hóa đơn) và căn cứ; 4) Điểm bất thường cần xem; "
    "5) Việc cần làm trước khi khóa sổ. Chỉ dựa vào số liệu được cung cấp, không bịa. Ngắn gọn, cụ thể."
)


def soat_so(con, cid, tu, den, kiem=None, cd=None):
    kiem = kiem if kiem is not None else kiem_tra_so(con, cid, tu, den)
    cau = ("KẾT QUẢ MÁY KIỂM TRA:\n" + ("\n".join(f"- [{m}] {nd}" for m, nd in kiem) or "- Không phát hiện lỗi.") +
           "\n\nSỐ LIỆU SỔ SÁCH:\n" + boi_canh_so_lieu(con, cid, tu, den))
    return AI.hoi(HE_THONG_SOAT, cau, cd, toi_da=4000)


# ================================================================ phan tich, du bao dong tien

HE_THONG_PHAN_TICH = (
    "Bạn là giám đốc tài chính tư vấn cho chủ doanh nghiệp nhỏ Việt Nam. Viết bằng Markdown, tiếng Việt dễ hiểu: "
    "1) Nhận xét xu hướng doanh thu, chi phí, lợi nhuận, biên lợi nhuận; 2) Các chỉ số chính (thanh khoản, vòng quay phải thu, "
    "số ngày tiền đủ chi); 3) DỰ BÁO DÒNG TIỀN 3 THÁNG TỚI dạng bảng (tháng | thu dự kiến | chi dự kiến | tiền cuối tháng) "
    "dựa trên xu hướng và công nợ phải thu, phải trả, nói rõ giả định; 4) Cảnh báo và 3-5 khuyến nghị cụ thể. "
    "Chỉ dựa trên số liệu được cung cấp; số liệu dự báo phải ghi là ước tính."
)


def phan_tich(con, cid, den, cd=None):
    th = chuoi_thang(con, cid, den, 12)
    cau = ("CHUỖI 12 THÁNG (tháng | doanh thu thuần | chi phí | lợi nhuận trước thuế | thu tiền | chi tiền | tiền cuối tháng):\n"
           + "\n".join(f"- {x['thang']}: {_f(x['doanh_thu'])} | {_f(x['chi_phi'])} | {_f(x['lai'])} | {_f(x['thu_tien'])} | "
                       f"{_f(x['chi_tien'])} | {_f(x['tien_cuoi'])}" for x in th)
           + "\n\n" + boi_canh_so_lieu(con, cid, th[0]["thang"] + "-01" if th else den, den))
    return AI.hoi(HE_THONG_PHAN_TICH, cau, cd, toi_da=4000)


# ================================================================ nhac no

def khach_qua_han(con, cid, ngay, tu_ngay=30):
    ds, _ = quan_ly.tuoi_no(con, cid, "131", ngay)
    return [x for x in ds if x["tong"] > 0 and (x["lau_nhat"] or 0) > tu_ngay]


HE_THONG_NHAC_NO = (
    "Bạn soạn tin nhắn nhắc thanh toán công nợ bằng tiếng Việt cho doanh nghiệp Việt Nam: lịch sự, rõ số tiền, "
    "giữ quan hệ tốt, không đe dọa. Trả về JSON: {\"zalo\": \"tin ngắn dưới 500 ký tự\", \"email_tieu_de\": \"\", \"email\": \"thư đầy đủ\"}."
)


def soan_nhac_no(con, cid, ma, ngay, giong="lịch sự", cd=None):
    ct = _cong_ty(con, cid)
    x = next((k for k in khach_qua_han(con, cid, ngay, -1) if k["ma"] == ma), None)
    if not x:
        raise AI.LoiAI("Khách này không còn nợ.")
    tk_nh = con.execute("SELECT ngan_hang, so_tk FROM tai_khoan_ngan_hang WHERE cong_ty_id=? LIMIT 1", (cid,)).fetchone() \
        if con.execute("SELECT 1 FROM sqlite_master WHERE name='tai_khoan_ngan_hang'").fetchone() else None
    cau = (f"Bên gửi: {ct['ten']}. Khách: {x['ten']}. Còn nợ {_f(x['tong'])} đồng tính đến {ngay}, khoản lâu nhất đã {x['lau_nhat']} ngày; "
           f"theo tuổi nợ 0-30 / 31-60 / 61-90 / trên 90 ngày: {' / '.join(_f(v) for v in x['nhom'])}. "
           + (f"Tài khoản nhận tiền: {tk_nh['so_tk']} tại {tk_nh['ngan_hang']}. " if tk_nh and tk_nh["so_tk"] else "")
           + f"Giọng văn: {giong}. Đề nghị khách đối chiếu và thanh toán, liên hệ nếu có sai lệch.")
    kq = AI.doc_json(AI.hoi(HE_THONG_NHAC_NO, cau, cd, toi_da=1500))
    if not isinstance(kq, dict):
        raise AI.LoiAI("AI trả lời không đúng định dạng, thử lại.")
    return {"khach": x, "zalo": str(kq.get("zalo") or ""), "email_tieu_de": str(kq.get("email_tieu_de") or ""),
            "email": str(kq.get("email") or "")}


# ================================================================ hien thi cau tra loi

def markdown_html(chu):
    """Chuyen Markdown don gian cua AI sang HTML an toan (escape truoc)."""
    dong = html.escape(chu or "").split("\n")
    ra, i = [], 0

    def nd(s):
        s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
        s = re.sub(r"(?<!\*)\*(?!\s)(.+?)(?<!\s)\*(?!\*)", r"<i>\1</i>", s)
        return re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    while i < len(dong):
        d = dong[i].rstrip()
        if d.strip().startswith("|") and i + 1 < len(dong) and re.match(r"^\s*\|?\s*:?-{2,}", dong[i + 1]):
            o = lambda s: [x.strip() for x in s.strip().strip("|").split("|")]
            bang = "<tr>" + "".join(f"<th>{nd(x)}</th>" for x in o(d)) + "</tr>"
            i += 2
            while i < len(dong) and dong[i].strip().startswith("|"):
                bang += "<tr>" + "".join(f"<td>{nd(x)}</td>" for x in o(dong[i])) + "</tr>"
                i += 1
            ra.append(f'<div class="cuon"><table>{bang}</table></div>')
            continue
        m = re.match(r"^(#{1,4})\s+(.*)", d)
        if m:
            ra.append(f"<h{min(len(m.group(1)) + 2, 5)}>{nd(m.group(2))}</h{min(len(m.group(1)) + 2, 5)}>")
        elif re.match(r"^\s*([-*•]|\d+[.)])\s+", d):
            loai = "ol" if re.match(r"^\s*\d+[.)]", d) else "ul"
            muc = []
            while i < len(dong) and re.match(r"^\s*([-*•]|\d+[.)])\s+", dong[i]):
                muc.append("<li>" + nd(re.sub(r"^\s*([-*•]|\d+[.)])\s+", "", dong[i])) + "</li>")
                i += 1
            ra.append(f"<{loai}>{''.join(muc)}</{loai}>")
            continue
        elif d.strip():
            ra.append(f"<p>{nd(d)}</p>")
        i += 1
    return "\n".join(ra)
