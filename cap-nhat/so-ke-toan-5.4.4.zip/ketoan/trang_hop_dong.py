"""Trang Hop dong mua, ban (tron vao lop XuLy)."""
from . import hop_dong
from . import giao_dien as G
from .giao_dien import e, ngay_vn, so


def _so(s):
    s = (s or "").strip().replace(".", "").replace(",", "").replace(" ", "")
    return int(s) if s.isdigit() else 0


def _hd_so(h):
    return f'{e(h["khhdon"])}-{e(h["shdon"])}'


class TrangHopDong:
    def hopdong(self, pt, con, ct, q, rest):
        hop_dong.chuan_bi(con)
        cid = ct["id"]
        if rest and rest[0].isdigit():
            return self._hdg_xem(pt, con, ct, int(rest[0]))
        loai = q.get("loai") if q.get("loai") in hop_dong.LOAI else ""
        tb = ""
        if pt == "POST":
            f = {k: v[0] for k, v in self.doc_form().items()}
            try:
                f["gia_tri"] = _so(f.get("gia_tri"))
                hid = hop_dong.them(con, cid, f)
                return self.chuyen(f"/cty/{cid}/hopdong/{hid}")
            except Exception as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        dong, tong = "", {"gt": 0, "hd": 0, "tt": 0}
        for hd in hop_dong.danh_sach(con, cid, loai or None):
            t = hop_dong.tinh_hinh(con, cid, hd)
            if hd["trang_thai"] == "dang":
                tong["gt"] += hd["gia_tri"]
                tong["hd"] += t["con_hoa_don"]
                tong["tt"] += t["con_tt"]
            mau = {"dang": "lam", "thanh_ly": "xanh", "huy": ""}[hd["trang_thai"]]
            if hd["trang_thai"] == "dang" and t["con_ngay"] is not None and t["con_ngay"] <= 15:
                mau = "do" if t["con_ngay"] < 0 else "vang"
            dong += (f'<tr><td><a href="/cty/{cid}/hopdong/{hd["id"]}"><b>{e(hd["so_hd"])}</b></a><br>'
                     f'<span class="mo">{hop_dong.LOAI[hd["loai"]]}</span></td><td>{e(hd["ten_doi_tac"])}<br><span class="mo">{e(hd["mst_doi_tac"])}</span></td>'
                     f'<td>{ngay_vn(hd["ngay_ky"])}</td><td>{ngay_vn(hd["ngay_het_han"])}</td><td class="s">{so(hd["gia_tri"])}</td>'
                     f'<td class="s">{so(t["da_hoa_don"])}</td><td class="s">{so(t["da_tt"]) if t["co_tt"] else "<span class=mo>?</span>"}</td>'
                     f'<td>{G.nhan_tt(hop_dong.TRANG_THAI[hd["trang_thai"]], mau)}</td></tr>')
        loc = G.tab([("", f"/cty/{cid}/hopdong", "Tất cả"), ("ban", f"/cty/{cid}/hopdong?loai=ban", "Hợp đồng bán"),
                     ("mua", f"/cty/{cid}/hopdong?loai=mua", "Hợp đồng mua")], loai)
        chon = "".join(f'<option value="{m}" {"selected" if m == (loai or "ban") else ""}>{t}</option>' for m, t in hop_dong.LOAI.items())
        nd = f"""<div class="luoi">{G.o_so("Giá trị hợp đồng đang thực hiện", so(tong["gt"]) or "0")}
{G.o_so("Còn phải xuất / nhận hóa đơn", so(tong["hd"]) or "0")}{G.o_so("Còn phải thanh toán", so(tong["tt"]) or "0")}</div>
<div class="the"><h1>Hợp đồng</h1>{tb}{loc}
<table><tr><th>Số hợp đồng</th><th>Đối tác</th><th>Ngày ký</th><th>Hết hạn</th><th class="s">Giá trị</th><th class="s">Đã có hóa đơn</th>
<th class="s">Đã thanh toán</th><th>Tình trạng</th></tr>{dong}</table></div>
<details class="the" {'open' if not dong else ''}><summary>Thêm hợp đồng</summary><form method="post" class="ngang" style="margin-top:12px">
<label>Loại<select name="loai">{chon}</select></label><label>Số hợp đồng<input name="so_hd" required size="14"></label>
<label>Đối tác<input name="ten_doi_tac" required size="34"></label><label>MST đối tác<input name="mst_doi_tac" size="14"></label>
<label>Mã đối tượng<input name="ma_doi_tuong" size="10" placeholder="tự tìm theo MST"></label>
<label>Ngày ký<input type="date" name="ngay_ky" required></label><label>Ngày hết hạn<input type="date" name="ngay_het_han"></label>
<label>Giá trị (gồm thuế)<input name="gia_tri" size="14"></label><label>Nội dung<input name="noi_dung" size="40"></label><button>Thêm</button></form>
<p class="mo">Có MST đối tác thì hóa đơn của đối tác trong thời hạn hợp đồng được gắn tự động. Có mã đối tượng thì tính được số đã thanh toán
(phân bổ cho các hợp đồng cùng đối tác theo ngày ký).</p></details>"""
        self.gui(G.trang("Hợp đồng", nd, cid, ct["ten"]))

    def _hdg_xem(self, pt, con, ct, hid):
        cid = ct["id"]
        hd = hop_dong.lay(con, cid, hid)
        if not hd:
            return self.gui(G.trang("Không tìm thấy", "<p>Không có hợp đồng này.</p>", cid, ct["ten"]), 404)
        tb = ""
        if pt == "POST":
            form = self.doc_form()
            f = {k: v[0] for k, v in form.items()}
            hd_ = f.get("hanh_dong")
            if hd_ == "gan":
                hop_dong.gan(con, hid, form.get("hoa_don", []))
                tb = '<p class="ok">Đã gắn hóa đơn.</p>'
            elif hd_ == "bo":
                hop_dong.bo_gan(con, hid, f["hoa_don"])
                tb = '<p class="ok">Đã bỏ gắn hóa đơn.</p>'
            elif hd_ == "trang_thai" and f.get("trang_thai") in hop_dong.TRANG_THAI:
                con.execute("UPDATE hop_dong SET trang_thai=? WHERE id=?", (f["trang_thai"], hid))
                con.commit()
                tb = '<p class="ok">Đã cập nhật tình trạng.</p>'
            elif hd_ == "xoa":
                con.execute("DELETE FROM hop_dong WHERE id=? AND cong_ty_id=?", (hid, cid))
                con.commit()
                return self.chuyen(f"/cty/{cid}/hopdong")
            hd = hop_dong.lay(con, cid, hid)
        t = hop_dong.tinh_hinh(con, cid, hd)
        dong_hd = "".join(
            f'<tr><td>{_hd_so(h)}</td><td>{ngay_vn(h["ngay_lap"])}</td><td class="s">{so(h["tien_hang"])}</td><td class="s">{so(h["tien_thue"])}</td>'
            f'<td class="s">{so(h["tong_tien"])}</td><td><form method="post"><input type="hidden" name="hanh_dong" value="bo">'
            f'<input type="hidden" name="hoa_don" value="{h["id"]}"><button class="phu nho">Bỏ gắn</button></form></td></tr>' for h in t["hoa_don"])
        goi_y = hop_dong.goi_y_hoa_don(con, cid, hd)
        o_goi_y = ("" if not goi_y else
                   '<form method="post"><input type="hidden" name="hanh_dong" value="gan"><h3>Hóa đơn của đối tác chưa gắn hợp đồng</h3><table>'
                   '<tr><th></th><th>Số hóa đơn</th><th>Ngày</th><th class="s">Tổng tiền</th></tr>'
                   + "".join(f'<tr><td><input type="checkbox" name="hoa_don" value="{h["id"]}" checked></td><td>{_hd_so(h)}</td>'
                             f'<td>{ngay_vn(h["ngay_lap"])}</td><td class="s">{so(h["tong_tien"])}</td></tr>' for h in goi_y)
                   + '</table><p><button>Gắn vào hợp đồng</button></p></form>')
        chon_tt = "".join(f'<option value="{m}" {"selected" if m == hd["trang_thai"] else ""}>{x}</option>' for m, x in hop_dong.TRANG_THAI.items())
        cn = (f'<a href="/cty/{cid}/congno?tk={"131" if hd["loai"] == "ban" else "331"}&ma={e(hd["ma_doi_tuong"])}">{e(hd["ma_doi_tuong"])}</a>'
              if hd["ma_doi_tuong"] else '<span class="mo">chưa có (không tính được số đã thanh toán)</span>')
        han = ngay_vn(hd["ngay_het_han"]) + (f' (còn {t["con_ngay"]} ngày)' if t["con_ngay"] is not None and t["con_ngay"] >= 0 else
                                             " (đã hết hạn)" if t["con_ngay"] is not None else "") if hd["ngay_het_han"] else "Không ghi"
        nd = f"""<div class="luoi">{G.o_so("Giá trị hợp đồng", so(hd["gia_tri"]) or "0")}{G.o_so("Đã có hóa đơn", so(t["da_hoa_don"]) or "0")}
{G.o_so("Còn phải xuất / nhận hóa đơn", so(t["con_hoa_don"]) or "0")}{G.o_so("Đã thanh toán", (so(t["da_tt"]) or "0") if t["co_tt"] else "?")}</div>
<div class="the"><h1>{hop_dong.LOAI[hd["loai"]]} {e(hd["so_hd"])}</h1>{tb}<table class="kv">
<tr><th>Đối tác</th><td>{e(hd["ten_doi_tac"])} {f'· MST {e(hd["mst_doi_tac"])}' if hd["mst_doi_tac"] else ''}</td></tr>
<tr><th>Mã đối tượng</th><td>{cn}</td></tr><tr><th>Ngày ký</th><td>{ngay_vn(hd["ngay_ky"])}</td></tr><tr><th>Hết hạn</th><td>{han}</td></tr>
{f'<tr><th>Nội dung</th><td>{e(hd["noi_dung"])}</td></tr>' if hd["noi_dung"] else ''}</table>
<form method="post" class="ngang" style="margin-top:10px"><input type="hidden" name="hanh_dong" value="trang_thai">
<label>Tình trạng<select name="trang_thai">{chon_tt}</select></label><button class="phu">Lưu</button></form></div>
<div class="the"><h2>Hóa đơn theo hợp đồng</h2><table><tr><th>Số hóa đơn</th><th>Ngày</th><th class="s">Tiền hàng</th><th class="s">Thuế</th>
<th class="s">Tổng</th><th></th></tr>{dong_hd}</table>{o_goi_y}
<form method="post" onsubmit="return confirm('Xóa hợp đồng này? Hóa đơn và chứng từ không bị xóa.')" style="margin-top:12px">
<input type="hidden" name="hanh_dong" value="xoa"><button class="nguy nho">Xóa hợp đồng</button>
<a class="nut phu nho" href="/cty/{cid}/hopdong">← Danh sách</a></form></div>"""
        self.gui(G.trang(f"Hợp đồng {hd['so_hd']}", nd, cid, ct["ten"]))
