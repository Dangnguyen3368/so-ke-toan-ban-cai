"""Phan he (module) kieu phan mem ke toan: menu ben trai, thanh chuc nang tren dau trang va so do quy trinh.

Moi phan he co: ma, ten, icon, mau nhan, mo ta, danh sach chuc nang (url, nhan) va so do quy trinh.
Url tinh tu /cty/<id>; url co dau ?... chi khop khi trang hien tai co dung cac tham so do.
Them trang moi: them mot dong (url, nhan) vao chuc_nang cua phan he phu hop.
"""
from urllib.parse import parse_qsl


def _b(ic, t, mo="", u=None, ngoai=False):
    """Mot buoc trong so do: icon, tieu de, mo ta ngan, url (None = viec lam ngoai phan mem)."""
    return {"ic": ic, "t": t, "mo": mo, "u": u, "ngoai": ngoai}


# (ma, ten, icon, mau, mo ta, chuc nang, so do quy trinh [cot[buoc]])
PHAN_HE = [
    {"ma": "tongquan", "ten": "Tổng quan", "ic": "", "mau": "#2563eb",
     "mo_ta": "Số liệu chính, biểu đồ và việc cần làm của công ty.",
     "chuc_nang": [("", "Bảng điều khiển"), ("/viec", "Việc cần làm")], "quy_trinh": []},

    {"ma": "ai", "ten": "Trợ lý AI", "ic": "ai", "mau": "#8b5cf6",
     "mo_ta": "Hỏi đáp về sổ sách, đọc chứng từ bằng AI, soát sổ, phân tích dự báo và nhắc nợ khách hàng.",
     "chuc_nang": [("/ai/hoi", "Hỏi đáp"), ("/ai/doc", "Đọc chứng từ"), ("/ai/soat", "Soát sổ"),
                   ("/ai/phantich", "Phân tích, dự báo"), ("/ai/nhacno", "Nhắc nợ")],
     "quy_trinh": [[_b("nap", "Đọc chứng từ", "Ảnh, PDF thành bút toán gợi ý", "/ai/doc")],
                   [_b("ghi", "Bạn duyệt, ghi sổ", "AI không tự ghi sổ", "/chungtu")],
                   [_b("/doichieu", "Soát sổ", "Tìm sai sót, bất thường", "/ai/soat")],
                   [_b("/luuchuyen", "Phân tích, dự báo", "Sức khỏe tài chính, dòng tiền", "/ai/phantich")],
                   [_b("gui", "Nhắc nợ", "Soạn tin nhắc khách hàng", "/ai/nhacno")],
                   [_b("ai", "Hỏi đáp", "Hỏi về số liệu của công ty", "/ai/hoi")]]},

    {"ma": "quy", "ten": "Quỹ tiền mặt", "ic": "tien", "mau": "#0d9488",
     "mo_ta": "Lập phiếu thu, phiếu chi, in phiếu và theo dõi sổ quỹ tiền mặt (TK 111).",
     "chuc_nang": [("/chungtu/moi", "Lập phiếu thu, chi"), ("/so/quy", "Sổ quỹ tiền mặt"),
                   ("/chungtu?q=PT", "Phiếu thu đã lập"), ("/chungtu?q=PC", "Phiếu chi đã lập")],
     "quy_trinh": [[_b("viec", "Đề nghị thu, chi", "Giấy đề nghị, hóa đơn", ngoai=True)],
                   [_b("thu", "Lập phiếu thu", "Nợ 111 / Có 131, 511...", "/chungtu/moi"),
                    _b("chi", "Lập phiếu chi", "Nợ 331, 642... / Có 111", "/chungtu/moi")],
                   [_b("in", "In phiếu, ký duyệt", "Phiếu thu, chi mẫu 01-TT", "/chungtu")],
                   [_b("/so", "Sổ quỹ tiền mặt", "Tồn quỹ từng ngày", "/so/quy")],
                   [_b("/doichieu", "Kiểm kê, đối chiếu", "Quỹ thực tế và sổ", "/doichieu")]]},

    {"ma": "nganhang", "ten": "Ngân hàng", "ic": "/nganhang", "mau": "#0284c7",
     "mo_ta": "Nạp sao kê, tự gợi ý hạch toán, ghi sổ và đối chiếu số dư tiền gửi (TK 112).",
     "chuc_nang": [("/nganhang", "Dòng sao kê"), ("/nganhang/nap", "Nạp sao kê"), ("/nganhang/quytac", "Quy tắc tự hạch toán"),
                   ("/nganhang/doichieu", "Đối chiếu số dư"), ("/so/tiengui", "Sổ tiền gửi"),
                   ("/vay", "Khế ước vay")],
     "quy_trinh": [[_b("tai", "Tải sao kê", "Excel từ internet banking", ngoai=True)],
                   [_b("nap", "Nạp sao kê", "Nhận diện mẫu các ngân hàng", "/nganhang/nap")],
                   [_b("ai", "Gợi ý hạch toán", "Theo quy tắc và lịch sử", "/nganhang/quytac")],
                   [_b("ghi", "Ghi sổ báo nợ, báo có", "Gắn khách hàng, nhà cung cấp", "/nganhang")],
                   [_b("/so", "Sổ tiền gửi", "Từng tài khoản ngân hàng", "/so/tiengui"),
                    _b("/doichieu", "Đối chiếu số dư", "Sổ và sao kê", "/nganhang/doichieu")]]},

    {"ma": "muahang", "ten": "Mua hàng", "ic": "mua", "mau": "#7c3aed",
     "mo_ta": "Hóa đơn mua vào, nhập kho, công nợ nhà cung cấp và thanh toán (TK 331).",
     "chuc_nang": [("/hoadon?chieu=mua", "Hóa đơn mua vào"), ("/doituong?loai=NCC", "Nhà cung cấp"),
                   ("/hopdong?loai=mua", "Hợp đồng mua"), ("/congno?tk=331", "Công nợ phải trả"), ("/congno?tk=331&muc=tuoino", "Tuổi nợ phải trả")],
     "quy_trinh": [[_b("/hoadon", "Nhận hóa đơn", "Tải từ cổng thuế hoặc file XML", "/hoadon/cong")],
                   [_b("ghi", "Ghi sổ hóa đơn mua", "Tự định khoản theo mặt hàng", "/hoadon?chieu=mua")],
                   [_b("/kho", "Nhập kho", "Tự tạo phiếu nhập 152, 156", "/kho"),
                    _b("/taisan", "Ghi tăng tài sản", "TSCĐ, CCDC", "/taisan")],
                   [_b("/congno", "Công nợ phải trả", "Theo từng nhà cung cấp", "/congno?tk=331")],
                   [_b("chi", "Thanh toán", "Ủy nhiệm chi, phiếu chi", "/nganhang")]]},

    {"ma": "banhang", "ten": "Bán hàng", "ic": "ban", "mau": "#db2777",
     "mo_ta": "Hóa đơn bán ra, doanh thu, giá vốn, công nợ khách hàng và thu tiền (TK 131).",
     "chuc_nang": [("/hoadon?chieu=ban", "Hóa đơn bán ra"), ("/doituong?loai=KH", "Khách hàng"),
                   ("/hopdong?loai=ban", "Hợp đồng bán"), ("/congno?tk=131", "Công nợ phải thu"), ("/congno?tk=131&muc=tuoino", "Tuổi nợ phải thu")],
     "quy_trinh": [[_b("/hoadon", "Xuất hóa đơn", "Trên phần mềm hóa đơn điện tử", ngoai=True)],
                   [_b("tai", "Lấy hóa đơn về", "Cổng thuế hoặc file XML", "/hoadon/cong")],
                   [_b("ghi", "Ghi doanh thu", "Nợ 131 / Có 511, 3331", "/hoadon?chieu=ban")],
                   [_b("/kho", "Xuất kho, giá vốn", "Bình quân cuối kỳ", "/kho")],
                   [_b("/congno", "Công nợ phải thu", "Tuổi nợ từng khách hàng", "/congno?tk=131")],
                   [_b("thu", "Thu tiền", "Báo có, phiếu thu", "/nganhang")]]},

    {"ma": "kho", "ten": "Kho", "ic": "/kho", "mau": "#ea580c",
     "mo_ta": "Nhập, xuất, tồn vật tư hàng hóa; tính giá xuất kho và sổ chi tiết vật tư.",
     "chuc_nang": [("/kho", "Nhập xuất tồn"), ("/so/vattu", "Sổ chi tiết vật tư")],
     "quy_trinh": [[_b("/hoadon", "Hóa đơn mua", "Có mặt hàng chi tiết", "/hoadon?chieu=mua")],
                   [_b("nap", "Phiếu nhập kho", "Tự tạo khi ghi sổ hóa đơn", "/kho")],
                   [_b("chi", "Phiếu xuất kho", "Nạp file Excel mẫu", "/kho")],
                   [_b("tinh", "Tính giá xuất", "Bình quân, ghi sổ giá vốn", "/kho")],
                   [_b("/so", "Sổ vật tư, tồn kho", "Chi tiết từng mặt hàng", "/so/vattu")]]},

    {"ma": "giathanh", "ten": "Giá thành", "ic": "/giathanh", "mau": "#b45309",
     "mo_ta": "Tập hợp chi phí theo công trình, sản phẩm, đơn hàng (TK 154), phân bổ chi phí chung, tính và kết chuyển giá thành.",
     "chuc_nang": [("/giathanh", "Tổng hợp giá thành")],
     "quy_trinh": [[_b("/kho", "Xuất vật tư", "Ghi tên công trình trên phiếu", "/kho"),
                    _b("/luong", "Lương công nhân", "TK chi phí 154", "/luong")],
                   [_b("ghi", "Tập hợp chi phí", "Nợ 154 theo đối tượng", "/giathanh")],
                   [_b("tinh", "Phân bổ chi phí chung", "Theo NVL hoặc dự toán", "/giathanh")],
                   [_b("/giathanh", "Thẻ tính giá thành", "Theo khoản mục", "/giathanh")],
                   [_b("/baocao", "Kết chuyển giá vốn", "Nợ 632 hoặc 155 / Có 154", "/giathanh")]]},

    {"ma": "hoadon", "ten": "Hóa đơn điện tử", "ic": "/hoadon", "mau": "#4f46e5",
     "mo_ta": "Tải hóa đơn từ cổng thuế, kiểm tra trạng thái, học định khoản theo mặt hàng và ghi sổ hàng loạt.",
     "chuc_nang": [("/hoadon", "Danh sách hóa đơn"), ("/hoadon/cong", "Tải từ cổng thuế"), ("/hoadon/nap", "Nạp file XML"),
                   ("/hoadon/quytac", "Quy tắc định khoản"), ("/hoadon/mathang", "Định khoản theo mặt hàng")],
     "quy_trinh": [[_b("tai", "Tải từ cổng thuế", "hoadondientu.gdt.gov.vn", "/hoadon/cong"),
                    _b("nap", "Nạp file XML", "Mọi nhà cung cấp TT78", "/hoadon/nap")],
                   [_b("/doichieu", "Kiểm tra", "Trạng thái, trùng, MST", "/hoadon")],
                   [_b("ai", "Định khoản", "Học theo mặt hàng, NCC", "/hoadon/mathang")],
                   [_b("ghi", "Ghi sổ hàng loạt", "Sinh chứng từ, kho, công nợ", "/hoadon")],
                   [_b("thue", "Lên tờ khai GTGT", "Bảng kê mua vào, bán ra", "/baocao?muc=gtgt")]]},

    {"ma": "thue", "ten": "Thuế", "ic": "thue", "mau": "#dc2626",
     "mo_ta": "Lập tờ khai GTGT, quyết toán TNDN, TNCN và xuất XML để mở bằng HTKK.",
     "chuc_nang": [("/baocao?muc=gtgt", "Tờ khai 01/GTGT"), ("/baocao?muc=tndn", "Quyết toán 03/TNDN"),
                   ("/baocao?muc=tncn", "Quyết toán 05/QTT-TNCN"), ("/baocao?muc=mau", "Mẫu XML HTKK")],
     "quy_trinh": [[_b("ghi", "Ghi sổ hóa đơn", "Mua vào, bán ra trong kỳ", "/hoadon")],
                   [_b("thue", "Lập tờ khai", "01/GTGT, 03/TNDN, 05/QTT", "/baocao?muc=gtgt")],
                   [_b("/doichieu", "Kiểm tra số liệu", "Đối chiếu sổ 133, 3331", "/doichieu")],
                   [_b("xml", "Xuất XML", "Mở bằng HTKK", "/baocao?muc=mau")],
                   [_b("gui", "Ký, nộp eTax", "Bạn tự kiểm tra và nộp", ngoai=True)]]},

    {"ma": "luong", "ten": "Tiền lương", "ic": "/luong", "mau": "#16a34a",
     "mo_ta": "Bảng lương, bảo hiểm, thuế TNCN, hạch toán và in bảng lương.",
     "chuc_nang": [("/luong", "Bảng lương"), ("/doituong?loai=NV", "Nhân viên"), ("/baocao?muc=tncn", "Quyết toán TNCN")],
     "quy_trinh": [[_b("viec", "Chấm công", "Bảng công tháng", ngoai=True)],
                   [_b("nap", "Nạp bảng lương", "File Excel mẫu", "/luong")],
                   [_b("tinh", "Tính BH, thuế TNCN", "Theo tham số luật hiện hành", "/luong")],
                   [_b("ghi", "Hạch toán lương", "Nợ 642 / Có 334, 338", "/luong")],
                   [_b("in", "In bảng lương", "Ký nhận", "/luong")],
                   [_b("chi", "Trả lương", "Chuyển khoản, tiền mặt", "/nganhang")]]},

    {"ma": "taisan", "ten": "Tài sản, CCDC", "ic": "/taisan", "mau": "#0891b2",
     "mo_ta": "Tài sản cố định, công cụ dụng cụ: ghi tăng, khấu hao, phân bổ hàng tháng.",
     "chuc_nang": [("/taisan", "Danh sách tài sản, CCDC")],
     "quy_trinh": [[_b("/hoadon", "Mua tài sản", "Hóa đơn mua vào", "/hoadon?chieu=mua")],
                   [_b("/taisan", "Ghi tăng", "TSCĐ (211), CCDC (242)", "/taisan")],
                   [_b("tinh", "Khấu hao, phân bổ", "Tự tính theo tháng", "/taisan")],
                   [_b("ghi", "Ghi sổ", "Nợ 642 / Có 214, 242", "/taisan")],
                   [_b("/baocao", "Lên báo cáo", "B01, thuyết minh", "/baocao?muc=bctc")]]},

    {"ma": "tonghop", "ten": "Tổng hợp", "ic": "/socai", "mau": "#475569",
     "mo_ta": "Chứng từ nghiệp vụ khác, sổ nhật ký chung, sổ cái, kết chuyển cuối kỳ và khóa sổ.",
     "chuc_nang": [("/chungtu/moi", "Nhập chứng từ"), ("/chungtu", "Danh sách chứng từ"), ("/nkc", "Nhật ký chung"),
                   ("/socai", "Sổ cái"), ("/sochedo", "Sổ theo thông tư"), ("/so", "Sổ quỹ, tiền gửi, vật tư"), ("/congno", "Công nợ"),
                   ("/cdtk", "Cân đối tài khoản"), ("/baocao?muc=ketchuyen", "Kết chuyển"), ("/khoaso", "Khóa sổ")],
     "quy_trinh": [[_b("/chungtu/moi", "Chứng từ", "Hóa đơn, sao kê, phiếu, lương", "/chungtu")],
                   [_b("/nkc", "Nhật ký chung", "Ghi theo thời gian", "/nkc")],
                   [_b("/socai", "Sổ cái, sổ chi tiết", "Theo tài khoản, đối tượng", "/socai")],
                   [_b("/cdtk", "Cân đối tài khoản", "Kiểm tra Nợ = Có", "/cdtk")],
                   [_b("tinh", "Kết chuyển", "Xác định kết quả (911)", "/baocao?muc=ketchuyen")],
                   [_b("/khoaso", "Khóa sổ", "Chặn sửa kỳ đã nộp", "/khoaso")]]},

    {"ma": "baocao", "ten": "Báo cáo", "ic": "/baocao", "mau": "#9333ea",
     "mo_ta": "Báo cáo tài chính, lưu chuyển tiền tệ và kiểm tra đối chiếu số liệu.",
     "chuc_nang": [("/baocao?muc=bctc", "Báo cáo tài chính"), ("/luuchuyen", "Lưu chuyển tiền tệ"),
                   ("/cdtk", "Cân đối tài khoản"), ("/doichieu", "Đối chiếu, kiểm tra")],
     "quy_trinh": [[_b("/khoaso", "Khóa sổ cuối năm", "Sau kết chuyển", "/khoaso")],
                   [_b("/doichieu", "Kiểm tra", "Cân đối, đối chiếu", "/doichieu")],
                   [_b("/baocao", "BCTC B01, B02", "Theo chế độ của công ty", "/baocao?muc=bctc"),
                    _b("/luuchuyen", "Lưu chuyển tiền tệ", "B03 trực tiếp", "/luuchuyen")],
                   [_b("xml", "Xuất XML, Excel", "Nộp kèm quyết toán", "/baocao?muc=bctc")]]},

    {"ma": "hethong", "ten": "Hệ thống", "ic": "/caidat", "mau": "#64748b",
     "mo_ta": "Cài đặt công ty, danh mục đối tượng, nạp dữ liệu MISA, nhật ký sửa.",
     "chuc_nang": [("/caidat", "Cài đặt công ty"), ("/doituong", "Danh mục đối tượng"), ("/nhap-misa", "Nạp dữ liệu MISA"),
                   ("/khoaso", "Khóa sổ, nhật ký sửa")],
     "quy_trinh": []},
]

THEO_MA = {p["ma"]: p for p in PHAN_HE}

# So do quy trinh tong the (trang bang dieu khien)
QUY_TRINH_CHUNG = [
    [_b("/hoadon", "Hóa đơn điện tử", "Mua vào, bán ra", "/hoadon"), _b("/nganhang", "Sao kê ngân hàng", "Báo nợ, báo có", "/nganhang"),
     _b("tien", "Phiếu thu, chi", "Tiền mặt", "/chungtu/moi")],
    [_b("ghi", "Ghi sổ", "Tự định khoản", "/chungtu"), _b("/kho", "Kho, lương, tài sản", "Sinh bút toán tự động", "/kho")],
    [_b("/socai", "Sổ sách", "NKC, sổ cái, công nợ", "/nkc")],
    [_b("tinh", "Kết chuyển, khóa sổ", "Cuối tháng, quý, năm", "/baocao?muc=ketchuyen")],
    [_b("/baocao", "Báo cáo tài chính", "B01, B02, B03", "/baocao?muc=bctc"), _b("thue", "Tờ khai thuế", "GTGT, TNDN, TNCN", "/baocao?muc=gtgt")],
    [_b("gui", "Nộp HTKK, eTax", "Bạn tự ký và nộp", ngoai=True)],
]


def _tach(u):
    duong, _, q = u.partition("?")
    return duong, dict(parse_qsl(q))


def _duoc_dung(u):
    """Loc theo goi ban quyen / che do ke toan neu giao_dien co ham muc_duoc_dung."""
    from . import giao_dien as G
    f = getattr(G, "muc_duoc_dung", None)
    try:
        if not f:
            return True
        duong, tham = _tach(u)
        if duong == "/baocao" and tham.get("muc") and not f("bc:" + tham["muc"]):
            return False
        return f(duong)
    except Exception:
        return True


def chuc_nang(ph):
    return [(u, t) for u, t in ph["chuc_nang"] if _duoc_dung(u)]


def _diem(u, duong, q, goc):
    """Muc khop cua url chuc nang u voi trang hien tai (0 = khong khop)."""
    d, tham = _tach(u)
    if any(q.get(k) != v for k, v in tham.items()):
        return 0
    if d == "":
        return 100 if duong == goc else 0
    if duong == goc + d:
        return 50 + len(d) + 10 * len(tham)
    if duong.startswith(goc + d + "/"):
        return 10 + len(d) + 10 * len(tham)
    return 0


def tim(cid, duong, q, uu_tien=""):
    """Tra ve (phan he, url chuc nang dang chon) cho trang hien tai."""
    goc = f"/cty/{cid}"
    duong = duong.rstrip("/")
    if duong.startswith(goc + "/phan-he/"):
        return THEO_MA.get(duong.rsplit("/", 1)[-1]), "quy-trinh"
    tot, kq = 0, (None, None)
    for ph in PHAN_HE:
        for u, _ in ph["chuc_nang"]:
            d = _diem(u, duong, q, goc)
            if d and ph["ma"] == uu_tien:
                d += 5  # phan he nguoi dung dang lam viec
            if d > tot:
                tot, kq = d, (ph, u)
    return kq


def so_do(cid, cot, dem=None, nho=False):
    """Ve so do quy trinh (HTML): cac cot buoc noi bang mui ten. dem: {url: (so, mau)} de gan nhan."""
    from .giao_dien import e, icon
    dem = dem or {}
    html = []
    for i, ds in enumerate(cot):
        o = []
        for b in ds:
            nhan = ""
            if b["u"] and b["u"] in dem:
                n, mau = dem[b["u"]]
                nhan = f'<span class="sd-dem {mau}">{e(n)}</span>'
            ben_trong = (f'<span class="sd-ic">{icon(b["ic"], 20)}</span><b>{e(b["t"])}</b>'
                         f'<small>{e(b["mo"])}</small>{nhan}')
            if b["u"] and not b["ngoai"] and not _duoc_dung(b["u"]):
                o.append(f'<div class="sd-buoc khoa" title="Không có trong gói bản quyền đang dùng">{ben_trong}</div>')
            elif b["u"] and not b["ngoai"]:
                o.append(f'<a class="sd-buoc" href="/cty/{cid}{b["u"]}">{ben_trong}</a>')
            else:
                o.append(f'<div class="sd-buoc ngoai" title="Việc làm ngoài phần mềm">{ben_trong}</div>')
        html.append(f'<div class="sd-cot"><span class="sd-so">{i + 1}</span>{"".join(o)}</div>')
    return f'<div class="so-do{" nho" if nho else ""}">' + '<span class="sd-mui"></span>'.join(html) + "</div>"
