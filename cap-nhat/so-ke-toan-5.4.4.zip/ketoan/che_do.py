"""Che do ke toan cua tung cong ty: TT133, TT99, TT58 (doanh nghiep sieu nho), TT152 (ho kinh doanh).

- TT133 / TT99: ghi so kep theo he thong tai khoan cua thong tu; BCTC, to khai nhu cu.
- TT58 / TT152: ung dung van ghi so kep ben duoi (dung danh muc TT133) de tu dong hoa hoa don, sao ke, kho...
  nhung SO KE TOAN in ra theo mau rieng cua thong tu (S1-DNSN..., S1a-HKD...), lap tu so lieu da ghi.

Ten va ma so lay theo cac bai huong dan dang lai noi dung thong tu (MISA AMIS, einvoice, LuatVietnam, 11/2026).
Bo cuc cot cua tung so la do ung dung thiet ke theo noi dung can theo doi; doi chieu lai phu luc mau so
cua thong tu truoc khi nop / luu tru chinh thuc. Ty le thue tren doanh thu sua duoc theo tung cong ty.
"""
from . import tt99, tt133

CHE_DO = {
    "TT133": {"ten": "Thông tư 133/2016/TT-BTC", "doi_tuong": "Doanh nghiệp nhỏ và vừa",
              "hieu_luc": "", "tai_khoan": tt133.TAI_KHOAN},
    "TT99": {"ten": "Thông tư 99/2025/TT-BTC", "doi_tuong": "Doanh nghiệp (thay Thông tư 200/2014)",
             "hieu_luc": "Năm tài chính bắt đầu từ 01/01/2026", "tai_khoan": tt99.TAI_KHOAN},
    "TT58": {"ten": "Thông tư 58/2026/TT-BTC", "doi_tuong": "Doanh nghiệp siêu nhỏ (thay Thông tư 132/2018)",
             "hieu_luc": "Từ 01/07/2026, năm tài chính bắt đầu từ ngày này", "tai_khoan": tt133.TAI_KHOAN},
    "TT152": {"ten": "Thông tư 152/2025/TT-BTC", "doi_tuong": "Hộ kinh doanh, cá nhân kinh doanh (thay Thông tư 88/2021)",
              "hieu_luc": "Từ 01/01/2026", "tai_khoan": tt133.TAI_KHOAN},
}
MAC_DINH = "TT133"


def ma(ct):
    """Ma che do cua cong ty (dong cong_ty hoac chuoi)."""
    v = ct if isinstance(ct, str) else (ct["che_do"] if ct is not None else None)
    return v if v in CHE_DO else MAC_DINH


def ten_day_du(m):
    c = CHE_DO[ma(m)]
    return f'{c["ten"]} · {c["doi_tuong"]}'


# Tai khoan ung dung dung tu dong, khac nhau theo he thong tai khoan
_TK = {
    "TT133": {"bhtn": "3385", "ts_huu_hinh": "2111", "cp_quan_ly": "6422", "cp_ban_hang": "6421"},
    "TT99": {"bhtn": "3386", "ts_huu_hinh": "211", "cp_quan_ly": "6428", "cp_ban_hang": "6418"},
}


def tk(m, vai_tro):
    return _TK.get(ma(m), _TK["TT133"])[vai_tro]


def che_do_cty(con, cid):
    r = con.execute("SELECT che_do FROM cong_ty WHERE id=?", (cid,)).fetchone()
    return ma(r["che_do"] if r else None)


def nap_tai_khoan(con, cid, m):
    """Them cac tai khoan cua che do `m` con thieu (khong xoa tai khoan cu de giu so lieu)."""
    from . import db
    n = 0
    for so_tk, ten, tc in CHE_DO[ma(m)]["tai_khoan"]:
        if not con.execute("SELECT 1 FROM tai_khoan WHERE cong_ty_id=? AND so_tk=?", (cid, so_tk)).fetchone():
            db.them_tai_khoan(con, cid, so_tk, ten, tc)
            n += 1
    return n


def doi_che_do(con, cid, m):
    """Doi che do: nap them tai khoan cua che do moi, doi TK chi phi mac dinh cua hoa don mua vao neu dang de mac dinh."""
    m = ma(m)
    con.execute("UPDATE cong_ty SET che_do=? WHERE id=?", (m, cid))
    n = nap_tai_khoan(con, cid, m)
    cot = {r[1] for r in con.execute("PRAGMA table_info(cong_ty)")}
    if "tk_mua_mac_dinh" in cot:
        moi = tk(m, "cp_quan_ly")
        con.execute("UPDATE cong_ty SET tk_mua_mac_dinh=? WHERE id=? AND (tk_mua_mac_dinh IS NULL OR tk_mua_mac_dinh IN ('6422','6428'))",
                    (moi, cid))
    con.commit()
    return n


# ------------------------------------------------------------------ muc bao cao theo che do

# Muc tren trang Bao cao, to khai duoc hien theo che do (ma muc trong trang_bao_cao.MUC)
BAO_CAO = {
    "TT133": ("bctc", "gtgt", "tndn", "tncn", "mau", "ketchuyen"),
    "TT99": ("kqkd", "gtgt", "tndn", "tncn", "mau", "ketchuyen"),
    "TT58": ("kqkd", "gtgt", "tndn", "tncn", "mau", "ketchuyen"),
    "TT152": ("gtgt", "tncn", "mau"),
}


def co_bao_cao(m, muc):
    return muc in BAO_CAO[ma(m)]


# ------------------------------------------------------------------ so theo mau rieng (TT58, TT152)

# (ma so, ten so, loai, ghi chu ap dung)
SO = {
    "TT152": [
        ("S1a-HKD", "Sổ doanh thu bán hàng hóa, dịch vụ", "doanh_thu",
         "Hộ, cá nhân kinh doanh doanh thu dưới ngưỡng chịu thuế: chỉ ghi doanh thu, không tính thuế."),
        ("S2a-HKD", "Sổ doanh thu bán hàng hóa, dịch vụ", "doanh_thu_thue",
         "Nộp thuế GTGT và TNCN theo tỷ lệ % trên doanh thu: doanh thu theo nhóm ngành nghề cùng tỷ lệ."),
        ("S2b-HKD", "Sổ doanh thu bán hàng hóa, dịch vụ", "doanh_thu_gtgt",
         "Nộp GTGT theo % doanh thu, TNCN theo thu nhập tính thuế: doanh thu theo nhóm cùng tỷ lệ GTGT."),
        ("S2c-HKD", "Sổ chi tiết doanh thu, chi phí", "thu_chi",
         "Nộp TNCN theo thu nhập tính thuế: doanh thu và chi phí hợp lý làm căn cứ tính thu nhập."),
        ("S2d-HKD", "Sổ chi tiết vật liệu, dụng cụ, sản phẩm, hàng hóa", "vat_tu", "Nhập, xuất, tồn theo từng mặt hàng."),
        ("S2e-HKD", "Sổ chi tiết tiền", "tien", "Tiền mặt và tiền gửi không kỳ hạn."),
        ("S3a-HKD", "Sổ theo dõi nghĩa vụ thuế khác", "thue_khac",
         "Thuế TTĐB, xuất nhập khẩu, tài nguyên, bảo vệ môi trường, đất đai... (nếu có)."),
    ],
    "TT58": [
        ("S1-DNSN", "Sổ doanh thu bán hàng hóa, dịch vụ", "doanh_thu_thue",
         "Nộp TNDN và GTGT theo tỷ lệ % trên doanh thu."),
        ("S2a-DNSN", "Sổ doanh thu bán hàng hóa, dịch vụ", "doanh_thu_gtgt",
         "Nộp TNDN theo thu nhập tính thuế, GTGT theo % doanh thu."),
        ("S2b-DNSN", "Sổ chi tiết doanh thu, chi phí", "thu_chi", "Nộp TNDN theo thu nhập tính thuế."),
        ("S2c-DNSN", "Sổ chi tiết vật liệu, dụng cụ, sản phẩm, hàng hóa", "vat_tu", "Nhập, xuất, tồn theo từng mặt hàng."),
        ("S2d-DNSN", "Sổ chi tiết tiền", "tien", "Tiền mặt và tiền gửi không kỳ hạn."),
        ("S3a-DNSN", "Sổ doanh thu bán hàng hóa, dịch vụ", "doanh_thu",
         "Nộp TNDN theo % doanh thu, GTGT theo phương pháp khấu trừ."),
        ("S3b-DNSN", "Sổ theo dõi nghĩa vụ thuế GTGT", "gtgt_khau_tru", "Nộp GTGT theo phương pháp khấu trừ."),
        ("S4a-DNSN", "Sổ chi tiết thanh toán công nợ", "cong_no", "Tự chọn."),
        ("S4b-DNSN", "Sổ tài sản cố định", "tai_san", "Tự chọn."),
        ("S4c-DNSN", "Sổ theo dõi nghĩa vụ thuế khác", "thue_khac", "Tự chọn."),
        ("S4d-DNSN", "Sổ theo dõi vốn chủ sở hữu", "von", "Tự chọn."),
    ],
}

# Nhom nganh nghe tinh thue tren doanh thu. Mac dinh gan theo tai khoan doanh thu cap 2.
# Ty le GTGT, TNCN cua ho kinh doanh theo Thong tu 40/2021 (con dung den khi co huong dan moi); ty le TNDN cua
# doanh nghiep sieu nho de trong de nguoi dung nhap theo quy dinh dang ap dung. Sua duoc tren trang so.
NHOM = [
    ("hang_hoa", "Phân phối, cung cấp hàng hóa", "5111", 1.0, 0.5),
    ("san_xuat", "Sản xuất, vận tải, dịch vụ gắn với hàng hóa, xây dựng có bao thầu nguyên vật liệu", "5112", 3.0, 1.5),
    ("dich_vu", "Dịch vụ, xây dựng không bao thầu nguyên vật liệu", "5113", 5.0, 2.0),
    ("khac", "Hoạt động kinh doanh khác", "5118", 2.0, 1.0),
]


def chuan_bi(con):
    con.execute("""CREATE TABLE IF NOT EXISTS ty_le_doanh_thu (
        cong_ty_id INTEGER NOT NULL, nhom TEXT NOT NULL, gtgt REAL, tndn_tncn REAL,
        PRIMARY KEY (cong_ty_id, nhom))""")


def ty_le(con, cid):
    """{nhom: (gtgt %, tndn/tncn %)}. Mac dinh: GTGT, TNCN theo TT40/2021 cho ho kinh doanh; DN sieu nho TNDN = 0."""
    chuan_bi(con)
    dn = che_do_cty(con, cid) == "TT58"
    kq = {n: (g, 0.0 if dn else t) for n, _, _, g, t in NHOM}
    for r in con.execute("SELECT * FROM ty_le_doanh_thu WHERE cong_ty_id=?", (cid,)):
        if r["nhom"] in kq:
            kq[r["nhom"]] = (r["gtgt"] or 0.0, r["tndn_tncn"] or 0.0)
    return kq


def luu_ty_le(con, cid, ds):
    chuan_bi(con)
    for nhom, (g, t) in ds.items():
        con.execute("INSERT OR REPLACE INTO ty_le_doanh_thu VALUES (?,?,?,?)", (cid, nhom, float(g), float(t)))
    con.commit()


def nhom_cua_tk(so_tk):
    for n, _, tk, _, _ in NHOM:
        if so_tk.startswith(tk):
            return n
    return "hang_hoa" if so_tk in ("511", "") else "khac"


def _dong(con, cid, tu, den):
    q = ("SELECT c.id, c.ngay_ht, c.ngay_ct, c.so_ct, COALESCE(b.dien_giai, c.dien_giai, '') dg, b.tk_no, b.tk_co, b.so_tien "
         "FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ? "
         "ORDER BY c.ngay_ht, c.so_ct, b.stt")
    return [dict(r) for r in con.execute(q, (cid, tu, den))]


def doanh_thu(con, cid, tu, den):
    """Doanh thu ban hang theo chung tu (Co 511 tru giam tru No 511, bo ket chuyen 911).
    Tra ve list dict: ngay_ht, ngay_ct, so_ct, dien_giai, nhom, so_tien (am = giam tru)."""
    kq = []
    for r in _dong(con, cid, tu, den):
        if r["tk_no"].startswith("911") or r["tk_co"].startswith("911"):
            continue
        if r["tk_co"].startswith("511"):
            kq.append({**r, "dien_giai": r["dg"], "nhom": nhom_cua_tk(r["tk_co"]), "so_tien": r["so_tien"]})
        elif r["tk_no"].startswith(("511", "521")):
            tk = r["tk_no"] if r["tk_no"].startswith("511") else "511"
            kq.append({**r, "dien_giai": r["dg"], "nhom": nhom_cua_tk(tk), "so_tien": -r["so_tien"]})
    return kq


def thue_theo_nhom(con, cid, ds):
    """Cong doanh thu va thue theo nhom: {nhom: {'doanh_thu', 'gtgt', 'tndn_tncn', 'tl_gtgt', 'tl_tt'}}."""
    tl = ty_le(con, cid)
    kq = {}
    for d in ds:
        k = kq.setdefault(d["nhom"], {"doanh_thu": 0})
        k["doanh_thu"] += d["so_tien"]
    for n, k in kq.items():
        g, t = tl[n]
        k.update(tl_gtgt=g, tl_tt=t, gtgt=round(k["doanh_thu"] * g / 100), tndn_tncn=round(k["doanh_thu"] * t / 100))
    return kq


# Tai khoan chi phi tinh vao so chi tiet doanh thu, chi phi
_CHI_PHI = ("632", "635", "641", "642", "811", "621", "622", "623", "627")
_DOANH_THU_KHAC = ("515", "711")


def thu_chi(con, cid, tu, den):
    """Dong so chi tiet doanh thu, chi phi: list dict (ngay_ht, so_ct, dien_giai, doanh_thu, chi_phi)."""
    kq = []
    for r in _dong(con, cid, tu, den):
        a, b, t = r["tk_no"], r["tk_co"], r["so_tien"]
        if a.startswith("911") or b.startswith("911"):
            continue
        dt = (t if b.startswith(("511",) + _DOANH_THU_KHAC) else 0) - (t if a.startswith(("511", "521") + _DOANH_THU_KHAC) else 0)
        cp = (t if a.startswith(_CHI_PHI) else 0) - (t if b.startswith(_CHI_PHI) else 0)
        if dt or cp:
            kq.append({"ngay_ht": r["ngay_ht"], "ngay_ct": r["ngay_ct"], "so_ct": r["so_ct"], "dien_giai": r["dg"],
                       "doanh_thu": dt, "chi_phi": cp})
    return kq


def theo_doi_tk(con, cid, tien_to, tu, den):
    """So du dau, phat sinh tang (Co) / giam (No) va cuoi cua nhom tai khoan nguon von / thue (du Co).
    Tra ve (dau, dong[], cuoi) voi dong: ngay_ht, so_ct, dien_giai, tk, tang, giam."""
    from . import so_sach
    th = so_sach.tong_hop_tai_khoan(con, cid, tu, den)
    dau = sum(r["dau_co"] - r["dau_no"] for r in th if r["so_tk"] in tien_to)
    dong = []
    for r in _dong(con, cid, tu, den):
        if r["tk_no"].startswith(("911",)) and not r["tk_co"].startswith(tien_to):
            continue
        tang = r["so_tien"] if r["tk_co"].startswith(tien_to) else 0
        giam = r["so_tien"] if r["tk_no"].startswith(tien_to) else 0
        if tang != giam:
            dong.append({"ngay_ht": r["ngay_ht"], "so_ct": r["so_ct"], "dien_giai": r["dg"],
                         "tk": r["tk_co"] if tang else r["tk_no"], "tang": tang, "giam": giam})
    cuoi = dau + sum(d["tang"] - d["giam"] for d in dong)
    return dau, dong, cuoi


THUE_KHAC = ("3332", "3333", "3336", "3337", "3338", "3339")
VON = ("411", "418", "421")
