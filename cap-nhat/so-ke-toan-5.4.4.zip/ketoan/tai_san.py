"""Tai san co dinh (TSCD) va cong cu dung cu (CCDC): khai bao, khau hao, phan bo.

Cach tinh giong MISA:
- TSCD khau hao duong thang theo thang; thang dau tinh theo so ngay con lai
  trong thang (tu ngay bat dau khau hao). Thang cuoi lay phan con lai.
- CCDC phan bo deu theo ky (thang), ky dau tinh tron thang.
"""
import calendar
import json
from datetime import date, datetime

from . import che_do, db

SCHEMA = """
CREATE TABLE IF NOT EXISTS tai_san (
    id INTEGER PRIMARY KEY,
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    loai TEXT NOT NULL,                  -- 'TSCD' hoac 'CCDC'
    ma TEXT NOT NULL,
    ten TEXT NOT NULL,
    nhom TEXT,                           -- nhom theo TT45 (TSCD) hoac loai CCDC
    bo_phan TEXT,
    ngay_tang TEXT NOT NULL,             -- ngay ghi tang
    ngay_bat_dau TEXT NOT NULL,          -- ngay bat dau khau hao / phan bo
    nguyen_gia INTEGER NOT NULL,
    so_thang INTEGER NOT NULL,
    tk_tai_san TEXT NOT NULL,            -- 211x cho TSCD, 242 cho CCDC
    tk_hao_mon TEXT NOT NULL,            -- 2141 cho TSCD, 242 cho CCDC
    tk_chi_phi TEXT NOT NULL,            -- 6421, 6422, 154...
    luy_ke_dau INTEGER NOT NULL DEFAULT 0,   -- da khau hao truoc khi dua vao he thong
    den_thang_dau TEXT,                  -- 'YYYY-MM': luy_ke_dau tinh den het thang nay
    ngung_tu TEXT,                       -- 'YYYY-MM': thanh ly / ngung khau hao tu thang nay
    tai_lieu TEXT,                       -- JSON danh sach file dinh kem
    ghi_chu TEXT,
    UNIQUE (cong_ty_id, loai, ma)
);
CREATE TABLE IF NOT EXISTS khau_hao (
    tai_san_id INTEGER NOT NULL REFERENCES tai_san(id) ON DELETE CASCADE,
    thang TEXT NOT NULL,
    so_tien INTEGER NOT NULL,
    chung_tu_id INTEGER REFERENCES chung_tu(id) ON DELETE CASCADE,
    PRIMARY KEY (tai_san_id, thang)
);
"""

# Khung thoi gian trich khau hao (thang) theo Phu luc I Thong tu 45/2013/TT-BTC.
# Chi liet ke cac nhom hay gap; can doi chieu van ban khi gap nhom khac.
KHUNG_TT45 = {
    "Phương tiện vận tải đường bộ": (72, 120),
    "Máy móc, thiết bị xây dựng": (96, 180),
    "Thiết bị nâng hạ": (120, 180),
    "Máy móc, thiết bị văn phòng": (60, 96),
    "Máy vi tính, phương tiện tin học": (36, 96),
    "Nhà cửa loại kiên cố": (300, 600),
    "Nhà cửa khác": (72, 300),
    "Dụng cụ quản lý khác": (60, 120),
}
TOI_DA_CCDC = 36   # chi phi tra truoc phan bo toi da 3 nam


def chuan_bi(con):
    con.executescript(SCHEMA)


def _thang(s):
    return s[:7]


def _cong_thang(t, n):
    y, m = int(t[:4]), int(t[5:7]) + n
    y += (m - 1) // 12
    m = (m - 1) % 12 + 1
    return f"{y:04d}-{m:02d}"


def canh_bao(ts):
    """Danh sach canh bao cho mot tai san (dict hoac Row)."""
    cb = []
    if ts["loai"] == "TSCD":
        k = KHUNG_TT45.get(ts["nhom"] or "")
        if k and not (k[0] <= ts["so_thang"] <= k[1]):
            cb.append(f"Thời gian khấu hao {ts['so_thang']} tháng nằm ngoài khung TT45 của nhóm "
                      f"\"{ts['nhom']}\" ({k[0]}–{k[1]} tháng). Phần khấu hao vượt mức không được trừ khi tính thuế TNDN.")
        if ts["nguyen_gia"] < 30_000_000:
            cb.append("Nguyên giá dưới 30 triệu: không đủ tiêu chuẩn TSCĐ, nên theo dõi là CCDC (TK 242).")
    if ts["loai"] == "CCDC" and ts["so_thang"] > TOI_DA_CCDC:
        cb.append(f"CCDC phân bổ {ts['so_thang']} tháng, quá tối đa {TOI_DA_CCDC} tháng.")
    if ts["den_thang_dau"]:
        dung = sum(x for _, x in lich(ts, ts["den_thang_dau"]))
        if abs(dung - ts["luy_ke_dau"]) > 1000:
            cb.append(f"Lũy kế chuyển sang ({ts['luy_ke_dau']:,} đ) khác số đáng lẽ đã trích đến "
                      f"{ts['den_thang_dau'][5:]}/{ts['den_thang_dau'][:4]} ({dung:,} đ). Cần xem lại sổ cũ.".replace(",", "."))
    return cb


def lich(ts, den_thang):
    """Lich khau hao/phan bo tu dau den `den_thang` (YYYY-MM): list (thang, so_tien)."""
    ng, n = ts["nguyen_gia"], ts["so_thang"]
    hang_thang = round(ng / n)
    bd = datetime.strptime(ts["ngay_bat_dau"], "%Y-%m-%d").date()
    t = _thang(ts["ngay_bat_dau"])
    da = 0
    kq = []
    while t <= den_thang and da < ng:
        if ts["ngung_tu"] and t >= ts["ngung_tu"]:
            break
        if t == _thang(ts["ngay_bat_dau"]) and ts["loai"] == "TSCD":
            so_ngay = calendar.monthrange(bd.year, bd.month)[1]
            tien = round(hang_thang * (so_ngay - bd.day + 1) / so_ngay)
        else:
            tien = hang_thang
        tien = min(tien, ng - da)
        da += tien
        kq.append((t, tien))
        t = _cong_thang(t, 1)
    return kq


def so_trich_thang(ts, thang):
    """So khau hao/phan bo cua mot thang, co tinh luy ke da trich truoc khi dua vao he thong."""
    if ts["den_thang_dau"] and thang <= ts["den_thang_dau"]:
        return 0
    ds = lich(ts, thang)
    if not ds or ds[-1][0] != thang:
        return 0
    if ts["den_thang_dau"]:
        # Tai san chuyen tu he thong cu: lich chuan cong den thang truoc so voi luy ke thuc te
        truoc = sum(x for t, x in ds[:-1])
        con_lai = ts["nguyen_gia"] - max(truoc, ts["luy_ke_dau"])
        return max(0, min(ds[-1][1], con_lai))
    return ds[-1][1]


def luy_ke(con, ts, den_thang):
    r = con.execute("SELECT COALESCE(SUM(so_tien),0) s FROM khau_hao WHERE tai_san_id=? AND thang<=?",
                    (ts["id"], den_thang)).fetchone()
    return ts["luy_ke_dau"] + r["s"]


def luu(con, cid, d):
    """Them hoac sua tai san theo (loai, ma). d co cac truong cua bang tai_san."""
    d = {k: v for k, v in d.items() if v not in (None, "")}
    cu = con.execute("SELECT id FROM tai_san WHERE cong_ty_id=? AND loai=? AND ma=?",
                     (cid, d["loai"], d["ma"])).fetchone()
    if cu:
        # Sua tai san da co: chi doi cac truong duoc gui, giu nguyen phan con lai
        for k in ("tk_tai_san", "tk_hao_mon", "tk_chi_phi"):
            if k in d:
                db.them_tai_khoan(con, cid, d[k], f"TK {d[k]}")
        con.execute(f"UPDATE tai_san SET {', '.join(k + '=?' for k in d)} WHERE id=?", list(d.values()) + [cu["id"]])
        return cu["id"]
    d.setdefault("ngay_bat_dau", d["ngay_tang"])
    if d["loai"] == "CCDC":
        d.setdefault("tk_tai_san", "242")
        d.setdefault("tk_hao_mon", "242")
    else:
        d.setdefault("tk_tai_san", che_do.tk(che_do.che_do_cty(con, cid), "ts_huu_hinh"))
        d.setdefault("tk_hao_mon", "2141")
    d.setdefault("tk_chi_phi", che_do.tk(che_do.che_do_cty(con, cid), "cp_quan_ly"))
    for k in ("tk_tai_san", "tk_hao_mon", "tk_chi_phi"):
        db.them_tai_khoan(con, cid, d[k], f"TK {d[k]}")
    d["cong_ty_id"] = cid
    return con.execute(f"INSERT INTO tai_san ({', '.join(d)}) VALUES ({', '.join('?' * len(d))})",
                       list(d.values())).lastrowid


def trich_thang(con, cid, thang):
    """Trich khau hao TSCD va phan bo CCDC cho thang (YYYY-MM), ghi mot chung tu.

    Chay lai cho cung thang se thay chung tu cu. Tra ve (chung_tu_id, list dong).
    """
    so_ct = f"KH-{thang.replace('-', '')}"
    cu = con.execute("SELECT id FROM chung_tu WHERE cong_ty_id=? AND so_ct=?", (cid, so_ct)).fetchone()
    if cu:
        con.execute("DELETE FROM khau_hao WHERE chung_tu_id=?", (cu["id"],))
        con.execute("DELETE FROM chung_tu WHERE id=?", (cu["id"],))
    y, m = int(thang[:4]), int(thang[5:])
    ngay = date(y, m, calendar.monthrange(y, m)[1]).isoformat()
    dong, ghi = [], []
    for ts in con.execute("SELECT * FROM tai_san WHERE cong_ty_id=? ORDER BY loai DESC, ma", (cid,)).fetchall():
        tien = so_trich_thang(ts, thang)
        if tien > 0:
            viec = "Khấu hao" if ts["loai"] == "TSCD" else "Phân bổ"
            dong.append({"tk_no": ts["tk_chi_phi"], "tk_co": ts["tk_hao_mon"], "so_tien": tien,
                         "dien_giai": f"{viec} {ts['ten']} tháng {m:02d}/{y}"})
            ghi.append((ts["id"], tien))
    if not dong:
        con.commit()
        return None, []
    ct = db.ghi_chung_tu(con, cid, so_ct, ngay, ngay, dong, loai="KH",
                         dien_giai=f"Khấu hao TSCĐ, phân bổ CCDC tháng {m:02d}/{y}", nguon="tai_san")
    con.executemany("INSERT OR REPLACE INTO khau_hao VALUES (?,?,?,?)", [(i, thang, t, ct) for i, t in ghi])
    con.commit()
    return ct, dong


def them_tai_lieu(con, ts_id, ten_file):
    r = con.execute("SELECT tai_lieu FROM tai_san WHERE id=?", (ts_id,)).fetchone()
    ds = json.loads(r["tai_lieu"] or "[]")
    if ten_file not in ds:
        ds.append(ten_file)
    con.execute("UPDATE tai_san SET tai_lieu=? WHERE id=?", (json.dumps(ds, ensure_ascii=False), ts_id))
    con.commit()
