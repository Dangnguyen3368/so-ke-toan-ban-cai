"""Tu dong tai hoa don tu cong thue moi ngay.

Cong hoadondientu bat go captcha khi dang nhap, nen khong the tu dang nhap. Cach lam:
- Khi nguoi dung dang nhap cong thue, phien (token) duoc giu lai den khi cong cho het han
  (doc tu han trong token), ke ca khi tat mo lai ung dung. Mat khau khong bao gio duoc luu.
- Moi ngay, tu gio da chon, neu con phien thi may tu tai hoa don mua vao va ban ra
  (co ma, khong ma) tu dau thang truoc den hom nay, chi tai XML cho hoa don chua co XML.
- Neu het phien, muc "Viec can lam" nhac dang nhap (go 1 captcha); dang nhap xong may tu tai luon.
- Hoa don may tinh tien van phai go captcha moi thang nen khong tu tai.
"""
import base64
import json
import threading
import time
from datetime import date, datetime, timedelta

from . import cai_dat, cong_hddt, db, hoa_don

_KHOA = threading.Lock()
_DANG_CHAY = set()
GIO_MAC_DINH = 7


def _tep(ten):
    return cai_dat.THU_MUC_DL / ten


def _doc(ten):
    try:
        return json.loads(_tep(ten).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _ghi(ten, d):
    t = _tep(ten)
    t.parent.mkdir(parents=True, exist_ok=True)
    tam = t.with_suffix(".tmp")
    tam.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tam.replace(t)


# ------------------------------------------------------------------ phien cong thue

def han_token(token):
    """Thoi diem (epoch) token het han, doc tu phan 'exp' cua JWT. Khong doc duoc thi tinh 8 gio."""
    try:
        phan = token.split(".")[1]
        d = json.loads(base64.urlsafe_b64decode(phan + "=" * (-len(phan) % 4)))
        return float(d["exp"])
    except (IndexError, ValueError, KeyError, TypeError):
        return time.time() + 8 * 3600


def luu_phien(cid, token):
    with _KHOA:
        d = _doc("phien_cong.json")
        d[str(cid)] = {"token": token, "het": han_token(token)}
        _ghi("phien_cong.json", d)


def xoa_phien(cid):
    with _KHOA:
        d = _doc("phien_cong.json")
        if d.pop(str(cid), None) is not None:
            _ghi("phien_cong.json", d)


def lay_phien(cid):
    """Token con han (con it nhat 5 phut) cua cong ty, hoac None."""
    p = _doc("phien_cong.json").get(str(cid))
    if p and p.get("het", 0) > time.time() + 300:
        return p["token"]
    return None


# ------------------------------------------------------------------ cai dat va trang thai

def cau_hinh(cid):
    c = (cai_dat.doc().get("tu_tai_hd") or {}).get(str(cid)) or {}
    return {"bat": bool(c.get("bat")), "gio": int(c.get("gio", GIO_MAC_DINH))}


def dat_cau_hinh(cid, bat, gio):
    cd = cai_dat.doc()
    t = cd.get("tu_tai_hd") or {}
    t[str(cid)] = {"bat": bool(bat), "gio": max(0, min(23, int(gio)))}
    cd["tu_tai_hd"] = t
    cai_dat.ghi(cd)


def trang_thai(cid):
    return _doc("tu_tai_hd.json").get(str(cid)) or {}


def _ghi_trang_thai(cid, **kw):
    with _KHOA:
        d = _doc("tu_tai_hd.json")
        d.setdefault(str(cid), {}).update(kw)
        _ghi("tu_tai_hd.json", d)


def den_han(cid, bay_gio=None):
    """Hom nay da den gio tu tai ma chua tai thanh cong."""
    bg = bay_gio or datetime.now()
    c = cau_hinh(cid)
    return c["bat"] and bg.hour >= c["gio"] and trang_thai(cid).get("ngay") != bg.date().isoformat()


def khoang_tai(hom_nay=None):
    """Tu dau thang truoc den hom nay: hoa don ben ban gui muon van duoc lay."""
    hn = hom_nay or date.today()
    dau = (hn.replace(day=1) - timedelta(days=1)).replace(day=1)
    return dau.isoformat(), hn.isoformat()


# ------------------------------------------------------------------ tai

def tai(duong_dan_db, cid, token, hom_nay=None):
    """Tai mot lan cho mot cong ty. Tra ve chuoi ket qua. Nem LoiCong neu het phien."""
    tu, den = khoang_tai(hom_nay)
    canh_bao = []
    con = db.mo(duong_dan_db)
    try:
        da_co = {cong_hddt.khoa_hd(dict(r)) for r in con.execute(
            "SELECT nbmst, khmshdon, khhdon, shdon FROM hoa_don WHERE cong_ty_id=? AND co_xml=1", (cid,))}
        dong = []
        for chieu in ("mua", "ban"):
            hds = cong_hddt.tai_ve(token, chieu, tu, den, kem_xml=True, da_co_xml=da_co,
                                   bao=lambda s: canh_bao.append(s) if s.startswith(("Không tải được", "Dừng")) else None)
            dem = hoa_don.luu(con, cid, hds, f"cong_thue_{chieu}")
            con.commit()
            dong.append(f"{'mua vào' if chieu == 'mua' else 'bán ra'} {len(hds)} ({dem['moi']} mới)")
    finally:
        con.close()
    return f"Từ {tu[8:]}/{tu[5:7]} đến {den[8:]}/{den[5:7]}: " + ", ".join(dong), canh_bao


def chay_mot(duong_dan_db, cid, hom_nay=None):
    """Chay tu tai cho mot cong ty neu con phien. Tra ve True neu da tai."""
    with _KHOA:
        if cid in _DANG_CHAY:
            return False
        _DANG_CHAY.add(cid)
    try:
        token = lay_phien(cid)
        if not token:
            _ghi_trang_thai(cid, can_dang_nhap=True)
            return False
        luc = datetime.now().strftime("%d/%m/%Y %H:%M")
        try:
            kq, canh_bao = tai(duong_dan_db, cid, token, hom_nay)
        except cong_hddt.LoiCong as ex:
            if "hết hạn" in str(ex):
                xoa_phien(cid)
                _ghi_trang_thai(cid, can_dang_nhap=True, luc=luc, loi=str(ex))
            else:
                _ghi_trang_thai(cid, luc=luc, loi=str(ex))
            return False
        _ghi_trang_thai(cid, ngay=(hom_nay or date.today()).isoformat(), luc=luc, kq=kq,
                        loi="; ".join(canh_bao[:3]), can_dang_nhap=False)
        return True
    finally:
        with _KHOA:
            _DANG_CHAY.discard(cid)


def chay_ngay(duong_dan_db, cid):
    """Chay nen ngay (vd vua dang nhap xong) neu dang bat va den han."""
    if den_han(cid):
        threading.Thread(target=chay_mot, args=(duong_dan_db, cid), daemon=True).start()


def chay_nen(lay_duong_dan, khoang=15 * 60):
    """Luong nen: cu 15 phut xem cong ty nao den han tu tai."""
    def vong():
        time.sleep(60)
        while True:
            try:
                for cid in list((cai_dat.doc().get("tu_tai_hd") or {}).keys()):
                    if den_han(int(cid)):
                        chay_mot(lay_duong_dan(), int(cid))
            except Exception as ex:  # khong de luong nen chet
                print("Tự tải hóa đơn lỗi:", ex)
            time.sleep(khoang)
    threading.Thread(target=vong, daemon=True).start()


def viec(cid, bay_gio=None):
    """Dong 'viec can lam' cho cong ty (dung trong quan_ly.viec_can_lam)."""
    if not cau_hinh(cid)["bat"]:
        return []
    tt = trang_thai(cid)
    if den_han(cid, bay_gio) and not lay_phien(cid):
        return [("vang", "Đến giờ tự tải hóa đơn hôm nay: đăng nhập cổng thuế (gõ 1 captcha), máy sẽ tự tải", "hoadon/cong")]
    if tt.get("loi") and tt.get("ngay") != (bay_gio or datetime.now()).date().isoformat():
        return [("do", f"Tự tải hóa đơn lỗi lúc {tt.get('luc', '')}: {tt['loi'][:150]}", "hoadon/cong")]
    return []
