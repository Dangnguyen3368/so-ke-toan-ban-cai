"""Luong, bao hiem, thue TNCN khau tru tai nguon.

Tham so (giam tru gia canh, bieu thue, ty le bao hiem, muc tran) dat theo
thoi ky trong THAM_SO. Khi nha nuoc thay doi, them mot dong moi voi ngay
hieu luc; cac thang cu van tinh theo tham so cu.
"""
import calendar
import re
from datetime import date

from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS nhan_vien (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    ma TEXT NOT NULL,
    ho_ten TEXT NOT NULL,
    mst TEXT, cccd TEXT, ngay_sinh TEXT, bo_phan TEXT,
    luong_bh INTEGER NOT NULL DEFAULT 0,     -- muc luong dong bao hiem
    dong_bh INTEGER NOT NULL DEFAULT 1,
    hop_dong TEXT NOT NULL DEFAULT 'DH',     -- 'DH' tu 3 thang tro len, 'NH' duoi 3 thang / thoi vu
    cu_tru INTEGER NOT NULL DEFAULT 1,
    tk_chi_phi TEXT NOT NULL DEFAULT '6422',
    PRIMARY KEY (cong_ty_id, ma)
);
CREATE TABLE IF NOT EXISTS nguoi_phu_thuoc (
    id INTEGER PRIMARY KEY,
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    ma_nv TEXT NOT NULL,
    ho_ten TEXT NOT NULL, ngay_sinh TEXT, mst TEXT, cccd TEXT, quan_he TEXT,
    tu_thang TEXT NOT NULL, den_thang TEXT,  -- 'YYYY-MM'
    UNIQUE (cong_ty_id, ma_nv, ho_ten)
);
CREATE TABLE IF NOT EXISTS bang_luong (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    thang TEXT NOT NULL,
    ma_nv TEXT NOT NULL,
    ngay_cong REAL NOT NULL DEFAULT 0,
    cong_chuan REAL NOT NULL DEFAULT 26,
    luong_co_ban INTEGER NOT NULL DEFAULT 0,
    phu_cap_chiu_thue INTEGER NOT NULL DEFAULT 0,
    phu_cap_mien_thue INTEGER NOT NULL DEFAULT 0,  -- an trua, dien thoai... trong muc mien
    thuong INTEGER NOT NULL DEFAULT 0,
    khau_tru_khac INTEGER NOT NULL DEFAULT 0,
    ket_qua TEXT,                                  -- JSON ket qua tinh
    PRIMARY KEY (cong_ty_id, thang, ma_nv)
);
"""

# Tham so theo thoi ky. CAN DOI CHIEU VAN BAN HIEN HANH truoc khi dung chinh thuc.
THAM_SO = [
    {
        "tu": "2020-07",
        "giam_tru_ban_than": 11_000_000, "giam_tru_npt": 4_400_000,          # NQ 954/2020/UBTVQH14
        "bieu_thue": [(5_000_000, 5), (10_000_000, 10), (18_000_000, 15), (32_000_000, 20),
                      (52_000_000, 25), (80_000_000, 30), (None, 35)],
        "luong_co_so": 2_340_000,
    },
    {
        "tu": "2026-01",
        "giam_tru_ban_than": 15_500_000, "giam_tru_npt": 6_200_000,          # NQ 110/2025/UBTVQH15
        # Bieu 5 bac theo Luat Thue TNCN sua doi 2025; kiem tra lai thoi diem ap dung
        "bieu_thue": [(10_000_000, 5), (30_000_000, 10), (60_000_000, 20), (100_000_000, 30), (None, 35)],
        "luong_co_so": 2_340_000,
    },
]
# Ty le bao hiem (%): (nguoi lao dong, doanh nghiep)
TY_LE_BH = {"3383": (8.0, 17.5), "3384": (1.5, 3.0), "3385": (1.0, 1.0)}
TEN_BH = {"3383": "BHXH", "3384": "BHYT", "3385": "BHTN"}


def chuan_bi(con):
    con.executescript(SCHEMA)


def tham_so(thang):
    return [t for t in THAM_SO if t["tu"] <= thang][-1]


def thue_luy_tien(tntt, bieu):
    thue, duoi = 0, 0
    for tren, ts in bieu:
        if tntt <= duoi:
            break
        phan = (tntt if tren is None else min(tntt, tren)) - duoi
        thue += phan * ts / 100
        if tren is None:
            break
        duoi = tren
    return round(thue)


def lam_sach_ten(s):
    """Bo xuong dong, khoang trang thua (loi da gap o XML quyet toan TNCN)."""
    return re.sub(r"\s+", " ", str(s or "")).strip()


def so_npt(con, cid, ma_nv, thang):
    return con.execute(
        "SELECT COUNT(*) n FROM nguoi_phu_thuoc WHERE cong_ty_id=? AND ma_nv=? AND tu_thang<=? "
        "AND (den_thang IS NULL OR den_thang='' OR den_thang>=?)", (cid, ma_nv, thang, thang)).fetchone()["n"]


def tinh_mot(nv, bl, n_npt, thang):
    """Tinh luong mot nguoi mot thang. Tra ve dict ket qua."""
    ts = tham_so(thang)
    luong = round(bl["luong_co_ban"] * bl["ngay_cong"] / bl["cong_chuan"]) if bl["cong_chuan"] else bl["luong_co_ban"]
    tong = luong + bl["phu_cap_chiu_thue"] + bl["phu_cap_mien_thue"] + bl["thuong"]
    bh = {}
    if nv["dong_bh"]:
        tran = 20 * ts["luong_co_so"]
        nen = min(nv["luong_bh"], tran)
        for tk, (nld, dn) in TY_LE_BH.items():
            bh[tk] = (round(nen * nld / 100), round(nen * dn / 100))
    bh_nld = sum(v[0] for v in bh.values())
    tnct = tong - bl["phu_cap_mien_thue"]
    if nv["cu_tru"] and nv["hop_dong"] == "DH":
        giam_tru = ts["giam_tru_ban_than"] + n_npt * ts["giam_tru_npt"] + bh_nld
        tntt = max(0, tnct - giam_tru)
        thue = thue_luy_tien(tntt, ts["bieu_thue"])
        cach = "Lũy tiến"
    elif nv["cu_tru"]:
        giam_tru, tntt = 0, tnct
        thue = round(tnct * 0.10) if tnct >= 2_000_000 else 0   # HĐ dưới 3 tháng: khấu trừ 10%
        cach = "10% (HĐ dưới 3 tháng)"
    else:
        giam_tru, tntt = 0, tnct
        thue = round(tnct * 0.20)
        cach = "20% (không cư trú)"
    return {
        "luong_thoi_gian": luong, "tong_thu_nhap": tong, "tn_chiu_thue": tnct, "so_npt": n_npt,
        "giam_tru": giam_tru, "tn_tinh_thue": tntt, "thue_tncn": thue, "cach_tinh_thue": cach,
        "bh": bh, "bh_nld": bh_nld, "bh_dn": sum(v[1] for v in bh.values()),
        "thuc_linh": tong - bh_nld - thue - bl["khau_tru_khac"],
    }


def tinh_thang(con, cid, thang):
    """Tinh bang luong thang, luu ket qua. Tra ve list (nhan_vien, bang_luong, ket_qua)."""
    import json
    kq = []
    for bl in con.execute("SELECT * FROM bang_luong WHERE cong_ty_id=? AND thang=? ORDER BY ma_nv", (cid, thang)).fetchall():
        nv = con.execute("SELECT * FROM nhan_vien WHERE cong_ty_id=? AND ma=?", (cid, bl["ma_nv"])).fetchone()
        if not nv:
            raise ValueError(f"Bảng lương có mã nhân viên {bl['ma_nv']} nhưng danh sách nhân viên chưa có.")
        r = tinh_mot(nv, bl, so_npt(con, cid, nv["ma"], thang), thang)
        con.execute("UPDATE bang_luong SET ket_qua=? WHERE cong_ty_id=? AND thang=? AND ma_nv=?",
                    (json.dumps(r, ensure_ascii=False), cid, thang, nv["ma"]))
        kq.append((nv, bl, r))
    con.commit()
    return kq


def ghi_so_thang(con, cid, thang):
    """Ghi so luong thang (chay lai se thay chung tu cu). Tra ve (chung_tu_id, so dong)."""
    ds = tinh_thang(con, cid, thang)
    so_ct = f"LUONG-{thang.replace('-', '')}"
    cu = con.execute("SELECT id FROM chung_tu WHERE cong_ty_id=? AND so_ct=?", (cid, so_ct)).fetchone()
    if cu:
        con.execute("DELETE FROM chung_tu WHERE id=?", (cu["id"],))
    y, m = int(thang[:4]), int(thang[5:])
    ngay = date(y, m, calendar.monthrange(y, m)[1]).isoformat()
    gop = {}

    def cong(no, co, tien, dg):
        if tien:
            k = (no, co, dg)
            gop[k] = gop.get(k, 0) + tien

    from . import che_do
    cd = che_do.che_do_cty(con, cid)
    for nv, bl, r in ds:
        tk = nv["tk_chi_phi"]
        cong(tk, "334", r["tong_thu_nhap"], f"Tiền lương phải trả tháng {m:02d}/{y}")
        for tkbh, (nld, dn) in r["bh"].items():
            ten_bh = TEN_BH[tkbh]
            tkbh = che_do.tk(cd, "bhtn") if tkbh == "3385" else tkbh
            cong("334", tkbh, nld, f"Trừ {ten_bh} người lao động tháng {m:02d}/{y}")
            cong(tk, tkbh, dn, f"{ten_bh} doanh nghiệp đóng tháng {m:02d}/{y}")
        cong("334", "3335", r["thue_tncn"], f"Khấu trừ thuế TNCN tháng {m:02d}/{y}")
        cong("334", "1388", bl["khau_tru_khac"], f"Khấu trừ khác vào lương tháng {m:02d}/{y}")
    dong = [{"tk_no": a, "tk_co": b, "dien_giai": dg, "so_tien": t} for (a, b, dg), t in gop.items()]
    if not dong:
        return None, 0
    for d in dong:
        for k in ("tk_no", "tk_co"):
            db.them_tai_khoan(con, cid, d[k], f"TK {d[k]}")
    ct = db.ghi_chung_tu(con, cid, so_ct, ngay, ngay, dong, loai="LUONG",
                         dien_giai=f"Lương và bảo hiểm tháng {m:02d}/{y}", nguon="luong")
    con.commit()
    return ct, len(dong)
