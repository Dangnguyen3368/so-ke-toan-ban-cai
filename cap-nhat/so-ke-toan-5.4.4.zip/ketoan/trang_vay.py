"""Trang Khe uoc vay (tron vao lop XuLy): danh sach, them khe uoc, lich tra, ghi so nhan vay va tung ky."""
from . import vay
from . import giao_dien as G
from .giao_dien import e, ngay_vn, so


def _so(s):
    s = (s or "").strip().replace(".", "").replace(",", "").replace(" ", "")
    return int(s) if s.lstrip("-").isdigit() else None


class TrangVay:
    def vay(self, pt, con, ct, q, rest):
        vay.chuan_bi(con)
        cid = ct["id"]
        if rest and rest[0].isdigit():
            return self._vay_xem(pt, con, ct, int(rest[0]))
        tb = ""
        if pt == "POST":
            f = {k: v[0].strip() for k, v in self.doc_form().items()}
            try:
                f["so_tien"] = _so(f.get("so_tien"))
                kid = vay.them(con, cid, f)
                return self.chuyen(f"/cty/{cid}/vay/{kid}")
            except Exception as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        dong = ""
        tong = 0
        for kv in vay.danh_sach(con, cid):
            t = vay.tinh_hinh(con, cid, kv)
            tong += t["du_no"]
            k = t["ky_tiep"]
            tt = (G.nhan_tt("Đã tất toán", "xanh") if not k else
                  G.nhan_tt("Quá hạn", "do") if t["qua_han"] else G.nhan_tt(f"Kỳ {k['ky']}: {ngay_vn(k['ngay'])}", "lam"))
            dong += (f'<tr><td><a href="/cty/{cid}/vay/{kv["id"]}"><b>{e(kv["so_khe_uoc"])}</b></a></td><td>{e(kv["ben_cho_vay"])}</td>'
                     f'<td>{ngay_vn(kv["ngay_vay"])}</td><td class="s">{so(kv["so_tien"])}</td><td class="s">{kv["lai_suat"]:g}%</td>'
                     f'<td class="s">{kv["so_ky"]} tháng</td><td class="s">{so(t["du_no"]) or 0}</td><td>{tt}</td></tr>')
        chon = "".join(f'<option value="{m}">{e(t)}</option>' for m, t in vay.CACH_TRA.items())
        nd = f"""<div class="luoi">{G.o_so("Dư nợ gốc theo khế ước", so(tong) or "0")}</div>
<div class="the"><h1>Khế ước vay</h1>{tb}
<table><tr><th>Số khế ước</th><th>Bên cho vay</th><th>Ngày vay</th><th class="s">Số tiền</th><th class="s">Lãi suất/năm</th>
<th class="s">Thời hạn</th><th class="s">Dư nợ gốc</th><th>Tình trạng</th></tr>{dong}</table></div>
<details class="the" {'open' if not dong else ''}><summary>Thêm khế ước vay</summary>
<form method="post" class="ngang" style="margin-top:12px">
<label>Số khế ước<input name="so_khe_uoc" required size="14"></label><label>Bên cho vay<input name="ben_cho_vay" required size="32"></label>
<label>Mã đối tượng (nếu có)<input name="ma_doi_tuong" size="10"></label><label>Ngày nhận tiền<input type="date" name="ngay_vay" required></label>
<label>Số tiền vay<input name="so_tien" required size="14"></label><label>Lãi suất %/năm<input name="lai_suat" size="6" value="0"></label>
<label>Số tháng<input type="number" name="so_ky" min="1" value="12" style="width:80px"></label>
<label>Cách trả<select name="cach_tra">{chon}</select></label>
<label>TK vay<input name="tk_vay" value="3411" size="6"></label><label>TK nhận / trả tiền<input name="tk_tien" value="1121" size="6"></label>
<label>TK lãi<input name="tk_lai" value="635" size="6"></label><label>Mục đích<input name="muc_dich" size="30"></label>
<button>Thêm</button></form>
<p class="mo">Lãi mỗi kỳ tính trên dư nợ đầu kỳ theo số ngày thực tế / 365. Khi ghi kỳ trả có thể sửa gốc, lãi theo giấy báo nợ của ngân hàng.</p></details>"""
        self.gui(G.trang("Khế ước vay", nd, cid, ct["ten"]))

    def _vay_xem(self, pt, con, ct, kid):
        cid = ct["id"]
        kv = vay.lay(con, cid, kid)
        if not kv:
            return self.gui(G.trang("Không tìm thấy", "<p>Không có khế ước này.</p>", cid, ct["ten"]), 404)
        tb = ""
        if pt == "POST":
            f = {k: v[0].strip() for k, v in self.doc_form().items()}
            try:
                if f.get("hanh_dong") == "nhan":
                    vay.ghi_nhan_vay(con, cid, kv)
                    tb = '<p class="ok">Đã ghi sổ nhận tiền vay.</p>'
                elif f.get("hanh_dong") == "ky":
                    ky = int(f["ky"])
                    vay.ghi_ky(con, cid, kv, ky, _so(f.get("goc")), _so(f.get("lai")), f.get("ngay") or None)
                    tb = f'<p class="ok">Đã ghi sổ kỳ {ky}.</p>'
                elif f.get("hanh_dong") == "xoa":
                    if vay.tinh_hinh(con, cid, kv)["da_ghi_ky"] or vay.da_ghi(con, cid, vay.so_ct_nhan(kv)):
                        raise ValueError("Khế ước đã có chứng từ ghi sổ: xóa các chứng từ VAY-/TRAVAY- trước.")
                    con.execute("DELETE FROM khe_uoc_vay WHERE id=? AND cong_ty_id=?", (kid, cid))
                    con.commit()
                    return self.chuyen(f"/cty/{cid}/vay")
            except Exception as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        t = vay.tinh_hinh(con, cid, kv)
        dong = ""
        for x in vay.lich_tra(kv):
            if x["ky"] in t["da_ghi_ky"]:
                hd = G.nhan_tt("Đã ghi sổ", "xanh")
            elif t["ky_tiep"] and x["ky"] == t["ky_tiep"]["ky"]:
                hd = (f'<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="ky"><input type="hidden" name="ky" value="{x["ky"]}">'
                      f'<input type="date" name="ngay" value="{x["ngay"]}"><input name="goc" size="11" value="{x["goc"]}" title="Gốc">'
                      f'<input name="lai" size="9" value="{x["lai"]}" title="Lãi"><button class="nho">Ghi sổ</button></form>')
            else:
                hd = ""
            dong += (f'<tr><td class="s">{x["ky"]}</td><td>{ngay_vn(x["ngay"])}</td><td class="s">{so(x["du_dau"])}</td>'
                     f'<td class="s">{so(x["goc"])}</td><td class="s">{so(x["lai"])}</td><td class="s">{so(x["tong"])}</td>'
                     f'<td class="s">{so(x["du_cuoi"]) or 0}</td><td>{hd}</td></tr>')
        lich = vay.lich_tra(kv)
        nhan = (G.nhan_tt("Đã ghi sổ nhận tiền", "xanh") if t["nhan_vay"] else
                '<form method="post" style="display:inline"><input type="hidden" name="hanh_dong" value="nhan">'
                f'<button class="nho">Ghi sổ nhận tiền vay (Nợ {e(kv["tk_tien"])} / Có {e(kv["tk_vay"])})</button></form>'
                ' <span class="mo">Bỏ qua nếu đã ghi khoản nhận tiền từ sao kê ngân hàng.</span>')
        nd = f"""<div class="luoi">{G.o_so("Số tiền vay", so(kv["so_tien"]))}{G.o_so("Dư nợ gốc", so(t["du_no"]) or "0")}
{G.o_so("Tổng lãi dự kiến", so(sum(x["lai"] for x in lich)) or "0")}{G.o_so("Kỳ đã ghi sổ", f'{len(t["da_ghi_ky"])}/{kv["so_ky"]}')}</div>
<div class="the"><h1>Khế ước {e(kv["so_khe_uoc"])}</h1>{tb}<table class="kv">
<tr><th>Bên cho vay</th><td>{e(kv["ben_cho_vay"])}{f' ({e(kv["ma_doi_tuong"])})' if kv["ma_doi_tuong"] else ''}</td></tr>
<tr><th>Ngày nhận tiền</th><td>{ngay_vn(kv["ngay_vay"])}</td></tr><tr><th>Lãi suất</th><td>{kv["lai_suat"]:g}%/năm</td></tr>
<tr><th>Thời hạn, cách trả</th><td>{kv["so_ky"]} tháng · {e(vay.CACH_TRA.get(kv["cach_tra"], kv["cach_tra"]))}</td></tr>
<tr><th>Tài khoản</th><td>Vay {e(kv["tk_vay"])} · Tiền {e(kv["tk_tien"])} · Lãi {e(kv["tk_lai"])}</td></tr>
{f'<tr><th>Mục đích</th><td>{e(kv["muc_dich"])}</td></tr>' if kv["muc_dich"] else ''}</table><p>{nhan}</p></div>
<div class="the"><h2>Lịch trả nợ</h2><table><tr><th class="s">Kỳ</th><th>Ngày trả</th><th class="s">Dư nợ đầu kỳ</th><th class="s">Gốc</th>
<th class="s">Lãi</th><th class="s">Tổng trả</th><th class="s">Dư nợ cuối kỳ</th><th></th></tr>{dong}</table>
<p class="mo">Mỗi kỳ ghi: Nợ {e(kv["tk_vay"])} (gốc), Nợ {e(kv["tk_lai"])} (lãi vay) / Có {e(kv["tk_tien"])}. Sửa số gốc, lãi, ngày theo giấy báo nợ trước khi bấm Ghi sổ.</p>
<form method="post" onsubmit="return confirm('Xóa khế ước này?')"><input type="hidden" name="hanh_dong" value="xoa">
<button class="nguy nho">Xóa khế ước</button> <a class="nut phu nho" href="/cty/{cid}/vay">← Danh sách</a></form></div>"""
        self.gui(G.trang(f"Khế ước {kv['so_khe_uoc']}", nd, cid, ct["ten"]))
