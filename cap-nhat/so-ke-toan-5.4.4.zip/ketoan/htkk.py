"""Xuat XML cho HTKK bang cach dien so vao mot file XML mau cua chinh cong ty.

Cach lam: lay file XML to khai da xuat tu HTKK (hoac da nop) lam mau, giu nguyen cau truc
va phien ban mau, chi thay so lieu, ky ke khai, ngay lap, ten va MST nguoi nop.
Chu ky so cu bi bo (file moi phai ky lai khi nop). Khong tu nop len cong thue.
"""
import copy
import re
import xml.etree.ElementTree as ET
from datetime import date
from pathlib import Path

NS = "http://kekhaithue.gdt.gov.vn/TKhaiThue"
N = "{" + NS + "}"
ET.register_namespace("", NS)
ET.register_namespace("xsi", "http://www.w3.org/2001/XMLSchema-instance")

LOAI = {"683": "BCTC", "892": "03/TNDN", "953": "05/QTT", "842": "01/GTGT"}


def _t(el):
    return el.tag.split("}")[-1]


def doc(du_lieu):
    try:
        return ET.fromstring(du_lieu)
    except ET.ParseError as ex:
        raise ValueError(f"File XML hỏng: {ex}")


def tim(goc, duong):
    el = goc
    for p in duong.split("/"):
        if el is None:
            return None
        el = el.find(N + p)
    return el


def thong_tin(goc):
    """Thong tin chinh cua mot file to khai HTKK."""
    tk = tim(goc, "HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue")
    nnt = tim(goc, "HSoKhaiThue/TTinChung/TTinTKhaiThue/NNT")
    if tk is None or nnt is None:
        raise ValueError("Không phải file tờ khai HTKK (thiếu TTinChung).")
    g = lambda e, k: (e.findtext(N + k) or "").strip()
    ma = g(tk, "maTKhai")
    ten = g(tk, "tenTKhai")
    loai = LOAI.get(ma)
    if not loai:
        loai = ("01/GTGT" if "GTGT" in ten and "01" in ten else "03/TNDN" if "03/TNDN" in ten
                else "05/QTT" if "05/QTT" in ten else "BCTC" if "B01" in ten else ma)
    ky = tk.find(N + "KyKKhaiThue")
    return {"ma": ma, "loai": loai, "ten_tk": ten, "phien_ban": g(tk, "pbanTKhaiXML"),
            "kieu_ky": g(ky, "kieuKy"), "ky": g(ky, "kyKKhai"), "mst": g(nnt, "mst"), "ten_nnt": g(nnt, "tenNNT")}


def _dat(el, gia_tri):
    if el is not None:
        el.text = "" if gia_tri is None else str(int(gia_tri) if isinstance(gia_tri, float) else gia_tri)


def dat_trong(goc_con, gia_tri):
    """Dat cac phan tu con truc tiep theo ten: {'ct110': 123, ...}."""
    for k, v in gia_tri.items():
        _dat(goc_con.find(N + k), v)


def _bo_chu_ky(goc):
    for cha in goc.iter():
        for c in list(cha):
            if _t(c) == "Signature":
                cha.remove(c)


def cap_nhat_chung(goc, ct, kieu_ky, ky, tu, den, tu_thang="", den_thang="", ngay_lap=None):
    """Cap nhat ky ke khai, ngay lap, nguoi ky, thong tin nguoi nop thue tu ho so cong ty."""
    ngay_lap = ngay_lap or date.today().isoformat()
    tk = tim(goc, "HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue")
    _dat(tk.find(N + "loaiTKhai"), "C")
    _dat(tk.find(N + "soLan"), "0")
    k = tk.find(N + "KyKKhaiThue")
    for ten, gt in [("kieuKy", kieu_ky), ("kyKKhai", ky), ("kyKKhaiTuNgay", tu), ("kyKKhaiDenNgay", den),
                    ("kyKKhaiTuThang", tu_thang), ("kyKKhaiDenThang", den_thang)]:
        _dat(k.find(N + ten), gt)
    _dat(tk.find(N + "ngayLapTKhai"), ngay_lap)
    _dat(tk.find(N + "ngayKy"), ngay_lap)
    if ct["nguoi_ky"]:
        _dat(tk.find(N + "nguoiKy"), ct["nguoi_ky"])
    if ct["ma_cqt"]:
        _dat(tk.find(N + "maCQTNoiNop"), ct["ma_cqt"])
    if ct["ten_cqt"]:
        _dat(tk.find(N + "tenCQTNoiNop"), ct["ten_cqt"])
    nnt = tim(goc, "HSoKhaiThue/TTinChung/TTinTKhaiThue/NNT")
    _dat(nnt.find(N + "mst"), ct["mst"])
    _dat(nnt.find(N + "tenNNT"), ct["ten"])
    if ct["dia_chi"]:
        _dat(nnt.find(N + "dchiNNT"), ct["dia_chi"])
    _bo_chu_ky(goc)


def xuat(goc):
    s = ET.tostring(goc, encoding="unicode")
    if "xmlns:xsi" not in s[:300]:
        s = s.replace("<HSoThueDTu ", '<HSoThueDTu xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ', 1)
    return ('<?xml version="1.0" encoding="UTF-8"?>\n' + s).encode("utf-8")


def _vn(d):
    return f"{d[8:10]}/{d[5:7]}/{d[:4]}"


# ------------------------------------------------------------------ B01a + B02 + CDTK

def lap_bctc(mau, ct, nam, cuoi, dau, kq_nay, kq_truoc, cdtk):
    """mau: bytes XML BCTC (maTKhai 683). cuoi/dau: chi tieu B01 ('110'...); kq_*: B02 ('01'...);
    cdtk: {tk: (dau_no, dau_co, ps_no, ps_co, cuoi_no, cuoi_co)}."""
    goc = doc(mau)
    cap_nhat_chung(goc, ct, "Y", str(nam), f"01/01/{nam}", f"31/12/{nam}")
    chinh = tim(goc, "HSoKhaiThue/CTieuTKhaiChinh")
    for ten, bang in (("SoCuoiNam", cuoi), ("SoDauNam", dau)):
        el = chinh.find(N + ten)
        if el is not None and bang is not None:
            dat_trong(el, {f"ct{k}": v for k, v in bang.items() if not k.startswith("_")})
    for ten in ("nguoiLapBieu", "nguoiDaiDienTheoPhapLuat"):
        if ct["nguoi_ky"]:
            _dat(chinh.find(N + ten), ct["nguoi_ky"])
    _dat(chinh.find(N + "ngayLap"), date.today().isoformat())
    kq = tim(goc, "HSoKhaiThue/PLuc/PL_KQHDSXKD")
    if kq is not None:
        for ten, bang in (("NamNay", kq_nay), ("NamTruoc", kq_truoc)):
            el = kq.find(N + ten)
            if el is not None and bang is not None:
                dat_trong(el, {f"ct{k}": v for k, v in bang.items() if not k.startswith("_")})
    pl = tim(goc, "HSoKhaiThue/PLuc/PL_CDTK")
    if pl is not None and cdtk:
        for muc, i in (("SoDuDauKy", 0), ("SoPhatSinhTrongKy", 2), ("SoDuCuoiKy", 4)):
            for ben, j in (("No", 0), ("Co", 1)):
                el = tim(pl, f"{muc}/{ben}")
                if el is None:
                    continue
                for c in el:
                    tk = "tongCong" if _t(c) == "tongCong" else _t(c)[2:]
                    if tk in cdtk:
                        _dat(c, cdtk[tk][i + j])
    return xuat(goc)


def doc_bctc(mau):
    """Doc so lieu tu mot file BCTC: (thong tin, SoCuoiNam, SoDauNam, NamNay, NamTruoc, cdtk)."""
    goc = doc(mau)
    tt = thong_tin(goc)

    def bang(duong):
        el = tim(goc, duong)
        if el is None:
            return None
        return {_t(c)[2:]: int(float(c.text)) for c in el if (c.text or "").strip().lstrip("-").replace(".", "").isdigit()}
    cdtk = {}
    pl = tim(goc, "HSoKhaiThue/PLuc/PL_CDTK")
    if pl is not None:
        for muc, i in (("SoDuDauKy", 0), ("SoPhatSinhTrongKy", 2), ("SoDuCuoiKy", 4)):
            for ben, j in (("No", 0), ("Co", 1)):
                el = tim(pl, f"{muc}/{ben}")
                for c in (el if el is not None else []):
                    tk = "tongCong" if _t(c) == "tongCong" else _t(c)[2:]
                    v = cdtk.setdefault(tk, [0] * 6)
                    v[i + j] = int(float((c.text or "0").strip() or 0))
    return (tt, bang("HSoKhaiThue/CTieuTKhaiChinh/SoCuoiNam"), bang("HSoKhaiThue/CTieuTKhaiChinh/SoDauNam"),
            bang("HSoKhaiThue/PLuc/PL_KQHDSXKD/NamNay"), bang("HSoKhaiThue/PLuc/PL_KQHDSXKD/NamTruoc"),
            {k: tuple(v) for k, v in cdtk.items()})


def tk_trong_mau_bctc(mau):
    goc = doc(mau)
    el = tim(goc, "HSoKhaiThue/PLuc/PL_CDTK/SoDuCuoiKy/No")
    return [_t(c)[2:] for c in el if _t(c) != "tongCong"] if el is not None else []


# ------------------------------------------------------------------ 03/TNDN

def doc_lo_03(mau):
    """Doc bang chuyen lo PL 03-2 (lo tu SXKD): (nam mau, [(nam_lo, so_lo, da_chuyen_truoc, chuyen_trong_nam)])."""
    goc = doc(mau)
    tt = thong_tin(goc)
    bang = tim(goc, "HSoKhaiThue/PLuc/PLuc_03_2_TNDN/Lo_HDSXKD/BangChiTietSoLo")
    ds = []
    for r in (bang if bang is not None else []):
        g = lambda k: int(float((r.findtext(N + k) or "0").strip() or 0))
        if g("ct2"):
            ds.append((g("ct2"), g("ct3"), g("ct4"), g("ct5")))
    return int(tt["ky"]), ds


def lap_03(mau, ct, nam, v, p, lo):
    goc = doc(mau)
    cap_nhat_chung(goc, ct, "Y", str(nam), f"01/01/{nam}", f"31/12/{nam}")
    chinh = tim(goc, "HSoKhaiThue/CTieuTKhaiChinh")
    # Xoa so cu cua cac chi tieu tinh thue de khong mang so nam truoc sang
    for c in chinh.iter():
        if len(c) == 0 and re.fullmatch(r"ct[C-I]\d+[a-z]?|tieuMuc\d+|tong\d+|soKK|thueTNDN_tamnop_\w+|ctE|ctG|ctI|ctD\d*",
                                       _t(c)):
            _dat(c, 0)
    dat_trong(chinh, {f"ct{k}": val for k, val in v.items() if re.fullmatch(r"[ABC]\d+[ab]?|C7_thuNhap|C7_thueSuat", k)})
    pl = tim(goc, "HSoKhaiThue/PLuc/PLuc_03_1A_TNDN")
    if pl is not None:
        dat_trong(pl, p)
    bang = tim(goc, "HSoKhaiThue/PLuc/PLuc_03_2_TNDN/Lo_HDSXKD/BangChiTietSoLo")
    if bang is not None:
        theo_nam = {x["nam_lo"]: x for x in lo}
        hang = list(bang)
        for i, r in enumerate(hang):
            nam_lo = nam - len(hang) + i
            x = theo_nam.get(nam_lo, {})
            dat_trong(r, {"ct2": nam_lo, "ct3": x.get("so_lo", 0), "ct4": x.get("da_chuyen", 0),
                          "ct5": x.get("chuyen", 0), "ct6": x.get("con_sau", 0)})
        _dat(tim(goc, "HSoKhaiThue/PLuc/PLuc_03_2_TNDN/Lo_HDSXKD/tongCong"), sum(x.get("chuyen", 0) for x in lo))
    return xuat(goc)


# ------------------------------------------------------------------ 05/QTT-TNCN

def _dung_lai(cha, ten_hang, ds, dien):
    """Thay cac phan tu lap `ten_hang` trong `cha` bang ban sao cua phan tu dau tien, dien theo ds."""
    cu = [c for c in cha if _t(c) == ten_hang]
    if not cu:
        return
    mau_hang = copy.deepcopy(cu[0])
    vi_tri = list(cha).index(cu[0])
    for c in cu:
        cha.remove(c)
    for i, d in enumerate(ds):
        h = copy.deepcopy(mau_hang)
        for c in h:
            if len(c) == 0 and (c.text or "").strip().lstrip("-").isdigit():
                c.text = "0"
        dat_trong(h, dien(d))
        cha.insert(vi_tri + i, h)


def lap_05(mau, ct, nam, chinh, ds1, t1, ds3):
    goc = doc(mau)
    cap_nhat_chung(goc, ct, "Y", str(nam), f"01/01/{nam}", f"31/12/{nam}")
    c = tim(goc, "HSoKhaiThue/CTieuTKhaiChinh")
    _dat(c.find(N + "mst_cu"), ct["mst"])
    nv = c.find(N + "NVuKhauTruThue")
    if nv is not None:
        for x in nv:
            _dat(x, 0)
        dat_trong(nv, {k: v for k, v in chinh.items() if k != "ct35"})
    qt = c.find(N + "NVuQToanThay")
    if qt is not None:
        for x in qt:
            _dat(x, 0)
        _dat(qt.find(N + "ct35"), chinh.get("ct35", 0))
    pl1 = tim(goc, "HSoKhaiThue/PLuc/PLuc_05_1_BK_QTT")
    if pl1 is not None:
        _dung_lai(pl1, "BKeCTietCNhan", ds1, lambda d: {
            "coDieuChinhSoLieu": 0, "ct07": d["ho_ten"], "ct08": d["mst"] or d["cccd"],
            "nguoiVNSongNN_NguoiNN": 0, "ct09a_ma": "03" if d["cccd"] else "",
            "ct09a_ten": "Thẻ CCCD/Số định danh cá nhân" if d["cccd"] else "", "ct09": d["cccd"],
            "ct10": 1 if d["uy_quyen"] else 0, "ct12": d["tnct"], "ct16": d["npt"], "ct17": d["gt_gc"],
            "ct19": d["bh"], "ct21": d["tntt"], "ct22": d["thue"]})
        for x in pl1:
            if len(x) == 0:
                _dat(x, 0)
        dat_trong(pl1, t1)
    pl3 = tim(goc, "HSoKhaiThue/PLuc/PLuc_05_3_BK_QTT")
    if pl3 is not None:
        _dung_lai(pl3, "BKeTTinNPT", ds3, lambda d: {
            "ct07": d["nv_ten"], "ct08": d["nv_ma_so"], "ct09": d["ho_ten"], "ct10": d["ngay_sinh"],
            "ct11": d["mst"], "nguoiVNSongNN_NguoiNN": 0, "ct12_ma": "03" if d["cccd"] else "",
            "ct12_ten": "Thẻ CCCD/Số định danh cá nhân" if d["cccd"] else "", "ct13": d["cccd"],
            "ct14_ma": d["qh_ma"], "ct14_ten": d["qh_ten"], "ct15": d["tu"], "ct16": d["den"]})
    return xuat(goc)


# ------------------------------------------------------------------ 01/GTGT

def lap_01gtgt(mau, ct, nam, quy, thang, v):
    """Dien 01/GTGT vao mau XML do HTKK xuat: tim phan tu ctNN o bat ky dau trong CTieuTKhaiChinh."""
    goc = doc(mau)
    if quy:
        tu_t, den_t = f"{3 * quy - 2:02d}/{nam}", f"{3 * quy:02d}/{nam}"
        import calendar
        cap_nhat_chung(goc, ct, "Q", f"{quy}/{nam}", f"01/{tu_t}",
                       f"{calendar.monthrange(nam, 3 * quy)[1]}/{den_t}", tu_t, den_t)
    else:
        import calendar
        cap_nhat_chung(goc, ct, "M", f"{thang:02d}/{nam}", f"01/{thang:02d}/{nam}",
                       f"{calendar.monthrange(nam, thang)[1]}/{thang:02d}/{nam}", f"{thang:02d}/{nam}", f"{thang:02d}/{nam}")
    chinh = tim(goc, "HSoKhaiThue/CTieuTKhaiChinh")
    dat = 0
    for c in chinh.iter():
        k = _t(c)
        if len(c) == 0 and k.startswith("ct") and k[2:] in v:
            _dat(c, v[k[2:]])
            dat += 1
    if not dat:
        raise ValueError("Mẫu XML 01/GTGT không có chỉ tiêu dạng ctNN, không điền được.")
    return xuat(goc)


def ten_file(mst, loai, ky):
    ma = {"BCTC": "133_B01A_DNN_BCTC", "03/TNDN": "03_TNDN_TT80", "05/QTT": "05_QTT_TNCN_TT80",
          "01/GTGT": "01_GTGT_TT80"}.get(loai, loai.replace("/", "_"))
    return f"{mst}000-{ma}-{ky}-L00.xml"


def thu_muc_mau(goc_dl, cid):
    p = Path(goc_dl) / "mau_htkk" / str(cid)
    p.mkdir(parents=True, exist_ok=True)
    return p


def luu_mau(goc_dl, cid, du_lieu):
    tt = thong_tin(doc(du_lieu))
    ten = tt["loai"].replace("/", "_") + ".xml"
    (thu_muc_mau(goc_dl, cid) / ten).write_bytes(du_lieu)
    return tt


def doc_mau(goc_dl, cid, loai):
    p = thu_muc_mau(goc_dl, cid) / (loai.replace("/", "_") + ".xml")
    return p.read_bytes() if p.exists() else None
