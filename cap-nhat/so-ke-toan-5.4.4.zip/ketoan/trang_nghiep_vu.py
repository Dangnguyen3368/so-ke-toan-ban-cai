"""Cac trang Kho, Luong, Tai san va tai file mau (tron vao lop XuLy)."""
import json
import re
from datetime import date
from urllib.parse import quote

from . import giao_dien as G
from . import kho, luong, mau_excel, tai_san
from .trang_hoa_don import doc_multipart

e, so = G.e, G.so


def _thang_nay():
    return date.today().strftime("%Y-%m")


def _loi(ds):
    return "".join(f'<p class="loi">{e(x)}</p>' for x in ds[:60]) + (
        f'<p class="loi">… và {len(ds) - 60} lỗi khác.</p>' if len(ds) > 60 else "")


class TrangNghiepVu:
    # ------------------------------------------------------------ file mau
    def mau(self, pt, con, ct, q, rest):
        loai = rest[0] if rest else ""
        cid = ct["id"]
        if loai == "kho":
            b, ten = mau_excel.mau_kho(con, cid), "Mau_kho"
        elif loai == "luong":
            t = q.get("thang", _thang_nay())
            b, ten = mau_excel.mau_luong(con, cid, t), f"Mau_luong_{t}"
        elif loai == "taisan":
            b, ten = mau_excel.mau_tai_san(con, cid), "Mau_tai_san"
        else:
            return self.gui("Không có mẫu này", 404)
        ten = f"{ten}_{ct['mst']}.xlsx"
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quote(ten)}")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _tep_tai_len(self):
        if not self.headers.get("Content-Type", "").startswith("multipart/"):
            return {}, []
        return doc_multipart(self)

    # ------------------------------------------------------------ Kho
    def kho(self, pt, con, ct, q, rest):
        cid = ct["id"]
        tb = ""
        if pt == "POST":
            truong, tep = self._tep_tai_len()
            if not tep and not truong:
                truong = {k: v[0] for k, v in self.doc_form().items()}
            hd = truong.get("hanh_dong")
            try:
                if hd == "nap" and tep:
                    nx, ntd, loi = mau_excel.doc_kho(con, cid, tep[0][1])
                    tb = f'<p class="ok">Đã nạp {nx} dòng xuất kho, {ntd} dòng tồn đầu.</p>' + _loi(loi)
                elif hd == "ton_misa" and tep:
                    n = mau_excel.doc_ton_kho_misa(con, cid, tep[0][1], truong.get("ngay") or f"{date.today().year}-01-01")
                    tb = f'<p class="ok">Đã lấy tồn đầu của {n} mặt hàng từ báo cáo MISA.</p>'
                elif hd == "tinh_gia":
                    ctid, cb = kho.tinh_gia_xuat(con, cid, truong["thang"])
                    tb = (f'<p class="ok">Đã tính giá xuất và ghi sổ tháng {e(truong["thang"])}.</p>' if ctid
                          else '<p class="mo">Tháng này không có phiếu xuất.</p>') + _loi(cb)
                else:
                    tb = '<p class="loi">Chưa chọn file.</p>'
            except Exception as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        tu, den = G.ky_mac_dinh(q)
        ds = kho.tong_hop_ton(con, cid, tu, den)
        k = ["dau_sl", "dau_gt", "nhap_sl", "nhap_gt", "xuat_sl", "xuat_gt", "cuoi_sl", "cuoi_gt"]
        fmt = lambda x, v: (f"{v:,.2f}".rstrip("0").rstrip(".").replace(",", "X").replace(".", ",").replace("X", ".")
                            if x.endswith("sl") and v else so(v))
        dong = "".join(
            f'<tr><td>{e(r["ma"])}</td><td>{e(r["ten"])}</td><td>{e(r["dvt"])}</td>'
            + "".join(f'<td class="s{" loi" if x.startswith("cuoi") and r[x] < 0 else ""}">{fmt(x, r[x])}</td>' for x in k)
            + "</tr>" for r in ds)
        chua = con.execute("SELECT COUNT(*) n FROM kho_dong WHERE cong_ty_id=? AND loai='X' AND thanh_tien IS NULL",
                           (cid,)).fetchone()["n"]
        nd = f"""<div class="the"><h1>Kho vật tư, hàng hóa</h1>{tb}
<p class="mo">Phiếu nhập tự tạo khi ghi sổ hóa đơn mua vào TK 152/153/156 (cần có XML). Phiếu xuất nhập bằng file Excel mẫu.
{f'<b>{chua} dòng xuất chưa tính giá.</b>' if chua else ''}</p>
<p class="dong-nut"><a class="nut phu" href="/cty/{cid}/mau/kho">Tải file mẫu phiếu xuất / tồn đầu</a>
<a class="nut phu" href="/cty/{cid}/so/vattu">Sổ chi tiết vật tư, in phiếu nhập / xuất</a></p>
<form method="post" enctype="multipart/form-data" class="ngang"><input type="hidden" name="hanh_dong" value="nap">
<label>File phiếu xuất đã điền<input type="file" name="tep" accept=".xlsx" required></label><button>Nạp phiếu xuất</button></form>
<form method="post" class="ngang" style="margin-top:12px"><input type="hidden" name="hanh_dong" value="tinh_gia">
<label>Tháng<input type="month" name="thang" value="{_thang_nay()}"></label><button>Tính giá xuất và ghi sổ</button></form>
<details style="margin-top:12px"><summary>Lấy tồn đầu từ báo cáo Tổng hợp tồn kho của MISA</summary>
<form method="post" enctype="multipart/form-data" class="ngang" style="margin-top:8px"><input type="hidden" name="hanh_dong" value="ton_misa">
<label>File Tong_hop_ton_kho.xlsx<input type="file" name="tep" accept=".xlsx" required></label>
<label>Ngày tồn đầu<input type="date" name="ngay" value="{date.today().year}-01-01"></label><button>Nạp tồn đầu</button></form></details></div>
<div class="the"><h2>Tổng hợp nhập xuất tồn</h2>{G.form_ky(tu, den)}</div>
<table><tr><th>Mã</th><th>Tên</th><th>ĐVT</th><th>SL đầu</th><th>GT đầu</th><th>SL nhập</th><th>GT nhập</th>
<th>SL xuất</th><th>GT xuất</th><th>SL cuối</th><th>GT cuối</th></tr>{dong}</table>"""
        self.gui(G.trang("Kho", nd, cid, ct["ten"]))

    # ------------------------------------------------------------ Luong
    def luong(self, pt, con, ct, q, rest):
        cid = ct["id"]
        thang = q.get("thang", _thang_nay())
        tb = ""
        if pt == "POST":
            truong, tep = self._tep_tai_len()
            if not tep and not truong:
                truong = {k: v[0] for k, v in self.doc_form().items()}
            try:
                if truong.get("hanh_dong") == "nap" and tep:
                    dem, loi = mau_excel.doc_luong(con, cid, tep[0][1])
                    tb = (f'<p class="ok">Đã nạp {dem["nhan_vien"]} nhân viên, {dem["nguoi_phu_thuoc"]} người phụ thuộc, '
                          f'{dem["bang_luong"]} dòng lương ({", ".join(dem["thang"])}).</p>' + _loi(loi))
                    if dem["thang"]:
                        thang = dem["thang"][-1]
                elif truong.get("hanh_dong") == "ghi_so":
                    thang = truong["thang"]
                    ctid, n = luong.ghi_so_thang(con, cid, thang)
                    tb = f'<p class="ok">Đã ghi sổ lương tháng {e(thang)} ({n} dòng định khoản).</p>' if ctid else \
                        '<p class="mo">Tháng này chưa có bảng lương.</p>'
            except Exception as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        try:
            ds = luong.tinh_thang(con, cid, thang)
        except ValueError as ex:
            ds, tb = [], tb + f'<p class="loi">{e(ex)}</p>'
        ts = luong.tham_so(thang)
        tong = {k: 0 for k in ("tong_thu_nhap", "bh_nld", "bh_dn", "thue_tncn", "thuc_linh")}
        dong = ""
        for nv, bl, r in ds:
            for k in tong:
                tong[k] += r[k]
            dong += (f'<tr><td>{e(nv["ma"])}</td><td>{e(nv["ho_ten"])}</td><td class="s">{bl["ngay_cong"]:g}/{bl["cong_chuan"]:g}</td>'
                     f'<td class="s">{so(r["tong_thu_nhap"])}</td><td class="s">{so(r["bh_nld"])}</td><td class="s">{r["so_npt"] or ""}</td>'
                     f'<td class="s">{so(r["giam_tru"])}</td><td class="s">{so(r["tn_tinh_thue"])}</td><td class="s">{so(r["thue_tncn"])}</td>'
                     f'<td class="s">{so(r["thuc_linh"])}</td><td class="s">{so(r["bh_dn"])}</td><td>{e(r["cach_tinh_thue"])}</td></tr>')
        if ds:
            dong += ('<tr class="c1"><td></td><td>Cộng</td><td></td>' + f'<td class="s">{so(tong["tong_thu_nhap"])}</td>'
                     f'<td class="s">{so(tong["bh_nld"])}</td><td></td><td></td><td></td><td class="s">{so(tong["thue_tncn"])}</td>'
                     f'<td class="s">{so(tong["thuc_linh"])}</td><td class="s">{so(tong["bh_dn"])}</td><td></td></tr>')
        da_ghi = con.execute("SELECT 1 FROM chung_tu WHERE cong_ty_id=? AND so_ct=?",
                             (cid, f"LUONG-{thang.replace('-', '')}")).fetchone()
        npt = con.execute("SELECT p.*, n.ho_ten nv FROM nguoi_phu_thuoc p LEFT JOIN nhan_vien n ON n.cong_ty_id=p.cong_ty_id "
                          "AND n.ma=p.ma_nv WHERE p.cong_ty_id=? ORDER BY p.ma_nv", (cid,)).fetchall()
        bang_npt = "".join(f'<tr><td>{e(p["nv"] or p["ma_nv"])}</td><td>{e(p["ho_ten"])}</td><td>{e(p["quan_he"])}</td>'
                           f'<td>{e(p["mst"] or "")}</td><td>{e(p["cccd"] or "")}</td><td>{e(p["tu_thang"])} → {e(p["den_thang"] or "")}</td>'
                           f'<td class="loi">{"" if (p["mst"] or p["cccd"]) else "Thiếu MST/CCCD"}</td></tr>' for p in npt)
        nd = f"""<div class="the"><h1>Lương, bảo hiểm, thuế TNCN</h1>{tb}
<p class="dong-nut"><a class="nut phu" href="/cty/{cid}/mau/luong?thang={thang}">Tải file mẫu tháng {thang[5:]}/{thang[:4]} (điền sẵn nhân viên)</a>
<a class="nut phu" href="/cty/{cid}/in/luong?thang={thang}">In bảng lương tháng {thang[5:]}/{thang[:4]}</a></p>
<form method="post" enctype="multipart/form-data" class="ngang"><input type="hidden" name="hanh_dong" value="nap">
<label>File lương đã điền<input type="file" name="tep" accept=".xlsx" required></label><button>Nạp</button></form>
<form method="get" class="ngang" style="margin-top:12px"><label>Xem tháng<input type="month" name="thang" value="{thang}"></label><button>Xem</button></form>
<p class="mo">Tháng {thang[5:]}/{thang[:4]}: giảm trừ bản thân {so(ts['giam_tru_ban_than'])}, người phụ thuộc {so(ts['giam_tru_npt'])}/người,
biểu thuế {len(ts['bieu_thue'])} bậc. Mức giảm trừ và biểu thuế cần đối chiếu văn bản hiện hành trước khi kê khai.</p></div>
<form method="post"><input type="hidden" name="hanh_dong" value="ghi_so"><input type="hidden" name="thang" value="{thang}">
<p><button>{'Ghi sổ lại' if da_ghi else 'Ghi sổ'} lương tháng {thang[5:]}/{thang[:4]}</button></p></form>
<table><tr><th>Mã</th><th>Họ tên</th><th>Công</th><th>Tổng thu nhập</th><th>BH NLĐ</th><th>NPT</th><th>Giảm trừ</th>
<th>TN tính thuế</th><th>Thuế TNCN</th><th>Thực lĩnh</th><th>BH DN đóng</th><th>Cách tính thuế</th></tr>{dong}</table>
<div class="the" style="margin-top:16px"><h2>Người phụ thuộc</h2><table><tr><th>Nhân viên</th><th>Người phụ thuộc</th><th>Quan hệ</th>
<th>MST</th><th>CCCD</th><th>Giảm trừ</th><th></th></tr>{bang_npt}</table></div>"""
        self.gui(G.trang("Lương", nd, cid, ct["ten"]))

    # ------------------------------------------------------------ Tai san
    def taisan(self, pt, con, ct, q, rest):
        THU_MUC_DL = G.THU_MUC_DL
        cid = ct["id"]
        tb = ""
        if rest and rest[0] == "tep" and len(rest) >= 3:
            p = THU_MUC_DL / "tai_lieu" / str(cid) / re.sub(r"[^\w.-]", "_", rest[1]) / re.sub(r"[\\/]", "_", rest[2])
            if not p.is_file():
                return self.gui("Không có file", 404)
            b = p.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quote(p.name)}")
            self.end_headers()
            return self.wfile.write(b)
        if pt == "POST":
            truong, tep = self._tep_tai_len()
            if not tep and not truong:
                truong = {k: v[0] for k, v in self.doc_form().items()}
            hd = truong.get("hanh_dong")
            try:
                if hd == "nap" and tep:
                    n, loi = mau_excel.doc_tai_san(con, cid, tep[0][1])
                    tb = f'<p class="ok">Đã nạp {n} tài sản.</p>' + _loi(loi)
                elif hd == "trich":
                    ctid, dong = tai_san.trich_thang(con, cid, truong["thang"])
                    tb = (f'<p class="ok">Đã trích khấu hao, phân bổ tháng {e(truong["thang"])}: '
                          f'{so(sum(d["so_tien"] for d in dong))} đồng.</p>' if ctid else '<p class="mo">Không có gì để trích tháng này.</p>')
                elif hd == "dinh_kem" and tep:
                    ts = con.execute("SELECT * FROM tai_san WHERE id=? AND cong_ty_id=?", (int(truong["id"]), cid)).fetchone()
                    tm = THU_MUC_DL / "tai_lieu" / str(cid) / re.sub(r"[^\w.-]", "_", ts["ma"])
                    tm.mkdir(parents=True, exist_ok=True)
                    for ten, b in tep:
                        ten = re.sub(r"[\\/:*?\"<>|]", "_", ten.rsplit("\\", 1)[-1])
                        (tm / ten).write_bytes(b)
                        tai_san.them_tai_lieu(con, ts["id"], ten)
                    tb = f'<p class="ok">Đã đính kèm {len(tep)} file cho {e(ts["ten"])}.</p>'
                elif hd == "them":
                    tai_san.luu(con, cid, {
                        "loai": truong["loai"], "ma": truong["ma"].strip(), "ten": truong["ten"].strip(),
                        "nhom": truong.get("nhom") or None, "bo_phan": truong.get("bo_phan") or None,
                        "ngay_tang": truong.get("ngay_tang") or None,
                        "nguyen_gia": int(truong["nguyen_gia"].replace(".", "").replace(",", "")) if truong.get("nguyen_gia") else None,
                        "so_thang": int(truong["so_thang"]), "tk_tai_san": truong.get("tk_tai_san") or None,
                        "tk_chi_phi": truong.get("tk_chi_phi") or None})
                    con.commit()
                    tb = f'<p class="ok">Đã lưu {e(truong["ten"])}.</p>'
            except Exception as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        thang = _thang_nay()
        sua = con.execute("SELECT * FROM tai_san WHERE id=? AND cong_ty_id=?", (int(q["sua"]), cid)).fetchone() if q.get("sua", "").isdigit() else None
        v = lambda k: e(sua[k] if sua and sua[k] is not None else "")
        dong = ""
        for ts in con.execute("SELECT * FROM tai_san WHERE cong_ty_id=? ORDER BY loai DESC, ma", (cid,)).fetchall():
            lk = tai_san.luy_ke(con, ts, "9999-12")
            cb = tai_san.canh_bao(ts)
            tl = "".join(f'<a href="/cty/{cid}/taisan/tep/{quote(ts["ma"])}/{quote(f)}">{e(f)}</a><br>'
                         for f in json.loads(ts["tai_lieu"] or "[]"))
            dong += (f'<tr><td>{e(ts["loai"])}</td><td>{e(ts["ma"])}<br><a class="nut phu nho" href="/cty/{cid}/taisan?sua={ts["id"]}#sua">Sửa</a></td><td>{e(ts["ten"])}<br><span class="mo">{e(ts["nhom"] or "")}</span>'
                     + "".join(f'<div class="loi" style="font-size:13px">{e(c)}</div>' for c in cb)
                     + f'</td><td>{G.ngay_vn(ts["ngay_bat_dau"])}</td><td class="s">{so(ts["nguyen_gia"])}</td><td class="s">{ts["so_thang"]}</td>'
                     f'<td class="s">{so(tai_san.so_trich_thang(ts, thang))}</td><td class="s">{so(lk)}</td><td class="s">{so(ts["nguyen_gia"] - lk)}</td>'
                     f'<td>{tl}<form method="post" enctype="multipart/form-data" style="margin-top:4px">'
                     f'<input type="hidden" name="hanh_dong" value="dinh_kem"><input type="hidden" name="id" value="{ts["id"]}">'
                     f'<input type="file" name="tep" multiple style="width:180px"><button class="phu nho">Đính kèm</button></form></td></tr>')
        nhom = "".join(f'<option value="{e(k)}" {"selected" if sua and sua["nhom"] == k else ""}>{e(k)} ({a}–{b} tháng)</option>'
                       for k, (a, b) in tai_san.KHUNG_TT45.items())
        nd = f"""<div class="the"><h1>Tài sản cố định, công cụ dụng cụ</h1>{tb}
<p><a class="nut phu" href="/cty/{cid}/mau/taisan">Tải file mẫu khai báo tài sản</a></p>
<form method="post" enctype="multipart/form-data" class="ngang"><input type="hidden" name="hanh_dong" value="nap">
<label>File mẫu đã điền, hoặc Sổ TSCĐ / Sổ theo dõi CCDC xuất từ MISA<input type="file" name="tep" accept=".xlsx" required></label>
<button>Nạp</button></form>
<form method="post" class="ngang" style="margin-top:12px"><input type="hidden" name="hanh_dong" value="trich">
<label>Tháng<input type="month" name="thang" value="{thang}"></label><button>Trích khấu hao và phân bổ</button></form></div>
<details class="the" id="sua" {"open" if sua else ""}><summary><b>{"Sửa tài sản " + e(sua["ma"]) if sua else "Thêm hoặc sửa tài sản"}</b></summary>
<p class="mo">Sửa tài sản đã có: nhập đúng Loại và Mã, chỉ điền ô cần đổi (ví dụ Số tháng); các ô để trống giữ nguyên.</p><form method="post" class="ngang" style="margin-top:10px">
<input type="hidden" name="hanh_dong" value="them">
<label>Loại<select name="loai"><option value="TSCD">TSCĐ</option><option value="CCDC" {"selected" if sua and sua["loai"] == "CCDC" else ""}>CCDC</option></select></label>
<label>Mã<input name="ma" size="8" required value="{v('ma')}"></label><label>Tên<input name="ten" size="30" required value="{v('ten')}"></label>
<label>Nhóm TT45<select name="nhom"><option value="">(không kiểm tra)</option>{nhom}</select></label>
<label>Ngày ghi tăng<input type="date" name="ngay_tang" value="{v('ngay_tang')}"></label>
<label>Nguyên giá<input name="nguyen_gia" size="14" value="{v('nguyen_gia')}"></label><label>Số tháng<input name="so_thang" size="5" required value="{v('so_thang')}"></label>
<label>TK tài sản<input name="tk_tai_san" size="7" placeholder="2111 / 242" value="{v('tk_tai_san')}"></label>
<label>TK chi phí<input name="tk_chi_phi" size="7" placeholder="6422" value="{v('tk_chi_phi')}"></label><button>Lưu</button></form></details>
<table><tr><th>Loại</th><th>Mã</th><th>Tên</th><th>Bắt đầu</th><th>Nguyên giá</th><th>Số tháng</th><th>Trích tháng này</th>
<th>Lũy kế</th><th>Còn lại</th><th>Hồ sơ đính kèm</th></tr>{dong}</table>"""
        self.gui(G.trang("Tài sản", nd, cid, ct["ten"]))
