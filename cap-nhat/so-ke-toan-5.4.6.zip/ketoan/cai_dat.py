"""Cai dat chung cua ung dung (khong rieng cong ty nao): tham so thue sua duoc, sao luu ra ngoai,
khoi phuc, nguoi dung va phan quyen khi dung chung trong mang LAN.

Cai dat luu o du_lieu/cai_dat.json. Mat khau chi luu ban bam PBKDF2, khong luu mat khau goc.
"""
import copy
import hashlib
import hmac
import json
import secrets
import sqlite3
import time
from datetime import datetime
from pathlib import Path

from . import luong, tai_san, to_khai
from .giao_dien import THU_MUC_DL

FILE = THU_MUC_DL / "cai_dat.json"
FILE_DL = THU_MUC_DL / "ketoan.db"

# Ban goc trong ma nguon, de "khoi phuc mac dinh"
MAC_DINH = {
    "luong": copy.deepcopy(luong.THAM_SO),
    "bao_hiem": copy.deepcopy(luong.TY_LE_BH),
    "khung_tt45": copy.deepcopy(tai_san.KHUNG_TT45),
    "to_khai": copy.deepcopy(to_khai.THAM_SO),
}

CAN_CU = {
    "luong": "Giảm trừ gia cảnh: NQ 954/2020/UBTVQH14 (11 triệu / 4,4 triệu, áp dụng từ 07/2020); "
             "NQ 110/2025/UBTVQH15 (15,5 triệu / 6,2 triệu, áp dụng từ kỳ tính thuế 2026). "
             "Biểu thuế lũy tiến: Điều 22 Luật Thuế TNCN; biểu 5 bậc theo Luật Thuế TNCN sửa đổi 2025 "
             "(kiểm tra lại thời điểm hiệu lực). Lương cơ sở: Nghị định 73/2024/NĐ-CP (2.340.000 đ từ 01/07/2024).",
    "bao_hiem": "Luật BHXH 2024 (41/2024/QH15), Luật BHYT, Luật Việc làm; QĐ 595/QĐ-BHXH. Người lao động: "
                "BHXH 8%, BHYT 1,5%, BHTN 1%. Doanh nghiệp: BHXH 17,5% (gồm 0,5% TNLĐ-BNN), BHYT 3%, BHTN 1%. "
                "KPCĐ 2% (TK 3382) theo Luật Công đoàn, không tính ở đây.",
    "khung_tt45": "Phụ lục I Thông tư 45/2013/TT-BTC (sửa đổi bởi TT 147/2016/TT-BTC, TT 28/2017/TT-BTC): "
                  "khung thời gian trích khấu hao các loại TSCĐ.",
    "nguong_tien_mat": "Điều kiện khấu trừ thuế GTGT đầu vào: chứng từ thanh toán không dùng tiền mặt cho hóa đơn "
                       "từ 20 triệu (Luật Thuế GTGT cũ) và từ 5 triệu (Luật Thuế GTGT 48/2024/QH15, hiệu lực 01/07/2025).",
    "thue_suat_tndn": "Thuế suất TNDN phổ thông 20% (Luật 14/2008, sửa đổi 2013). Luật Thuế TNDN 67/2025/QH15: "
                      "15% cho DN doanh thu năm đến 3 tỷ, 17% cho DN doanh thu trên 3 tỷ đến 50 tỷ (kiểm tra lại năm áp dụng).",
    "so_nam_chuyen_lo": "Điều 16 Luật Thuế TNDN: lỗ được chuyển liên tục tối đa 5 năm.",
}


# ------------------------------------------------------------------ doc / ghi file cai dat

def doc():
    try:
        return json.loads(FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def ghi(cd):
    FILE.parent.mkdir(parents=True, exist_ok=True)
    tam = FILE.with_suffix(".tmp")
    tam.write_text(json.dumps(cd, ensure_ascii=False, indent=2), encoding="utf-8")
    tam.replace(FILE)


def dat(**kw):
    cd = doc()
    cd.update(kw)
    ghi(cd)
    return cd


# ------------------------------------------------------------------ tham so thue

def _tuple_hoa(ds):
    return [tuple(x) for x in ds]


def ap_dung_tham_so(cd=None):
    """Nap tham so da sua (neu co) vao cac module tinh toan. Goi khi khoi dong va sau khi luu."""
    ts = (cd if cd is not None else doc()).get("tham_so") or {}
    luong.THAM_SO[:] = copy.deepcopy(ts.get("luong") or MAC_DINH["luong"])
    for t in luong.THAM_SO:
        t["bieu_thue"] = _tuple_hoa(t["bieu_thue"])
    luong.THAM_SO.sort(key=lambda t: t["tu"])
    luong.TY_LE_BH.clear()
    luong.TY_LE_BH.update({k: tuple(v) for k, v in (ts.get("bao_hiem") or MAC_DINH["bao_hiem"]).items()})
    tai_san.KHUNG_TT45.clear()
    tai_san.KHUNG_TT45.update({k: tuple(v) for k, v in (ts.get("khung_tt45") or MAC_DINH["khung_tt45"]).items()})
    tk = ts.get("to_khai") or MAC_DINH["to_khai"]
    to_khai.THAM_SO.clear()
    to_khai.THAM_SO.update({
        "nguong_tien_mat": sorted(_tuple_hoa(tk["nguong_tien_mat"])),
        "thue_suat_tndn": _tuple_hoa(tk["thue_suat_tndn"]),
        "so_nam_chuyen_lo": int(tk["so_nam_chuyen_lo"]),
    })


def tham_so_hien_tai():
    return {"luong": luong.THAM_SO, "bao_hiem": luong.TY_LE_BH, "khung_tt45": tai_san.KHUNG_TT45,
            "to_khai": to_khai.THAM_SO}


def luu_tham_so(ts, nguoi=None):
    """ts: dict cung cau truc tham_so_hien_tai(). Kiem tra so lieu truoc khi luu."""
    for t in ts["luong"]:
        if len(t["tu"]) != 7 or t["tu"][4] != "-":
            raise ValueError(f"Kỳ áp dụng '{t['tu']}' phải dạng YYYY-MM")
        if not t["bieu_thue"] or t["bieu_thue"][-1][0] is not None:
            raise ValueError("Bậc cuối của biểu thuế TNCN phải để trống mức trên (phần vượt)")
        cu = 0
        for muc, ts_ in t["bieu_thue"][:-1]:
            if muc <= cu:
                raise ValueError("Các mức của biểu thuế TNCN phải tăng dần")
            cu = muc
    for k, (a, b) in ts["bao_hiem"].items():
        if not (0 <= a <= 30 and 0 <= b <= 30):
            raise ValueError(f"Tỷ lệ bảo hiểm {k} không hợp lý")
    for k, (a, b) in ts["khung_tt45"].items():
        if not (0 < a <= b):
            raise ValueError(f"Khung khấu hao '{k}': tối thiểu phải nhỏ hơn hoặc bằng tối đa")
    cd = doc()
    cd["tham_so"] = json.loads(json.dumps(ts))
    cd.setdefault("lich_su_tham_so", []).append({"luc": datetime.now().isoformat(timespec="seconds"), "nguoi": nguoi})
    ghi(cd)
    ap_dung_tham_so(cd)


def khoi_phuc_mac_dinh():
    cd = doc()
    cd.pop("tham_so", None)
    ghi(cd)
    ap_dung_tham_so(cd)


# ------------------------------------------------------------------ sao luu, khoi phuc

def thu_muc_sao_luu():
    return THU_MUC_DL / "sao_luu"


def _sao(dich):
    """Sao file du lieu bang API backup cua SQLite (an toan ca khi dang mo)."""
    dich.parent.mkdir(parents=True, exist_ok=True)
    nguon = sqlite3.connect(str(FILE_DL))
    try:
        d = sqlite3.connect(str(dich))
        with d:
            nguon.backup(d)
        d.close()
    finally:
        nguon.close()


def sao_luu(giu_lai=30, ly_do=""):
    """Sao luu vao du_lieu/sao_luu va (neu da cai) thu muc ngoai (USB, Google Drive...).

    Tra ve (list duong dan da luu, list loi)."""
    if not FILE_DL.exists():
        return [], []
    ten = f"ketoan-{datetime.now():%Y%m%d-%H%M%S}{('-' + ly_do) if ly_do else ''}.db"
    da, loi = [], []
    dich = [thu_muc_sao_luu()]
    ngoai = doc().get("sao_luu_ngoai")
    if ngoai:
        dich.append(Path(ngoai))
    for i, tm in enumerate(dich):
        try:
            if i and not tm.exists():
                raise OSError(f"không thấy thư mục {tm} (USB chưa cắm hoặc Google Drive chưa chạy?)")
            _sao(tm / ten)
            da.append(tm / ten)
            for cu in sorted(tm.glob("ketoan-*.db"))[:-giu_lai]:
                cu.unlink()
        except OSError as ex:
            loi.append(f"{tm}: {ex}")
    cd = doc()
    cd["lan_sao_luu"] = {"luc": datetime.now().isoformat(timespec="seconds"), "file": [str(x) for x in da], "loi": loi}
    ghi(cd)
    return da, loi


BO_QUA_TOAN_BO = {"sao_luu", "ma_cu", "nhap_tam", "ketoan.db", "ketoan.db-journal", "ketoan.db-wal", "ketoan.db-shm", "cai_dat.json", "cai_dat.tmp"}


def sao_luu_toan_bo(thu_muc):
    """Sao luu TOAN BO du lieu (file so, mau HTKK, file da xuat, cai dat...) thanh mot file .zip trong thu muc
    nguoi dung chon. Ma API cua tro ly AI khong dua vao file. Tra ve duong dan file zip."""
    import tempfile
    import zipfile
    tm = Path(str(thu_muc).strip().strip('"'))
    if not str(tm).strip() or str(tm) == ".":
        raise ValueError("Chọn thư mục để lưu bản sao lưu.")
    if not tm.exists():
        if not tm.anchor or not Path(tm.anchor).exists():
            raise OSError(f"Không thấy ổ {tm.anchor or tm} (USB chưa cắm?)")
        tm.mkdir(parents=True, exist_ok=True)
    goc = THU_MUC_DL.resolve()
    if tm.resolve() == goc or goc in tm.resolve().parents:
        raise ValueError("Chọn thư mục nằm ngoài thư mục dữ liệu của phần mềm (ví dụ ổ USB, ổ D, Google Drive).")
    ten = tm / f"iFixKeToan-sao-luu-toan-bo-{datetime.now():%Y%m%d-%H%M%S}.zip"
    tam = ten.with_suffix(".tmp")
    with tempfile.TemporaryDirectory() as td:
        db_tam = Path(td) / "ketoan.db"
        if FILE_DL.exists():
            _sao_file(FILE_DL, db_tam)
        cd = doc()
        if isinstance(cd.get("ai"), dict) and cd["ai"].get("ma"):
            cd["ai"] = {**cd["ai"], "ma": ""}
        try:
            with zipfile.ZipFile(tam, "w", zipfile.ZIP_DEFLATED) as z:
                if db_tam.exists():
                    z.write(db_tam, "du_lieu/ketoan.db")
                z.writestr("du_lieu/cai_dat.json", json.dumps(cd, ensure_ascii=False, indent=2))
                for f in sorted(THU_MUC_DL.rglob("*")):
                    rel = f.relative_to(THU_MUC_DL)
                    if f.is_file() and rel.parts[0] not in BO_QUA_TOAN_BO:
                        z.write(f, "du_lieu/" + rel.as_posix())
                z.writestr("DOC_TRUOC.txt",
                           "Bản sao lưu toàn bộ dữ liệu iFix Kế toán.\r\n"
                           "Khôi phục: tắt iFix Kế toán, giải nén file này, chép các file trong thư mục du_lieu đè vào thư mục du_lieu\r\n"
                           f"của phần mềm (thường là {THU_MUC_DL}), rồi mở lại phần mềm.\r\n"
                           "Mã API của trợ lý AI không có trong bản sao lưu, cần nhập lại.\r\n")
            with zipfile.ZipFile(tam) as z:
                if z.testzip() is not None:
                    raise OSError("File sao lưu ghi ra bị lỗi")
            tam.replace(ten)
        except Exception:
            try:
                tam.unlink()
            except OSError:
                pass
            raise
    cd = doc()
    cd["sao_luu_toan_bo"] = {"thu_muc": str(tm), "luc": datetime.now().isoformat(timespec="seconds"), "file": str(ten)}
    ghi(cd)
    return ten


def _sao_file(nguon, dich):
    s = sqlite3.connect(str(nguon))
    try:
        d = sqlite3.connect(str(dich))
        with d:
            s.backup(d)
        d.close()
    finally:
        s.close()


def chon_thu_muc(goi_y="", tieu_de="Chọn thư mục lưu bản sao lưu toàn bộ dữ liệu iFix Kế toán"):
    """Mo hop thoai chon thu muc cua Windows tren may chay ung dung. Tra ve duong dan, hoac None neu huy."""
    return _hop_thoai("$f=New-Object System.Windows.Forms.FolderBrowserDialog;$f.Description=$env:TIEU_DE;"
                      "$f.ShowNewFolderButton=$true;if($env:GOI_Y -and (Test-Path -LiteralPath $env:GOI_Y)){$f.SelectedPath=$env:GOI_Y};",
                      "$f.SelectedPath", goi_y, tieu_de)


def chon_file(goi_y="", tieu_de="Chọn file dữ liệu iFix Kế toán", loc="Dữ liệu iFix Kế toán (*.zip;*.db)|*.zip;*.db|Mọi file (*.*)|*.*"):
    """Mo hop thoai chon file cua Windows. Tra ve duong dan, hoac None neu huy."""
    return _hop_thoai("$f=New-Object System.Windows.Forms.OpenFileDialog;$f.Title=$env:TIEU_DE;$f.Filter=$env:LOC;"
                      "$d=$env:GOI_Y;if($d -and (Test-Path -LiteralPath $d -PathType Leaf)){$d=Split-Path -LiteralPath $d};"
                      "if(-not $d){$d=[Environment]::GetFolderPath('UserProfile')+'\\Downloads'};"
                      "if(Test-Path -LiteralPath $d){$f.InitialDirectory=$d};",
                      "$f.FileName", goi_y, tieu_de, loc)


def _hop_thoai(tao, ket_qua, goi_y, tieu_de, loc=""):
    import os
    import subprocess
    import sys
    if sys.platform != "win32":
        return None
    ps = ("Add-Type -AssemblyName System.Windows.Forms;" + tao +
          "$o=New-Object System.Windows.Forms.Form;$o.TopMost=$true;"
          "if($f.ShowDialog($o) -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8;[Console]::Write(" + ket_qua + ")}")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps], capture_output=True, timeout=600,
                           env={**os.environ, "GOI_Y": goi_y or "", "TIEU_DE": tieu_de, "LOC": loc},
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, subprocess.TimeoutExpired):
        return None
    p = r.stdout.decode("utf-8", "replace").strip()
    return p or None


def danh_sach_ban_sao():
    ds = []
    for tm in [thu_muc_sao_luu()] + ([Path(doc()["sao_luu_ngoai"])] if doc().get("sao_luu_ngoai") else []):
        try:
            for f in tm.glob("ketoan-*.db"):
                ds.append({"duong": str(f), "ten": f.name, "noi": "ngoài" if tm != thu_muc_sao_luu() else "trong máy",
                           "luc": datetime.fromtimestamp(f.stat().st_mtime), "co": f.stat().st_size})
        except OSError:
            pass
    return sorted(ds, key=lambda x: x["luc"], reverse=True)


def kiem_tra_ban_sao(duong):
    """Mo thu ban sao, tra ve (so cong ty, so chung tu). Loi neu khong phai file so ke toan."""
    c = sqlite3.connect(f"file:{duong}?mode=ro", uri=True)
    try:
        if c.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError("File sao lưu bị hỏng")
        return (c.execute("SELECT COUNT(*) FROM cong_ty").fetchone()[0],
                c.execute("SELECT COUNT(*) FROM chung_tu").fetchone()[0])
    except sqlite3.DatabaseError as ex:
        raise ValueError(f"Không phải file sổ kế toán: {ex}")
    finally:
        c.close()


def khoi_phuc(duong, nguoi=None):
    """Thay du lieu hien tai bang ban sao. Truoc do tu sao luu du lieu hien tai (ly do 'truoc-khoi-phuc')."""
    duong = Path(duong)
    hop_le = {str(Path(x["duong"]).resolve()) for x in danh_sach_ban_sao()}
    if str(duong.resolve()) not in hop_le:
        raise ValueError("Chỉ khôi phục được từ các bản sao lưu trong danh sách")
    n_ct, n_chung_tu = kiem_tra_ban_sao(duong)
    sao_luu(ly_do="truoc-khoi-phuc")
    nguon = sqlite3.connect(f"file:{duong}?mode=ro", uri=True)
    dich = sqlite3.connect(str(FILE_DL))
    try:
        with dich:
            nguon.backup(dich)
        dich.execute("CREATE TABLE IF NOT EXISTS nhat_ky_sua (id INTEGER PRIMARY KEY, cong_ty_id INTEGER NOT NULL, luc TEXT NOT NULL, "
                     "nguoi TEXT, hanh_dong TEXT NOT NULL, so_ct TEXT, noi_dung TEXT)")
        dich.execute("INSERT INTO nhat_ky_sua (cong_ty_id, luc, nguoi, hanh_dong, noi_dung) VALUES (0,?,?,?,?)",
                     (datetime.now().isoformat(timespec="seconds"), nguoi, "khoi_phuc",
                      json.dumps({"tu_file": str(duong)}, ensure_ascii=False)))
        dich.commit()
    finally:
        nguon.close()
        dich.close()
    return n_ct, n_chung_tu


# ------------------------------------------------------------------ nguoi dung, dang nhap

VAI_TRO = {"quan_tri": "Quản trị (toàn quyền, quản lý người dùng, khôi phục, mở khóa sổ)",
           "ke_toan": "Kế toán (nhập liệu, ghi sổ, lập báo cáo)",
           "xem": "Chỉ xem (không sửa được gì)"}

SCHEMA_ND = """
CREATE TABLE IF NOT EXISTS nguoi_dung (
    ten TEXT PRIMARY KEY,
    ho_ten TEXT,
    vai_tro TEXT NOT NULL DEFAULT 'ke_toan',
    muoi TEXT NOT NULL,
    bam TEXT NOT NULL,
    khoa INTEGER NOT NULL DEFAULT 0,
    tao_luc TEXT
);
CREATE TABLE IF NOT EXISTS nguoi_dung_cong_ty (
    ten TEXT NOT NULL REFERENCES nguoi_dung(ten) ON DELETE CASCADE,
    cong_ty_id INTEGER NOT NULL,
    PRIMARY KEY (ten, cong_ty_id)
);
"""
VONG_LAP = 200_000
PHIEN = {}            # token -> (ten, het_han)
HAN_PHIEN = 12 * 3600


def chuan_bi(con):
    con.executescript(SCHEMA_ND)


def _bam(mat_khau, muoi):
    return hashlib.pbkdf2_hmac("sha256", mat_khau.encode("utf-8"), bytes.fromhex(muoi), VONG_LAP).hex()


def co_nguoi_dung(con):
    chuan_bi(con)
    return con.execute("SELECT 1 FROM nguoi_dung WHERE khoa=0 LIMIT 1").fetchone() is not None


def dat_nguoi_dung(con, ten, mat_khau, vai_tro="ke_toan", ho_ten=None):
    chuan_bi(con)
    ten = (ten or "").strip().lower()
    if not ten or not ten.replace(".", "").replace("_", "").isalnum():
        raise ValueError("Tên đăng nhập chỉ gồm chữ không dấu, số, dấu chấm, gạch dưới")
    if vai_tro not in VAI_TRO:
        raise ValueError("Vai trò không hợp lệ")
    cu = con.execute("SELECT * FROM nguoi_dung WHERE ten=?", (ten,)).fetchone()
    if mat_khau:
        if len(mat_khau) < 6:
            raise ValueError("Mật khẩu phải từ 6 ký tự")
        muoi = secrets.token_hex(16)
        bam = _bam(mat_khau, muoi)
    elif cu:
        muoi, bam = cu["muoi"], cu["bam"]
    else:
        raise ValueError("Người dùng mới phải có mật khẩu")
    if not cu and not co_nguoi_dung(con) and vai_tro != "quan_tri":
        raise ValueError("Người dùng đầu tiên phải là Quản trị")
    if cu and cu["vai_tro"] == "quan_tri" and vai_tro != "quan_tri" and con.execute(
            "SELECT COUNT(*) FROM nguoi_dung WHERE vai_tro='quan_tri' AND khoa=0").fetchone()[0] <= 1:
        raise ValueError("Phải còn ít nhất một người Quản trị")
    con.execute("INSERT OR REPLACE INTO nguoi_dung (ten, ho_ten, vai_tro, muoi, bam, khoa, tao_luc) VALUES (?,?,?,?,?,?,?)",
                (ten, ho_ten or (cu["ho_ten"] if cu else None), vai_tro, muoi, bam, 0,
                 cu["tao_luc"] if cu else datetime.now().isoformat(timespec="seconds")))
    con.commit()
    return ten


def cong_ty_duoc_dung(con, nguoi):
    """None = moi cong ty (chua co nguoi dung, hoac la Quan tri); nguoc lai la tap id cong ty duoc giao."""
    if not nguoi or nguoi.get("vai_tro") == "quan_tri":
        return None
    chuan_bi(con)
    return {r["cong_ty_id"] for r in con.execute("SELECT cong_ty_id FROM nguoi_dung_cong_ty WHERE ten=?", (nguoi["ten"],))}


def giao_cong_ty(con, ten, ids):
    """Dat danh sach cong ty mot nguoi dung duoc xem / lam."""
    chuan_bi(con)
    con.execute("DELETE FROM nguoi_dung_cong_ty WHERE ten=?", (ten,))
    con.executemany("INSERT OR IGNORE INTO nguoi_dung_cong_ty VALUES (?,?)", [(ten, int(i)) for i in ids])
    con.commit()


def xoa_nguoi_dung(con, ten):
    r = con.execute("SELECT vai_tro FROM nguoi_dung WHERE ten=?", (ten,)).fetchone()
    if r and r["vai_tro"] == "quan_tri" and con.execute(
            "SELECT COUNT(*) FROM nguoi_dung WHERE vai_tro='quan_tri' AND khoa=0").fetchone()[0] <= 1:
        raise ValueError("Không xóa được người Quản trị cuối cùng")
    con.execute("DELETE FROM nguoi_dung_cong_ty WHERE ten=?", (ten,))
    con.execute("DELETE FROM nguoi_dung WHERE ten=?", (ten,))
    con.commit()
    for k, (t, _) in list(PHIEN.items()):
        if t == ten:
            PHIEN.pop(k, None)


_SAI = {}   # ten -> (so lan sai, luc)


def dang_nhap(con, ten, mat_khau):
    """Tra ve token phien hoac None. Sai 5 lan lien tiep thi khoa 5 phut."""
    chuan_bi(con)
    ten = (ten or "").strip().lower()
    n, luc = _SAI.get(ten, (0, 0))
    if n >= 5 and time.time() - luc < 300:
        raise ValueError("Sai mật khẩu nhiều lần, thử lại sau 5 phút")
    r = con.execute("SELECT * FROM nguoi_dung WHERE ten=? AND khoa=0", (ten,)).fetchone()
    if not r or not hmac.compare_digest(_bam(mat_khau or "", r["muoi"]), r["bam"]):
        _SAI[ten] = (n + 1 if time.time() - luc < 300 else 1, time.time())
        return None
    _SAI.pop(ten, None)
    tok = secrets.token_urlsafe(32)
    PHIEN[tok] = (ten, time.time() + HAN_PHIEN)
    return tok


def nguoi_cua_phien(con, tok):
    """dict nguoi dung cua token, hoac None."""
    x = PHIEN.get(tok or "")
    if not x or x[1] < time.time():
        PHIEN.pop(tok or "", None)
        return None
    r = con.execute("SELECT ten, ho_ten, vai_tro FROM nguoi_dung WHERE ten=? AND khoa=0", (x[0],)).fetchone()
    return dict(r) if r else None


def dang_xuat(tok):
    PHIEN.pop(tok or "", None)


def dia_chi_lan():
    """Dia chi IP trong mang LAN cua may nay (de may khac go vao trinh duyet)."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"

