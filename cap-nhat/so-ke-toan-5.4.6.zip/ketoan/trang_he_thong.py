"""Trang Cai dat chung (khong rieng cong ty): sao luu / khoi phuc, tham so thue, nguoi dung, dung chung LAN,
phien ban. Va trang dang nhap / dang xuat."""
from http.cookies import SimpleCookie

from . import NGAY_PHAT_HANH, PHIEN_BAN, cai_dat, giao_dien as G
from . import thuong_hieu
from .giao_dien import e, so


JS_CHON = """<script>function chonDuong(nut,loai,ten){var o=nut.form.elements[ten];var t=nut.textContent;nut.disabled=true;nut.textContent="Đang mở hộp thoại…";
fetch("/he-thong/chon",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"loai="+loai+"&goi_y="+encodeURIComponent(o.value)})
.then(function(r){return r.json()}).then(function(d){if(d.duong){o.value=d.duong}else if(d.loi){alert(d.loi)}})
.catch(function(){alert("Không mở được hộp thoại chọn. Gõ đường dẫn vào ô.")}).finally(function(){nut.disabled=false;nut.textContent=t})}</script>"""


class _Xong(Exception):
    """Da xu ly xong yeu cau trong khoi try, khong can lam tiep."""

THAY_DOI = {
    "5.4.6": [
        "Nút Chọn thư mục… / Chọn file… (hộp thoại Windows) ở Sao lưu toàn bộ, Thư mục sao lưu ngoài, Xuất riêng một công ty và Nhập từ file: không phải gõ đường dẫn tay.",
    ],
    "5.4.5": [
        "Gửi sổ một công ty sang máy khác: Cài đặt chung → Chuyển dữ liệu → Xuất riêng một công ty ra file .zip (không kèm công ty khác, không kèm key). Máy nhận chọn file .zip ở mục Nhập từ file, không cần giải nén.",
        "Trang Hóa đơn mở sẵn năm có hóa đơn mới nhất (trước đây mở năm có chứng từ gần nhất, nên hóa đơn năm mới tải về chưa ghi sổ trông như trống).",
    ],
    "5.4.4": [
        "Tự tải hóa đơn từ cổng thuế mỗi ngày: bật ở trang Tải từ cổng thuế; hết phiên thì Việc cần làm nhắc đăng nhập.",
        "Tự nhận ra dữ liệu của bản cũ (bản chạy từ thư mục, ví dụ ổ E) chưa chuyển sang bản cài: trang chủ báo, bấm Xem và chuyển sang.",
        "Cài đặt chung → Chuyển dữ liệu bản cũ: chọn công ty cần chuyển. Gộp theo mã số thuế, công ty đã có chỉ thêm phần còn thiếu, không ghi đè; tự sao lưu trước khi chuyển; file cũ không bị sửa.",
        "Sao lưu toàn bộ ra chỗ khác: gói hết dữ liệu (sổ mọi công ty, mẫu HTKK, file đã xuất, cài đặt, key) thành một file .zip, lưu vào thư mục tự chọn (USB, ổ D, Google Drive). Có nút Chọn thư mục…, máy nhớ thư mục cho lần sau.",
    ],
    "5.4.3": [
        "Tải hóa đơn máy tính tiền từ cổng thuế ngay trong ứng dụng: gõ captcha, bấm Tải tháng này; xong máy tự chuyển sang tháng sau.",
    ],
    "5.4.2": [
        "Tải hóa đơn từ cổng thuế: khi cổng báo tải quá nhiều (lỗi 429) máy tự chờ rồi tải tiếp, tải chậm lại cho khỏi bị chặn.",
        "Hóa đơn đã có XML trong sổ thì không tải XML lại, lần tải sau nhanh hơn nhiều.",
    ],
    "5.4.1": [
        "Sửa tải hóa đơn từ cổng thuế: dùng địa chỉ mới của cổng hoadondientu, hết lỗi \"Truy vấn không hợp lệ\".",
        "Chọn ngày quá hôm nay thì tự lùi về hôm nay. Tháng nào cổng từ chối thì chỉ báo tháng đó, các tháng khác vẫn tải và lưu.",
    ],
    "5.4": [
        "Tên mới iFix Kế toán. Giao diện theo phân hệ: mỗi phân hệ có sơ đồ quy trình; bảng điều khiển mới có chỉ số sức khỏe tài chính; nút Tạo mới và ô tìm kiếm trên thanh trên cùng.",
        "Các gói bản quyền: Cơ bản, Đầy đủ, Nhiều công ty. Phân hệ ngoài gói được ẩn. Nâng gói hoặc gia hạn chỉ cần nhập key mới; key cũ vẫn dùng được.",
        "Chọn chế độ kế toán cho từng công ty: TT133, TT99 (thay TT200), TT58 (doanh nghiệp siêu nhỏ), TT152 (hộ kinh doanh). Có Sổ theo thông tư (S1a-HKD..., S1-DNSN...) tự tính thuế theo tỷ lệ trên doanh thu, và báo cáo kết quả kinh doanh B02-DN.",
        "Khế ước vay: lịch trả gốc, lãi; ghi sổ nhận tiền vay và từng kỳ trả; nhắc kỳ đến hạn.",
        "Hợp đồng mua, bán: tự gắn hóa đơn theo hợp đồng, theo dõi số đã thanh toán, nhắc hợp đồng sắp hết hạn.",
        "Giá thành: tập hợp chi phí theo công trình, sản phẩm, đơn hàng; phân bổ chi phí chung; thẻ tính giá thành; kết chuyển giá vốn.",
        "Trợ lý AI (gói Đầy đủ): chọn Claude, ChatGPT, Gemini, DeepSeek bằng mã API riêng hoặc AI trên máy (Ollama, LM Studio); gợi ý tài khoản cho hóa đơn và sao kê; hỏi đáp tiếng Việt trên sổ; đọc hóa đơn PDF, ảnh; soát sổ trước khi khóa sổ; dự báo dòng tiền 3 tháng; soạn tin nhắc nợ.",
        "Tải hóa đơn từ cổng thuế dùng địa chỉ mới của Tổng cục Thuế.",
    ],
    "5.3": [
        "Có file cài đặt (SoKeToan-CaiDat.exe): bấm Next là xong, tự tạo biểu tượng trên Desktop và Start Menu, gỡ cài đặt không mất dữ liệu.",
        "Tự cập nhật: ứng dụng báo khi có bản mới; vào Cài đặt chung → Cập nhật, bấm Cập nhật ngay. Máy tự sao lưu, cài, khởi động lại; dữ liệu và key giữ nguyên.",
        "Bản cập nhật có chữ ký của nhà phát triển; bản không đúng chữ ký bị từ chối.",
    ],
    "5.2": [
        "Chạy ẩn, không còn cửa sổ đen. Bấm biểu tượng Sổ kế toán khi đang chạy thì chỉ mở lại trang. Nút Tắt ở góc trên bên phải.",
        "Giao diện: menu có biểu tượng, gọn hơn; thanh tiêu đề có đường dẫn công ty / nhóm / trang; biểu đồ doanh thu, chi phí theo tháng trên bảng điều khiển.",
        "Bảng trống hiện thông báo; ô nhập trong bảng vừa khung; nút không bấm hai lần khi đang xử lý.",
        "Logo iFix Laptop; liên hệ hỗ trợ (điện thoại, Zalo, Facebook, TikTok) ở chân menu và trang Bản quyền.",
    ],
    "5.1": [
        "Danh mục khách hàng, nhà cung cấp, nhân viên: tự lấy từ hóa đơn, công nợ MISA, bảng lương; nạp và xuất Excel; địa chỉ in lên phiếu thu, phiếu chi.",
        "Phân quyền theo công ty: mỗi tài khoản Kế toán / Chỉ xem chỉ thấy các công ty được giao.",
        "Bản quyền: dùng thử 30 ngày (tối đa 3 công ty), kích hoạt bằng key theo máy. Hết hạn thì chuyển sang chỉ xem, dữ liệu vẫn xem và xuất được.",
        "Gói cài đặt kèm sẵn Python, không cần cài thêm gì.",
    ],
    "5.0": [
        "Giao diện mới: thanh menu bên trái theo nhóm, bảng điều khiển có số liệu chính và việc cần làm, dùng được trên điện thoại.",
        "Ngân hàng: nạp sao kê Excel/CSV của các ngân hàng, tự khớp với chứng từ đã có, gợi ý tài khoản đối ứng, ghi sổ hàng loạt, quy tắc theo từ khóa, đối chiếu số dư.",
        "Công nợ chi tiết theo khách hàng, nhà cung cấp; sổ chi tiết từng đối tượng; tuổi nợ 0–30/31–60/61–90/trên 90 ngày.",
        "Việc cần làm cho từng công ty và cho tất cả công ty: hạn nộp tờ khai, hóa đơn chưa ghi sổ, sao kê chưa ghi, chưa trích khấu hao, chưa kết chuyển...",
        "Khóa sổ theo ngày; danh sách chứng từ; sửa, xóa chứng từ có lưu bản cũ vào nhật ký.",
        "In phiếu thu, phiếu chi, phiếu nhập kho, phiếu xuất kho, phiếu kế toán, bảng thanh toán tiền lương theo mẫu TT133 (in hoặc lưu PDF từ trình duyệt).",
        "Báo cáo lưu chuyển tiền tệ B03-DNN; sổ quỹ tiền mặt, sổ tiền gửi ngân hàng, sổ chi tiết vật tư hàng hóa.",
        "Đối chiếu sổ cái với sổ chi tiết (TSCĐ, CCDC, kho, công nợ, lương, ngân hàng, thuế GTGT); hóa đơn bị hủy sau khi đã ghi sổ.",
        "Hóa đơn: máy học tài khoản theo từng mặt hàng, tách nhiều dòng định khoản; chặn ghi trùng hóa đơn trong kỳ đã nạp sổ từ MISA.",
        "Sao lưu ra thư mục ngoài (USB, Google Drive), sao lưu ngay, khôi phục từ bản sao lưu.",
        "Dùng chung trong mạng LAN: đăng nhập, phân quyền Quản trị / Kế toán / Chỉ xem, nhật ký ghi tên người thao tác.",
        "Tham số thuế (giảm trừ gia cảnh, biểu thuế TNCN, tỷ lệ bảo hiểm, khung khấu hao TT45, ngưỡng tiền mặt, thuế suất TNDN) sửa được trên trang Cài đặt chung, kèm căn cứ pháp lý.",
        "Tài sản: nút Sửa trên từng dòng; nạp MISA: chọn file từ máy.",
    ],
    "4.0": ["Báo cáo tài chính B01a/B02, tờ khai 01/GTGT, 03/TNDN, 05/QTT-TNCN, xuất XML cho HTKK."],
    "3.0": ["Kho, lương, bảo hiểm, tài sản cố định, công cụ dụng cụ."],
    "2.0": ["Hóa đơn điện tử: tải từ cổng thuế, nạp XML/ZIP/Excel, chọn nhà cung cấp hóa đơn."],
    "1.0": ["Sổ cái, nhật ký chung, cân đối tài khoản theo TT133, nạp dữ liệu MISA."],
}


def _so_nguyen(s):
    s = (s or "").strip().replace(".", "").replace(",", "").replace(" ", "")
    if not s:
        return None
    if not s.lstrip("-").isdigit():
        raise ValueError(f"'{s}' không phải số")
    return int(s)


def _so_thuc(s):
    return float((s or "0").strip().replace(",", "."))


def _bieu_chu(bieu):
    return "; ".join(f"{so(m) if m else ''}:{t:g}" for m, t in bieu)


def _doc_bieu(s):
    kq = []
    for phan in [x for x in s.replace("\n", ";").split(";") if x.strip()]:
        muc, _, ts = phan.partition(":")
        kq.append((_so_nguyen(muc), _so_thuc(ts)))
    return kq


def _dong(s):
    return [[x.strip() for x in d.split("|")] for d in s.splitlines() if d.strip()]


class TrangHeThong:
    def cookie(self, ten):
        c = SimpleCookie(self.headers.get("Cookie", ""))
        return c[ten].value if ten in c else None

    def dang_nhap(self, pt, q):
        con = self.con()
        loi = ""
        if pt == "POST":
            f = {k: v[0] for k, v in self.doc_form().items()}
            try:
                tok = cai_dat.dang_nhap(con, f.get("ten"), f.get("mat_khau"))
            except ValueError as ex:
                tok, loi = None, str(ex)
            if tok:
                self.send_response(303)
                self.send_header("Set-Cookie", f"phien={tok}; HttpOnly; SameSite=Strict; Path=/")
                ve = f.get("ve") or "/"
                self.send_header("Location", ve if ve.startswith("/") and not ve.startswith("//") else "/")
                self.end_headers()
                return
            loi = loi or "Sai tên đăng nhập hoặc mật khẩu."
        nd = f"""<div class="the" style="max-width:420px;margin:40px auto"><div class="logo-sang">{thuong_hieu.LOGO_SANG}</div><h1>Đăng nhập iFix Kế toán</h1>
{f'<p class="loi">{e(loi)}</p>' if loi else ''}
<form method="post" style="display:grid;gap:12px"><input type="hidden" name="ve" value="{e(q.get('ve', '/'))}">
<label>Tên đăng nhập<input name="ten" autofocus required autocomplete="username"></label>
<label>Mật khẩu<input type="password" name="mat_khau" required autocomplete="current-password"></label>
<div><button>Đăng nhập</button></div></form>
<p class="mo">Quên mật khẩu: nhờ người Quản trị đặt lại ở Cài đặt chung → Người dùng.</p></div>"""
        self.gui(G.trang("Đăng nhập", nd))  # noqa

    def dang_xuat(self):
        cai_dat.dang_xuat(self.cookie("phien"))
        self.send_response(303)
        self.send_header("Set-Cookie", "phien=; Max-Age=0; Path=/")
        self.send_header("Location", "/")
        self.end_headers()

    def he_thong(self, pt, q, rest):
        muc = rest[0] if rest else "saoluu"
        if muc == "chon":
            return self._ht_chon(pt)
        tabs = G.tab([("saoluu", "/he-thong/saoluu", "Sao lưu, khôi phục"), ("nhap-cu", "/he-thong/nhap-cu", "Chuyển dữ liệu"),
                      ("thamso", "/he-thong/thamso", "Tham số thuế"),
                      ("nguoidung", "/he-thong/nguoidung", "Người dùng, mạng LAN"), ("ai", "/he-thong/ai", "Trợ lý AI"), ("phien-ban", "/he-thong/phien-ban", "Phiên bản"),
                      ("cap-nhat", "/he-thong/cap-nhat", "Cập nhật")], muc)
        f = {"saoluu": self._ht_sao_luu, "nhap-cu": self._ht_nhap_cu, "thamso": self._ht_tham_so, "nguoidung": self._ht_nguoi_dung, "ai": self._ht_ai,
             "phien-ban": self._ht_phien_ban, "cap-nhat": self._ht_cap_nhat}.get(muc)
        if not f:
            return self.gui(G.trang("Không tìm thấy", "<p>Trang không tồn tại.</p>"), 404)
        nd, tb = f(pt, q)
        if nd is None:
            return
        self.gui(G.trang("Cài đặt chung", f'<div class="the"><h1>Cài đặt chung</h1>{tabs}{tb}</div>{nd}{JS_CHON}'))

    def _ht_cap_nhat(self, pt, q):
        from . import cap_nhat, PHIEN_BAN
        tb = ""
        hd = {k: v[0] for k, v in self.doc_form().items()}.get("hanh_dong") if pt == "POST" else None
        if hd and not self.la_quan_tri():
            hd, tb = None, '<p class="loi">Chỉ người Quản trị mới cập nhật được.</p>'
        if hd and self.client_address[0] not in ("127.0.0.1", "::1"):
            hd, tb = None, '<p class="loi">Chỉ cập nhật được trên máy chạy ứng dụng.</p>'
        if hd:
            if hd == "kiem":
                cap_nhat.kiem_tra()
            elif hd == "cai":
                kk = cap_nhat.TRANG_THAI.get("ban_moi") or cap_nhat.kiem_tra()
                if not kk:
                    tb = '<p class="ok">Đang dùng bản mới nhất.</p>'
                else:
                    try:
                        from . import ung_dung
                        cu = cap_nhat.tai_va_cai(kk, sao_luu=lambda: ung_dung.sao_luu(ly_do="truoc-cap-nhat"))
                    except Exception as ex:
                        tb = f'<p class="loi">Chưa cập nhật được: {G.e(ex)}. Ứng dụng vẫn chạy bản cũ, dữ liệu không đổi.</p>'
                    else:
                        self.khoi_dong_lai(f"Đã cài bản {kk['phien_ban']}. Mã cũ lưu ở {cu}.")
                        return None, None
        tt = cap_nhat.TRANG_THAI
        moi = tt.get("ban_moi")
        if moi:
            ghi_chu = "".join(f"<li>{G.e(x)}</li>" for x in moi.get("ghi_chu") or [])
            khoi = (f'<p class="bao">Có bản mới <b>{G.e(moi["phien_ban"])}</b>'
                    f'{" (" + G.e(G.ngay_vn(moi.get("ngay"))) + ")" if moi.get("ngay") else ""}.</p>'
                    f'{"<ul>" + ghi_chu + "</ul>" if ghi_chu else ""}'
                    '<form method="post" class="dong-nut"><input type="hidden" name="hanh_dong" value="cai">'
                    '<button>Cập nhật ngay</button></form>'
                    '<p class="mo">Máy tự sao lưu dữ liệu và mã cũ trước khi cập nhật, rồi khởi động lại trong vài giây. '
                    'Dữ liệu, key bản quyền, người dùng giữ nguyên.</p>')
        elif tt.get("luc"):
            khoi = ('<p class="ok">Đang dùng bản mới nhất.</p>' if not tt.get("loi") else
                    f'<p class="mo">Chưa kiểm tra được bản mới (máy không có mạng hoặc máy chủ cập nhật chưa sẵn sàng).</p>')
        else:
            khoi = '<p class="mo">Chưa kiểm tra.</p>'
        nd = f"""<div class="the"><h2>Cập nhật phiên bản</h2><p>Đang dùng bản <b>{PHIEN_BAN}</b>.</p>{khoi}
<form method="post" class="dong-nut"><input type="hidden" name="hanh_dong" value="kiem"><button class="phu">Kiểm tra bản mới</button></form>
<p class="mo">Ứng dụng tự kiểm tra khi mở và mỗi 12 giờ. Bản cập nhật có chữ ký của nhà phát triển; bản không đúng chữ ký sẽ bị từ chối.</p></div>"""
        return nd, tb

    # ---------------------------------------------------------------- tro ly AI
    def _ht_ai(self, pt, q):
        from . import tro_ly_ai as AI
        tb = ""
        if pt == "POST":
            f = {k: v[0] for k, v in self.doc_form().items()}
            try:
                self._can_quan_tri()
                ncc = f.get("nha_cung_cap", "")
                AI.luu_cau_hinh(f.get("bat") == "1", ncc, f.get("mo_hinh", ""),
                                "-" if f.get("xoa_ma") == "1" else f.get("ma", ""), f.get("dia_chi", ""),
                                f.get("suy_nghi") or None, f.get("token_nghi") if "token_nghi" in f else None)
                tb = '<p class="ok">Đã lưu cài đặt Trợ lý AI.</p>'
                if f.get("hanh_dong") == "thu":
                    tl = AI.thu_ket_noi()
                    tb = f'<p class="ok">Đã lưu. AI trả lời: “{e(tl[:200])}”</p>'
            except (ValueError, PermissionError) as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
            except AI.LoiAI as ex:
                tb = f'<p class="loi">Đã lưu nhưng thử kết nối không được: {e(ex)}</p>'
        cd = cai_dat.doc()
        c = AI.cau_hinh(cd)
        ok_bq, tb_bq = AI.duoc_phep(getattr(self, "bq", None))
        ma_luu = (cd.get("ai") or {}).get("ma") or {}
        mo_hinh_luu = (cd.get("ai") or {}).get("mo_hinh") or {}
        chon = ""
        for m, tt in AI.NHA_CUNG_CAP.items():
            da_co = " · đã có mã" if ma_luu.get(m) else ""
            chon += (f'<label class="chon"><input type="radio" name="nha_cung_cap" value="{m}" '
                     f'{"checked" if m == c["nha_cung_cap"] else ""} onchange="doiNcc(this.value)"> {e(tt["ten"])}'
                     f'<span class="mo">{da_co}</span></label>')
        du_lieu_js = {m: {"mo_hinh": tt["mo_hinh"], "dang": mo_hinh_luu.get(m) or tt["mo_hinh"][0], "can_ma": tt["can_ma"],
                          "lay_ma": tt["lay_ma"], "ma": AI.che_ma(ma_luu.get(m, ""))} for m, tt in AI.NHA_CUNG_CAP.items()}
        import json as _json
        dl = _json.dumps(du_lieu_js, ensure_ascii=False).replace("</", "<\\/")
        ds_ct = "".join(f'<a class="nut phu nho" href="/cty/{r["id"]}/ai">{e(r["ten"])}</a>' for r in self.con().execute(
            "SELECT id, ten FROM cong_ty ORDER BY ten").fetchall()
            if (cai_dat.cong_ty_duoc_dung(self.con(), self.nguoi) is None or r["id"] in cai_dat.cong_ty_duoc_dung(self.con(), self.nguoi)))
        tn_luu = (cd.get("ai") or {}).get("token_nghi") or ""
        chon_nghi = "".join(f'<option value="{m}" data-tk="{t}" {"selected" if m == c["suy_nghi"] else ""}>{e(ten)}'
                            f'{f" (~{t:,} token)".replace(",", ".") if t else ""}</option>'
                            for m, (ten, t) in AI.MUC_SUY_NGHI.items())
        dc_local = "".join(f'<option value="{u}">{t}</option>' for u, t in AI.DIA_CHI_LOCAL_MAU)
        nd = f"""<div class="hai-cot"><div class="the"><h2>Trợ lý AI</h2>
{'' if ok_bq else f'<p class="bao">{e(tb_bq)}</p>'}
<p>AI giúp gợi ý tài khoản hạch toán cho mặt hàng trên hóa đơn và cho dòng sao kê ngân hàng máy chưa chắc.
AI chỉ <b>gợi ý</b>; bạn xem lại rồi mới lưu hoặc ghi sổ.</p>
<form method="post" style="display:grid;gap:12px">
<label class="chon"><input type="checkbox" name="bat" value="1" {"checked" if c["bat"] else ""}> Bật Trợ lý AI</label>
<div><b>Chọn hãng AI</b><div style="display:grid;gap:6px;margin-top:6px">{chon}</div></div>
<label>Mô hình<input name="mo_hinh" id="mo_hinh" size="30" list="ds_mh" value="{e(c["mo_hinh"])}"></label><datalist id="ds_mh"></datalist>
<div id="o_ma"><label>Mã API (API key)<input name="ma" type="password" size="46" autocomplete="off" placeholder="dán mã API vào đây"></label>
<p class="mo" style="margin:4px 0">Đang lưu: <code id="ma_luu"></code> · bỏ trống để giữ mã cũ ·
<label class="chon" style="display:inline"><input type="checkbox" name="xoa_ma" value="1"> xóa mã này</label><br>
Lấy mã tại <a id="lay_ma" target="_blank" rel="noopener"></a> (bạn tự trả phí cho hãng AI theo lượt dùng).</p></div>
<div id="o_dc"><label>Địa chỉ máy chủ AI<input name="dia_chi" size="40" list="ds_dc" value="{e(c["dia_chi"] if c["nha_cung_cap"] == "local" else AI.NHA_CUNG_CAP["local"]["dia_chi"])}"></label>
<datalist id="ds_dc">{dc_local}</datalist>
<p class="mo" style="margin:4px 0">Ollama: cài từ ollama.com, chạy <code>ollama pull qwen2.5:7b</code>, địa chỉ <code>http://localhost:11434/v1</code>.
LM Studio: bật Local Server, địa chỉ <code>http://localhost:1234/v1</code>. Máy chủ khác trong mạng LAN cũng được nếu nói chuẩn OpenAI.
Nếu máy chủ cần mã thì dán vào ô Mã API.</p></div>
<div><b>Mức suy nghĩ của AI</b>
<div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:6px;align-items:end">
<label>Mức<select name="suy_nghi" id="suy_nghi" onchange="doiNghi(1)">{chon_nghi}</select></label>
<label>Số token suy nghĩ tối đa<input name="token_nghi" id="token_nghi" type="number" min="0" max="{AI.TOI_DA_TOKEN_NGHI}" step="256"
 style="width:9em" value="{e(str(tn_luu)) if c["suy_nghi"] != "tat" else ""}" placeholder="{c["token_nghi"]}"></label></div>
<p class="mo" style="margin:4px 0">Suy nghĩ nhiều thì AI trả lời kỹ hơn nhưng chậm hơn và tốn phí hơn. Bỏ trống ô số token để dùng mặc định của mức.
Đang dùng: <b>{c["token_nghi"]:,} token</b>, chờ tối đa {AI.thoi_gian_cho(c)} giây.<br>
<b>LM Studio / Ollama:</b> nên đặt Reasoning Budget trong LM Studio <i>không lớn hơn</i> số token ở đây (hoặc để LM Studio ở mức tự động),
vì phần mềm cộng số token này vào giới hạn trả lời; mô hình nghĩ quá số này sẽ không kịp trả lời.</p></div>
<div class="dong-nut"><button>Lưu</button><button class="phu" name="hanh_dong" value="thu">Lưu và thử kết nối</button></div></form>
{('<h3>Mở Trợ lý AI của công ty</h3><p class="mo">Hỏi đáp trên sổ, đọc hóa đơn PDF / ảnh, soát sổ, phân tích và dự báo dòng tiền, nhắc nợ.</p><div class="dong-nut">' + ds_ct + '</div>') if ds_ct else ''}</div>
<div class="the"><h2>Dữ liệu đi đâu</h2>
<p><b>Claude, ChatGPT, Gemini, DeepSeek:</b> khi bạn bấm nút gợi ý, tên hàng hóa, số tiền, nội dung chuyển khoản, danh mục tài khoản
và tên đối tượng của công ty đó được gửi tới hãng AI đã chọn qua Internet. Không gửi gì khi bạn không bấm.</p>
<p><b>AI trên máy (Ollama, LM Studio):</b> dữ liệu không ra khỏi máy / mạng nội bộ, không mất phí, không cần Internet.
Cần máy đủ mạnh (khuyên dùng từ 16 GB RAM); chậm và kém chính xác hơn AI của hãng.</p>
<p><b>Mã API</b> chỉ lưu trên máy này (file <code>du_lieu\\cai_dat.json</code>), chỉ gửi tới hãng AI đã chọn, không gửi cho nhà phát triển phần mềm.
Ai mở được máy này thì đọc được file đó, nên đặt hạn mức chi tiêu thấp cho mã API ở trang của hãng.</p></div></div>
<script>
var AI={dl};
function doiNcc(m){{var d=AI[m];var l=document.getElementById('ds_mh');l.innerHTML='';
d.mo_hinh.forEach(function(x){{var o=document.createElement('option');o.value=x;l.appendChild(o)}});
var mh=document.getElementById('mo_hinh');if(doiNcc.da)mh.value=d.dang;doiNcc.da=1;
document.getElementById('o_dc').style.display=m=='local'?'':'none';
document.getElementById('ma_luu').textContent=d.ma||'(chưa có)';
var a=document.getElementById('lay_ma');a.href=d.lay_ma;a.textContent=d.lay_ma;}}
doiNcc({_json.dumps(c["nha_cung_cap"])});
function doiNghi(x){{var s=document.getElementById('suy_nghi');var t=document.getElementById('token_nghi');
var tk=s.options[s.selectedIndex].getAttribute('data-tk');t.placeholder=tk;if(x||s.value=='tat')t.value='';t.disabled=s.value=='tat';}}
doiNghi();
</script>"""
        return nd, tb

    def _can_quan_tri(self):
        if not self.la_quan_tri():
            raise PermissionError("Chỉ người Quản trị làm được việc này.")

    # ---------------------------------------------------------------- sao luu
    def _ht_sao_luu(self, pt, q):
        tb = ""
        cd = cai_dat.doc()
        if pt == "POST":
            f = {k: v[0].strip() for k, v in self.doc_form().items()}
            try:
                hd = f.get("hanh_dong")
                if hd == "thu_muc":
                    self._can_quan_tri()
                    tm = f.get("sao_luu_ngoai", "").strip().strip('"')
                    if tm:
                        from pathlib import Path
                        p = Path(tm)
                        if not p.exists():
                            p.mkdir(parents=True, exist_ok=True)
                    cd = cai_dat.dat(sao_luu_ngoai=tm or None)
                    tb = '<p class="ok">Đã lưu thư mục sao lưu ngoài.</p>' if tm else '<p class="ok">Đã bỏ sao lưu ngoài.</p>'
                elif hd == "sao_ngay":
                    da, loi = cai_dat.sao_luu(ly_do="tay")
                    tb = "".join(f'<p class="ok">Đã sao lưu: {e(x)}</p>' for x in da) + "".join(f'<p class="loi">{e(x)}</p>' for x in loi)
                    cd = cai_dat.doc()
                elif hd == "toan_bo":
                    self._can_quan_tri()
                    z = cai_dat.sao_luu_toan_bo(f.get("thu_muc_toan_bo", ""))
                    tb = (f'<p class="ok">Đã sao lưu toàn bộ dữ liệu vào {e(z)} ({z.stat().st_size / 1048576:.1f} MB). '
                          'Mã API của trợ lý AI không có trong file này.</p>')
                    cd = cai_dat.doc()
                elif hd == "khoi_phuc":
                    self._can_quan_tri()
                    if f.get("xac_nhan") != "KHOI PHUC":
                        raise ValueError("Gõ đúng chữ KHOI PHUC để xác nhận.")
                    n_ct, n_ctu = cai_dat.khoi_phuc(f["file"], self.ten_nguoi())
                    tb = (f'<p class="ok">Đã khôi phục từ {e(f["file"])}: {n_ct} công ty, {so(n_ctu)} chứng từ. '
                          'Dữ liệu ngay trước khi khôi phục đã được sao lưu (tên file có chữ truoc-khoi-phuc).</p>')
            except (ValueError, OSError, PermissionError) as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        lan = cd.get("lan_sao_luu") or {}
        ds = cai_dat.danh_sach_ban_sao()
        bang = "".join(
            f'<tr><td><label class="chon"><input type="radio" name="file" value="{e(x["duong"])}" required>{e(x["ten"])}</label></td>'
            f'<td>{e(x["noi"])}</td><td>{x["luc"]:%d/%m/%Y %H:%M}</td><td class="s">{x["co"] / 1048576:.1f} MB</td></tr>' for x in ds[:60])
        nd = f"""<div class="hai-cot"><div class="the"><h2>Sao lưu</h2>
<p>Mỗi lần mở ứng dụng, máy tự sao lưu file dữ liệu vào <code>du_lieu\\sao_luu</code> (giữ 30 bản gần nhất){' và vào thư mục ngoài bên dưới' if cd.get('sao_luu_ngoai') else ''}.</p>
<p class="mo">Lần gần nhất: {e((lan.get('luc') or 'chưa có').replace('T', ' '))}{''.join(f'<br><span class="loi">{e(x)}</span>' for x in lan.get('loi') or [])}</p>
<form method="post"><input type="hidden" name="hanh_dong" value="sao_ngay"><button>Sao lưu ngay</button></form>
<h3>Thư mục sao lưu ngoài</h3>
<p class="mo">Chọn ổ USB (ví dụ <code>F:\\SaoLuuKeToan</code>) hoặc thư mục Google Drive trên máy (cài Google Drive cho máy tính, ví dụ
<code>G:\\My Drive\\SaoLuuKeToan</code>) để có bản sao nằm ngoài ổ E. Nếu USB không cắm, máy vẫn sao lưu trong máy và báo lỗi ở đây.</p>
<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="thu_muc">
<label>Đường dẫn thư mục<input name="sao_luu_ngoai" size="42" value="{e(cd.get('sao_luu_ngoai') or '')}"></label><button type="button" class="phu" onclick="chonDuong(this,'thu_muc','sao_luu_ngoai')">Chọn…</button><button class="phu">Lưu</button></form>
<h3>Sao lưu toàn bộ ra chỗ khác</h3>
<p class="mo">Gói tất cả dữ liệu (sổ của mọi công ty, mẫu HTKK, file đã xuất, cài đặt, key bản quyền) thành một file .zip và lưu vào thư mục anh/chị chọn:
USB, ổ D, Google Drive... Dùng khi đổi máy, cài lại Windows hoặc cất giữ cuối năm. Mã API trợ lý AI không đưa vào file.</p>
{(lambda tb_: f'<p class="mo">Lần gần nhất: {e(tb_.get("luc", "").replace("T", " "))} → {e(tb_.get("file"))}</p>' if tb_.get("file") else "")(cd.get("sao_luu_toan_bo") or {})}
<form method="post" class="ngang">
<label>Thư mục lưu<input name="thu_muc_toan_bo" size="42" placeholder="F:\\SaoLuuKeToan" value="{e((cd.get('sao_luu_toan_bo') or {}).get('thu_muc') or '')}"></label>
<button type="button" class="phu" onclick="chonDuong(this,'thu_muc','thu_muc_toan_bo')">Chọn thư mục…</button>
<button name="hanh_dong" value="toan_bo">Sao lưu toàn bộ</button></form></div>
<div class="the"><h2>Khôi phục</h2>
<p class="bao">Khôi phục sẽ thay toàn bộ dữ liệu hiện tại (mọi công ty) bằng bản sao lưu đã chọn. Trước khi thay, máy tự sao lưu dữ liệu hiện tại.
Chỉ người Quản trị làm được.</p>
<form method="post"><input type="hidden" name="hanh_dong" value="khoi_phuc">
{'<table><tr><th>Bản sao lưu</th><th>Nơi lưu</th><th>Lúc</th><th class="s">Dung lượng</th></tr>' + bang + '</table>' if ds else '<p class="mo">Chưa có bản sao lưu nào.</p>'}
<div class="ngang" style="margin-top:10px"><label>Gõ KHOI PHUC để xác nhận<input name="xac_nhan" size="14" autocomplete="off"></label>
<button class="nguy">Khôi phục bản đã chọn</button></div></form></div></div>"""
        return nd, tb

    # ---------------------------------------------------------------- nut Chon... (hop thoai Windows)
    def _ht_chon(self, pt):
        """POST loai=thu_muc|file, goi_y=...: mo hop thoai chon cua Windows tren may chay ung dung, tra JSON {duong}."""
        import json as _json
        f = {k: v[0] for k, v in self.doc_form().items()} if pt == "POST" else {}
        if pt != "POST" or not self.la_quan_tri() or self.client_address[0] not in ("127.0.0.1", "::1"):
            return self.gui(_json.dumps({"loi": "Chỉ chọn được trên máy chạy ứng dụng. Gõ đường dẫn vào ô."}),
                            403, "application/json; charset=utf-8")
        goi_y = f.get("goi_y", "")
        p = cai_dat.chon_file(goi_y) if f.get("loai") == "file" else cai_dat.chon_thu_muc(goi_y, "Chọn thư mục")
        return self.gui(_json.dumps({"duong": p}), 200, "application/json; charset=utf-8")

    # ---------------------------------------------------------------- chuyen du lieu ban cu
    def _ht_nhap_cu(self, pt, q):
        from pathlib import Path
        from . import nhap_du_lieu_cu as NC
        tb, xem = "", None
        dich = cai_dat.FILE_DL
        if pt == "POST":
            fm = self.doc_form()
            f = {k: v[0].strip() for k, v in fm.items()}
            duong = f.get("file", "").strip().strip('"')
            try:
                self._can_quan_tri()
                if self.client_address[0] not in ("127.0.0.1", "::1"):
                    raise PermissionError("Chỉ chuyển dữ liệu được trên máy chạy ứng dụng.")
                if f.get("hanh_dong") == "xuat":
                    z, bang = NC.xuat_cong_ty(dich, f.get("mst_xuat", ""), f.get("thu_muc_xuat", ""))
                    cd = cai_dat.doc()
                    cd["thu_muc_xuat_cong_ty"] = f.get("thu_muc_xuat", "")
                    cai_dat.ghi(cd)
                    tb = (f'<p class="ok">Đã xuất riêng công ty ra {e(z)} ({z.stat().st_size / 1048576:.1f} MB): '
                          f'{so(bang.get("chung_tu", 0))} chứng từ, {so(bang.get("hoa_don", 0))} hóa đơn. '
                          'Gửi file này sang máy kia, ở máy kia vào đúng trang này, mục Nhập từ file, chọn file .zip.</p>')
                    raise _Xong
                p = Path(duong)
                if p.suffix.lower() == ".zip" and p.is_file():
                    import zipfile
                    try:
                        p = NC.mo_zip(p, Path(dich).parent / "nhap_tam")
                    except zipfile.BadZipFile:
                        raise ValueError("File .zip bị hỏng hoặc chưa tải xong.")
                if p.is_dir():
                    p = p / ("du_lieu" if (p / "du_lieu" / "ketoan.db").exists() else "") / "ketoan.db"
                if not p.is_file() or p.suffix.lower() != ".db":
                    raise ValueError(f"Không thấy file dữ liệu {duong}. Chọn file ketoan.db hoặc thư mục chứa nó.")
                if NC._chuan(p) == NC._chuan(dich):
                    raise ValueError("Đây là file dữ liệu đang dùng.")
                if not NC.la_so_ke_toan(p):
                    raise ValueError("File này không phải dữ liệu iFix Kế toán.")
                hd = f.get("hanh_dong")
                if hd == "bo_qua":
                    cd = cai_dat.doc()
                    cd.setdefault("du_lieu_cu_da_xu_ly", {})[str(p)] = "bo_qua"
                    cai_dat.ghi(cd)
                    NC.KET_QUA_TIM["ds"] = [x for x in NC.KET_QUA_TIM["ds"] if NC._chuan(x["duong"]) != NC._chuan(p)]
                    tb = f'<p class="ok">Đã bỏ qua {e(p)}. Máy sẽ không nhắc lại file này.</p>'
                elif hd == "nhap":
                    ds_mst = set(fm.get("mst") or [])
                    if not ds_mst:
                        raise ValueError("Chọn ít nhất một công ty để chuyển.")
                    da, loi = cai_dat.sao_luu(ly_do="truoc-nhap-du-lieu-cu")
                    if not da:
                        raise OSError("Chưa sao lưu được dữ liệu hiện tại nên chưa chuyển. " + "; ".join(loi))
                    kq = NC.gop(p, dich, ds_mst)
                    so_tep = NC.chep_thu_muc(p.parent, dich.parent, kq)
                    NC.danh_dau_da_chuyen(p, dich)
                    cd = cai_dat.doc()
                    cd.setdefault("du_lieu_cu_da_xu_ly", {})[str(p)] = "da_nhap"
                    cai_dat.ghi(cd)
                    NC.KET_QUA_TIM["ds"] = [x for x in NC.KET_QUA_TIM["ds"] if NC._chuan(x["duong"]) != NC._chuan(p)]
                    from . import quan_ly
                    con = self.con()
                    for x in kq:
                        quan_ly.ghi_nhat_ky(con, x["cid"], "nhap_du_lieu_cu", None, {"tu_file": str(p), "bang": x["bang"]}, self.ten_nguoi())
                    con.commit()
                    ten_bang = {"chung_tu": "chứng từ", "but_toan": "bút toán", "hoa_don": "hóa đơn", "doi_tuong": "đối tượng",
                                "vat_tu": "vật tư", "tai_san": "tài sản", "nhan_vien": "nhân viên", "tai_khoan": "tài khoản"}
                    dong = "".join(
                        f'<li><b>{e(x["ten"])}</b> ({"tạo mới" if x["tao_moi"] else "đã có, thêm phần còn thiếu"}): '
                        + (", ".join(f'{so(v)} {ten_bang.get(k, k)}' for k, v in x["bang"].items()) or "không có gì mới")
                        + '</li>' for x in kq)
                    tb = (f'<p class="ok">Đã chuyển dữ liệu từ {e(p)}. Dữ liệu ngay trước khi chuyển đã được sao lưu '
                          f'({e(da[0].name)}).</p><ul>{dong}</ul>'
                          + (f'<p class="mo">Đã chép thêm {so_tep} file mẫu HTKK, file đã xuất.</p>' if so_tep else '')
                          + '<p class="mo">File cũ không bị sửa. Từ nay chỉ dùng bản này, không mở bản cũ nữa.</p>')
                else:
                    xem = (p, NC.tom_tat(p, dich))
            except _Xong:
                pass
            except (ValueError, OSError, PermissionError) as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        if xem:
            p, tt = xem
            dong = "".join(
                f'<tr><td><label class="chon"><input type="checkbox" name="mst" value="{e(x["mst"])}" '
                f'{"checked" if (x["moi_chung_tu"] or x["moi_hoa_don"]) else ""}>{e(x["ten"])}</label><br><small>MST {e(x["mst"])}</small></td>'
                f'<td>{G.ngay_vn(x["ngay"][0]) + " – " + G.ngay_vn(x["ngay"][1]) if x["ngay"] else ""}</td>'
                f'<td class="s">{so(x["chung_tu"])}</td><td class="s">{so(x["hoa_don"])}</td>'
                f'<td>{"Đã có ở bản này" if x["da_co"] else "Chưa có, sẽ tạo mới"}</td>'
                f'<td class="s">' + (f'<b>{x["moi_chung_tu"]:,}</b> chứng từ, <b>{x["moi_hoa_don"]:,}</b> hóa đơn'.replace(",", ".")
                                     if x["moi_chung_tu"] or x["moi_hoa_don"] else "Không có gì mới") + '</td></tr>' for x in tt)
            nd = f"""<div class="the"><h2>Dữ liệu trong {e(p)}</h2>
<form method="post"><input type="hidden" name="file" value="{e(p)}"><input type="hidden" name="hanh_dong" value="nhap">
<table><tr><th>Công ty</th><th>Kỳ có chứng từ</th><th class="s">Chứng từ</th><th class="s">Hóa đơn</th><th>Ở bản này</th><th class="s">Sẽ thêm</th></tr>{dong}</table>
<p class="mo">Công ty đã có (cùng mã số thuế) thì chỉ thêm phần còn thiếu, không ghi đè số liệu đang có. Chứng từ trùng số và ngày, hóa đơn trùng số thì bỏ qua.
Trước khi chuyển, máy tự sao lưu dữ liệu hiện tại. File cũ chỉ được đọc, không bị sửa.</p>
<div class="dong-nut"><button>Chuyển các công ty đã chọn</button><a class="nut phu" href="/he-thong/nhap-cu">Quay lại</a></div></form></div>"""
            return nd, tb
        if q.get("tim") == "lai":
            NC.KET_QUA_TIM["xong"] = False
            NC.quet_nen(dich, list((cai_dat.doc().get("du_lieu_cu_da_xu_ly") or {}).keys())).join(15)
        ds = NC.KET_QUA_TIM["ds"]
        if ds:
            the = "".join(
                f'<div class="the"><h3>{e(x["duong"])}</h3><ul>'
                + "".join(f'<li>{e(c["ten"])}: {so(c["moi_chung_tu"])} chứng từ, {so(c["moi_hoa_don"])} hóa đơn chưa có ở bản này</li>'
                          for c in x["tom_tat"] if c["moi_chung_tu"] or c["moi_hoa_don"])
                + f'</ul><div class="dong-nut"><form method="post"><input type="hidden" name="file" value="{e(x["duong"])}">'
                f'<button name="hanh_dong" value="xem">Xem và chuyển</button> <button class="phu" name="hanh_dong" value="bo_qua">Bỏ qua</button></form></div></div>'
                for x in ds)
        else:
            the = ('<p class="mo">Chưa tìm thấy dữ liệu bản cũ nào cần chuyển.</p>' if NC.KET_QUA_TIM["xong"]
                   else '<p class="mo">Máy đang tìm dữ liệu bản cũ, mở lại trang sau ít giây.</p>')
        nd = f"""<div class="the"><h2>Chuyển dữ liệu bản cũ</h2>
<p>Nếu trước đây anh/chị chạy iFix Kế toán (Sổ kế toán) từ một thư mục khác, ví dụ <code>E:\\...\\ban-dang-chay</code>, dữ liệu cũ nằm ở
<code>du_lieu\\ketoan.db</code> trong thư mục đó. Mỗi lần mở, máy tự tìm và báo ở đây.</p>
{the}
<p class="mo"><a href="/he-thong/nhap-cu?tim=lai">Tìm lại trên máy</a></p></div>
<div class="hai-cot"><div class="the"><h2>Xuất riêng một công ty</h2>
<p class="mo">Gửi sổ của một công ty sang máy khác đã cài iFix Kế toán. File .zip chỉ có công ty đã chọn (chứng từ, hóa đơn, danh mục,
tài sản, lương, mẫu HTKK...), không có công ty khác, không có key bản quyền.</p>
<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="xuat">
<label>Công ty<select name="mst_xuat">{"".join(f'<option value="{e(r["mst"])}">{e(r["ten"])} ({e(r["mst"])})</option>' for r in self.con().execute("SELECT mst, ten FROM cong_ty ORDER BY ten"))}</select></label>
<label>Lưu vào thư mục<input name="thu_muc_xuat" size="36" required placeholder="F:\\GuiMayKhac" value="{e(cai_dat.doc().get('thu_muc_xuat_cong_ty') or '')}"></label>
<button type="button" class="phu" onclick="chonDuong(this,'thu_muc','thu_muc_xuat')">Chọn thư mục…</button>
<button>Xuất file</button></form></div>
<div class="the"><h2>Nhập từ file</h2>
<p class="mo">Chọn file .zip nhận từ máy khác (xuất riêng một công ty hoặc sao lưu toàn bộ, không cần giải nén), hoặc file ketoan.db.
Bấm Xem để chọn công ty cần nhập. Công ty đang có trên máy này được giữ nguyên.</p>
<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="xem">
<label>Đường dẫn file .zip / ketoan.db<input name="file" size="50" placeholder="C:\\Users\\...\\Downloads\\iFixKeToan-....zip" required></label>
<button type="button" class="phu" onclick="chonDuong(this,'file','file')">Chọn file…</button>
<button>Xem</button></form></div></div>"""
        return nd, tb

    # ---------------------------------------------------------------- tham so thue
    def _ht_tham_so(self, pt, q):
        tb = ""
        if pt == "POST":
            f = self.doc_form()
            g = lambda k: (f.get(k) or [""])[0]
            try:
                self._can_quan_tri()
                if g("hanh_dong") == "mac_dinh":
                    cai_dat.khoi_phuc_mac_dinh()
                    tb = '<p class="ok">Đã trả các tham số về mặc định trong chương trình.</p>'
                else:
                    ky = []
                    for i, tu in enumerate(f.get("l_tu", [])):
                        if not tu.strip():
                            continue
                        ky.append({"tu": tu.strip(), "giam_tru_ban_than": _so_nguyen(f["l_bt"][i]),
                                   "giam_tru_npt": _so_nguyen(f["l_npt"][i]), "luong_co_so": _so_nguyen(f["l_cs"][i]),
                                   "bieu_thue": _doc_bieu(f["l_bieu"][i])})
                    if not ky:
                        raise ValueError("Phải có ít nhất một kỳ tham số lương")
                    bh = {tk: (_so_thuc(g(f"bh_{tk}_nld")), _so_thuc(g(f"bh_{tk}_dn"))) for tk in ("3383", "3384", "3385")}
                    khung = {d[0]: (int(d[1]), int(d[2])) for d in _dong(g("khung")) if len(d) >= 3}
                    tien_mat = [(d[0], _so_nguyen(d[1])) for d in _dong(g("tien_mat")) if len(d) >= 2]
                    tndn = [(int(d[0]), _so_nguyen(d[1]), _so_thuc(d[2])) for d in _dong(g("tndn")) if len(d) >= 3]
                    if not tien_mat or not tndn:
                        raise ValueError("Ngưỡng tiền mặt và thuế suất TNDN không được để trống")
                    cai_dat.luu_tham_so({"luong": ky, "bao_hiem": bh, "khung_tt45": khung,
                                         "to_khai": {"nguong_tien_mat": tien_mat, "thue_suat_tndn": tndn,
                                                     "so_nam_chuyen_lo": int(g("chuyen_lo") or 5)}}, self.ten_nguoi())
                    tb = '<p class="ok">Đã lưu và áp dụng tham số mới. Các bảng lương, tờ khai tính lại sẽ dùng số mới.</p>'
            except (ValueError, KeyError, IndexError, PermissionError) as ex:
                tb = f'<p class="loi">Chưa lưu: {e(ex)}</p>'
        ts = cai_dat.tham_so_hien_tai()
        da_sua = bool(cai_dat.doc().get("tham_so"))
        cc = cai_dat.CAN_CU
        dong_l = "".join(
            f'<tr><td><input name="l_tu" size="8" value="{e(t["tu"])}"></td><td><input name="l_bt" size="12" value="{so(t["giam_tru_ban_than"])}"></td>'
            f'<td><input name="l_npt" size="11" value="{so(t["giam_tru_npt"])}"></td><td><input name="l_cs" size="11" value="{so(t["luong_co_so"])}"></td>'
            f'<td><input name="l_bieu" size="70" value="{e(_bieu_chu(t["bieu_thue"]))}"></td></tr>'
            for t in ts["luong"] + [{"tu": "", "giam_tru_ban_than": 0, "giam_tru_npt": 0, "luong_co_so": 0, "bieu_thue": []}])
        ten_bh = {"3383": "BHXH", "3384": "BHYT", "3385": "BHTN"}
        dong_bh = "".join(
            f'<tr><td>{ten_bh[k]} (TK {k})</td><td><input name="bh_{k}_nld" size="6" value="{v[0]:g}"></td>'
            f'<td><input name="bh_{k}_dn" size="6" value="{v[1]:g}"></td></tr>' for k, v in ts["bao_hiem"].items())
        khung = "\n".join(f"{k} | {a} | {b}" for k, (a, b) in ts["khung_tt45"].items())
        tm = "\n".join(f"{d} | {so(v)}" for d, v in ts["to_khai"]["nguong_tien_mat"])
        tndn = "\n".join(f"{n} | {so(m) if m else ''} | {t:g}" for n, m, t in ts["to_khai"]["thue_suat_tndn"])
        nd = f"""<form method="post" class="the"><h2>Tham số thuế, bảo hiểm, khấu hao</h2>
<p class="mo">{'Đang dùng tham số đã sửa trên trang này.' if da_sua else 'Đang dùng tham số mặc định trong chương trình.'}
Khi nhà nước thay đổi mức, thêm một kỳ mới với tháng bắt đầu áp dụng thay vì sửa kỳ cũ, để tính lại các tháng trước vẫn đúng. Chỉ Quản trị lưu được.</p>
<h3>Thuế TNCN, giảm trừ gia cảnh, lương cơ sở</h3>
<table><tr><th>Áp dụng từ tháng (YYYY-MM)</th><th>Giảm trừ bản thân</th><th>Giảm trừ / NPT</th><th>Lương cơ sở</th>
<th>Biểu thuế lũy tiến tháng (mức trên:thuế suất %; bậc cuối để trống mức)</th></tr>{dong_l}</table>
<p class="mo">Căn cứ: {e(cc['luong'])}</p>
<h3>Tỷ lệ bảo hiểm bắt buộc (%)</h3>
<table style="max-width:520px"><tr><th>Loại</th><th>Người lao động</th><th>Doanh nghiệp</th></tr>{dong_bh}</table>
<p class="mo">Căn cứ: {e(cc['bao_hiem'])} Mức đóng tối đa bằng 20 lần lương cơ sở.</p>
<div class="hai-cot"><div><h3>Khung khấu hao TSCĐ (tháng)</h3><p class="mo">Mỗi dòng: Nhóm tài sản | tối thiểu | tối đa</p>
<textarea name="khung" rows="9" style="width:100%">{e(khung)}</textarea><p class="mo">Căn cứ: {e(cc['khung_tt45'])}</p></div>
<div><h3>Ngưỡng thanh toán không dùng tiền mặt (GTGT)</h3><p class="mo">Mỗi dòng: từ ngày (YYYY-MM-DD) | ngưỡng</p>
<textarea name="tien_mat" rows="3" style="width:100%">{e(tm)}</textarea><p class="mo">Căn cứ: {e(cc['nguong_tien_mat'])}</p>
<h3>Thuế suất TNDN</h3><p class="mo">Mỗi dòng: từ năm | doanh thu năm tối đa (trống = không giới hạn) | thuế suất %</p>
<textarea name="tndn" rows="4" style="width:100%">{e(tndn)}</textarea><p class="mo">Căn cứ: {e(cc['thue_suat_tndn'])}</p>
<label>Số năm được chuyển lỗ<input name="chuyen_lo" size="4" value="{ts['to_khai']['so_nam_chuyen_lo']}"></label>
<p class="mo">Căn cứ: {e(cc['so_nam_chuyen_lo'])}</p></div></div>
<div class="dong-nut"><button>Lưu tham số</button></div></form>
<form method="post" class="the"><input type="hidden" name="hanh_dong" value="mac_dinh">
<p class="mo">Bỏ mọi chỉnh sửa trên trang này, quay về số mặc định trong chương trình.</p><button class="nguy">Khôi phục mặc định</button></form>"""
        return nd, tb

    # ---------------------------------------------------------------- nguoi dung, LAN
    def _ht_nguoi_dung(self, pt, q):
        con = self.con()
        cai_dat.chuan_bi(con)
        tb = ""
        co_nd = cai_dat.co_nguoi_dung(con)
        cd = cai_dat.doc()
        if pt == "POST":
            self._form_cu = self.doc_form()
            f = {k: v[0].strip() for k, v in self._form_cu.items()}
            try:
                if co_nd:
                    self._can_quan_tri()
                hd = f.get("hanh_dong")
                if hd == "luu":
                    cai_dat.dat_nguoi_dung(con, f.get("ten"), f.get("mat_khau"), f.get("vai_tro", "ke_toan"), f.get("ho_ten"))
                    tb = '<p class="ok">Đã lưu người dùng.</p>' + (
                        '' if co_nd else '<p class="bao">Từ giờ phải đăng nhập mới dùng được ứng dụng.</p>')
                elif hd == "giao":
                    f2 = self._form_cu
                    cai_dat.giao_cong_ty(con, f["ten"], f2.get("cty", []))
                    tb = f'<p class="ok">Đã giao {len(f2.get("cty", []))} công ty cho {e(f["ten"])}.</p>'
                elif hd == "xoa":
                    cai_dat.xoa_nguoi_dung(con, f["ten"])
                    tb = '<p class="ok">Đã xóa người dùng.</p>'
                elif hd == "lan":
                    bat = f.get("lan") == "1"
                    if bat and not cai_dat.co_nguoi_dung(con):
                        raise ValueError("Phải tạo người dùng Quản trị trước khi mở cho máy khác trong mạng LAN.")
                    cd = cai_dat.dat(lan=bat)
                    tb = '<p class="ok">Đã lưu. Bấm nút Tắt (góc trên bên phải) rồi mở lại để áp dụng.</p>'
            except (ValueError, PermissionError, KeyError) as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        ds = con.execute("SELECT * FROM nguoi_dung ORDER BY ten").fetchall()
        cac_cty = con.execute("SELECT id, ten FROM cong_ty ORDER BY ten").fetchall()

        def o_giao(r):
            if r["vai_tro"] == "quan_tri":
                return '<span class="mo">Mọi công ty</span>'
            co = {x["cong_ty_id"] for x in con.execute("SELECT cong_ty_id FROM nguoi_dung_cong_ty WHERE ten=?", (r["ten"],))}
            hop = "".join(f'<label class="chon"><input type="checkbox" name="cty" value="{c["id"]}" {"checked" if c["id"] in co else ""}>{e(c["ten"])}</label>'
                          for c in cac_cty)
            return (f'<details><summary>{len(co)} / {len(cac_cty)} công ty</summary><form method="post" style="display:grid;gap:4px;margin-top:6px">'
                    f'<input type="hidden" name="hanh_dong" value="giao"><input type="hidden" name="ten" value="{e(r["ten"])}">{hop}'
                    f'<div><button class="phu nho">Lưu</button></div></form></details>')
        vai = lambda chon: "".join(f'<option value="{k}" {"selected" if k == chon else ""}>{e(t)}</option>' for k, t in cai_dat.VAI_TRO.items())
        bang = "".join(
            f'<tr><td><b>{e(r["ten"])}</b></td><td>{e(r["ho_ten"] or "")}</td><td>{e(cai_dat.VAI_TRO.get(r["vai_tro"], r["vai_tro"]).split(" (")[0])}</td><td>{o_giao(r)}</td>'
            f'<td><form method="post" onsubmit="return confirm(\'Xóa người dùng {e(r["ten"])}?\')"><input type="hidden" name="hanh_dong" value="xoa">'
            f'<input type="hidden" name="ten" value="{e(r["ten"])}"><button class="nguy nho">Xóa</button></form></td></tr>' for r in ds)
        ip = cai_dat.dia_chi_lan()
        dang_lan = getattr(self.server, "lan", False)
        nd = f"""<div class="hai-cot"><div class="the"><h2>Người dùng</h2>
<p class="mo">{'Khi đã có người dùng, ai mở ứng dụng cũng phải đăng nhập. Quản trị: toàn quyền. Kế toán: nhập liệu, ghi sổ, lập báo cáo; không quản lý người dùng, không khôi phục dữ liệu, không mở khóa sổ. Chỉ xem: xem và tải báo cáo, không sửa được gì.' if co_nd else 'Chưa có người dùng nào nên ứng dụng không cần đăng nhập (chỉ máy này mở được). Muốn cho máy khác trong mạng LAN dùng chung, tạo người Quản trị trước.'}</p>
{'<table><tr><th>Tên đăng nhập</th><th>Họ tên</th><th>Vai trò</th><th>Công ty được dùng</th><th></th></tr>' + bang + '</table>' if ds else ''}
{'<p class="mo">Kế toán và Chỉ xem chỉ thấy các công ty được giao. Kế toán tự thêm công ty mới thì được giao luôn công ty đó.</p>' if ds else ''}
<h3>Thêm người dùng, hoặc đổi mật khẩu / vai trò</h3>
<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="luu">
<label>Tên đăng nhập<input name="ten" size="14" required></label><label>Họ tên<input name="ho_ten" size="20"></label>
<label>Mật khẩu (từ 6 ký tự; để trống nếu chỉ đổi vai trò)<input type="password" name="mat_khau" size="16" autocomplete="new-password"></label>
<label>Vai trò<select name="vai_tro">{vai('quan_tri' if not ds else 'ke_toan')}</select></label><button>Lưu</button></form>
<p class="mo">Mật khẩu chỉ lưu dạng mã băm, không ai đọc lại được.</p></div>
<div class="the"><h2>Dùng chung trong mạng LAN</h2>
<p>Hiện tại: {'<b>đang mở cho mạng LAN</b>' if dang_lan else '<b>chỉ máy này</b> (127.0.0.1)'}.</p>
<p class="mo">Bật lên thì các máy khác cùng mạng nội bộ mở trình duyệt, gõ <code>http://{e(ip)}:{getattr(self.server, 'server_port', 8765)}</code> và đăng nhập.
Dữ liệu vẫn chỉ nằm trên máy này. Windows có thể hỏi cho phép Python qua tường lửa: chọn Private network (mạng riêng). Không mở cổng này ra Internet.</p>
<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="lan">
<label class="chon"><input type="checkbox" name="lan" value="1" {'checked' if cd.get('lan') else ''}> Cho máy khác trong mạng LAN truy cập</label>
<button class="phu">Lưu</button></form></div></div>"""
        return nd, tb

    def _ht_phien_ban(self, pt, q):
        nd = '<div class="the">' + f'<h2>iFix Kế toán phiên bản {PHIEN_BAN}</h2><p class="mo">Phát hành {e(NGAY_PHAT_HANH)}. Chạy trên máy, dữ liệu ở thư mục du_lieu.</p>' + "".join(
            f'<h3>Bản {v}</h3><ul>' + "".join(f"<li>{e(x)}</li>" for x in ds) + "</ul>" for v, ds in THAY_DOI.items()) + "</div>"
        return nd, ""
