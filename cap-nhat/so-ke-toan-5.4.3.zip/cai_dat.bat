@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist "%~dp0python\python.exe" (
  echo Ban nay da kem san Python va thu vien. Khong can cai them.
  goto loitat
)
echo Dang cai thu vien can thiet...
py -3 -m pip install -r requirements.txt
if errorlevel 1 python -m pip install -r requirements.txt
:loitat
echo.
echo Tao bieu tuong "iFix Ke toan" tren Desktop va Start Menu...
cscript //nologo "%~dp0tao_loi_tat.vbs"
echo Xong. Bam dup "iFix Ke toan" tren Desktop de mo.
pause
