' Tat iFix Ke toan dang chay an (dung khi khong mo duoc trang de bam nut Tat).
Set wmi = GetObject("winmgmts:\\.\root\cimv2")
n = 0
For Each p In wmi.ExecQuery("SELECT * FROM Win32_Process WHERE CommandLine LIKE '%ketoan.ung_dung%'")
  p.Terminate
  n = n + 1
Next
If n > 0 Then
  MsgBox "Da tat iFix Ke toan.", 64, "iFix Ke toan"
Else
  MsgBox "iFix Ke toan khong chay.", 64, "iFix Ke toan"
End If
