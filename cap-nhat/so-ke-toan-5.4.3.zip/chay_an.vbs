' Mo So ke toan chay an (khong co cua so den). Dang chay roi thi chi mo trinh duyet.
Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
d = fs.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = d
sh.Environment("PROCESS")("PYTHONUTF8") = "1"
py = d & "\python\pythonw.exe"
If fs.FileExists(py) Then
  sh.Run """" & py & """ -m ketoan.ung_dung", 0, False
Else
  sh.Run "pyw -3 -m ketoan.ung_dung", 0, False
End If
