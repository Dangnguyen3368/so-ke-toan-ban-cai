"""Doi chieu so lieu cua he thong moi voi so cai xuat tu MISA."""
from . import nhap_misa, so_sach

TRUONG = ["dau_no", "dau_co", "ps_no", "ps_co", "cuoi_no", "cuoi_co"]
NHAN = {"dau_no": "Dư Nợ đầu kỳ", "dau_co": "Dư Có đầu kỳ", "ps_no": "Phát sinh Nợ",
        "ps_co": "Phát sinh Có", "cuoi_no": "Dư Nợ cuối kỳ", "cuoi_co": "Dư Có cuối kỳ"}


def voi_so_cai_misa(con, cid, duong_so_cai, tu, den):
    """Tra ve (so_tk_khop, tong_so_tk, list chenh lech).

    Moi chenh lech: dict so_tk, ten, truong, misa, he_thong, chenh.
    """
    misa = nhap_misa.doc_so_cai(duong_so_cai)
    ht = {r["so_tk"]: r for r in so_sach.tong_hop_tai_khoan(con, cid, tu, den)}
    lech = []
    khop = 0
    for tk in sorted(set(misa) | set(ht)):
        m = misa.get(tk, {})
        h = ht.get(tk, {})
        dong = [
            {"so_tk": tk, "ten": (m or h).get("ten", ""), "truong": NHAN[f],
             "misa": m.get(f, 0), "he_thong": h.get(f, 0), "chenh": h.get(f, 0) - m.get(f, 0)}
            for f in TRUONG if m.get(f, 0) != h.get(f, 0)
        ]
        if dong:
            lech += dong
        else:
            khop += 1
    return khop, len(set(misa) | set(ht)), lech
