"""Trang Tro ly AI cua tung cong ty: /cty/<id>/ai/{hoi, doc, soat, phantich, nhacno}."""
import json
from datetime import date

from . import ai_nghiep_vu as NV
from . import bao_cao, db, giao_dien as G, hoa_don
from . import tro_ly_ai as AI
from .giao_dien import e, ngay_vn, so

THE = [("hoi", "Hỏi đáp"), ("doc", "Đọc chứng từ"), ("soat", "Soát sổ"), ("phantich", "Phân tích, dự báo"), ("nhacno", "Nhắc nợ")]
MAU = {"do": "do", "vang": "vang", "xanh": "lam"}
NHAN = {"do": "Cần sửa", "vang": "Cần xem", "xanh": "Lưu ý"}


def _ds_tk(con, cid):
    return "".join(f'<option value="{e(t["so_tk"])}">{e(t["ten"])}</option>' for t in
                   con.execute("SELECT so_tk, ten FROM tai_khoan WHERE cong_ty_id=? ORDER BY so_tk", (cid,)))


def chi_so_suc_khoe(con, cid, tu, den):
    """Chi so suc khoe tai chinh tinh san (khong can AI): list (ten, gia tri chu, danh gia 'xanh'|'vang'|'do', giai thich)."""
    bang, _ = bao_cao.phan_hai_ben(con, cid, bao_cao.ngay_sau(den))
    du = lambda *tt: sum(n - c for t, (n, c) in bang.items() if t.startswith(tt))
    no_ben = lambda *tt: sum(n for t, (n, c) in bang.items() if t.startswith(tt))
    co_ben = lambda *tt: sum(c for t, (n, c) in bang.items() if t.startswith(tt))
    tien = du("111", "112")
    ts_nh = tien + du("121", "128") + no_ben("131", "136", "138", "141") + du("133") + du("152", "153", "154", "155", "156")
    no_nh = co_ben("331", "333", "334", "335", "338", "341")
    k = bao_cao.b02(con, cid, tu, den)
    so_ngay = max((date.fromisoformat(den) - date.fromisoformat(tu)).days + 1, 1)
    chi = k["11"] + k["22"] + k["24"] + k["32"]
    kq = []
    if no_nh:
        r = ts_nh / no_nh
        kq.append(("Khả năng thanh toán ngắn hạn", f"{r:.2f} lần", "xanh" if r >= 1.5 else "vang" if r >= 1 else "do",
                   "Tài sản ngắn hạn / nợ ngắn hạn. Dưới 1 là có thể thiếu tiền trả nợ."))
        r = tien / no_nh
        kq.append(("Khả năng thanh toán bằng tiền", f"{r:.2f} lần", "xanh" if r >= 0.5 else "vang" if r >= 0.2 else "do",
                   "Tiền mặt + tiền gửi / nợ ngắn hạn."))
    if k["10"]:
        bg = k["20"] / k["10"] * 100
        kq.append(("Biên lợi nhuận gộp", f"{bg:.1f}%", "xanh" if bg >= 20 else "vang" if bg >= 5 else "do", "Lợi nhuận gộp / doanh thu thuần."))
        br = k["50"] / k["10"] * 100
        kq.append(("Biên lợi nhuận trước thuế", f"{br:.1f}%", "xanh" if br >= 5 else "vang" if br >= 0 else "do",
                   "Lợi nhuận trước thuế / doanh thu thuần."))
        pt = no_ben("131")
        ngay_thu = pt / (k["10"] / so_ngay)
        kq.append(("Số ngày thu tiền bình quân", f"{ngay_thu:.0f} ngày", "xanh" if ngay_thu <= 45 else "vang" if ngay_thu <= 90 else "do",
                   "Phải thu khách hàng / doanh thu bình quân một ngày."))
    if chi:
        ngay_chi = tien / (chi / so_ngay)
        kq.append(("Tiền đủ chi", f"{ngay_chi:.0f} ngày", "xanh" if ngay_chi >= 60 else "vang" if ngay_chi >= 30 else "do",
                   "Tiền hiện có / chi phí bình quân một ngày trong kỳ."))
    return kq


class TrangAI:
    def ai(self, pt, con, ct, q, rest):
        cid = ct["id"]
        muc = rest[0] if rest else "hoi"
        f = {"hoi": self._ai_hoi, "doc": self._ai_doc, "soat": self._ai_soat, "phantich": self._ai_phantich,
             "nhacno": self._ai_nhacno}.get(muc)
        if not f:
            return self.gui(G.trang("Không tìm thấy", "<p>Trang không tồn tại.</p>"), 404)
        self._ai_ok, self._ai_tb = AI.san_sang(bq=getattr(self, "bq", None))
        nd = f(pt, con, ct, q, rest[1:])
        if nd is None:
            return
        tabs = G.tab([(m, f"/cty/{cid}/ai/{m}", t) for m, t in THE], muc)
        c = AI.cau_hinh()
        dau = (f'<p class="mo">Đang dùng: <b>{e(AI.NHA_CUNG_CAP[c["nha_cung_cap"]]["ten"])}</b> · {e(c["mo_hinh"])} · '
               '<a href="/he-thong/ai">đổi</a></p>' if self._ai_ok else
               f'<p class="bao">{e(self._ai_tb)} <a class="nut nho" href="/he-thong/ai">Cài đặt Trợ lý AI</a></p>')
        self.gui(G.trang("Trợ lý AI", f'<div class="the"><h1>Trợ lý AI</h1>{tabs}{dau}</div>{nd}', cid, ct["ten"]))

    def _nut_ai(self, nhan, ten="hanh_dong", gia_tri="ai"):
        return f'<button name="{ten}" value="{gia_tri}">{nhan}</button>' if self._ai_ok else ""

    # ------------------------------------------------------------ hoi dap
    def _ai_hoi(self, pt, con, ct, q, rest):
        cid = ct["id"]
        tu0, den0 = NV.ky_du_lieu(con, cid)
        tho = self.doc_form() if pt == "POST" else {}
        f = {k: next((x for x in reversed(v) if x.strip()), v[0]) for k, v in tho.items()}
        tu, den = f.get("tu") or q.get("tu") or tu0, f.get("den") or q.get("den") or den0
        try:
            lich_su = [tuple(x) for x in json.loads(f.get("lich_su") or "[]")][-12:]
        except ValueError:
            lich_su = []
        tb = ""
        cau = (f.get("cau_hoi") or "").strip()
        if f.get("hanh_dong") == "xoa":
            lich_su, cau = [], ""
        elif cau:
            try:
                if not self._ai_ok:
                    raise AI.LoiAI(self._ai_tb)
                tl = NV.hoi_dap(con, cid, cau, tu, den, lich_su)
                lich_su = (lich_su + [("user", cau), ("assistant", tl)])[-12:]
            except AI.LoiAI as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        hoi_thoai = "".join(
            (f'<div class="the" style="background:var(--nen2, #f3f6fb)"><b>Bạn hỏi:</b> {e(t)}</div>' if v == "user" else
             f'<div class="the">{NV.markdown_html(t)}</div>') for v, t in lich_su)
        mau = "".join(f'<button type="submit" class="phu nho" name="cau_hoi" value="{e(x)}">{e(x)}</button>' for x in NV.CAU_HOI_MAU)
        return f"""{hoi_thoai}{tb}
<form method="post" class="the" style="display:grid;gap:10px">
<input type="hidden" name="lich_su" value="{e(json.dumps(lich_su, ensure_ascii=False))}">
<div class="ngang"><label>Từ ngày<input type="date" name="tu" value="{e(tu)}"></label>
<label>Đến ngày<input type="date" name="den" value="{e(den)}"></label></div>
<label>Câu hỏi về sổ sách của {e(ct["ten"])}<textarea name="cau_hoi" rows="3" style="width:100%"
 placeholder="Ví dụ: quý này lãi bao nhiêu? khách nào nợ quá 60 ngày?"></textarea></label>
<div class="dong-nut">{self._nut_ai("Hỏi AI", "hanh_dong", "hoi")}{'<button class="phu" name="hanh_dong" value="xoa">Hỏi lại từ đầu</button>' if lich_su else ''}</div>
{('<div class="dong-nut">' + mau + '</div>') if self._ai_ok else ''}
<p class="mo">AI đọc bảng tóm tắt số liệu máy tính sẵn trong kỳ (kết quả kinh doanh, cân đối tài khoản, công nợ lớn, việc cần làm),
không tự sửa dữ liệu. Số liệu quan trọng nên đối chiếu lại trên sổ.</p></form>"""

    # ------------------------------------------------------------ doc chung tu
    def _ai_doc(self, pt, con, ct, q, rest):
        cid = ct["id"]
        dstk = f'<datalist id="dstk">{_ds_tk(con, cid)}</datalist>'
        if rest and rest[0] == "luu" and pt == "POST":
            return self._ai_doc_luu(con, ct)
        tb, kq, ten_file = "", None, ""
        if pt == "POST":
            from .trang_hoa_don import doc_multipart
            _, tep = doc_multipart(self)
            try:
                if not self._ai_ok:
                    raise AI.LoiAI(self._ai_tb)
                if not tep:
                    raise AI.LoiAI("Chưa chọn file.")
                ten_file, b = tep[0]
                kq = NV.doc_chung_tu(con, cid, ten_file, b)
            except AI.LoiAI as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        anh, pdf = AI.doc_duoc_tep()
        nap = f"""<div class="the"><h2>Đọc hóa đơn, chứng từ bằng AI</h2>{tb}
<p>Nạp file PDF hóa đơn điện tử (bản thể hiện), ảnh chụp hóa đơn giấy, phiếu chi, biên lai, vé... AI đọc thông tin và đề nghị định khoản;
bạn xem lại, sửa rồi mới lưu.</p>
<form method="post" enctype="multipart/form-data" class="ngang">
<label>File PDF hoặc ảnh<input type="file" name="tep" accept=".pdf,.jpg,.jpeg,.png,.webp" required></label>
{self._nut_ai("Đọc bằng AI", "hanh_dong", "doc")}</form>
<p class="mo">{'' if pdf else 'Hãng AI đang chọn không đọc được PDF: hãy nạp ảnh. ' if anh else 'Hãng AI đang chọn không đọc được ảnh và PDF: chọn Claude, ChatGPT hoặc Gemini. '}
Hóa đơn điện tử có file XML thì nên nạp XML ở mục Hóa đơn (chính xác tuyệt đối). Hóa đơn AI đọc sau này nạp XML cùng số sẽ được thay bằng dữ liệu XML.</p></div>"""
        if not kq:
            return nap
        return nap + self._ai_doc_form(con, ct, kq, ten_file) + dstk

    def _ai_doc_form(self, con, ct, d, ten_file):
        cid = ct["id"]
        o = lambda ten, gt, co=14, kieu="text": f'<input name="{ten}" type="{kieu}" size="{co}" value="{e(gt)}">'
        cb = "".join(f'<p class="bao">{e(x)}</p>' for x in d["canh_bao"])
        hang = "".join(
            f'<tr><td>{o("h_ten", x["ten"], 34)}</td><td>{o("h_dvt", x["dvt"], 5)}</td><td>{o("h_sl", x["so_luong"], 5)}</td>'
            f'<td>{o("h_dg", so(x["don_gia"]), 11)}</td><td>{o("h_tt", so(x["thanh_tien"]), 12)}</td><td>{o("h_ts", x["thue_suat"], 5)}</td>'
            f'<td><input name="h_tk" size="7" list="dstk" value="{e(x["tk"])}"></td></tr>' for x in d["dong_hang"])
        bt = d["but_toan"] + [{"tk_no": "", "tk_co": "", "so_tien": 0, "dien_giai": ""}] * 2
        dk = "".join(
            f'<tr><td><input name="tk_no" size="7" list="dstk" value="{e(x["tk_no"])}"></td>'
            f'<td><input name="tk_co" size="7" list="dstk" value="{e(x["tk_co"])}"></td>'
            f'<td>{o("so_tien", so(x["so_tien"]) if x["so_tien"] else "", 13)}</td><td>{o("dg", x["dien_giai"], 40)}</td></tr>' for x in bt)
        la_hd = d["loai"] == "hoa_don"
        return f"""<form method="post" action="/cty/{cid}/ai/doc/luu">
<div class="the"><h2>Kết quả đọc: {e(ten_file)}</h2>{cb}
<div class="ngang"><label class="chon"><input type="radio" name="luu_thanh" value="hoa_don" {"checked" if la_hd else ""}> Lưu thành hóa đơn {'mua vào' if d['chieu'] == 'mua' else 'bán ra'} (vào bảng kê, tờ khai GTGT)</label>
<label class="chon"><input type="radio" name="luu_thanh" value="chung_tu" {"" if la_hd else "checked"}> Lưu thành chứng từ kế toán (phiếu chi, biên lai...)</label></div>
<input type="hidden" name="chieu" value="{e(d['chieu'])}">
<div class="ngang"><label>Mẫu số{o("mau_so", d["mau_so"], 3)}</label><label>Ký hiệu{o("ky_hieu", d["ky_hieu"], 9)}</label>
<label>Số{o("so", d["so"], 9)}</label><label>Ngày{o("ngay", d["ngay"], 10, "date")}</label>
<label>Hình thức thanh toán{o("hinh_thuc_tt", d["hinh_thuc_tt"], 12)}</label></div>
<div class="ngang"><label>MST người bán{o("nb_mst", d["nb_mst"], 14)}</label><label>Tên người bán{o("nb_ten", d["nb_ten"], 36)}</label></div>
<div class="ngang"><label>MST người mua{o("nm_mst", d["nm_mst"], 14)}</label><label>Tên người mua{o("nm_ten", d["nm_ten"], 36)}</label></div>
<div class="ngang"><label>Tiền hàng{o("tien_hang", so(d["tien_hang"]), 14)}</label><label>Tiền thuế{o("tien_thue", so(d["tien_thue"]), 12)}</label>
<label>Tổng thanh toán{o("tong_tien", so(d["tong_tien"]), 14)}</label></div>
<label>Diễn giải{o("dien_giai", d["dien_giai"], 70)}</label></div>
{'<div class="the"><h3>Hàng hóa, dịch vụ</h3><div class="cuon"><table><tr><th>Tên</th><th>ĐVT</th><th>SL</th><th>Đơn giá</th><th>Thành tiền</th><th>Thuế suất</th><th>TK hạch toán</th></tr>' + hang + '</table></div><p class="mo">Lưu thành hóa đơn: máy nhớ TK theo từng mặt hàng cho lần sau, rồi định khoản như hóa đơn XML.</p></div>' if hang else ''}
<div class="the"><h3>Định khoản (khi lưu thành chứng từ)</h3><div class="cuon"><table><tr><th>TK Nợ</th><th>TK Có</th><th>Số tiền</th><th>Diễn giải</th></tr>{dk}</table></div>
<div class="ngang"><label>Số chứng từ<input name="so_ct" size="14" value="{e(('AI-' + (d['so'] or '')).rstrip('-'))}"></label>
<label>Loại<select name="loai"><option value="PC">Phiếu chi</option><option value="PT">Phiếu thu</option><option value="PK">Phiếu kế toán</option>
<option value="MH">Mua hàng</option><option value="BH">Bán hàng</option></select></label></div></div>
<div class="dong-nut"><button name="ghi" value="luu">Lưu</button><button class="phu" name="ghi" value="ghi_so">Lưu và ghi sổ luôn</button></div></form>"""

    def _ai_doc_luu(self, con, ct):
        cid = ct["id"]
        f = self.doc_form()
        g = lambda k: (f.get(k) or [""])[0].strip()
        sn = lambda v: NV._so(v)
        d = {"chieu": g("chieu") or "mua", "mau_so": g("mau_so"), "ky_hieu": g("ky_hieu"), "so": g("so"), "ngay": g("ngay"),
             "nb_mst": g("nb_mst"), "nb_ten": g("nb_ten"), "nm_mst": g("nm_mst"), "nm_ten": g("nm_ten"),
             "tien_hang": sn(g("tien_hang")), "tien_thue": sn(g("tien_thue")), "tong_tien": sn(g("tong_tien")),
             "dien_giai": g("dien_giai"),
             "dong_hang": [{"ten": t.strip(), "dvt": dv, "so_luong": sl, "don_gia": sn(dg), "thanh_tien": sn(tt), "thue_suat": ts, "tk": tk.strip()}
                           for t, dv, sl, dg, tt, ts, tk in zip(f.get("h_ten", []), f.get("h_dvt", []), f.get("h_sl", []), f.get("h_dg", []),
                                                                f.get("h_tt", []), f.get("h_ts", []), f.get("h_tk", [])) if t.strip()]}
        ghi = g("ghi") == "ghi_so"
        try:
            if g("luu_thanh") == "hoa_don":
                hid = NV.luu_hoa_don_doc(con, cid, d)
                tb = f'<p class="ok">Đã lưu hóa đơn {e(d["ky_hieu"])}-{e(d["so"])}. <a href="/cty/{cid}/hoadon/xem/{hid}">Xem hóa đơn</a></p>'
                if ghi:
                    da, loi = hoa_don.ghi_so(con, cid, [hid])
                    tb += (f'<p class="ok">Đã ghi sổ.</p>' if da else "") + "".join(f'<p class="loi">{e(x)}</p>' for x in loi)
            else:
                dong = [{"tk_no": a.strip(), "tk_co": b.strip(), "so_tien": sn(t), "dien_giai": dg.strip() or d["dien_giai"]}
                        for a, b, t, dg in zip(f.get("tk_no", []), f.get("tk_co", []), f.get("so_tien", []), f.get("dg", []))
                        if a.strip() and b.strip() and sn(t) > 0]
                if not dong:
                    raise ValueError("Chưa có dòng định khoản nào đủ TK Nợ, TK Có, số tiền.")
                if not d["ngay"]:
                    raise ValueError("Cần ngày chứng từ.")
                so_ct = g("so_ct") or f"AI-{d['ngay']}"
                ct_id = db.ghi_chung_tu(con, cid, so_ct, d["ngay"], d["ngay"], dong, loai=g("loai") or "PK",
                                        dien_giai=d["dien_giai"], nguon="ai_doc")
                con.commit()
                tb = f'<p class="ok">Đã ghi chứng từ {e(so_ct)}. <a href="/cty/{cid}/chungtu/{ct_id}">Xem chứng từ</a></p>'
        except (ValueError, KeyError) as ex:
            tb = f'<p class="loi">Chưa lưu được: {e(ex)}. Bấm Quay lại để sửa.</p><p><a href="javascript:history.back()">← Quay lại</a></p>'
        self.gui(G.trang("Trợ lý AI", f'<div class="the"><h1>Trợ lý AI</h1>{tb}<p><a class="nut phu" href="/cty/{cid}/ai/doc">Đọc chứng từ khác</a></p></div>',
                         cid, ct["ten"]))
        return None

    # ------------------------------------------------------------ soat so
    def _ai_soat(self, pt, con, ct, q, rest):
        cid = ct["id"]
        tu0, den0 = NV.ky_du_lieu(con, cid)
        f = {k: v[0] for k, v in self.doc_form().items()} if pt == "POST" else {}
        tu, den = f.get("tu") or q.get("tu") or tu0, f.get("den") or q.get("den") or den0
        kiem = NV.kiem_tra_so(con, cid, tu, den)
        bc = ""
        if f.get("hanh_dong") == "ai":
            try:
                if not self._ai_ok:
                    raise AI.LoiAI(self._ai_tb)
                bc = f'<div class="the"><h2>Báo cáo soát sổ của AI</h2>{NV.markdown_html(NV.soat_so(con, cid, tu, den, kiem))}</div>'
            except AI.LoiAI as ex:
                bc = f'<p class="loi">{e(ex)}</p>'
        dong = "".join(f'<tr><td>{G.nhan_tt(NHAN[m], MAU[m])}</td><td>{e(nd)}</td></tr>' for m, nd in kiem)
        return f"""<div class="the"><h2>Soát sổ trước khi khóa sổ</h2>
<form method="post" class="ngang"><label>Từ ngày<input type="date" name="tu" value="{e(tu)}"></label>
<label>Đến ngày<input type="date" name="den" value="{e(den)}"></label><button class="phu" name="hanh_dong" value="kiem">Kiểm tra lại</button>
{self._nut_ai("Nhờ AI soát và viết báo cáo")}</form>
<p class="mo">Máy tự kiểm tra: số dư sai bên, chưa kết chuyển, lệch sổ cái và sổ chi tiết, trả tiền mặt từ 5 triệu có khấu trừ thuế,
cặp định khoản ít gặp, chi phí lớn, hạn nộp tờ khai. AI đọc kết quả này cùng số liệu để chỉ ra lỗi, rủi ro thuế và cách sửa.</p>
<table><tr><th>Mức</th><th>Nội dung</th></tr>{dong or '<tr><td colspan="2" class="ok">Máy không phát hiện lỗi nào.</td></tr>'}</table></div>{bc}"""

    # ------------------------------------------------------------ phan tich, du bao
    def _ai_phantich(self, pt, con, ct, q, rest):
        cid = ct["id"]
        tu0, den0 = NV.ky_du_lieu(con, cid)
        f = {k: v[0] for k, v in self.doc_form().items()} if pt == "POST" else {}
        den = f.get("den") or q.get("den") or den0
        tu = f.get("tu") or q.get("tu") or tu0
        th = NV.chuoi_thang(con, cid, den, 12)
        cs = chi_so_suc_khoe(con, cid, tu, den)
        bc = ""
        if f.get("hanh_dong") == "ai":
            try:
                if not self._ai_ok:
                    raise AI.LoiAI(self._ai_tb)
                bc = f'<div class="the"><h2>Phân tích và dự báo của AI</h2>{NV.markdown_html(NV.phan_tich(con, cid, den))}</div>'
            except AI.LoiAI as ex:
                bc = f'<p class="loi">{e(ex)}</p>'
        the_cs = "".join(f'<div class="the" style="margin:0"><div class="mo">{e(t)}</div><div style="font-size:22px;font-weight:700">{e(v)}</div>'
                         f'{G.nhan_tt({"xanh": "Tốt", "vang": "Cần chú ý", "do": "Đáng lo"}[m], {"xanh": "xanh", "vang": "vang", "do": "do"}[m])}'
                         f'<div class="mo nho-chu" style="margin-top:6px">{e(gc)}</div></div>' for t, v, m, gc in cs)
        bang = "".join(f'<tr><td>{e(x["thang"][5:])}/{e(x["thang"][:4])}</td><td class="s">{so(x["doanh_thu"])}</td><td class="s">{so(x["chi_phi"])}</td>'
                       f'<td class="s {"loi" if x["lai"] < 0 else ""}">{so(x["lai"])}</td><td class="s">{so(x["thu_tien"])}</td>'
                       f'<td class="s">{so(x["chi_tien"])}</td><td class="s">{so(x["tien_cuoi"])}</td></tr>' for x in th)
        return f"""<div class="the"><h2>Chỉ số sức khỏe tài chính</h2>
<form method="post" class="ngang"><label>Từ ngày<input type="date" name="tu" value="{e(tu)}"></label>
<label>Đến ngày<input type="date" name="den" value="{e(den)}"></label><button class="phu" name="hanh_dong" value="xem">Xem</button>
{self._nut_ai("Nhờ AI phân tích và dự báo dòng tiền 3 tháng")}</form>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-top:12px">{the_cs or '<p class="mo">Chưa đủ số liệu.</p>'}</div></div>
{bc}<div class="the"><h2>12 tháng gần nhất</h2><div class="cuon"><table><tr><th>Tháng</th><th class="s">Doanh thu thuần</th><th class="s">Chi phí</th>
<th class="s">Lợi nhuận trước thuế</th><th class="s">Thu tiền</th><th class="s">Chi tiền</th><th class="s">Tiền cuối tháng</th></tr>{bang}</table></div></div>"""

    # ------------------------------------------------------------ nhac no
    def _ai_nhacno(self, pt, con, ct, q, rest):
        cid = ct["id"]
        _, den0 = NV.ky_du_lieu(con, cid)
        f = {k: v[0] for k, v in self.doc_form().items()} if pt == "POST" else {}
        ngay = f.get("ngay") or q.get("ngay") or max(den0, date.today().isoformat())
        ds = NV.khach_qua_han(con, cid, bao_cao.ngay_sau(ngay))
        kq = ""
        if f.get("ma") is not None and f.get("hanh_dong") == "ai":
            try:
                if not self._ai_ok:
                    raise AI.LoiAI(self._ai_tb)
                r = NV.soan_nhac_no(con, cid, f["ma"], bao_cao.ngay_sau(ngay), f.get("giong") or "lịch sự")
                kq = f"""<div class="the"><h2>Tin nhắc nợ cho {e(r['khach']['ten'])}</h2>
<label>Tin Zalo / SMS<textarea id="t_zalo" rows="5" style="width:100%">{e(r['zalo'])}</textarea></label>
<p><button type="button" class="phu nho" onclick="navigator.clipboard.writeText(document.getElementById('t_zalo').value)">Chép tin Zalo</button></p>
<label>Tiêu đề email<input id="t_tde" style="width:100%" value="{e(r['email_tieu_de'])}"></label>
<label>Nội dung email<textarea id="t_email" rows="12" style="width:100%">{e(r['email'])}</textarea></label>
<p><button type="button" class="phu nho" onclick="navigator.clipboard.writeText(document.getElementById('t_email').value)">Chép email</button></p>
<p class="mo">Phần mềm không tự gửi tin. Bạn đọc lại, sửa rồi tự gửi qua Zalo, email.</p></div>"""
            except AI.LoiAI as ex:
                kq = f'<p class="loi">{e(ex)}</p>'
        giong = '<select name="giong"><option>lịch sự</option><option>thân mật</option><option>nhắc lần 2, dứt khoát hơn</option></select>'
        dong = "".join(
            f'<tr><td><a href="/cty/{cid}/congno?tk=131&ma={e(x["ma"])}">{e(x["ten"])}</a><br><span class="mo">{e(x["ma"])}</span></td>'
            f'<td class="s">{so(x["tong"])}</td>' + "".join(f'<td class="s">{so(v)}</td>' for v in x["nhom"]) +
            f'<td class="s">{x["lau_nhat"]} ngày</td><td>' +
            (f'<form method="post" class="ngang"><input type="hidden" name="ngay" value="{e(ngay)}"><input type="hidden" name="ma" value="{e(x["ma"])}">'
             f'{giong}<button class="nho" name="hanh_dong" value="ai">AI soạn tin</button></form>' if self._ai_ok else '') + '</td></tr>'
            for x in ds)
        return f"""{kq}<div class="the"><h2>Khách nợ quá 30 ngày</h2>
<form method="get" class="ngang"><label>Tính đến ngày<input type="date" name="ngay" value="{e(ngay)}"></label><button class="phu">Xem</button></form>
<div class="cuon"><table><tr><th>Khách hàng</th><th class="s">Còn nợ</th><th class="s">0–30</th><th class="s">31–60</th><th class="s">61–90</th>
<th class="s">Trên 90</th><th class="s">Lâu nhất</th><th></th></tr>{dong or '<tr><td colspan="8" class="ok">Không có khách nợ quá 30 ngày.</td></tr>'}</table></div>
<p class="mo">Tuổi nợ tính theo nguyên tắc phát sinh trước trả trước. AI soạn tin Zalo và email nhắc thanh toán; không tự gửi.</p></div>"""
