"""Ham dung chung cho giao dien: dinh dang so, ngay, khung trang (thanh ben, the, bang, nut)."""
import html
import os
import re
import threading
from datetime import date, datetime
from pathlib import Path

from . import PHIEN_BAN, thuong_hieu

TEN_UNG_DUNG = "iFix Kế toán"
TEN_UNG_DUNG_HTML = '<b class="ten-ud"><em>iFix</em> Kế toán</b>'

THU_MUC_DL = Path(os.environ.get("KETOAN_DULIEU", Path(__file__).resolve().parent.parent / "du_lieu"))

# Thong tin cua yeu cau dang xu ly (duong dan, nguoi dung) de to dam muc menu dang chon
HIEN_TAI = threading.local()

e = lambda s: html.escape("" if s is None else str(s))


def so(v):
    return f"{v:,.0f}".replace(",", ".") if v else ""


def ngay_vn(s):
    try:
        return datetime.strptime(s[:10], "%Y-%m-%d").strftime("%d/%m/%Y") if s else ""
    except ValueError:
        return ""


CSS = """
:root{--nen:#f3f5f8;--the:#fff;--chu:#17202c;--mo:#647084;--vien:#e1e5ec;--vien2:#cfd6e0;
--nhan:#1d4f91;--nhan2:#163e73;--nhan-nhat:#e8f0fb;--do:#b42318;--do-nhat:#fdecea;--xanh:#18794e;--xanh-nhat:#e6f4ec;
--vang:#9a6700;--vang-nhat:#fff6dd;--ben:#0f1c2e;--ben2:#1a2a40;--ben-chu:#aebbd0;--bo:10px;
--bong:0 1px 2px rgba(16,24,40,.06),0 1px 3px rgba(16,24,40,.08)}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;font:14.5px/1.5 "Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif;background:var(--nen);color:var(--chu)}
a{color:var(--nhan)}a:hover{color:var(--nhan2)}
.khung{display:grid;grid-template-columns:248px minmax(0,1fr);min-height:100vh}
.ben{background:var(--ben);color:var(--ben-chu);position:sticky;top:0;height:100vh;overflow-y:auto;display:flex;flex-direction:column}
.logo{display:flex;align-items:center;gap:10px;padding:18px 18px 14px;color:#fff;text-decoration:none;font-weight:650;font-size:16px;letter-spacing:.2px}
.logo i{width:30px;height:30px;border-radius:8px;background:linear-gradient(135deg,#3b82f6,#1d4f91);display:grid;place-items:center;font-style:normal;font-size:15px}
.logo:hover{color:#fff}
.cty{margin:0 12px 10px;padding:10px 12px;background:var(--ben2);border-radius:8px;color:#e6ecf5;font-size:13px;line-height:1.35}
.cty b{display:block;font-weight:600;color:#fff;margin-bottom:3px}.cty a{color:#8fb3ff;font-size:12px;text-decoration:none}
.ben nav{padding:4px 10px 16px;flex:1}
.ben h4{margin:12px 10px 3px;font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#6f7f97;font-weight:600}
.ben nav a{display:flex;align-items:center;gap:10px;padding:6px 10px;border-radius:7px;color:var(--ben-chu);text-decoration:none;font-size:13.5px;margin:1px 0}
.ben nav a:hover{background:var(--ben2);color:#fff}
.ben nav a.dang{background:#24406a;color:#fff;font-weight:600;box-shadow:inset 3px 0 0 #5b9bff}.ben nav a.dang .ic{opacity:1;color:#8fb3ff}
.bq{padding:9px 28px;font-size:13.5px;border-bottom:1px solid var(--vien,#e3e8ef)}.bq.vang{background:#fff6dd;color:#7a5200}
.bq.do{background:#fdecea;color:#a1261b;font-weight:600}.bq a{margin-left:8px;font-weight:600;color:inherit}
.ma-may{font:600 22px/1.2 ui-monospace,Consolas,monospace;letter-spacing:.06em;padding:10px 14px;background:#f3f6fa;border-radius:8px;display:inline-block}
.chan{padding:12px 18px 16px;border-top:1px solid #1f3049;font-size:12.5px;color:#7d8ba1}
.chan a{color:#aebbd0;text-decoration:none}.chan a:hover{color:#fff}
.dau{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:11px 28px;min-height:56px;background:var(--the);border-bottom:1px solid var(--vien);position:sticky;top:0;z-index:5}
.dau .phai{color:var(--mo);font-size:13px;display:flex;gap:14px;align-items:center}
main{padding:22px 28px 40px;max-width:1480px}
.the{background:var(--the);border:1px solid var(--vien);border-radius:var(--bo);padding:18px 20px;margin-bottom:18px;box-shadow:var(--bong)}
h1{font-size:20px;margin:0 0 12px;font-weight:650;letter-spacing:-.01em}
h2{font-size:16px;margin:0 0 10px;font-weight:650}
h3{font-size:14.5px;margin:14px 0 8px;font-weight:650}
p{margin:8px 0}
.cuon{overflow-x:auto;margin:8px 0;border:1px solid var(--vien);border-radius:8px;background:var(--the)}
table{border-collapse:separate;border-spacing:0;width:100%;background:var(--the);font-size:13.5px}
th,td{border-bottom:1px solid var(--vien);padding:7px 10px;vertical-align:top;text-align:left}
tr:last-child td{border-bottom:0}
th{background:#f7f8fa;font-weight:600;color:#3b4656;white-space:nowrap;font-size:12.5px;border-bottom:1px solid var(--vien2)}
table tr:hover td{background:#fafbfd}
td.s,th.s{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
tr.c1 td{font-weight:600;background:#f9fafb}
tr.tong td{font-weight:700;background:#eef3fa;border-top:1px solid var(--vien2)}
input,select,textarea{font:inherit;padding:7px 9px;border:1px solid var(--vien2);border-radius:7px;background:#fff;color:var(--chu);max-width:100%}
input:focus,select:focus,textarea:focus{outline:2px solid #bcd3f5;border-color:var(--nhan)}
input[type=checkbox],input[type=radio]{width:16px;height:16px;padding:0;vertical-align:middle;accent-color:var(--nhan)}
td input,td select{padding:4px 6px}
button,.nut{font:inherit;font-weight:600;background:var(--nhan);color:#fff;border:1px solid var(--nhan);border-radius:7px;padding:7px 15px;
cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px;line-height:1.3;white-space:nowrap}
button:hover,.nut:hover{background:var(--nhan2);color:#fff}
.nut.phu,button.phu{background:#fff;color:var(--nhan);border-color:var(--vien2)}
.nut.phu:hover,button.phu:hover{background:var(--nhan-nhat);color:var(--nhan2)}
.nut.nguy,button.nguy{background:#fff;color:var(--do);border-color:#f1b5ae}.nut.nguy:hover,button.nguy:hover{background:var(--do-nhat)}
.nut.nho,button.nho{padding:4px 10px;font-size:13px}
form.ngang,.ngang{display:flex;gap:10px;flex-wrap:wrap;align-items:end}
label{display:flex;flex-direction:column;font-size:12.5px;color:var(--mo);gap:4px;font-weight:500}
label.chon{flex-direction:row;align-items:center;gap:7px;color:var(--chu);font-size:14px}
p.loi,div.loi,p.ok,div.ok,p.bao,div.bao{padding:9px 12px;border-radius:8px;margin:8px 0}
p.loi,div.loi{background:var(--do-nhat);color:var(--do);border:1px solid #f6c9c3}
p.ok,div.ok{background:var(--xanh-nhat);color:var(--xanh);border:1px solid #bfe3cf}
p.bao,div.bao{background:var(--vang-nhat);color:var(--vang);border:1px solid #f2dc9b}
span.loi,td.loi{color:var(--do)}span.ok,td.ok{color:var(--xanh)}
.the.loi{background:var(--the);color:var(--chu);border:1px solid #f6c9c3}
.mo{color:var(--mo)}
.luoi{display:grid;grid-template-columns:repeat(auto-fit,minmax(175px,1fr));gap:14px;margin-bottom:18px}
.o{background:var(--the);border:1px solid var(--vien);border-radius:var(--bo);padding:14px 16px;box-shadow:var(--bong)}
.o .nhan{font-size:12.5px;color:var(--mo);font-weight:500}
.chiso{font-size:22px;font-weight:650;font-variant-numeric:tabular-nums;letter-spacing:-.01em;margin-top:2px}
.o .phu{font-size:12.5px;color:var(--mo);margin-top:2px}
.tab{display:flex;gap:4px;border-bottom:1px solid var(--vien);margin:0 0 14px;flex-wrap:wrap}
.tab a{padding:8px 14px;text-decoration:none;color:var(--mo);border-bottom:2px solid transparent;margin-bottom:-1px;font-weight:500}
.tab a:hover{color:var(--chu)}.tab a.dang{color:var(--nhan);border-bottom-color:var(--nhan);font-weight:600}
.nhan-tt{display:inline-block;padding:1px 8px;border-radius:999px;font-size:12px;font-weight:600;background:#eef1f5;color:#475467;white-space:nowrap}
.nhan-tt.do{background:var(--do-nhat);color:var(--do)}.nhan-tt.vang{background:var(--vang-nhat);color:var(--vang)}
.nhan-tt.xanh{background:var(--xanh-nhat);color:var(--xanh)}.nhan-tt.lam{background:var(--nhan-nhat);color:var(--nhan)}
ul.viec{list-style:none;padding:0;margin:0}ul.viec li{display:flex;gap:10px;align-items:flex-start;padding:9px 2px;border-bottom:1px solid var(--vien)}
ul.viec li:last-child{border-bottom:0}ul.viec li a{margin-left:auto;white-space:nowrap;font-size:13px}
.cham{width:9px;height:9px;border-radius:50%;margin-top:6px;flex:none}.cham.do{background:#d92d20}.cham.vang{background:#e0a100}.cham.xanh{background:#12b76a}
pre{white-space:pre-wrap;background:#f7f8fa;border:1px solid var(--vien);border-radius:8px;padding:10px;font-size:13px}
details>summary{cursor:pointer;font-weight:600;color:var(--nhan)}
.menu-mo{display:none}
.ic{flex:none;opacity:.85}
.logo span{display:flex;flex-direction:column;line-height:1.15}.logo small{font-size:11px;font-weight:500;color:#7d8ba1;letter-spacing:.02em;margin-top:2px}
.cty{display:block;text-decoration:none}.cty .ten{display:block;font-weight:600;color:#fff;font-size:12.5px;line-height:1.35;margin-bottom:4px}
.cty .doi{color:#8fb3ff;font-size:12px}.cty:hover{background:#22344f}
.hotro{margin-top:8px;color:#9fb0c8;display:flex;flex-direction:column;gap:6px}.hotro b{color:#fff;font-weight:600;letter-spacing:.02em}
.ds-lh{display:flex;gap:6px;flex-wrap:wrap}.ds-lh:empty{display:none}
a.lh{display:inline-flex;align-items:center;gap:5px;font-size:11.5px;font-weight:600;padding:3px 10px 3px 7px;border-radius:999px;text-decoration:none;color:#fff;background:#2a3b55}
a.lh.zalo{background:#0068ff}a.lh.facebook{background:#1877f2}a.lh.tiktok{background:#111;border:1px solid #444}a.lh:hover{filter:brightness(1.12);color:#fff}
.hotro.lon{color:var(--chu);font-size:14px}.hotro.lon b{color:var(--chu);font-size:16px}.hotro.lon a.lh{font-size:13px;padding:5px 14px}
.dau .tieu{display:flex;align-items:center;gap:8px;min-width:0;flex-wrap:wrap}
.vet{font-size:13px;color:var(--mo);white-space:nowrap;max-width:320px;overflow:hidden;text-overflow:ellipsis}
.vet a{color:var(--mo);text-decoration:none}.vet a:hover{color:var(--nhan)}
.vet::after{content:"/";margin-left:8px;color:var(--vien2)}
.ten-trang{font-size:16.5px;margin:0;font-weight:650}
.ai{display:inline-flex;align-items:center;gap:8px;color:var(--chu);font-weight:500}
.ai b{width:26px;height:26px;border-radius:50%;background:var(--nhan-nhat);color:var(--nhan);display:grid;place-items:center;font-size:12px}
.nut.tat:hover{color:var(--do);border-color:#f1b5ae;background:var(--do-nhat)}
td.rong{text-align:center;color:var(--mo);padding:22px 10px;font-style:italic}
td input:not([type=checkbox]):not([type=radio]),td select{width:100%;min-width:70px}
input[type=file]{padding:5px;background:#f7f8fa}
input[type=file]::file-selector-button{font:inherit;font-weight:600;font-size:13px;border:1px solid var(--vien2);background:#fff;color:var(--nhan);
border-radius:6px;padding:4px 12px;margin-right:10px;cursor:pointer}
button.dang-chay{opacity:.65;cursor:progress}
.o{position:relative;overflow:hidden}.o::before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--nhan);opacity:.75}
.o .phu a{text-decoration:none;font-weight:500}.o .phu a:hover{text-decoration:underline}
.chiso{font-size:clamp(17px,1.55vw,22px)}
.bieu-do{width:100%;height:auto;display:block}.bieu-do .truc{font-size:12px;fill:#8a94a6}.bieu-do .luoi-bd{stroke:#eef0f4}
.bieu-do .cham-bd{fill:transparent}.bieu-do .cham-bd:hover{fill:rgba(29,79,145,.06)}
.chu-giai{display:flex;gap:16px;flex-wrap:wrap;font-size:12.5px;color:#3b4656;margin-bottom:6px;align-items:center}
.chu-giai i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}
.chu-giai .mo{margin-left:auto}
.nho-chu{font-size:12.5px}
.logo i.chip{background:none;width:38px;height:38px;border-radius:0}.logo i.chip svg{width:38px;height:38px;display:block}
.nha-pt svg{width:150px;height:auto;display:block;margin:10px 0 2px -4px}
.logo-sang svg{width:240px;height:auto;display:block;margin:4px 0 10px}
table.kv th{width:200px;background:#f7f8fa}
td.g,th.g{text-align:center}
.dong-nut{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}
.hai-cot{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:18px}

/* ===== Giao dien iFix Ke toan (phan he) ===== */
:root{--nen:#f3f6fb;--vien:#e3e8f0;--vien2:#d3dbe7;--nhan:#1e56c8;--nhan2:#1846a6;--nhan-nhat:#eaf1fd;--bo:14px;
--ben:#0a1730;--ben2:#13254a;--ben-chu:#b5c3da;--bong:0 1px 2px rgba(15,23,42,.04),0 4px 14px rgba(15,23,42,.05);--bong2:0 10px 30px rgba(15,23,42,.10)}
body{font-size:14.5px;background:var(--nen)}
.khung{grid-template-columns:252px minmax(0,1fr)}
.ben{background:linear-gradient(180deg,#0b1a36 0%,#0a1730 55%,#081226 100%);border-right:1px solid #0d1d3b}
.logo{padding:18px 18px 16px;gap:11px}
.logo .ten-ud{font-size:17.5px;font-weight:700;color:#fff;letter-spacing:-.01em}.logo .ten-ud em{font-style:normal;color:#60a5fa}
.logo small{font-size:11px;color:#7f90ad}
.cty{display:flex!important;gap:10px;align-items:center;margin:0 14px 8px;padding:10px 12px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:11px;color:#cbd7ea}
.cty .ic{color:#60a5fa;opacity:1}.cty>span{min-width:0}.cty .ten{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:1px}
.cty:hover{background:rgba(255,255,255,.1)}
.ben nav{padding:4px 12px 14px}
.ben h4{margin:14px 8px 6px;font-size:10.5px;color:#5d7090;letter-spacing:.12em}
.ben nav a.ph{padding:6px 8px;gap:11px;border-radius:9px;font-size:13.8px;color:#c3cfe2;margin:2px 0;transition:background .12s}
.ben nav a.ph i{width:28px;height:28px;border-radius:8px;display:grid;place-items:center;flex:none;font-style:normal;
background:color-mix(in srgb,var(--m) 22%,transparent);color:color-mix(in srgb,var(--m) 45%,#fff)}
.ben nav a.ph i .ic{opacity:1}
.ben nav a.ph:hover{background:rgba(255,255,255,.06);color:#fff}
.ben nav a.ph.dang{background:rgba(96,165,250,.14);color:#fff;font-weight:600;box-shadow:inset 3px 0 0 var(--m)}
.ben nav a.ph.dang i{background:var(--m);color:#fff;box-shadow:0 4px 12px color-mix(in srgb,var(--m) 45%,transparent)}
.chan{border-top:1px solid rgba(255,255,255,.07);padding:12px 16px 16px}
.chan-link{display:flex;flex-direction:column;gap:5px;margin-bottom:10px}.chan-link a{display:flex;gap:8px;align-items:center;font-size:12.5px}
.dau{padding:10px 26px;min-height:60px;background:rgba(255,255,255,.92);backdrop-filter:saturate(1.4) blur(8px)}
.dau .phai{gap:10px}
.vet{font-size:12.5px}.ten-trang{font-size:17px;letter-spacing:-.01em}
form.tim{display:flex;align-items:center;gap:8px;background:#f1f4f9;border:1px solid var(--vien);border-radius:10px;padding:0 10px;height:36px;width:300px}
form.tim .ic{color:#8a96ab}form.tim input{border:0;background:transparent;padding:0;height:34px;width:100%;outline:0;font-size:13.5px}
form.tim:focus-within{border-color:var(--nhan);background:#fff;box-shadow:0 0 0 3px #d9e6fb}
details.tao-moi{position:relative}details.tao-moi summary{list-style:none;cursor:pointer}details.tao-moi summary::-webkit-details-marker{display:none}
.tm-ds{position:absolute;right:0;top:calc(100% + 6px);background:#fff;border:1px solid var(--vien);border-radius:12px;box-shadow:var(--bong2);padding:6px;min-width:250px;z-index:20}
.tm-ds a{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;color:var(--chu);text-decoration:none;font-size:13.5px}
.tm-ds a .ic{color:var(--nhan)}.tm-ds a:hover{background:var(--nhan-nhat)}
.ai b{background:linear-gradient(135deg,#3b82f6,#1e40af);color:#fff}
.nut.xanh-la{background:#16a34a;border-color:#16a34a}
.thanh-ph{display:flex;align-items:center;gap:16px;padding:0 26px;background:#fff;border-bottom:1px solid var(--vien);min-height:46px;overflow-x:auto}
.thanh-ph .ten-ph{display:flex;align-items:center;gap:8px;font-weight:650;font-size:13.5px;white-space:nowrap;padding-right:16px;border-right:1px solid var(--vien)}
.thanh-ph .ten-ph i{width:26px;height:26px;border-radius:7px;display:grid;place-items:center;background:var(--m);color:#fff;font-style:normal}
.thanh-ph nav{display:flex;gap:2px;align-self:stretch}
.thanh-ph nav a{display:flex;align-items:center;gap:6px;padding:0 12px;color:var(--mo);text-decoration:none;font-size:13.5px;font-weight:500;white-space:nowrap;border-bottom:2px solid transparent}
.thanh-ph nav a:hover{color:var(--chu);background:#f7f9fc}
.thanh-ph nav a.dang{color:var(--m);border-bottom-color:var(--m);font-weight:650}
main{padding:22px 26px 44px}
.the{border-radius:var(--bo);padding:20px 22px;border-color:#e6ebf2}
h1{font-size:19px}h2{font-size:15.5px}
.cuon{border-radius:12px;box-shadow:var(--bong)}
th{background:#f6f8fb;color:#4a5568;text-transform:none}
button,.nut{border-radius:9px;transition:background .12s,box-shadow .12s}
button:hover,.nut:hover{box-shadow:0 2px 8px rgba(30,86,200,.25)}
.nut.phu:hover,button.phu:hover{box-shadow:none}
input,select,textarea{border-radius:9px}
.tab a.dang{color:var(--nhan)}
.o{border-radius:var(--bo);padding:16px 18px}
.o::before{display:none}
/* the chi so co icon */
.kpi{display:flex;gap:14px;align-items:flex-start;background:#fff;border:1px solid #e6ebf2;border-radius:var(--bo);padding:16px 18px;box-shadow:var(--bong);min-width:0}
.kpi>i{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;flex:none;font-style:normal;background:color-mix(in srgb,var(--m) 13%,#fff);color:var(--m)}
.kpi>i .ic{opacity:1}.kpi>div{min-width:0}
.kpi .nhan{font-size:12.5px;color:var(--mo);font-weight:500}.kpi .chiso{margin-top:1px}
.kpi .phu{font-size:12.5px;color:var(--mo);margin-top:3px}.kpi .phu a{text-decoration:none;font-weight:500}
/* bang dieu khien */
.bia{position:relative;overflow:hidden;border-radius:18px;padding:24px 28px;margin-bottom:18px;color:#fff;
background:radial-gradient(1200px 300px at 90% -40%,rgba(96,165,250,.55),transparent 60%),linear-gradient(120deg,#0b1f4a 0%,#1e40af 60%,#2563eb 100%);
display:flex;gap:20px;align-items:center;justify-content:space-between;flex-wrap:wrap;box-shadow:0 12px 30px rgba(30,64,175,.25)}
.bia::after{content:"";position:absolute;right:-60px;bottom:-90px;width:300px;height:300px;border-radius:50%;border:40px solid rgba(255,255,255,.05)}
.bia h1{font-size:22px;margin:2px 0 8px;color:#fff}.bia .chao{font-size:13px;color:#bcd0f5}
.bia .chip-ds{display:flex;gap:8px;flex-wrap:wrap}
.bia .chip{font-size:12.5px;padding:4px 10px;border-radius:999px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.16);color:#e7efff}
.bia .dong-nut{position:relative;z-index:1;margin:0}
.bia .nut{background:#fff;color:#1e40af;border-color:#fff}.bia .nut:hover{background:#eaf1fd}
.bia .nut.phu{background:rgba(255,255,255,.1);color:#fff;border-color:rgba(255,255,255,.3)}.bia .nut.phu:hover{background:rgba(255,255,255,.2)}
.luoi-kpi{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-bottom:18px}
.luoi-cty{display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:14px;margin-bottom:18px}
.the-cty{background:#fff;border:1px solid #e6ebf2;border-radius:var(--bo);padding:18px;box-shadow:var(--bong);display:flex;flex-direction:column;gap:10px}
.the-cty:hover{border-color:#bcd0f2;box-shadow:var(--bong2)}
a.tc-dau{display:flex;gap:12px;align-items:center;text-decoration:none;color:var(--chu)}
a.tc-dau i{width:44px;height:44px;border-radius:12px;display:grid;place-items:center;flex:none;font-style:normal;font-weight:700;color:#fff;background:linear-gradient(135deg,#3b82f6,#1e40af)}
a.tc-dau b{display:block;font-size:14.5px;line-height:1.3}a.tc-dau small{display:block;color:var(--mo);font-size:12.5px;margin-top:2px}
.tc-tt{display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:12.5px}.tc-viec{margin:0;font-size:13.5px;color:#3b4656;min-height:20px}
.the-cty .dong-nut{margin:auto 0 0}
ul.sk{list-style:none;margin:0;padding:0}ul.sk li{padding:10px 0;border-bottom:1px solid var(--vien)}ul.sk li:last-child{border-bottom:0}
.sk-dau{display:flex;align-items:center;gap:10px}.sk-dau>span:first-child{flex:1;font-weight:550;font-size:13.5px}
.sk-dau small{display:block;font-weight:400;color:var(--mo);font-size:12px}.sk-dau b{font-variant-numeric:tabular-nums;font-size:15px}
.sk-thanh{height:6px;background:#eef1f6;border-radius:99px;margin-top:7px;overflow:hidden}
.sk-thanh i{display:block;height:100%;border-radius:99px;background:#16a34a}.sk-thanh i.vang{background:#f59e0b}.sk-thanh i.do{background:#dc2626}
.bd-hai{display:grid;grid-template-columns:minmax(0,1.9fr) minmax(300px,1fr);gap:18px}
.the h2 .phu-h{float:right;font-size:12.5px;font-weight:500}
/* so do quy trinh */
.so-do{display:flex;align-items:stretch;gap:0;overflow-x:auto;padding:6px 2px 4px}
.sd-cot{position:relative;display:flex;flex-direction:column;gap:10px;justify-content:center;flex:1 1 0;min-width:150px;padding-top:12px}
.sd-so{position:absolute;top:-4px;left:50%;transform:translateX(-50%);font-size:11px;font-weight:700;color:#8a96ab;background:#fff;padding:0 6px}
.sd-mui{flex:0 0 34px;position:relative;align-self:center;height:2px;background:linear-gradient(90deg,#c7d4ea,#93b1e6);margin-top:12px}
.sd-mui::after{content:"";position:absolute;right:-1px;top:-5px;border:6px solid transparent;border-left:8px solid #93b1e6;border-right:0}
.sd-buoc{position:relative;display:flex;flex-direction:column;align-items:center;text-align:center;gap:3px;padding:14px 10px 12px;border-radius:14px;
background:#fff;border:1px solid #dfe6f1;text-decoration:none;color:var(--chu);box-shadow:var(--bong);transition:transform .12s,box-shadow .12s,border-color .12s}
a.sd-buoc:hover{transform:translateY(-2px);box-shadow:var(--bong2);border-color:#9dbcf0;color:var(--chu)}
.sd-buoc .sd-ic{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;background:color-mix(in srgb,var(--m,#2563eb) 12%,#fff);color:var(--m,#2563eb);margin-bottom:4px}
.sd-buoc .sd-ic .ic{opacity:1}
.sd-buoc b{font-size:13.5px;font-weight:650;line-height:1.25}.sd-buoc small{font-size:12px;color:var(--mo);line-height:1.3}
.sd-buoc.ngoai{background:repeating-linear-gradient(135deg,#fafbfd,#fafbfd 8px,#f3f5f9 8px,#f3f5f9 16px);border-style:dashed;box-shadow:none}
.sd-buoc.ngoai .sd-ic,.sd-buoc.khoa .sd-ic{background:#eef1f6;color:#64748b}
.sd-buoc.khoa{opacity:.55;box-shadow:none;cursor:not-allowed}
.sd-dem{position:absolute;top:-8px;right:-6px;font-size:11.5px;font-weight:700;padding:1px 8px;border-radius:999px;background:var(--nhan);color:#fff;box-shadow:0 2px 6px rgba(0,0,0,.15)}
.sd-dem.vang{background:#f59e0b}.sd-dem.do{background:#dc2626}.sd-dem.xanh{background:#16a34a}
.chu-thich-sd{display:flex;gap:16px;flex-wrap:wrap;font-size:12px;color:var(--mo);margin-top:10px}
.chu-thich-sd span{display:inline-flex;align-items:center;gap:6px}.chu-thich-sd i{width:14px;height:10px;border-radius:3px;border:1px solid #cfd8e6;background:#fff}
.chu-thich-sd i.ngoai{border-style:dashed;background:#f3f5f9}
/* luoi phan he */
.luoi-ph{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:12px}
a.o-ph{display:flex;gap:12px;align-items:flex-start;padding:14px;border-radius:14px;border:1px solid #e6ebf2;background:#fff;text-decoration:none;color:var(--chu);transition:border-color .12s,box-shadow .12s,transform .12s}
a.o-ph:hover{border-color:color-mix(in srgb,var(--m) 45%,#fff);box-shadow:var(--bong2);transform:translateY(-1px);color:var(--chu)}
a.o-ph i{width:40px;height:40px;border-radius:11px;display:grid;place-items:center;flex:none;background:var(--m);color:#fff;font-style:normal;box-shadow:0 6px 14px color-mix(in srgb,var(--m) 35%,transparent)}
a.o-ph i .ic{opacity:1}a.o-ph b{display:block;font-size:14px}a.o-ph small{display:block;color:var(--mo);font-size:12.5px;line-height:1.35;margin-top:2px}
/* trang phan he */
.dau-ph{display:flex;gap:16px;align-items:center;margin-bottom:18px;padding:20px 22px;border-radius:16px;background:linear-gradient(120deg,color-mix(in srgb,var(--m) 10%,#fff),#fff 70%);border:1px solid color-mix(in srgb,var(--m) 20%,#e6ebf2)}
.dau-ph>i{width:54px;height:54px;border-radius:15px;display:grid;place-items:center;background:var(--m);color:#fff;font-style:normal;flex:none;box-shadow:0 8px 20px color-mix(in srgb,var(--m) 35%,transparent)}
.dau-ph>i .ic{opacity:1}.dau-ph h1{margin:0 0 4px;font-size:21px}.dau-ph p{margin:0;color:var(--mo)}
.so-do-ph .sd-buoc{--m:var(--mph)}
.cn-ds{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px}
.cn-ds a{display:flex;align-items:center;gap:10px;padding:12px 14px;border:1px solid #e6ebf2;border-radius:12px;text-decoration:none;color:var(--chu);font-weight:550;background:#fff}
.cn-ds a:hover{border-color:var(--m);color:var(--m)}.cn-ds a::after{content:"→";margin-left:auto;color:#a0aec0}
@media (max-width:1200px){.bd-hai{grid-template-columns:minmax(0,1fr)}form.tim{width:220px}.luoi-kpi{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:900px){
 .khung{grid-template-columns:minmax(0,1fr)}
 form.tim,.ten-nd{display:none}
 .thanh-ph{padding:0 12px}.dau{padding:10px 14px}
 .sd-cot{min-width:130px}
 .bia{padding:18px}
}
@media (max-width:600px){.luoi-kpi{grid-template-columns:minmax(0,1fr)}}
@media print{.thanh-ph,.tao-moi,form.tim{display:none!important}}
@media (max-width:900px){
 .khung{grid-template-columns:minmax(0,1fr)}
 .ben{position:relative;height:auto}
 .ben nav,.ben .chan{display:none}
 #mo-menu:checked~.khung .ben nav,#mo-menu:checked~.khung .ben .chan{display:block}
 .menu-mo{display:block;position:absolute;right:16px;top:16px;color:#fff;font-size:22px;cursor:pointer}
 main{padding:16px}
 .dau{padding:12px 16px;position:static}
 .the{padding:14px}
 .hai-cot{grid-template-columns:minmax(0,1fr)}
 .luoi{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
 .chiso{font-size:18px}
}
@media print{
 .ben,.dau,.khong-in,button,.nut,form.ngang{display:none!important}
 .khung{display:block}main{padding:0;max-width:none}
 .the{border:0;box-shadow:none;padding:0}
 body{background:#fff;font-size:12.5px}
 .cuon{border:0;overflow:visible}
}
"""

def _menu():
    from . import phan_he
    return [(ph["ten"], ph["chuc_nang"]) for ph in phan_he.PHAN_HE]


# Giu ten MENU cho code cu: (nhom, [(duong dan, nhan)]) lay tu cac phan he
MENU = _menu()


def muc_duoc_dung(u):
    """Muc menu (duong dan '/luong'...) hoac muc bao cao ('bc:bctc') co trong goi ban quyen va che do ke toan
    cua cong ty dang xem khong."""
    from . import ban_quyen, che_do
    cd = getattr(HIEN_TAI, "che_do", None)
    if cd:
        if u.startswith("bc:") and not che_do.co_bao_cao(cd, u[3:]):
            return False
        if u == "/sochedo" and cd not in che_do.SO:
            return False
    bq = getattr(HIEN_TAI, "ban_quyen", None)
    return bq is None or ban_quyen.duoc_dung(bq, u.strip("/").split("/")[0] if not u.startswith("bc:") else u)


def muc_bao_cao_dau():
    """Muc bao cao mac dinh: muc dau tien duoc dung theo che do va goi."""
    from .trang_bao_cao import MUC
    return next((m for m, _ in MUC if muc_duoc_dung("bc:" + m)), "mau")


def _dang_chon(cid, u):
    duong = (getattr(HIEN_TAI, "duong", "") or "").split("?")[0].rstrip("/")
    goc = f"/cty/{cid}"
    if u == "":
        return duong == goc
    if u == "/chungtu":
        return duong.startswith(goc + "/chungtu") and not duong.startswith(goc + "/chungtu/moi")
    return duong == goc + u or duong.startswith(goc + u + "/")


_BANG = re.compile(r"<table.*?</table>", re.S)


def _boc_bang(s):
    """Boc moi bang chua co khung cuon (de cuon ngang tren man hinh nho)."""
    def boc(m):
        truoc = s[max(0, m.start() - 40):m.start()]
        return m.group(0) if 'class="cuon"' in truoc else f'<div class="cuon">{m.group(0)}</div>'
    return _BANG.sub(boc, s)


_ICON = {
    "": '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
    "/viec": '<path d="M9 11l3 3L21 5"/><path d="M20 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
    "/chungtu/moi": '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M12 12v6M9 15h6"/>',
    "/chungtu": '<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
    "/hoadon": '<path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
    "/nganhang": '<path d="M3 10h18L12 4z"/><path d="M5.5 10v8M10 10v8M14 10v8M18.5 10v8M3 21h18"/>',
    "/doituong": '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.6a6.5 6.5 0 0 1 3.5 5.4"/>',
    "/kho": '<path d="M21 8l-9-5-9 5 9 5z"/><path d="M3 8v8l9 5 9-5V8M12 13v8"/>',
    "/luong": '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M3 10h18M16 15h2M7 3h10"/>',
    "/taisan": '<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M9 7h2M13 7h2M9 11h2M13 11h2M10 21v-4h4v4"/>',
    "/sochedo": '<path d="M4 4h12a4 4 0 0 1 4 4v12H8a4 4 0 0 1-4-4z"/><path d="M8 9h8M8 13h8M8 17h5"/>',
    "/hopdong": '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17l2 1 2-2 2 2 2-1"/>',
    "/giathanh": '<path d="M4 20V10l5-4 5 4v10"/><path d="M14 20v-6h6v6M9 20v-4"/><circle cx="18" cy="6" r="2.5"/>',
    "/vay": '<path d="M3 7h18v12H3z"/><path d="M3 11h18M7 15h3M16 4l-4 3-4-3"/>',
    "/so": '<path d="M4 19.5V5a2 2 0 0 1 2-2h14v16H6.5A2.5 2.5 0 0 0 4 21.5 2.5 2.5 0 0 0 6.5 24"/><path d="M8 7h8M8 11h6"/>',
    "/congno": '<path d="M7 4v16M3 8l4-4 4 4M17 20V4M13 16l4 4 4-4"/>',
    "/socai": '<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2zM22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/>',
    "/nkc": '<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M8 2v4M16 2v4M3 10h18M7 14h10M7 17h6"/>',
    "/cdtk": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M12 3v18"/>',
    "/baocao": '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 18v-3M12 18v-6M16 18v-4"/>',
    "/luuchuyen": '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
    "/doichieu": '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.8 2.8L16 9.5"/>',
    "/khoaso": '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    "/nhap-misa": '<path d="M12 15V3M7 8l5-5 5 5"/><path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"/>',
    "/caidat": '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
    "cong_ty": '<path d="M3 21h18M5 21V7l7-4 7 4v14M9.5 9h1M13.5 9h1M9.5 13h1M13.5 13h1M9.5 17h1M13.5 17h1"/>',
    "tat": '<path d="M12 3v9"/><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/>',
    "tien": '<rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 9.5v5M18 9.5v5"/>',
    "thu": '<path d="M12 4v12M7 11l5 5 5-5"/><path d="M4 20h16"/>',
    "chi": '<path d="M12 20V8M7 13l5-5 5 5"/><path d="M4 4h16"/>',
    "mua": '<circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M2.5 3.5h3l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.5L21.5 8H6.6"/>',
    "ban": '<path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1.3"/>',
    "thue": '<path d="M6 3h12v18l-3-1.8-3 1.8-3-1.8L6 21z"/><path d="M9.5 14.5l5-5M9.7 9.7h.01M14.3 14.3h.01"/>',
    "viec": '<path d="M9 4h6v3H9z"/><path d="M15 5.5h2.5a1.5 1.5 0 0 1 1.5 1.5v12.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 19.5V7a1.5 1.5 0 0 1 1.5-1.5H9"/><path d="M9 12h6M9 16h4"/>',
    "in": '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
    "tai": '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"/>',
    "nap": '<path d="M12 15V3M7 8l5-5 5 5"/><path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"/>',
    "ghi": '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    "tinh": '<rect x="4" y="2.5" width="16" height="19" rx="2"/><path d="M8 6.5h8v3H8zM8 13h.01M12 13h.01M16 13h.01M8 17h.01M12 17h.01M16 17h.01"/>',
    "ai": '<path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
    "xml": '<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M13.5 5l-3 14"/>',
    "gui": '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
    "tim": '<circle cx="11" cy="11" r="7"/><path d="M20.5 20.5L16 16"/>',
    "cong": '<path d="M12 5v14M5 12h14"/>',
    "quy-trinh": '<rect x="2.5" y="9" width="5" height="6" rx="1.2"/><rect x="16.5" y="3" width="5" height="6" rx="1.2"/><rect x="16.5" y="15" width="5" height="6" rx="1.2"/><path d="M7.5 12H12M12 6v12M12 6h4.5M12 18h4.5"/>',
    "khoa": '<circle cx="7.5" cy="15.5" r="4.5"/><path d="M10.7 12.3L20 3M16 7l3 3M18 5l2 2"/>',
}


def icon(ten, co=18):
    return (f'<svg class="ic" width="{co}" height="{co}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" '
            f'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{_ICON.get(ten, "")}</svg>')


FAVICON = ("data:image/svg+xml," + "%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' "
           "fill='%231d4f91'/%3E%3Ctext x='16' y='23' font-size='20' font-family='Arial' font-weight='700' fill='white' "
           "text-anchor='middle'%3E%E2%82%AB%3C/text%3E%3C/svg%3E")

_JS = """<script>
document.querySelectorAll('main table').forEach(function(t){
  if(t.rows.length===1&&t.rows[0].querySelector('th')){var r=t.insertRow(),c=r.insertCell();
  c.colSpan=t.rows[0].cells.length;c.className='rong';c.textContent='Chưa có dữ liệu trong kỳ này.';}});
document.querySelectorAll('form').forEach(function(f){f.addEventListener('submit',function(){
  var b=f.querySelector('button:not([type=button])');if(b&&f.method==='post'){setTimeout(function(){b.disabled=true;b.classList.add('dang-chay');},0);}});});
</script>"""


_SVG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">{}</svg>'
_LOGO_MXH = {
    "zalo": _SVG.format('<path d="M12 3C6.5 3 2 6.8 2 11.5c0 2.6 1.4 4.9 3.6 6.5L5 21.5l3.9-1.9c1 .3 2 .4 3.1.4 5.5 0 10-3.8 10-8.5S17.5 3 12 3z"/>'
                        '<path fill="#0068ff" d="M7.2 9h4.3v1.1l-2.8 3.4h2.9V15H7v-1.1l2.8-3.4H7.2zM12.6 9h1.3v6h-1.3zM15 11h1.3v.6c.3-.5.8-.7 1.3-.7 1.1 0 1.9.9 1.9 2.1s-.8 2.1-1.9 2.1c-1.1 0-1.9-.9-1.9-2.1z"/>'),
    "facebook": _SVG.format('<path d="M13.5 22v-8.2h2.8l.4-3.2h-3.2V8.5c0-.9.3-1.6 1.6-1.6h1.7V4.1c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3v2.4H7.3v3.2h2.8V22z"/>'),
    "tiktok": _SVG.format('<path d="M16.6 2h-3.3v13.4a2.9 2.9 0 1 1-2-2.8V9.2a6.3 6.3 0 1 0 5.3 6.2V8.6a7.7 7.7 0 0 0 4.4 1.4V6.7a4.4 4.4 0 0 1-4.4-4.7z"/>'),
}


def lien_he_html(lon=False):
    """Khoi lien he ho tro: dien thoai, Zalo, Facebook, TikTok (lay tu ban_quyen.LIEN_HE)."""
    from . import ban_quyen
    lh = ban_quyen.LIEN_HE
    nut = "".join(f'<a class="lh {k}" href="{e(lh[k])}" target="_blank" rel="noopener" title="{t}">{_LOGO_MXH[k]}<span>{t}</span></a>'
                  for k, t in (("zalo", "Zalo"), ("facebook", "Facebook"), ("tiktok", "TikTok")) if lh.get(k))
    so_dt = ban_quyen.DIEN_THOAI
    return (f'<div class="hotro{" lon" if lon else ""}"><span>Hỗ trợ: <a class="dt" href="tel:{so_dt.replace(" ", "")}"><b>{so_dt}</b></a></span>'
            f'<span class="ds-lh">{nut}</span></div>')


def _thanh_ben(cid, ten_ct, ph_dang):
    """Thanh ben trai: logo, cong ty dang xem, danh sach phan he."""
    from . import phan_he
    duong = getattr(HIEN_TAI, "duong", "") or ""
    if cid:
        hop_cty = (f'<a class="cty" href="/" title="Đổi công ty">{icon("cong_ty", 18)}<span><span class="ten">{e(ten_ct)}</span>'
                   f'<span class="doi">Đổi công ty ⇄</span></span></a>')
        muc = ""
        for ph in phan_he.PHAN_HE:
            ds = phan_he.chuc_nang(ph)
            if not ds:
                continue
            dau = "" if ph["ma"] == "tongquan" else f"/phan-he/{ph['ma']}"
            dang = ph_dang is not None and ph_dang["ma"] == ph["ma"]
            muc += (f'<a href="/cty/{cid}{dau}" class="ph{" dang" if dang else ""}" style="--m:{ph["mau"]}">'
                    f'<i>{icon(ph["ic"], 17)}</i><span>{e(ph["ten"])}</span></a>')
        nav = f'<h4>Phân hệ</h4>{muc}'
    else:
        hop_cty = ""
        nav = ('<h4>Chung</h4>'
               f'<a href="/" class="ph{" dang" if duong in ("", "/") else ""}" style="--m:#2563eb"><i>{icon("cong_ty", 17)}</i><span>Các công ty</span></a>'
               f'<a href="/he-thong" class="ph{" dang" if duong.startswith("/he-thong") else ""}" style="--m:#64748b"><i>{icon("/caidat", 17)}</i><span>Cài đặt chung</span></a>'
               f'<a href="/ban-quyen" class="ph{" dang" if duong.startswith("/ban-quyen") else ""}" style="--m:#d97706"><i>{icon("khoa", 17)}</i><span>Bản quyền</span></a>')
    return f"""<aside class="ben"><a class="logo" href="/"><i class="chip">{thuong_hieu.DAU_CHIP}</i>
<span>{TEN_UNG_DUNG_HTML}<small>by {thuong_hieu.TEN}</small></span></a>
<label for="mo-menu" class="menu-mo">☰</label>{hop_cty}<nav>{nav}</nav>
<div class="chan"><div class="chan-link"><a href="/he-thong">{icon("/caidat", 14)}Cài đặt chung</a><a href="/ban-quyen">{icon("khoa", 14)}Bản quyền</a>
<a href="/he-thong/phien-ban">Phiên bản {PHIEN_BAN}</a></div>{lien_he_html()}</div></aside>"""


def _thanh_phan_he(cid, ph, u_dang):
    """Thanh chuc nang cua phan he dang mo (giong cac phan mem ke toan: Quy trinh | chuc nang...)."""
    from . import phan_he
    if not ph or ph["ma"] == "tongquan":
        return ""
    the = ""
    if ph["quy_trinh"]:
        the += (f'<a href="/cty/{cid}/phan-he/{ph["ma"]}" class="{"dang" if u_dang == "quy-trinh" else ""}">'
                f'{icon("quy-trinh", 15)}Quy trình</a>')
    the += "".join(f'<a href="/cty/{cid}{u}" class="{"dang" if u == u_dang else ""}">{e(t)}</a>'
                   for u, t in phan_he.chuc_nang(ph))
    return (f'<div class="thanh-ph khong-in" style="--m:{ph["mau"]}"><span class="ten-ph"><i>{icon(ph["ic"], 16)}</i>{e(ph["ten"])}</span>'
            f'<nav>{the}</nav></div>')


def _tao_moi(cid):
    ds = [("/chungtu/moi", "Phiếu thu, phiếu chi", "tien"), ("/chungtu/moi", "Chứng từ nghiệp vụ khác", "ghi"),
          ("/hoadon/cong", "Tải hóa đơn từ cổng thuế", "tai"), ("/hoadon/nap", "Nạp file hóa đơn XML", "/hoadon"),
          ("/nganhang/nap", "Nạp sao kê ngân hàng", "/nganhang"), ("/luong", "Bảng lương tháng", "/luong"),
          ("/taisan", "Tài sản, công cụ dụng cụ", "/taisan"), ("/doituong", "Khách hàng, nhà cung cấp", "/doituong")]
    from . import phan_he
    muc = "".join(f'<a href="/cty/{cid}{u}">{icon(ic, 16)}{t}</a>' for u, t, ic in ds if phan_he._duoc_dung(u))
    return (f'<details class="tao-moi khong-in"><summary class="nut nho">{icon("cong", 15)}Tạo mới</summary>'
            f'<div class="tm-ds">{muc}</div></details>')


def trang(tieu_de, noi_dung, cid=None, ten_ct=""):
    from . import phan_he
    nd = getattr(HIEN_TAI, "nguoi", None)
    duong = getattr(HIEN_TAI, "duong", "") or ""
    ph, u_dang = (phan_he.tim(cid, duong, getattr(HIEN_TAI, "q", None) or {}, getattr(HIEN_TAI, "ph", "") or "")
                  if cid else (None, None))
    if cid:
        vet = [f'<a href="/cty/{cid}">{e(ten_ct)}</a>']
        if ph and ph["ma"] != "tongquan":
            vet.append(f'<a href="/cty/{cid}/phan-he/{ph["ma"]}">{e(ph["ten"])}</a>')
        tim = (f'<form class="tim khong-in" method="get" action="/cty/{cid}/chungtu">{icon("tim", 16)}'
               f'<input name="q" placeholder="Tìm chứng từ, số hóa đơn, diễn giải..." aria-label="Tìm chứng từ"></form>')
        tao = _tao_moi(cid)
    else:
        vet, tim, tao = [], "", ""
    vet_html = "".join(f'<span class="vet">{x}</span>' for x in vet)
    bq = getattr(HIEN_TAI, "ban_quyen", None)
    bang_bq = ""
    if bq and bq.get("thong_bao"):
        mau = "vang" if bq.get("cho_ghi") else "do"
        bang_bq = (f'<div class="bq {mau} khong-in">{e(bq["thong_bao"])} <a href="/ban-quyen">'
                   f'{"Nhập key" if bq["loai"] != "key" else "Xem bản quyền"}</a></div>')
    la_qt = nd is None or nd.get("vai_tro") == "quan_tri"
    nguoi = (f'<span class="ai" title="{e(nd.get("ho_ten") or nd["ten"])}"><b>{e((nd.get("ho_ten") or nd["ten"])[:1].upper())}</b>'
             f'<span class="ten-nd">{e(nd.get("ho_ten") or nd["ten"])}</span></span>'
             f'<a class="nut phu nho" href="/dang-xuat">Đăng xuất</a>' if nd else "")
    bm = getattr(HIEN_TAI, "ban_moi", None)
    moi = (f'<a class="nut nho xanh-la" href="/he-thong/cap-nhat" title="Có phiên bản mới">Có bản {e(bm["phien_ban"])}</a>' if bm else "")
    tat = f'<a class="nut phu nho tat" href="/tat" title="Tắt ứng dụng">{icon("tat", 15)}<span>Tắt</span></a>' if la_qt else ""
    nho_ph = (f'<script>document.cookie="ph={ph["ma"]};path=/;SameSite=Lax"</script>' if ph else "")
    return f"""<!doctype html><html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{e(tieu_de)} · {TEN_UNG_DUNG}</title>
<link rel="icon" href="{thuong_hieu.FAVICON}"><style>{CSS}</style></head><body><input type="checkbox" id="mo-menu" hidden>
<div class="khung">{_thanh_ben(cid, ten_ct, ph)}
<div class="phan-chinh"><header class="dau"><div class="tieu">{vet_html}<h1 class="ten-trang">{e(tieu_de)}</h1></div>
<div class="phai">{tim}{tao}{moi}{nguoi}{tat}</div></header>{_thanh_phan_he(cid, ph, u_dang)}
{bang_bq}<main>{_boc_bang(noi_dung)}</main></div></div>{_JS}{nho_ph}</body></html>"""


def trang_in(tieu_de, noi_dung, ngang=False):
    """Trang de in (phieu thu, phieu chi, bang luong...): khong co menu, co nut In / Luu PDF."""
    kho = "A4 landscape" if ngang else "A4"
    rong = "297mm" if ngang else "210mm"
    return f"""<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>{e(tieu_de)}</title>
<style>
body{{font:13.5px/1.45 "Times New Roman",Times,serif;color:#000;margin:0;background:#e9ecf1}}
.to{{background:#fff;width:{rong};margin:16px auto;padding:12mm 14mm;box-shadow:0 2px 10px rgba(0,0,0,.15)}}
.to+.to{{break-before:page}}
table{{border-collapse:collapse;width:100%}}td,th{{padding:3px 5px;vertical-align:top}}
.bang td,.bang th{{border:1px solid #000}}.bang th{{font-weight:bold;text-align:center}}.bang{{font-size:12.5px}}
.s{{text-align:right;white-space:nowrap}}.g{{text-align:center}}.dam{{font-weight:bold}}.nghieng{{font-style:italic}}
h1{{font-size:18px;text-align:center;margin:6px 0 2px;letter-spacing:.5px}}
.dong{{display:flex;justify-content:space-between;gap:20px}}
.ky{{display:grid;grid-template-columns:repeat(5,1fr);text-align:center;margin-top:14px}}
.ky.bon{{grid-template-columns:repeat(4,1fr)}}.ky.ba{{grid-template-columns:repeat(3,1fr)}}
.ky div{{min-height:90px}}
.cong-cu{{text-align:center;margin:14px;font:14px system-ui}}.cong-cu button{{font:600 14px system-ui;padding:8px 18px;border-radius:7px;border:0;
background:#1d4f91;color:#fff;cursor:pointer}}.cong-cu a{{margin-left:14px}}
@media print{{body{{background:#fff}}.to{{margin:0;box-shadow:none;width:auto;padding:4mm 6mm}}.cong-cu{{display:none}}
@page{{size:{kho};margin:8mm}}}}
</style></head><body><div class="cong-cu"><button onclick="window.print()">In / Lưu PDF</button>
<a href="javascript:history.back()">Quay lại</a></div>{noi_dung}</body></html>"""


def ky_mac_dinh(q):
    """Ky mac dinh: ca nam co so lieu gan nhat cua cong ty dang xem (hoac nam nay)."""
    nam = getattr(HIEN_TAI, "nam", None) or date.today().year
    return q.get("tu", f"{nam}-01-01"), q.get("den", f"{nam}-12-31")


def form_ky(tu, den, them=""):
    return f"""<form class="ngang" method="get">{them}
<label>Từ ngày<input type="date" name="tu" value="{e(tu)}"></label>
<label>Đến ngày<input type="date" name="den" value="{e(den)}"></label><button>Xem</button></form>"""


def tab(ds, dang):
    """Thanh the: ds la list (ma, url, nhan)."""
    return '<div class="tab">' + "".join(
        f'<a href="{u}" class="{"dang" if m == dang else ""}">{t}</a>' for m, u, t in ds) + "</div>"


def o_so(nhan, gia_tri, phu=""):
    return (f'<div class="o"><div class="nhan">{nhan}</div><div class="chiso">{gia_tri}</div>'
            + (f'<div class="phu">{phu}</div>' if phu else "") + "</div>")


def o_kpi(ic, mau, nhan, gia_tri, phu=""):
    """The chi so co icon mau (bang dieu khien)."""
    return (f'<div class="kpi" style="--m:{mau}"><i>{icon(ic, 20)}</i><div><div class="nhan">{nhan}</div>'
            f'<div class="chiso">{gia_tri}</div>' + (f'<div class="phu">{phu}</div>' if phu else "") + "</div></div>")


def nhan_tt(chu, mau=""):
    return f'<span class="nhan-tt {mau}">{e(chu)}</span>'


def bieu_do_cot(nhan, chuoi, don_vi=1_000_000, cao=250, rong=1150):
    """Bieu do cot nhom (SVG). nhan: nhan truc x; chuoi: [(ten, mau, [gia tri])]. Gia tri tinh theo dong, ve theo trieu."""
    n, k = len(nhan), len(chuoi)
    lon = max([max(v) for _, _, v in chuoi if v] + [0])
    if lon <= 0:
        return '<p class="mo">Chưa có số liệu để vẽ biểu đồ.</p>'
    buoc = 10 ** len(str(int(lon / don_vi / 4) or 1)) / 10
    buoc = next(b * buoc for b in (1, 2, 2.5, 5, 10) if b * buoc * 4 >= lon / don_vi)
    dinh = buoc * 4
    trai, duoi, tren = 52, 26, 10
    o = (rong - trai) / n
    cot = min(22, (o - 14) / k - 2)
    y = lambda v: tren + (cao - tren - duoi) * (1 - v / don_vi / dinh)
    g = "".join(f'<line x1="{trai}" x2="{rong}" y1="{y(i * buoc * don_vi):.1f}" y2="{y(i * buoc * don_vi):.1f}" class="luoi-bd"/>'
                f'<text x="{trai - 8}" y="{y(i * buoc * don_vi) + 4:.1f}" class="truc" text-anchor="end">{so(i * buoc) or 0}</text>'
                for i in range(5))
    m = ""
    for i, t in enumerate(nhan):
        x0 = trai + o * i + (o - (cot + 2) * k + 2) / 2
        goi_y = t + ": " + "; ".join(f"{ten} {so(v[i]) or 0} đ" for ten, _, v in chuoi)
        for j, (ten, mau, v) in enumerate(chuoi):
            gt = max(v[i], 0)
            if gt:
                h = cao - duoi - y(gt)
                r = min(4, h)
                x = x0 + j * (cot + 2)
                m += (f'<path d="M{x:.1f},{cao - duoi} v{-(h - r):.1f} q0,{-r:.1f} {r:.1f},{-r:.1f} h{cot - 2 * r:.1f} '
                      f'q{r:.1f},0 {r:.1f},{r:.1f} v{h - r:.1f} z" fill="{mau}"/>')
        m += (f'<rect x="{trai + o * i:.1f}" y="{tren}" width="{o:.1f}" height="{cao - tren - duoi}" class="cham-bd"><title>{e(goi_y)}</title></rect>'
              f'<text x="{trai + o * i + o / 2:.1f}" y="{cao - 8}" class="truc" text-anchor="middle">{e(t)}</text>')
    chu_giai = "".join(f'<span><i style="background:{mau}"></i>{e(ten)}</span>' for ten, mau, _ in chuoi)
    return (f'<div class="chu-giai">{chu_giai}<span class="mo">Đơn vị: triệu đồng</span></div>'
            f'<svg class="bieu-do" viewBox="0 0 {rong} {cao}" role="img" aria-label="Biểu đồ cột">{g}{m}</svg>')
