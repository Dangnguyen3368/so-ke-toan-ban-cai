"""Sao ke ngan hang: doc file Excel/CSV cua moi ngan hang, nhan khoan da co tren so,
goi y tai khoan doi ung va ghi so hang loat.

Ngan hang nao cung xuat sao ke theo dang bang: ngay, so tham chieu, noi dung, tien ra (ghi no),
tien vao (ghi co), so du. Bo doc tu do tim dong tieu de va nhan cot theo ten, nen khong can
viet rieng cho tung ngan hang. Doc duoc ca so tien gui ngan hang (S05-DNN) cua MISA.
"""
import csv
import io
import json
import re
import unicodedata
from datetime import date, datetime, timedelta

import openpyxl

from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS sao_ke (
    id INTEGER PRIMARY KEY,
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    tk TEXT NOT NULL,                    -- TK tien gui tren so (1121, 11211...)
    ngan_hang TEXT, so_tk TEXT,
    ngay TEXT NOT NULL,
    so_ref TEXT NOT NULL DEFAULT '',
    vao INTEGER NOT NULL DEFAULT 0,      -- tien vao tai khoan (ngan hang ghi Co)
    ra INTEGER NOT NULL DEFAULT 0,       -- tien ra (ngan hang ghi No)
    so_du INTEGER,
    noi_dung TEXT NOT NULL DEFAULT '',
    tk_file TEXT,                        -- TK doi ung co san trong file (so MISA)
    tk_goi_y TEXT, dt_goi_y TEXT, ly_do TEXT,
    trang_thai TEXT NOT NULL DEFAULT 'moi',   -- moi | da_co (khop chung tu san co) | da_ghi
    chung_tu_id INTEGER REFERENCES chung_tu(id) ON DELETE SET NULL,
    UNIQUE (cong_ty_id, so_tk, ngay, so_ref, vao, ra, noi_dung)
);
CREATE INDEX IF NOT EXISTS ix_sk_ngay ON sao_ke(cong_ty_id, ngay);
CREATE TABLE IF NOT EXISTS quy_tac_ngan_hang (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    tu_khoa TEXT NOT NULL,               -- khong dau, chu thuong
    chieu TEXT NOT NULL DEFAULT '',      -- 'vao', 'ra' hoac '' (ca hai)
    tk TEXT NOT NULL,
    doi_tuong TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (cong_ty_id, tu_khoa, chieu)
);
CREATE TABLE IF NOT EXISTS tai_khoan_ngan_hang (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    so_tk TEXT NOT NULL,
    ngan_hang TEXT,
    tk TEXT NOT NULL,
    PRIMARY KEY (cong_ty_id, so_tk)
);
"""

NGAN_HANG = [("quan doi", "MB"), ("mbbank", "MB"), ("mb bank", "MB"), ("ngoai thuong", "Vietcombank"),
             ("vietcombank", "Vietcombank"), ("bidv", "BIDV"), ("dau tu va phat trien", "BIDV"),
             ("vietinbank", "VietinBank"), ("cong thuong", "VietinBank"), ("techcombank", "Techcombank"),
             ("ky thuong", "Techcombank"), ("agribank", "Agribank"), ("nong nghiep", "Agribank"), ("acb", "ACB"),
             ("a chau", "ACB"), ("vpbank", "VPBank"), ("viet nam thinh vuong", "VPBank"), ("tpbank", "TPBank"),
             ("tien phong", "TPBank"), ("sacombank", "Sacombank"), ("sai gon thuong tin", "Sacombank"),
             ("hdbank", "HDBank"), ("shb", "SHB"), ("vib", "VIB"), ("ocb", "OCB"), ("lpbank", "LPBank")]

# (tu khoa khong dau, chieu, tk, ghi chu). Chieu: 'vao' | 'ra' | ''.
TU_KHOA = [
    (("lai tien gui", "lai tgnh", "tra lai tg", "lai nhap von", "interest", "lai tk", "tien lai"), "vao", "515", "Lãi tiền gửi"),
    (("nop tien mat", "nop tm", "nop tien vao", "cash deposit"), "vao", "1111", "Nộp tiền mặt vào tài khoản"),
    (("rut tien", "rut tm", "nhap quy", "cash withdrawal", "atm"), "ra", "1111", "Rút tiền về quỹ"),
    (("tra lai vay", "lai vay"), "ra", "635", "Trả lãi vay"),
    (("tra goc", "tra no vay", "tat toan khoan vay"), "ra", "341", "Trả nợ gốc vay"),
    (("giai ngan", "khoan vay"), "vao", "341", "Nhận tiền vay"),
    (("cham nop", "tien phat"), "ra", "3339", "Nộp tiền chậm nộp, phạt"),
    (("thue gtgt", "thue gia tri gia tang"), "ra", "33311", "Nộp thuế GTGT"),
    (("thue tndn", "thu nhap doanh nghiep"), "ra", "3334", "Nộp thuế TNDN"),
    (("thue tncn", "thu nhap ca nhan"), "ra", "3335", "Nộp thuế TNCN"),
    (("mon bai", "le phi mon bai"), "ra", "3338", "Nộp lệ phí môn bài"),
    (("nsnn", "ngan sach", "nop thue"), "ra", "3339", "Nộp ngân sách (chọn lại TK thuế cụ thể)"),
    (("bhxh", "bao hiem xa hoi", "bhyt", "bhtn"), "ra", "3383", "Nộp bảo hiểm"),
    (("luong", "salary", "payroll"), "ra", "334", "Trả lương"),
    (("gop von",), "vao", "4111", "Nhận vốn góp"),
    (("phi", "fee", "sms", "qltk", "quan ly tai khoan", "duy tri", "charge", "vat phi", "mua sec", "sec"), "ra", "6422", "Phí ngân hàng"),
]
BO_TU = {"cong", "ty", "tnhh", "co", "phan", "cp", "mtv", "mot", "thanh", "vien", "va", "chi", "nhanh", "cn",
         "tm", "dv", "xd", "thuong", "mai", "dich", "vu", "xay", "dung", "san", "xuat", "dau", "tu", "viet", "nam",
         "group", "jsc", "ltd", "company", "tap", "doan", "doanh", "nghiep", "tu", "nhan", "hop", "tac", "xa"}


def chuan_bi(con):
    con.executescript(SCHEMA)


def khong_dau(s):
    s = unicodedata.normalize("NFD", str(s or "")).replace("đ", "d").replace("Đ", "D")
    s = "".join(c for c in s if unicodedata.category(c) != "Mn").lower()
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", s)).strip()


# ---------------------------------------------------------------- doc file

def _so(v):
    if v is None or v == "":
        return 0
    if isinstance(v, (int, float)):
        return int(round(v))
    s = str(v).strip().replace(" ", "").replace("VND", "").replace("đ", "")
    am = s.startswith("-") or (s.startswith("(") and s.endswith(")"))
    s = re.sub(r"[.,]\d{1,2}$", "", s)
    d = re.sub(r"\D", "", s)
    return (-int(d) if am else int(d)) if d else 0


def _ngay(v):
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    s = str(v or "").strip()
    m = re.match(r"(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})", s)
    if m:
        try:
            return date(int(m.group(3)), int(m.group(2)), int(m.group(1))).isoformat()
        except ValueError:
            return None
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", s)
    return f"{m.group(1)}-{m.group(2)}-{m.group(3)}" if m else None


def _co(ten, *tu):
    t = f" {ten} "
    return any(f" {x} " in t for x in tu)


def _nhan_cot(tieu_de):
    """tieu_de: list ten cot (khong dau). Tra ve dict vai tro -> chi so cot."""
    c = {}
    for i, t in enumerate(tieu_de):
        if not t:
            continue
        if "ngay" not in c and (t.startswith("ngay") or _co(t, "date", "transaction date", "posting date")) \
                and not _co(t, "hieu luc", "value date"):
            c["ngay"] = i
        elif "noi_dung" not in c and _co(t, "noi dung", "dien giai", "mo ta", "description", "details", "remark",
                                        "remarks", "chi tiet giao dich", "noi dung giao dich", "transaction details"):
            c["noi_dung"] = i
        elif "tk_du" not in c and _co(t, "tk doi ung"):
            c["tk_du"] = i
        elif "ra" not in c and _co(t, "ghi no", "debit", "rut ra", "tien ra", "withdrawal", "withdrawals", "chi", "so tien chi",
                                   "phat sinh no", "debit amount"):
            c["ra"] = i
        elif "vao" not in c and _co(t, "ghi co", "credit", "tien vao", "deposit", "deposits", "thu", "so tien thu",
                                    "phat sinh co", "credit amount"):
            c["vao"] = i
        elif "so_du" not in c and _co(t, "so du", "balance", "ton", "running balance"):
            c["so_du"] = i
        elif "ref" not in c and _co(t, "so tham chieu", "so ct", "so chung tu", "ma gd", "ma giao dich", "reference",
                                    "ref", "so but toan", "transaction no", "so giao dich", "trace", "so tham chieu giao dich"):
            c["ref"] = i
        elif "so_tien" not in c and _co(t, "so tien", "amount", "so tien giao dich"):
            c["so_tien"] = i
    return c


def doc(ten_file, du_lieu):
    """Doc mot file sao ke. Tra ve (thong tin dau file, list dong)."""
    ten = ten_file.lower()
    if ten.endswith(".csv"):
        txt = du_lieu.decode("utf-8-sig", "replace")
        dong = list(csv.reader(io.StringIO(txt), delimiter=";" if txt.count(";") > txt.count(",") else ","))
    else:
        wb = openpyxl.load_workbook(io.BytesIO(du_lieu), read_only=True, data_only=True)
        try:
            dong = [list(r) for r in wb.active.iter_rows(values_only=True)]
        finally:
            wb.close()
    tt = {"ngan_hang": "", "so_tk": ""}
    for r in dong[:15]:
        s = " ".join(str(x) for x in r if x is not None)
        k = khong_dau(s)
        if not tt["ngan_hang"]:
            for kw, nh in NGAN_HANG:
                if f" {kw} " in f" {k} ":
                    tt["ngan_hang"] = nh
                    break
        if not tt["so_tk"]:
            m = re.search(r"(?:so tai khoan|tai khoan|account(?: number| no)?|tk ngan hang|stk)\D{0,25}?(\d[\d ]{5,20}\d)", k)
            if m:
                tt["so_tk"] = m.group(1).replace(" ", "")
    hang_td, cot = None, None
    for i, r in enumerate(dong[:40]):
        td = [khong_dau(x) for x in r]
        c = _nhan_cot(td)
        if "ngay" in c and "noi_dung" in c and (("ra" in c and "vao" in c) or "so_tien" in c):
            hang_td, cot = i, c
            break
        if i + 1 < len(dong):  # tieu de hai dong
            td2 = [f"{a} {khong_dau(b)}".strip() for a, b in zip(td, dong[i + 1] + [None] * (len(td) - len(dong[i + 1])))]
            c = _nhan_cot(td2)
            if "ngay" in c and "noi_dung" in c and (("ra" in c and "vao" in c) or "so_tien" in c):
                hang_td, cot = i + 1, c
                break
    if cot is None:
        raise ValueError(f"{ten_file}: không tìm thấy dòng tiêu đề (cần có cột ngày, nội dung, tiền vào/ra hoặc số tiền).")
    kq = []
    g = lambda r, k: r[cot[k]] if k in cot and cot[k] < len(r) else None
    for r in dong[hang_td + 1:]:
        ngay = _ngay(g(r, "ngay"))
        if not ngay:
            continue
        nd = re.sub(r"\s+", " ", str(g(r, "noi_dung") or "")).strip()
        if "so_tien" in cot and not ("ra" in cot and "vao" in cot):
            st = _so(g(r, "so_tien"))
            vao, ra = (st, 0) if st > 0 else (0, -st)
        else:
            vao, ra = abs(_so(g(r, "vao"))), abs(_so(g(r, "ra")))
        if not vao and not ra:
            continue
        sd = g(r, "so_du")
        kq.append({"ngay": ngay, "so_ref": str(g(r, "ref") or "").strip(), "noi_dung": nd, "vao": vao, "ra": ra,
                   "so_du": _so(sd) if sd not in (None, "") else None,
                   "tk_du": str(g(r, "tk_du") or "").strip()})
    return tt, kq


# ---------------------------------------------------------------- luu, khop so

def tk_cho_so_tk(con, cid, so_tk):
    r = con.execute("SELECT tk FROM tai_khoan_ngan_hang WHERE cong_ty_id=? AND so_tk=?", (cid, so_tk)).fetchone()
    return r["tk"] if r else None


def luu(con, cid, tt, dong, tk):
    """Luu cac dong sao ke (bo qua dong trung). Tra ve so dong moi."""
    chuan_bi(con)
    db.them_tai_khoan(con, cid, tk, f"Tiền gửi {tt.get('ngan_hang') or ''} {tt.get('so_tk') or ''}".strip())
    if tt.get("so_tk"):
        con.execute("INSERT OR REPLACE INTO tai_khoan_ngan_hang VALUES (?,?,?,?)", (cid, tt["so_tk"], tt.get("ngan_hang"), tk))
    n = 0
    for d in dong:
        cur = con.execute(
            "INSERT OR IGNORE INTO sao_ke (cong_ty_id, tk, ngan_hang, so_tk, ngay, so_ref, vao, ra, so_du, noi_dung, tk_file) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (cid, tk, tt.get("ngan_hang"), tt.get("so_tk") or "", d["ngay"], d["so_ref"], d["vao"], d["ra"], d["so_du"],
             d["noi_dung"], d.get("tk_du") or None))
        n += cur.rowcount
    con.commit()
    khop_so(con, cid)
    goi_y_tat_ca(con, cid)
    return n


def khop_so(con, cid):
    """Danh dau dong sao ke da co chung tu tren so (cung so tien vao/ra TK 112, ngay lech toi da 3 ngay)."""
    da_dung = {r["chung_tu_id"] for r in con.execute(
        "SELECT chung_tu_id FROM sao_ke WHERE cong_ty_id=? AND chung_tu_id IS NOT NULL", (cid,))}
    moi = con.execute("SELECT * FROM sao_ke WHERE cong_ty_id=? AND trang_thai='moi' ORDER BY ngay, id", (cid,)).fetchall()
    if not moi:
        return 0
    tu = (date.fromisoformat(moi[0]["ngay"]) - timedelta(days=3)).isoformat()
    den = (date.fromisoformat(moi[-1]["ngay"]) + timedelta(days=3)).isoformat()
    ct = {}
    q = ("SELECT c.id, c.ngay_ht, b.tk_no, b.tk_co, b.so_tien FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id "
         "WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ? AND (b.tk_no LIKE '112%' OR b.tk_co LIKE '112%')")
    for r in con.execute(q, (cid, tu, den)):
        x = ct.setdefault(r["id"], {"ngay": r["ngay_ht"], "vao": 0, "ra": 0})
        if r["tk_no"].startswith("112") and not r["tk_co"].startswith("112"):
            x["vao"] += r["so_tien"]
        if r["tk_co"].startswith("112") and not r["tk_no"].startswith("112"):
            x["ra"] += r["so_tien"]
    n, xong = 0, set()
    for lech in (0, 1, 2, 3):
        for s in moi:
            if s["id"] in xong:
                continue
            ng = date.fromisoformat(s["ngay"])
            for cid_ct, x in ct.items():
                if cid_ct in da_dung or abs((date.fromisoformat(x["ngay"]) - ng).days) != lech:
                    continue
                if (s["vao"] and x["vao"] == s["vao"]) or (s["ra"] and x["ra"] == s["ra"]):
                    con.execute("UPDATE sao_ke SET trang_thai='da_co', chung_tu_id=? WHERE id=?", (cid_ct, s["id"]))
                    da_dung.add(cid_ct)
                    xong.add(s["id"])
                    n += 1
                    break
    # nhieu dong sao ke cung ngay, cung noi dung gop thanh mot chung tu (vd nop BHXH tach 3 dong)
    nhom = {}
    for s in moi:
        if s["id"] not in xong:
            nhom.setdefault((s["ngay"], "vao" if s["vao"] else "ra", s["noi_dung"]), []).append(s)
    for (ngay, chieu, _), ds in nhom.items():
        if len(ds) < 2:
            continue
        tong = sum(x[chieu] for x in ds)
        ng = date.fromisoformat(ngay)
        for cid_ct, x in ct.items():
            if cid_ct not in da_dung and abs((date.fromisoformat(x["ngay"]) - ng).days) <= 3 and x[chieu] == tong:
                for y in ds:
                    con.execute("UPDATE sao_ke SET trang_thai='da_co', chung_tu_id=? WHERE id=?", (cid_ct, y["id"]))
                da_dung.add(cid_ct)
                n += len(ds)
                break
    con.commit()
    return n


# ---------------------------------------------------------------- goi y dinh khoan

def _doi_tac(con, cid):
    """Danh sach doi tac da biet: (cum tu ten khong dau, mst/ma, vai tro 'kh'|'ncc')."""
    ds = {}

    def them(ten, ma, vai):
        k = " ".join(w for w in khong_dau(ten).split() if w not in BO_TU)
        if len(k) >= 4 and (ma or k) not in ds:
            ds[ma or k] = (k, ma or "", vai)
    if con.execute("SELECT 1 FROM sqlite_master WHERE name='hoa_don'").fetchone():
        for r in con.execute("SELECT DISTINCT nb_ten, nbmst FROM hoa_don WHERE cong_ty_id=? AND chieu='mua'", (cid,)):
            them(r["nb_ten"], r["nbmst"], "ncc")
        for r in con.execute("SELECT DISTINCT nm_ten, nmmst FROM hoa_don WHERE cong_ty_id=? AND chieu='ban'", (cid,)):
            them(r["nm_ten"], r["nmmst"], "kh")
    if con.execute("SELECT 1 FROM sqlite_master WHERE name='cong_no_doi_tuong'").fetchone():
        for r in con.execute("SELECT DISTINCT ten, ma, so_tk FROM cong_no_doi_tuong WHERE cong_ty_id=?", (cid,)):
            them(r["ten"], r["ma"], "kh" if r["so_tk"].startswith("131") else "ncc")
    return list(ds.values())


def goi_y(con, cid, s, doi_tac=None, quy_tac=None):
    """Goi y (tk doi ung, doi tuong, ly do, tin cay) cho mot dong sao ke."""
    nd = khong_dau(s["noi_dung"])
    chieu = "vao" if s["vao"] else "ra"
    so_tien = s["vao"] or s["ra"]
    if s["tk_file"]:
        return s["tk_file"], "", "Theo TK đối ứng trong file", "cao"
    for r in quy_tac if quy_tac is not None else con.execute(
            "SELECT * FROM quy_tac_ngan_hang WHERE cong_ty_id=?", (cid,)).fetchall():
        if r["tu_khoa"] in nd and r["chieu"] in ("", chieu):
            return r["tk"], r["doi_tuong"], f"Quy tắc: '{r['tu_khoa']}'", "cao"
    # MST trong noi dung
    doi_tac = doi_tac if doi_tac is not None else _doi_tac(con, cid)
    so = set(re.findall(r"\d{10}(?:\d{3})?", nd.replace(" ", "")) + re.findall(r"\b\d{10}\b", nd))
    hoan = any(t in nd for t in ("tra lai tien", "chuyen thua", "hoan tien", "hoan tra", "refund"))
    for k, ma, vai in doi_tac:
        if (ma and ma in so) or (k and f" {k} " in f" {nd} "):
            # chieu tien quyet dinh: tien vao la khach tra, tien ra la tra nha cung cap; tra lai tien thi nguoc lai
            tk = "131" if (chieu == "vao") != hoan else "331"
            return tk, ma, f"Đối tác: {k}", "cao"
    # Hoa don cung so tien
    if con.execute("SELECT 1 FROM sqlite_master WHERE name='hoa_don'").fetchone():
        tu = (date.fromisoformat(s["ngay"]) - timedelta(days=90)).isoformat()
        r = con.execute("SELECT nbmst, nb_ten, nmmst, nm_ten, shdon FROM hoa_don WHERE cong_ty_id=? AND chieu=? "
                        "AND tong_tien=? AND ngay_lap BETWEEN ? AND ? AND trang_thai NOT IN (4,6) ORDER BY ngay_lap DESC",
                        (cid, "ban" if chieu == "vao" else "mua", so_tien, tu, s["ngay"])).fetchone()
        if r:
            if chieu == "vao":
                return "131", r["nmmst"] or "", f"Khớp số tiền hóa đơn bán {r['shdon']} ({r['nm_ten']})", "cao"
            return "331", r["nbmst"] or "", f"Khớp số tiền hóa đơn mua {r['shdon']} ({r['nb_ten']})", "cao"
    for tu_khoa, ch, tk, ghi in TU_KHOA:
        if ch in ("", chieu) and any(f" {t} " in f" {nd} " for t in tu_khoa):
            return tk, "", ghi, "cao"
    if chieu == "vao":
        return "131", "", "Chưa rõ: tạm coi là khách hàng trả tiền", "thap"
    return "331", "", "Chưa rõ: tạm coi là trả nhà cung cấp", "thap"


def goi_y_tat_ca(con, cid):
    dt = _doi_tac(con, cid)
    qt = con.execute("SELECT * FROM quy_tac_ngan_hang WHERE cong_ty_id=?", (cid,)).fetchall()
    for s in con.execute("SELECT * FROM sao_ke WHERE cong_ty_id=? AND trang_thai='moi'", (cid,)).fetchall():
        tk, dtg, ly_do, tc = goi_y(con, cid, s, dt, qt)
        con.execute("UPDATE sao_ke SET tk_goi_y=?, dt_goi_y=?, ly_do=? WHERE id=?",
                    (tk, dtg, ly_do + ("" if tc == "cao" else " (cần xem)"), s["id"]))
    con.commit()


def dat_quy_tac(con, cid, tu_khoa, tk, doi_tuong="", chieu=""):
    con.execute("INSERT OR REPLACE INTO quy_tac_ngan_hang VALUES (?,?,?,?,?)",
                (cid, khong_dau(tu_khoa), chieu, tk.strip(), doi_tuong.strip()))
    con.commit()
    goi_y_tat_ca(con, cid)


# ---------------------------------------------------------------- ghi so

def ghi_so(con, cid, chon):
    """chon: {id: (tk_doi_ung, doi_tuong)}. Tra ve (so chung tu ghi, loi)."""
    n, loi = 0, []
    for i, (tk, dt) in chon.items():
        s = con.execute("SELECT * FROM sao_ke WHERE id=? AND cong_ty_id=?", (i, cid)).fetchone()
        if not s or s["trang_thai"] != "moi":
            continue
        tk = (tk or s["tk_goi_y"] or "").strip()
        if not tk:
            loi.append(f"Dòng {s['ngay']} {s['noi_dung'][:40]}: chưa có tài khoản đối ứng.")
            continue
        db.them_tai_khoan(con, cid, tk, f"TK {tk}")
        dg = s["noi_dung"][:250] or ("Thu tiền gửi" if s["vao"] else "Chi tiền gửi")
        if s["vao"]:
            d = {"tk_no": s["tk"], "tk_co": tk, "so_tien": s["vao"], "doi_tuong_co": dt or "", "dien_giai": dg}
            loai = "NTTK"
        else:
            d = {"tk_no": tk, "tk_co": s["tk"], "so_tien": s["ra"], "doi_tuong_no": dt or "", "dien_giai": dg}
            loai = "UNC"
        try:
            ct = db.ghi_chung_tu(con, cid, f"NH{s['id']:06d}", s["ngay"], s["ngay"], [d], loai=loai, dien_giai=dg,
                                 nguon="saoke")
        except Exception as ex:
            loi.append(f"Dòng {s['ngay']} {s['noi_dung'][:40]}: {ex}")
            continue
        con.execute("UPDATE sao_ke SET trang_thai='da_ghi', chung_tu_id=? WHERE id=?", (ct, s["id"]))
        n += 1
    con.commit()
    return n, loi


def doi_chieu(con, cid, tu, den):
    """So du cuoi ky theo sao ke va theo so, gop theo TK tren so (nhieu tai khoan ngan hang chung mot TK thi cong lai)."""
    from . import bao_cao
    kq = []
    for r in con.execute("SELECT DISTINCT tk FROM sao_ke WHERE cong_ty_id=? AND ngay BETWEEN ? AND ?", (cid, tu, den)).fetchall():
        tk = r["tk"]
        cac_tk, so_du_nh, du = [], 0, True
        for a in con.execute("SELECT DISTINCT so_tk, ngan_hang FROM sao_ke WHERE cong_ty_id=? AND tk=?", (cid, tk)).fetchall():
            cuoi = con.execute("SELECT so_du FROM sao_ke WHERE cong_ty_id=? AND tk=? AND so_tk=? AND ngay<=? AND so_du IS NOT NULL "
                               "ORDER BY ngay DESC, id DESC LIMIT 1", (cid, tk, a["so_tk"], den)).fetchone()
            cac_tk.append(f"{a['ngan_hang'] or ''} {a['so_tk']}".strip())
            if cuoi:
                so_du_nh += cuoi["so_du"]
            else:
                du = False
        dem = {d["trang_thai"]: d["n"] for d in con.execute(
            "SELECT trang_thai, COUNT(*) n FROM sao_ke WHERE cong_ty_id=? AND tk=? AND ngay BETWEEN ? AND ? GROUP BY trang_thai",
            (cid, tk, tu, den))}
        bang, _ = bao_cao.phan_hai_ben(con, cid, bao_cao.ngay_sau(den))
        so = sum(n - c for k, (n, c) in bang.items() if k.startswith(tk))
        kq.append({"tk": tk, "tai_khoan": ", ".join(cac_tk), "so_du_nh": so_du_nh if du else None,
                   "so_du_so": so, "dem": dem})
    return kq
