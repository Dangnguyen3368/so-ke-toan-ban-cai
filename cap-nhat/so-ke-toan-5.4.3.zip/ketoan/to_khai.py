"""Lap to khai thue tu so lieu trong he thong: 01/GTGT, 03/TNDN (+03-1A, 03-2), 05/QTT-TNCN.

Ket qua la dict chi tieu -> so (ma chi tieu dung theo mau HTKK), kem danh sach canh bao.
To khai da lap duoc luu vao bang to_khai de ky sau lay so chuyen sang (vd [43] -> [22]).

CAN DOI CHIEU VAN BAN HIEN HANH: nguong thanh toan khong dung tien mat, thue suat TNDN,
giam thue GTGT 8%... dat trong THAM_SO duoi day, sua khi nha nuoc thay doi.
"""
import json
from datetime import date

from . import bao_cao, luong

SCHEMA = """
CREATE TABLE IF NOT EXISTS to_khai (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    loai TEXT NOT NULL,                 -- '01/GTGT', '03/TNDN', '05/QTT', 'BCTC'
    ky TEXT NOT NULL,                   -- '2025-Q4', '2025-12', '2025'
    du_lieu TEXT NOT NULL,              -- JSON chi tieu
    ngay_lap TEXT NOT NULL,
    PRIMARY KEY (cong_ty_id, loai, ky)
);
CREATE TABLE IF NOT EXISTS lo_tndn (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    nam_lo INTEGER NOT NULL,
    so_lo INTEGER NOT NULL,             -- so lo phat sinh (duong)
    PRIMARY KEY (cong_ty_id, nam_lo)
);
CREATE TABLE IF NOT EXISTS chuyen_lo (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    nam_lo INTEGER NOT NULL,
    nam_qt INTEGER NOT NULL,            -- nam quyet toan da tru so lo nay
    so_tien INTEGER NOT NULL,
    PRIMARY KEY (cong_ty_id, nam_lo, nam_qt)
);
CREATE TABLE IF NOT EXISTS dieu_chinh_tndn (
    id INTEGER PRIMARY KEY,
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    nam INTEGER NOT NULL,
    chi_tieu TEXT NOT NULL,             -- 'B4' chi phi khong duoc tru, 'B7', 'B12', 'C2'...
    noi_dung TEXT NOT NULL,
    so_tien INTEGER NOT NULL
);
"""

THAM_SO = {
    # Thanh toan tu nguong nay phai khong dung tien mat moi duoc khau tru GTGT
    "nguong_tien_mat": [("2000-01-01", 20_000_000), ("2025-07-01", 5_000_000)],
    # Thue suat TNDN pho thong; DN nho theo Luat 67/2025/QH15 (kiem tra lai truoc khi dung)
    "thue_suat_tndn": [(2014, None, 20), (2025, 3_000_000_000, 15), (2025, 50_000_000_000, 17), (2025, None, 20)],
    "so_nam_chuyen_lo": 5,
}
QUAN_HE = {"con": ("01", "Con"), "vợ": ("02", "Vợ/Chồng"), "chồng": ("02", "Vợ/Chồng"),
           "cha": ("03", "Cha/Mẹ"), "mẹ": ("03", "Cha/Mẹ"), "bố": ("03", "Cha/Mẹ")}


def chuan_bi(con):
    con.executescript(SCHEMA)
    bao_cao.chuan_bi(con)
    luong.chuan_bi(con)
    cot = {r["name"] for r in con.execute("PRAGMA table_info(nhan_vien)")}
    if "uy_quyen_qt" not in cot:
        con.execute("ALTER TABLE nhan_vien ADD COLUMN uy_quyen_qt INTEGER NOT NULL DEFAULT 0")


def luu(con, cid, loai, ky, du_lieu):
    con.execute("INSERT OR REPLACE INTO to_khai VALUES (?,?,?,?,?)",
                (cid, loai, ky, json.dumps(du_lieu, ensure_ascii=False), date.today().isoformat()))
    con.commit()


def doc(con, cid, loai, ky):
    r = con.execute("SELECT du_lieu FROM to_khai WHERE cong_ty_id=? AND loai=? AND ky=?", (cid, loai, ky)).fetchone()
    return json.loads(r["du_lieu"]) if r else None


def _f(s):
    return f"{s:,.0f}".replace(",", ".")


# ================================================================ 01/GTGT

def ky_gtgt(nam, quy=None, thang=None):
    """(ma ky, tu, den, ma ky truoc)."""
    if quy:
        tu = date(nam, 3 * quy - 2, 1)
        den = date(nam + (quy == 4), (3 * quy) % 12 + 1, 1)
        truoc = f"{nam}-Q{quy - 1}" if quy > 1 else f"{nam - 1}-Q4"
        return f"{nam}-Q{quy}", tu.isoformat(), bao_cao.ngay_truoc(den.isoformat()), truoc
    tu = date(nam, thang, 1)
    den = date(nam + (thang == 12), thang % 12 + 1, 1)
    truoc = f"{nam}-{thang - 1:02d}" if thang > 1 else f"{nam - 1}-12"
    return f"{nam}-{thang:02d}", tu.isoformat(), bao_cao.ngay_truoc(den.isoformat()), truoc


def _nhom_ts(ts):
    s = (ts or "").upper().replace(" ", "")
    if s in ("KCT",):
        return "26"
    if s in ("KKKNT",):
        return "32a"
    if s.startswith("KHAC"):
        return "32"
    try:
        v = float(s.rstrip("%"))
    except ValueError:
        return "?"
    return {0: "29", 5: "30"}.get(round(v), "32")


def _ty_le(ts):
    try:
        return float((ts or "").upper().replace("KHAC:", "").rstrip("%"))
    except ValueError:
        return None


def _nguong_tien_mat(ngay):
    return [v for d, v in THAM_SO["nguong_tien_mat"] if d <= ngay][-1]


def gtgt_tu_hoa_don(con, cid, tu, den):
    from . import hoa_don
    hoa_don.chuan_bi(con)
    v = {k: 0 for k in ("23", "24", "26", "29", "30", "31", "32", "33", "32a")}
    giam, cb, mua_kct = 0, [], 0
    n_mua = n_ban = 0
    for h in hoa_don.danh_sach(con, cid, "mua", tu, den):
        if h["trang_thai"] in hoa_don.KHONG_GHI_SO:
            continue
        n_mua += 1
        for x in json.loads(h["theo_thue_suat"] or "[]") or [{"tsuat": "", "thtien": h["tien_hang"], "tthue": h["tien_thue"]}]:
            if x["tthue"] or _nhom_ts(x["tsuat"]) in ("29", "30", "32"):
                v["23"] += x["thtien"]
                v["24"] += x["tthue"]
            else:
                mua_kct += x["thtien"]
        if h["tong_tien"] >= _nguong_tien_mat(h["ngay_lap"]) and h["chung_tu_id"]:
            tm = con.execute("SELECT 1 FROM but_toan WHERE chung_tu_id=? AND tk_co LIKE '111%'",
                             (h["chung_tu_id"],)).fetchone()
            if tm:
                cb.append(f"Hóa đơn mua {h['khhdon']}-{h['shdon']} ({h['nb_ten']}) {_f(h['tong_tien'])} đ "
                          f"trả bằng tiền mặt: không được khấu trừ thuế GTGT {_f(h['tien_thue'])} đ.")
    for h in hoa_don.danh_sach(con, cid, "ban", tu, den):
        if h["trang_thai"] in hoa_don.KHONG_GHI_SO:
            continue
        n_ban += 1
        for x in json.loads(h["theo_thue_suat"] or "[]") or [{"tsuat": "", "thtien": h["tien_hang"], "tthue": h["tien_thue"]}]:
            nh = _nhom_ts(x["tsuat"])
            if nh == "?":
                cb.append(f"Hóa đơn bán {h['khhdon']}-{h['shdon']}: không rõ thuế suất '{x['tsuat']}', tạm xếp vào 10%.")
                nh = "32"
            v[nh] += x["thtien"]
            if nh == "30":
                v["31"] += x["tthue"]
            elif nh == "32":
                v["33"] += x["tthue"]
            if _ty_le(x["tsuat"]) == 8:
                giam += x["thtien"]
    if mua_kct:
        cb.append(f"Hàng mua không có thuế GTGT {_f(mua_kct)} đ không đưa vào [23].")
    return v, {"giam_8": giam}, cb, {"nguon": "hóa đơn", "so_hd_mua": n_mua, "so_hd_ban": n_ban}


def gtgt_tu_so(con, cid, tu, den):
    """Uoc tinh 01/GTGT tu but toan khi chua nap hoa don."""
    v = {k: 0 for k in ("23", "24", "26", "29", "30", "31", "32", "33", "32a")}
    q = ("SELECT b.chung_tu_id ct, b.tk_no, b.tk_co, b.so_tien FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id "
         "WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ? ORDER BY b.chung_tu_id, b.stt")
    theo_ct = {}
    for r in con.execute(q, (cid, tu, den)):
        theo_ct.setdefault(r["ct"], []).append(r)
    giam, cb = 0, []
    for ds in theo_ct.values():
        thue_vao = [r for r in ds if r["tk_no"].startswith("133") and not r["tk_co"].startswith("133")]
        if thue_vao:
            v["24"] += sum(r["so_tien"] for r in thue_vao)
            doi_ung = {r["tk_co"] for r in thue_vao}
            v["23"] += sum(r["so_tien"] for r in ds if r["tk_co"] in doi_ung and not r["tk_no"].startswith("133"))
        dt = sum(r["so_tien"] for r in ds if r["tk_co"].startswith("511")) - \
            sum(r["so_tien"] for r in ds if r["tk_no"].startswith("511") and not r["tk_co"].startswith("911"))
        thue = sum(r["so_tien"] for r in ds if r["tk_co"].startswith("3331") and not r["tk_no"].startswith("133")) - \
            sum(r["so_tien"] for r in ds if r["tk_no"].startswith("3331") and not r["tk_co"].startswith(("133", "11")))
        if not dt:
            continue
        if not thue:
            v["26"] += dt
            continue
        ts = min((0, 5, 8, 10), key=lambda t: abs(dt * t / 100 - thue))
        if ts == 5:
            v["30"] += dt
            v["31"] += thue
        else:
            v["32"] += dt
            v["33"] += thue
            if ts == 8:
                giam += dt
    if v["26"]:
        cb.append(f"Có doanh thu {_f(v['26'])} đ không kèm thuế GTGT, tạm đưa vào [26] (không chịu thuế). "
                  "Kiểm tra lại: hàng chịu thuế 0% vào [29], không phải kê khai vào [32a].")
    cb.append("Số liệu ước tính từ sổ vì kỳ này chưa có hóa đơn điện tử trong hệ thống. "
              "[23] có thể lệch nhẹ do hóa đơn không có thuế GTGT.")
    return v, {"giam_8": giam}, cb, {"nguon": "sổ kế toán"}


def gtgt(con, cid, nam, quy=None, thang=None, nhap=None):
    """Lap 01/GTGT. nhap: chi tieu nguoi dung go (22, 37, 38, 39a, 40b, 42, giam_25)."""
    chuan_bi(con)
    nhap = nhap or {}
    ma_ky, tu, den, ky_truoc = ky_gtgt(nam, quy, thang)
    co_hd = con.execute("SELECT COUNT(*) n FROM hoa_don WHERE cong_ty_id=? AND ngay_lap BETWEEN ? AND ?",
                        (cid, tu, den)).fetchone()["n"] if con.execute(
        "SELECT 1 FROM sqlite_master WHERE name='hoa_don'").fetchone() else 0
    v, pl, cb, tt = (gtgt_tu_hoa_don if co_hd else gtgt_tu_so)(con, cid, tu, den)
    truoc = doc(con, cid, "01/GTGT", ky_truoc)
    if "22" in nhap and nhap["22"] != "":
        v["22"] = int(nhap["22"])
    elif truoc:
        v["22"] = truoc.get("43", 0)
        tt["nguon_22"] = f"lấy [43] tờ khai {ky_truoc}"
    else:
        v["22"] = 0
        cb.append(f"Chưa có tờ khai kỳ {ky_truoc} trong hệ thống: [22] đang để 0, cần nhập theo [43] kỳ trước.")
    for k in ("37", "38", "39a", "40b", "42"):
        v[k] = int(nhap.get(k) or 0)
    v["21"] = 0 if any(v[k] for k in ("23", "26", "29", "30", "32", "32a")) else 1
    v["23a"] = v["24a"] = 0
    v["25"] = v["24"] - int(nhap.get("giam_25") or 0)
    v["27"] = v["29"] + v["30"] + v["32"] + v["32a"]
    v["28"] = v["31"] + v["33"]
    v["34"] = v["26"] + v["27"]
    v["35"] = v["28"]
    v["36"] = v["35"] - v["25"]
    x = v["36"] - v["22"] + v["37"] - v["38"] - v["39a"]
    v["40a"] = max(x, 0)
    v["40b"] = min(v["40b"], v["40a"])
    v["40"] = v["40a"] - v["40b"]
    v["41"] = max(-x, 0)
    v["42"] = min(v["42"], v["41"])
    v["43"] = v["41"] - v["42"]
    # Phu luc giam thue GTGT (hang hoa dich vu 10% duoc giam con 8%)
    pl["giam_thue"] = round(pl["giam_8"] * 2 / 100)
    tt.update({"ky": ma_ky, "tu": tu, "den": den})
    # Doi chieu so
    ps = bao_cao.phat_sinh(con, cid, tu, den)
    thue_ra = sum(c for k, (n, c) in ps.items() if k.startswith("33311"))
    if tt["nguon"] == "hóa đơn" and thue_ra and abs(thue_ra - v["35"]) > 1000:
        cb.append(f"Thuế đầu ra theo hóa đơn {_f(v['35'])} khác phát sinh Có 33311 trên sổ {_f(thue_ra)}: "
                  "kiểm tra hóa đơn chưa ghi sổ.")
    return v, pl, cb, tt


# ================================================================ 03/TNDN

def thue_suat_tndn(nam, doanh_thu):
    ds = [x for x in THAM_SO["thue_suat_tndn"] if x[0] <= nam]
    nam_ap = max(x[0] for x in ds)
    for _, tran, ts in [x for x in ds if x[0] == nam_ap]:
        if tran is None or doanh_thu <= tran:
            return ts
    return 20


def goi_y_khong_duoc_tru(con, cid, nam):
    """Cac khoan nen xem xet dua vao B4 (chi phi khong duoc tru)."""
    from . import tai_san
    tai_san.chuan_bi(con)
    gy = []
    for ts in con.execute("SELECT * FROM tai_san WHERE cong_ty_id=? AND loai='TSCD'", (cid,)).fetchall():
        k = tai_san.KHUNG_TT45.get(ts["nhom"] or "")
        if not k or ts["so_thang"] >= k[0]:
            continue
        trich = con.execute("SELECT COALESCE(SUM(so_tien),0) s FROM khau_hao WHERE tai_san_id=? AND thang LIKE ?",
                            (ts["id"], f"{nam}-%")).fetchone()["s"]
        so_thang = con.execute("SELECT COUNT(*) n FROM khau_hao WHERE tai_san_id=? AND thang LIKE ? AND so_tien>0",
                               (ts["id"], f"{nam}-%")).fetchone()["n"]
        duoc = min(trich, round(ts["nguyen_gia"] / k[0] * so_thang))
        if trich > duoc:
            gy.append(("B4", f"Khấu hao vượt khung TT45: {ts['ma']} {ts['ten']} ({ts['so_thang']} tháng < {k[0]} tháng)",
                       trich - duoc))
    q = ("SELECT b.so_tien, COALESCE(b.dien_giai, c.dien_giai, '') dg, c.so_ct FROM but_toan b JOIN chung_tu c "
         "ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? AND c.ngay_ht LIKE ? AND b.tk_no LIKE '811%'")
    for r in con.execute(q, (cid, f"{nam}-%")):
        s = r["dg"].lower()
        if any(x in s for x in ("phạt", "chậm nộp", "lãi phạt")):
            gy.append(("B4", f"Phạt, chậm nộp: {r['so_ct']} {r['dg']}", r["so_tien"]))
    return gy


def lo_duoc_chuyen(con, cid, nam):
    """Cac nam lo con duoc chuyen (trong 5 nam): list dict nam_lo, so_lo, da_chuyen, con_lai."""
    ds = []
    for r in con.execute("SELECT * FROM lo_tndn WHERE cong_ty_id=? AND nam_lo<? AND nam_lo>=? ORDER BY nam_lo",
                         (cid, nam, nam - THAM_SO["so_nam_chuyen_lo"])):
        da = con.execute("SELECT COALESCE(SUM(so_tien),0) s FROM chuyen_lo WHERE cong_ty_id=? AND nam_lo=? AND nam_qt<?",
                         (cid, r["nam_lo"], nam)).fetchone()["s"]
        ds.append({"nam_lo": r["nam_lo"], "so_lo": r["so_lo"], "da_chuyen": da, "con_lai": max(0, r["so_lo"] - da)})
    return ds


def luu_tndn(con, cid, nam, v, lo):
    """Luu ket qua quyet toan: so lo da chuyen trong nam, so lo phat sinh nam nay (neu lo)."""
    con.execute("DELETE FROM chuyen_lo WHERE cong_ty_id=? AND nam_qt=?", (cid, nam))
    for x in lo:
        if x.get("chuyen"):
            con.execute("INSERT INTO chuyen_lo VALUES (?,?,?,?)", (cid, x["nam_lo"], nam, x["chuyen"]))
    con.execute("DELETE FROM lo_tndn WHERE cong_ty_id=? AND nam_lo=?", (cid, nam))
    if v["C1"] - v["C2"] < 0:
        con.execute("INSERT INTO lo_tndn (cong_ty_id, nam_lo, so_lo) VALUES (?,?,?)", (cid, nam, -(v["C1"] - v["C2"])))
    luu(con, cid, "03/TNDN", str(nam), v)


def nap_lo_tu_mau(con, cid, nam_mau, dong):
    """dong: list (nam_lo, so_lo, da_chuyen_truoc, chuyen_trong_nam_mau) doc tu PL 03-2 cua to khai nam_mau."""
    for nam_lo, so_lo, truoc, trong in dong:
        if not so_lo:
            continue
        con.execute("INSERT OR REPLACE INTO lo_tndn (cong_ty_id, nam_lo, so_lo) VALUES (?,?,?)", (cid, nam_lo, so_lo))
        if truoc:
            con.execute("INSERT OR REPLACE INTO chuyen_lo VALUES (?,?,?,?)", (cid, nam_lo, nam_mau - 1, truoc))
        if trong:
            con.execute("INSERT OR REPLACE INTO chuyen_lo VALUES (?,?,?,?)", (cid, nam_lo, nam_mau, trong))
    con.commit()


def tndn(con, cid, nam, nhap=None):
    """Lap 03/TNDN nam `nam`. nhap: {'B4':..,'B7':..,'B12':..,'C2':..,'thue_suat':..}."""
    chuan_bi(con)
    nhap = nhap or {}
    tu, den = f"{nam}-01-01", f"{nam}-12-31"
    k = bao_cao.b02(con, cid, tu, den)
    ct = k["_chi_tiet"]
    p = {  # Phu luc 03-1A
        "ct04": k["01"], "ct05": 0, "ct06": k["02"], "ct07": 0, "ct08": k["02"], "ct09": 0, "ct10": 0,
        "ct11": k["21"], "ct13": k["11"], "ct14": ct["6421"], "ct15": ct["6422"] + ct["642_khac"],
        "ct16": k["22"], "ct17": k["23"], "ct19": k["31"], "ct20": k["32"],
    }
    p["ct12"] = p["ct13"] + p["ct14"] + p["ct15"]
    p["ct18"] = p["ct04"] - p["ct06"] + p["ct11"] - p["ct12"] - p["ct16"]
    p["ct21"] = p["ct19"] - p["ct20"]
    p["ct22"] = p["ct18"] + p["ct21"]
    cb = []
    if k["02"]:
        cb.append("Giảm trừ doanh thu đang xếp vào [08] Giảm giá hàng bán; nếu là chiết khấu hoặc hàng trả lại thì sửa trên HTKK.")
    dc = {}
    for r in con.execute("SELECT chi_tieu, SUM(so_tien) s FROM dieu_chinh_tndn WHERE cong_ty_id=? AND nam=? GROUP BY chi_tieu",
                         (cid, nam)):
        dc[r["chi_tieu"]] = r["s"]
    for key, val in nhap.items():
        if key.startswith(("B", "C")) and val not in ("", None):
            dc[key] = int(val)
    v = {"A1": p["ct22"]}
    for i in range(2, 13):
        v[f"B{i}"] = int(dc.get(f"B{i}", 0))
    v["B1"] = sum(v[f"B{i}"] for i in range(2, 8))
    v["B8"] = sum(v[f"B{i}"] for i in range(9, 13))
    v["B13"] = v["A1"] + v["B1"] - v["B8"]
    v["B15"] = 0
    v["B14"] = v["B13"] - v["B15"]
    v["C1"] = v["B13"]
    v["C2"] = int(dc.get("C2", 0))
    # chuyen lo: lo cu nhat truoc
    lo = lo_duoc_chuyen(con, cid, nam)
    con_tn = max(0, v["C1"] - v["C2"])
    for x in lo:
        x["chuyen"] = min(x["con_lai"], con_tn)
        con_tn -= x["chuyen"]
        x["con_sau"] = x["con_lai"] - x["chuyen"]
    v["C3a"] = sum(x["chuyen"] for x in lo)
    v["C3b"] = 0
    v["C3"] = v["C3a"] + v["C3b"]
    v["C4"] = max(0, v["C1"] - v["C2"] - v["C3"])
    v["C5"] = 0
    v["C6"] = v["C4"] - v["C5"]
    ts = int(nhap.get("thue_suat") or thue_suat_tndn(nam, k["10"]))
    v["C7_thuNhap"] = v["C6"]
    v["C7_thueSuat"] = ts
    v["thue_phai_nop"] = round(v["C6"] * ts / 100)
    if v["C1"] < 0:
        cb.append(f"Năm {nam} lỗ {_f(-v['C1'])} đ: được chuyển sang tối đa {THAM_SO['so_nam_chuyen_lo']} năm sau "
                  "(bấm 'Lưu tờ khai' để ghi nhận số lỗ).")
    if not lo and con.execute("SELECT 1 FROM lo_tndn WHERE cong_ty_id=?", (cid,)).fetchone() is None and v["C1"] > 0:
        cb.append("Chưa có số lỗ các năm trước. Nếu công ty còn lỗ được chuyển, nạp tờ khai 03/TNDN năm trước ở mục Mẫu XML.")
    if ts != 20:
        cb.append(f"Đang dùng thuế suất {ts}% theo doanh thu năm ({_f(k['10'])} đ). Kiểm tra điều kiện áp dụng "
                  "trước khi nộp; sửa ở ô thuế suất nếu cần.")
    tam_nop = sum(n for kk, (n, c) in bao_cao.phat_sinh(con, cid, tu, den).items() if kk.startswith("3334"))
    v["tam_nop_trong_nam"] = tam_nop
    goi_y = goi_y_khong_duoc_tru(con, cid, nam)
    da_co = {r["noi_dung"] for r in con.execute("SELECT noi_dung FROM dieu_chinh_tndn WHERE cong_ty_id=? AND nam=?",
                                                 (cid, nam))}
    goi_y = [g for g in goi_y if g[1] not in da_co]
    if not con.execute("SELECT 1 FROM chung_tu WHERE cong_ty_id=? AND ngay_ht BETWEEN ? AND ?",
                       (cid, tu, f"{nam}-01-31")).fetchone():
        cb.append(f"Sổ không có chứng từ tháng 01/{nam}: số liệu cả năm có thể thiếu, cần nạp đủ sổ 12 tháng.")
    return v, p, lo, cb, goi_y


# ================================================================ 05/QTT-TNCN

def _ma_quan_he(s):
    s = (s or "").strip().lower()
    for k, v in QUAN_HE.items():
        if s.startswith(k):
            return v
    return ("04", "Khác")


def tncn(con, cid, nam):
    """Lap 05/QTT-TNCN tu bang luong nam `nam`. Tra ve (chinh, ds 05-1, tong 05-1, ds 05-3, canh bao)."""
    chuan_bi(con)
    cb = []
    nguoi = {}
    for bl in con.execute("SELECT * FROM bang_luong WHERE cong_ty_id=? AND thang LIKE ? ORDER BY thang",
                          (cid, f"{nam}-%")).fetchall():
        if not bl["ket_qua"]:
            cb.append(f"Bảng lương tháng {bl['thang']} chưa tính (bấm Tính lương).")
            continue
        r = json.loads(bl["ket_qua"])
        x = nguoi.setdefault(bl["ma_nv"], {"tnct": 0, "gt_gc": 0, "bh": 0, "tntt": 0, "thue": 0, "npt": 0, "thang": 0})
        x["tnct"] += r["tn_chiu_thue"]
        x["bh"] += r["bh_nld"] if r["cach_tinh_thue"] == "Lũy tiến" else 0
        x["gt_gc"] += (r["giam_tru"] - r["bh_nld"]) if r["cach_tinh_thue"] == "Lũy tiến" else 0
        x["tntt"] += r["tn_tinh_thue"]
        x["thue"] += r["thue_tncn"]
        x["npt"] = max(x["npt"], r["so_npt"])
        x["thang"] += 1
    ds1, khac = [], []
    for ma, x in nguoi.items():
        nv = con.execute("SELECT * FROM nhan_vien WHERE cong_ty_id=? AND ma=?", (cid, ma)).fetchone()
        dong = {**x, "ma": ma, "ho_ten": luong.lam_sach_ten(nv["ho_ten"]), "mst": (nv["mst"] or "").strip(),
                "cccd": (nv["cccd"] or "").strip(), "uy_quyen": nv["uy_quyen_qt"], "hop_dong": nv["hop_dong"],
                "cu_tru": nv["cu_tru"]}
        if not dong["mst"] and not dong["cccd"]:
            cb.append(f"{dong['ho_ten']}: chưa có MST hoặc số CCCD.")
        (ds1 if nv["cu_tru"] and nv["hop_dong"] == "DH" else khac).append(dong)
    ds1.sort(key=lambda d: d["ma"])
    if khac:
        cb.append(f"{len(khac)} người là HĐ dưới 3 tháng hoặc không cư trú: kê ở phụ lục 05-2 trên HTKK "
                  "(hệ thống chưa xuất phụ lục này).")
    t1 = {"ct28": sum(d["tnct"] for d in ds1), "ct32": sum(d["npt"] for d in ds1),
          "ct33": sum(d["gt_gc"] for d in ds1), "ct35": sum(d["bh"] for d in ds1),
          "ct37": sum(d["tntt"] for d in ds1), "ct38": sum(d["thue"] for d in ds1)}
    ds3 = []
    for p in con.execute("SELECT p.*, n.ho_ten nv_ten, n.mst nv_mst, n.cccd nv_cccd FROM nguoi_phu_thuoc p "
                         "JOIN nhan_vien n ON n.cong_ty_id=p.cong_ty_id AND n.ma=p.ma_nv WHERE p.cong_ty_id=? "
                         "AND p.tu_thang<=? AND (p.den_thang IS NULL OR p.den_thang='' OR p.den_thang>=?) "
                         "ORDER BY p.ma_nv, p.id", (cid, f"{nam}-12", f"{nam}-01")):
        tu = max(p["tu_thang"], f"{nam}-01")
        den = min(p["den_thang"] or f"{nam}-12", f"{nam}-12")
        ma_qh, ten_qh = _ma_quan_he(p["quan_he"])
        ds3.append({"nv_ten": luong.lam_sach_ten(p["nv_ten"]), "nv_ma_so": (p["nv_mst"] or p["nv_cccd"] or "").strip(),
                    "ho_ten": luong.lam_sach_ten(p["ho_ten"]), "ngay_sinh": p["ngay_sinh"] or "",
                    "mst": (p["mst"] or "").strip(), "cccd": (p["cccd"] or "").strip(), "qh_ma": ma_qh,
                    "qh_ten": ten_qh, "tu": f"{tu[5:]}/{tu[:4]}", "den": f"{den[5:]}/{den[:4]}"})
        if not p["mst"] and not p["cccd"]:
            cb.append(f"Người phụ thuộc {p['ho_ten']} chưa có MST hoặc CCCD.")
    tat_ca = ds1 + khac
    chinh = {
        "ct16": len(tat_ca), "ct17": len(ds1),
        "ct18": sum(1 for d in tat_ca if d["thue"]), "ct19": sum(1 for d in tat_ca if d["thue"] and d["cu_tru"]),
        "ct20": sum(1 for d in tat_ca if d["thue"] and not d["cu_tru"]), "ct21": 0,
        "ct22": sum(1 for d in ds1 if d["gt_gc"]),
        "ct23": sum(d["tnct"] for d in tat_ca), "ct24": sum(d["tnct"] for d in tat_ca if d["cu_tru"]),
        "ct25": sum(d["tnct"] for d in tat_ca if not d["cu_tru"]), "ct26": 0, "ct27": 0,
        "ct28": sum(d["thue"] for d in tat_ca), "ct29": sum(d["thue"] for d in tat_ca if d["cu_tru"]),
        "ct30": sum(d["thue"] for d in tat_ca if not d["cu_tru"]),
        "ct35": sum(1 for d in ds1 if d["uy_quyen"]),
    }
    ps3335 = sum(c for k, (n, c) in bao_cao.phat_sinh(con, cid, f"{nam}-01-01", f"{nam}-12-31").items()
                 if k.startswith("3335"))
    if ps3335 != chinh["ct28"]:
        cb.append(f"Thuế TNCN theo bảng lương {_f(chinh['ct28'])} đ khác phát sinh Có 3335 trên sổ {_f(ps3335)} đ.")
    thang = {r["thang"] for r in con.execute("SELECT DISTINCT thang FROM bang_luong WHERE cong_ty_id=? AND thang LIKE ?",
                                             (cid, f"{nam}-%"))}
    if thang and len(thang) < 12:
        cb.append(f"Bảng lương mới có {len(thang)} tháng của năm {nam}.")
    return chinh, ds1, t1, ds3, cb


# ================================================================ BCTC tron bo

def bctc(con, cid, nam, mau=None, nguon_dau="tu_dong"):
    """Lap B01a, B02, bang CDTK nam `nam`.

    mau: bytes BCTC XML cua cong ty (nam nay hoac nam truoc). Neu nguon_dau la 'tu_dong' hoac 'mau'
    va mau dung nam, so dau nam / nam truoc lay theo so da nop; neu 'so' thi tinh tu so."""
    from . import htkk
    chuan_bi(con)
    tu, den = f"{nam}-01-01", f"{nam}-12-31"
    cuoi, cb = bao_cao.b01(con, cid, f"{nam + 1}-01-01")
    kq_nay = bao_cao.b02(con, cid, tu, den)
    if mau:
        tks = htkk.tk_trong_mau_bctc(mau)
    else:
        tks = [r["so_tk"] for r in con.execute("SELECT so_tk FROM tai_khoan WHERE cong_ty_id=? ORDER BY so_tk", (cid,))]
    cdtk, cb2 = bao_cao.cdtk_hai_ben(con, cid, tu, den, tks)
    cb += cb2
    dau = kq_truoc = None
    nguon = "sổ kế toán"
    if mau and nguon_dau in ("tu_dong", "mau"):
        tt, sc, sd, nn, nt, cd = htkk.doc_bctc(mau)
        y = int(tt["ky"] or 0)
        if y == nam:
            dau, kq_truoc, cot = sd, nt, (0, 1)
        elif y == nam - 1:
            dau, kq_truoc, cot = sc, nn, (4, 5)
        if dau is not None:
            nguon = f"BCTC năm {y} đã nộp"
            for tk, v in list(cdtk.items()):
                if tk in cd:
                    cdtk[tk] = (cd[tk][cot[0]], cd[tk][cot[1]]) + v[2:]
    if dau is None:
        dau, cb3 = bao_cao.b01(con, cid, tu)
        kq_truoc = bao_cao.b02(con, cid, f"{nam - 1}-01-01", f"{nam - 1}-12-31")
        cb += [x for x in cb3 if x not in cb]
    # doi chieu noi bo
    lech = [tk for tk, v in cdtk.items() if tk != "tongCong" and len(tk) == 3
            and (v[0] - v[1]) + v[2] - v[3] != v[4] - v[5]]
    if lech:
        cb.append(f"Số đầu năm ({nguon}) cộng phát sinh trên sổ không ra số cuối năm ở TK {', '.join(lech[:12])}"
                  f"{'…' if len(lech) > 12 else ''}: sổ chưa đủ chứng từ cả năm hoặc số đầu năm chưa khớp.")
    if cuoi["417"] - dau.get("417", 0) != kq_nay["60"]:
        cb.append(f"LNST năm theo B02 ({_f(kq_nay['60'])}) khác chênh lệch chỉ tiêu 417 cuối năm và đầu năm "
                  f"({_f(cuoi['417'] - dau.get('417', 0))}); nếu không có chia lợi nhuận thì sổ đang thiếu chứng từ.")
    if not con.execute("SELECT 1 FROM chung_tu WHERE cong_ty_id=? AND ngay_ht BETWEEN ? AND ?",
                       (cid, tu, f"{nam}-01-31")).fetchone():
        cb.append(f"Sổ không có chứng từ tháng 01/{nam}: B02 và phát sinh trong năm chỉ là một phần năm.")
    if kq_nay["50"] and con.execute("SELECT COUNT(*) n FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id "
                                    "WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ? AND (b.tk_no LIKE '911%' "
                                    "OR b.tk_co LIKE '911%')", (cid, tu, den)).fetchone()["n"] == 0:
        cb.append("Chưa kết chuyển cuối kỳ sang 911: chỉ tiêu 417 đã cộng tạm kết quả, nên bấm Kết chuyển.")
    return {"cuoi": cuoi, "dau": dau, "kq_nay": kq_nay, "kq_truoc": kq_truoc, "cdtk": cdtk,
            "canh_bao": cb, "nguon_dau": nguon}


def kiem_tra_mau(ct, tt):
    """So thong tin nguoi nop trong mau XML voi ho so cong ty."""
    cb = []
    if tt["mst"] and tt["mst"] != ct["mst"]:
        cb.append(f"Mẫu XML là của MST {tt['mst']}, không phải {ct['mst']}.")
    if tt["ten_nnt"] and tt["ten_nnt"].strip().upper() != ct["ten"].strip().upper():
        cb.append(f"Tên trong mẫu là '{tt['ten_nnt']}', khác tên công ty '{ct['ten']}'. File xuất ra sẽ dùng tên công ty.")
    return cb
