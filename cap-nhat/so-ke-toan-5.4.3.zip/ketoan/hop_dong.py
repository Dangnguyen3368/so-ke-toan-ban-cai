"""Hop dong mua, ban: theo doi gia tri hop dong, hoa don da xuat / nhan theo hop dong, thanh toan va han hop dong.

- Hoa don gan vao hop dong qua bang hop_dong_hoa_don (tu goi y: hoa don cua dung doi tac trong thoi han hop dong).
- Thanh toan: tien doi tac da tra (ban: Co 131) / minh da tra (mua: No 331) theo ma doi tuong, tu ngay ky,
  phan bo lan luot cho cac hop dong cua cung doi tac theo ngay ky (cu truoc).
"""
from datetime import date, timedelta

SCHEMA = """
CREATE TABLE IF NOT EXISTS hop_dong (
    id INTEGER PRIMARY KEY,
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    loai TEXT NOT NULL,                     -- 'ban' | 'mua'
    so_hd TEXT NOT NULL,
    ten_doi_tac TEXT NOT NULL,
    mst_doi_tac TEXT NOT NULL DEFAULT '',
    ma_doi_tuong TEXT NOT NULL DEFAULT '',
    ngay_ky TEXT NOT NULL,
    ngay_het_han TEXT,
    gia_tri INTEGER NOT NULL DEFAULT 0,     -- gia tri hop dong gom thue
    noi_dung TEXT,
    trang_thai TEXT NOT NULL DEFAULT 'dang',  -- dang | thanh_ly | huy
    UNIQUE (cong_ty_id, loai, so_hd)
);
CREATE TABLE IF NOT EXISTS hop_dong_hoa_don (
    hop_dong_id INTEGER NOT NULL REFERENCES hop_dong(id) ON DELETE CASCADE,
    hoa_don_id INTEGER NOT NULL UNIQUE,
    PRIMARY KEY (hop_dong_id, hoa_don_id)
);
"""

LOAI = {"ban": "Hợp đồng bán", "mua": "Hợp đồng mua"}
TRANG_THAI = {"dang": "Đang thực hiện", "thanh_ly": "Đã thanh lý", "huy": "Đã hủy"}


def chuan_bi(con):
    from . import hoa_don
    hoa_don.chuan_bi(con)
    con.executescript(SCHEMA)


def _ma_theo_mst(con, cid, mst):
    if not mst or not con.execute("SELECT 1 FROM sqlite_master WHERE name='doi_tuong'").fetchone():
        return ""
    r = con.execute("SELECT ma FROM doi_tuong WHERE cong_ty_id=? AND mst=? ORDER BY ma LIMIT 1", (cid, mst)).fetchone()
    return r["ma"] if r else ""


def them(con, cid, d):
    chuan_bi(con)
    v = {k: (d.get(k) or "").strip() if isinstance(d.get(k), str) else d.get(k) for k in
         ("loai", "so_hd", "ten_doi_tac", "mst_doi_tac", "ma_doi_tuong", "ngay_ky", "ngay_het_han", "gia_tri", "noi_dung")}
    if v["loai"] not in LOAI:
        raise ValueError("Chọn hợp đồng mua hay bán.")
    if not v["so_hd"] or not v["ten_doi_tac"] or not v["ngay_ky"]:
        raise ValueError("Cần số hợp đồng, đối tác và ngày ký.")
    date.fromisoformat(v["ngay_ky"])
    if v["ngay_het_han"]:
        date.fromisoformat(v["ngay_het_han"])
    v["gia_tri"] = int(v["gia_tri"] or 0)
    v["ma_doi_tuong"] = v["ma_doi_tuong"] or _ma_theo_mst(con, cid, v["mst_doi_tac"])
    v = {k: x for k, x in v.items() if x not in (None, "")} | {"gia_tri": v["gia_tri"]}
    cur = con.execute(f"INSERT INTO hop_dong (cong_ty_id, {', '.join(v)}) VALUES (?{', ?' * len(v)})", [cid, *v.values()])
    hid = cur.lastrowid
    gan_tu_dong(con, cid, hid)
    con.commit()
    return hid


def lay(con, cid, hid):
    chuan_bi(con)
    return con.execute("SELECT * FROM hop_dong WHERE cong_ty_id=? AND id=?", (cid, hid)).fetchone()


def danh_sach(con, cid, loai=None):
    chuan_bi(con)
    q, a = "SELECT * FROM hop_dong WHERE cong_ty_id=?", [cid]
    if loai:
        q, a = q + " AND loai=?", a + [loai]
    return con.execute(q + " ORDER BY ngay_ky DESC, so_hd", a).fetchall()


def hoa_don_cua(con, hid):
    return con.execute("SELECT h.* FROM hoa_don h JOIN hop_dong_hoa_don x ON x.hoa_don_id=h.id WHERE x.hop_dong_id=? "
                       "ORDER BY h.ngay_lap", (hid,)).fetchall()


def goi_y_hoa_don(con, cid, hd):
    """Hoa don cua dung doi tac (theo MST), trong thoi han hop dong, chua gan hop dong nao."""
    if not hd["mst_doi_tac"]:
        return []
    cot = "nmmst" if hd["loai"] == "ban" else "nbmst"
    den = hd["ngay_het_han"] or "9999-12-31"
    return con.execute(f"SELECT * FROM hoa_don WHERE cong_ty_id=? AND chieu=? AND {cot}=? AND ngay_lap BETWEEN ? AND ? "
                       "AND trang_thai NOT IN (4, 6) AND id NOT IN (SELECT hoa_don_id FROM hop_dong_hoa_don) ORDER BY ngay_lap",
                       (cid, hd["loai"], hd["mst_doi_tac"], hd["ngay_ky"], den)).fetchall()


def gan(con, hid, ids):
    for i in ids:
        con.execute("INSERT OR IGNORE INTO hop_dong_hoa_don VALUES (?,?)", (hid, int(i)))
    con.commit()


def bo_gan(con, hid, hoa_don_id):
    con.execute("DELETE FROM hop_dong_hoa_don WHERE hop_dong_id=? AND hoa_don_id=?", (hid, int(hoa_don_id)))
    con.commit()


def gan_tu_dong(con, cid, hid):
    hd = lay(con, cid, hid)
    ds = goi_y_hoa_don(con, cid, hd)
    gan(con, hid, [h["id"] for h in ds])
    return len(ds)


def _da_thanh_toan_doi_tac(con, cid, loai, ma, tu):
    """Tong tien doi tac da thanh toan (ban) / minh da tra (mua) tu ngay `tu`, theo ma doi tuong."""
    if loai == "ban":
        q = ("SELECT SUM(b.so_tien) s FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? "
             "AND b.tk_co LIKE '131%' AND b.doi_tuong_co=? AND c.ngay_ht>=? AND b.tk_no NOT LIKE '511%' AND b.tk_no NOT LIKE '3331%'")
    else:
        q = ("SELECT SUM(b.so_tien) s FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? "
             "AND b.tk_no LIKE '331%' AND b.doi_tuong_no=? AND c.ngay_ht>=? AND b.tk_co NOT LIKE '133%'")
    return con.execute(q, (cid, ma, tu)).fetchone()["s"] or 0


def tinh_hinh(con, cid, hd, hom_nay=None):
    """dict: da_hoa_don, con_hoa_don, da_tt, con_tt, sap_het (so ngay con lai hoac None), co_tt (co tinh duoc thanh toan)."""
    hn = hom_nay or date.today()
    hds = hoa_don_cua(con, hd["id"])
    da_hd = sum(h["tong_tien"] for h in hds)
    da_tt, co_tt = 0, bool(hd["ma_doi_tuong"])
    if co_tt:
        cung = [x for x in con.execute("SELECT * FROM hop_dong WHERE cong_ty_id=? AND loai=? AND ma_doi_tuong=? AND trang_thai!='huy' "
                                       "ORDER BY ngay_ky, id", (cid, hd["loai"], hd["ma_doi_tuong"]))]
        con_lai = _da_thanh_toan_doi_tac(con, cid, hd["loai"], hd["ma_doi_tuong"], cung[0]["ngay_ky"]) if cung else 0
        for x in cung:  # phan bo FIFO theo gia tri hop dong (hoac hoa don da xuat neu lon hon)
            can = max(x["gia_tri"], sum(h["tong_tien"] for h in hoa_don_cua(con, x["id"])))
            phan = min(con_lai, can)
            con_lai -= phan
            if x["id"] == hd["id"]:
                da_tt = phan
    con_ngay = (date.fromisoformat(hd["ngay_het_han"]) - hn).days if hd["ngay_het_han"] else None
    return {"hoa_don": hds, "da_hoa_don": da_hd, "con_hoa_don": max(hd["gia_tri"] - da_hd, 0), "da_tt": da_tt,
            "con_tt": max(max(hd["gia_tri"], da_hd) - da_tt, 0), "co_tt": co_tt, "con_ngay": con_ngay}


def viec(con, cid, hom_nay=None):
    chuan_bi(con)
    hn = hom_nay or date.today()
    v = []
    for hd in con.execute("SELECT * FROM hop_dong WHERE cong_ty_id=? AND trang_thai='dang' AND ngay_het_han IS NOT NULL "
                          "AND ngay_het_han<=?", (cid, (hn + timedelta(days=15)).isoformat())):
        con_ngay = (date.fromisoformat(hd["ngay_het_han"]) - hn).days
        v.append(("do" if con_ngay < 0 else "vang",
                  f"{LOAI[hd['loai']]} {hd['so_hd']} ({hd['ten_doi_tac']}) "
                  + (f"đã hết hạn {-con_ngay} ngày, chưa thanh lý" if con_ngay < 0 else f"hết hạn sau {con_ngay} ngày"),
                  f"hopdong/{hd['id']}"))
    return v
