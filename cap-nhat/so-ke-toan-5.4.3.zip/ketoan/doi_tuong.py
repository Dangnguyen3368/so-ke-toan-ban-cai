"""Danh muc doi tuong: khach hang, nha cung cap, nhan vien, doi tuong khac cua tung cong ty.

Ma doi tuong la ma dung trong cot doi_tuong_no / doi_tuong_co cua but toan. Doi tac tu hoa don
dien tu dung ma = MST. Danh muc tu bo sung tu hoa don, bang cong no MISA, nhan vien.
"""
import io
import re

from openpyxl import Workbook, load_workbook

SCHEMA = """
CREATE TABLE IF NOT EXISTS doi_tuong (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    ma TEXT NOT NULL,
    ten TEXT NOT NULL,
    loai TEXT NOT NULL DEFAULT 'KH',      -- KH, NCC, NV, KHAC
    mst TEXT, dia_chi TEXT, dien_thoai TEXT, email TEXT, ghi_chu TEXT,
    PRIMARY KEY (cong_ty_id, ma)
);
"""
LOAI = {"KH": "Khách hàng", "NCC": "Nhà cung cấp", "NV": "Nhân viên", "KHAC": "Khác"}
COT = ["ma", "ten", "loai", "mst", "dia_chi", "dien_thoai", "email", "ghi_chu"]
TIEU_DE = ["Mã", "Tên", "Loại (KH/NCC/NV/KHAC)", "Mã số thuế", "Địa chỉ", "Điện thoại", "Email", "Ghi chú"]


def chuan_bi(con):
    con.executescript(SCHEMA)


def _co_bang(con, ten):
    return con.execute("SELECT 1 FROM sqlite_master WHERE name=?", (ten,)).fetchone() is not None


def luu(con, cid, d, ghi_de=True):
    """Them hoac sua mot doi tuong. d: dict theo COT (ma, ten bat buoc)."""
    d = {k: (str(d.get(k)).strip() if d.get(k) not in (None, "") else None) for k in COT}
    if not d["ma"] or not d["ten"]:
        raise ValueError("Cần có mã và tên đối tượng")
    d["loai"] = (d["loai"] or "KH").upper()
    if d["loai"] not in LOAI:
        raise ValueError(f"Loại '{d['loai']}' không hợp lệ (KH, NCC, NV, KHAC)")
    if ghi_de:
        con.execute(f"INSERT OR REPLACE INTO doi_tuong (cong_ty_id, {', '.join(COT)}) VALUES (?{', ?' * len(COT)})",
                    [cid] + [d[k] for k in COT])
    else:
        con.execute(f"INSERT OR IGNORE INTO doi_tuong (cong_ty_id, {', '.join(COT)}) VALUES (?{', ?' * len(COT)})",
                    [cid] + [d[k] for k in COT])


def xoa(con, cid, ma):
    con.execute("DELETE FROM doi_tuong WHERE cong_ty_id=? AND ma=?", (cid, ma))
    con.commit()


def lay(con, cid, ma):
    chuan_bi(con)
    return con.execute("SELECT * FROM doi_tuong WHERE cong_ty_id=? AND ma=?", (cid, ma or "")).fetchone()


def danh_sach(con, cid, loai="", tim=""):
    chuan_bi(con)
    dk, ts = ["cong_ty_id=?"], [cid]
    if loai:
        dk.append("loai=?")
        ts.append(loai)
    if tim:
        dk.append("(ma LIKE ? OR ten LIKE ? OR COALESCE(mst,'') LIKE ?)")
        ts += [f"%{tim}%"] * 3
    return con.execute(f"SELECT * FROM doi_tuong WHERE {' AND '.join(dk)} ORDER BY loai, ten", ts).fetchall()


def _dia_chi_xml(xml, the):
    """Lay dia chi nguoi ban / nguoi mua tu XML hoa don."""
    if not xml:
        return None
    m = re.search(rf"<{the}>(.*?)</{the}>", xml, re.S)
    if not m:
        return None
    d = re.search(r"<DChi>(.*?)</DChi>", m.group(1), re.S)
    return d.group(1).strip() if d else None


def tu_bo_sung(con, cid):
    """Them vao danh muc cac doi tuong chua co, lay tu hoa don, bang cong no MISA, nhan vien, but toan.
    Khong sua doi tuong da co. Tra ve so doi tuong moi."""
    chuan_bi(con)
    truoc = con.execute("SELECT COUNT(*) FROM doi_tuong WHERE cong_ty_id=?", (cid,)).fetchone()[0]
    if _co_bang(con, "hoa_don"):
        ct = con.execute("SELECT mst FROM cong_ty WHERE id=?", (cid,)).fetchone()
        mst_minh = ct["mst"] if ct else ""
        for r in con.execute("SELECT nbmst m, nb_ten t, 'NCC' l, xml, 'NBan' the FROM hoa_don WHERE cong_ty_id=? AND chieu='mua' "
                             "UNION ALL SELECT nmmst, nm_ten, 'KH', xml, 'NMua' FROM hoa_don WHERE cong_ty_id=? AND chieu='ban' "
                             "AND COALESCE(nmmst,'')!=''", (cid, cid)).fetchall():
            if r["m"] and r["m"] != mst_minh and r["t"]:
                luu(con, cid, {"ma": r["m"], "ten": r["t"], "loai": r["l"], "mst": r["m"],
                               "dia_chi": _dia_chi_xml(r["xml"], r["the"])}, ghi_de=False)
    if _co_bang(con, "cong_no_doi_tuong"):
        for r in con.execute("SELECT DISTINCT ma, ten, so_tk FROM cong_no_doi_tuong WHERE cong_ty_id=?", (cid,)).fetchall():
            if r["ma"] and r["ten"]:
                luu(con, cid, {"ma": r["ma"], "ten": r["ten"], "loai": "KH" if r["so_tk"].startswith("131") else "NCC"},
                    ghi_de=False)
    if _co_bang(con, "nhan_vien"):
        for r in con.execute("SELECT ma, ho_ten, mst FROM nhan_vien WHERE cong_ty_id=?", (cid,)).fetchall():
            luu(con, cid, {"ma": r["ma"], "ten": r["ho_ten"], "loai": "NV", "mst": r["mst"]}, ghi_de=False)
    for r in con.execute("SELECT DISTINCT b.doi_tuong_no m, b.tk_no tk FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id "
                         "WHERE c.cong_ty_id=? AND b.doi_tuong_no!='' UNION SELECT DISTINCT b.doi_tuong_co, b.tk_co FROM but_toan b "
                         "JOIN chung_tu c ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? AND b.doi_tuong_co!=''", (cid, cid)).fetchall():
        loai = "KH" if r["tk"].startswith("131") else "NCC" if r["tk"].startswith("331") else "NV" if r["tk"].startswith(("334", "141")) else "KHAC"
        luu(con, cid, {"ma": r["m"], "ten": r["m"], "loai": loai}, ghi_de=False)
    con.commit()
    return con.execute("SELECT COUNT(*) FROM doi_tuong WHERE cong_ty_id=?", (cid,)).fetchone()[0] - truoc


def mau_excel(con, cid):
    wb = Workbook()
    ws = wb.active
    ws.title = "DoiTuong"
    ws.append(TIEU_DE)
    for r in danh_sach(con, cid):
        ws.append([r[k] for k in COT])
    for c, w in zip("ABCDEFGH", (14, 45, 12, 15, 50, 14, 24, 20)):
        ws.column_dimensions[c].width = w
    ws.freeze_panes = "A2"
    b = io.BytesIO()
    wb.save(b)
    return b.getvalue()


def _kd(s):
    from .sao_ke import khong_dau
    return khong_dau(str(s or "")).lower().strip()


def nap_excel(con, cid, du_lieu):
    """Nap danh muc tu Excel (mau cua ung dung hoac danh sach khach hang / NCC xuat tu MISA).
    Tim dong tieu de co cot ma va ten. Tra ve (so dong luu, list loi)."""
    wb = load_workbook(io.BytesIO(du_lieu), read_only=True, data_only=True)
    n, loi = 0, []
    for ws in wb.worksheets:
        dong = list(ws.iter_rows(values_only=True))
        for i, h in enumerate(dong[:15]):
            ten_cot = [_kd(x) for x in h]
            vi_tri = {}
            for j, t in enumerate(ten_cot):
                if not t:
                    continue
                if "ma so thue" in t or t in ("mst", "ma so thue"):
                    vi_tri.setdefault("mst", j)
                elif t.startswith("ma") and "ma" not in vi_tri:
                    vi_tri["ma"] = j
                elif t.startswith("ten") and "ten" not in vi_tri:
                    vi_tri["ten"] = j
                elif "dia chi" in t:
                    vi_tri.setdefault("dia_chi", j)
                elif "dien thoai" in t or t == "dt":
                    vi_tri.setdefault("dien_thoai", j)
                elif "email" in t:
                    vi_tri.setdefault("email", j)
                elif t.startswith("loai"):
                    vi_tri.setdefault("loai", j)
                elif "ghi chu" in t:
                    vi_tri.setdefault("ghi_chu", j)
            if "ma" in vi_tri and "ten" in vi_tri:
                loai_ws = "NCC" if "cung cap" in _kd(ws.title) else "NV" if "nhan vien" in _kd(ws.title) else "KH"
                for k, h2 in enumerate(dong[i + 1:], i + 2):
                    d = {c: (h2[j] if j < len(h2) else None) for c, j in vi_tri.items()}
                    if not d.get("ma") or not d.get("ten"):
                        continue
                    d.setdefault("loai", loai_ws)
                    lo = _kd(d.get("loai"))
                    d["loai"] = ("NCC" if "cung cap" in lo or lo == "ncc" else "NV" if "nhan vien" in lo or lo == "nv"
                                 else "KHAC" if lo == "khac" else "KH" if lo else loai_ws)
                    try:
                        luu(con, cid, d)
                        n += 1
                    except ValueError as ex:
                        loi.append(f"{ws.title} dòng {k}: {ex}")
                break
    con.commit()
    if not n and not loi:
        loi.append("Không tìm thấy dòng tiêu đề có cột Mã và Tên.")
    return n, loi
