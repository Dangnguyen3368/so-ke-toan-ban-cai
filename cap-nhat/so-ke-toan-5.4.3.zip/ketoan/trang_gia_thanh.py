"""Trang Gia thanh (tron vao lop XuLy): doi tuong tinh gia thanh, tong hop chi phi, phan bo, the tinh gia thanh, ket chuyen."""
from datetime import date

from . import che_do, gia_thanh
from . import giao_dien as G
from .giao_dien import e, ngay_vn, so

KM = gia_thanh.KHOAN_MUC


def _so(s):
    s = (s or "").strip().replace(".", "").replace(",", "").replace(" ", "")
    return int(s) if s.isdigit() else 0


class TrangGiaThanh:
    def giathanh(self, pt, con, ct, q, rest):
        gia_thanh.chuan_bi(con)
        cid = ct["id"]
        nam = G.ky_mac_dinh(q)[0][:4]
        tu, den = q.get("tu", f"{nam}-01-01"), q.get("den", f"{nam}-12-31")
        if rest and rest[0].isdigit():
            return self._gt_xem(pt, con, ct, int(rest[0]), tu, den)
        tb = ""
        if pt == "POST":
            f = {k: v[0].strip() for k, v in self.doc_form().items()}
            try:
                hd = f.get("hanh_dong")
                if hd == "them":
                    f["du_toan"] = _so(f.get("du_toan"))
                    gia_thanh.them(con, cid, f)
                    tb = '<p class="ok">Đã thêm đối tượng.</p>'
                elif hd == "phan_bo":
                    kq = gia_thanh.phan_bo(con, cid, f["tu"], f["den"], f.get("tieu_thuc", "nvl"))
                    tb = (f'<p class="ok">Đã phân bổ {so(sum(kq.values()))} đ cho {len(kq)} đối tượng.</p>' if kq else
                          '<p class="ok">Không còn chi phí chung chưa phân bổ trong kỳ.</p>')
                elif hd == "kc_tg":
                    n = gia_thanh.ket_chuyen_trung_gian(con, cid, f["tu"], f["den"])
                    tb = f'<p class="ok">Đã kết chuyển {n} dòng 621, 622, 623, 627 sang 154.</p>' if n else '<p class="ok">Không có số dư 621-627 cần kết chuyển.</p>'
            except Exception as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        dong = ""
        tong = {"dau": 0, "ps": 0, "ra": 0, "cuoi": 0}
        for d, r in gia_thanh.tong_hop(con, cid, tu, den):
            dau, ps = sum(r["dau"].values()), sum(r["ps"].values())
            if not (dau or ps or r["ra"]) and d["trang_thai"] == "xong":
                continue
            for k, v in (("dau", dau), ("ps", ps), ("ra", r["ra"]), ("cuoi", r["cuoi"])):
                tong[k] += v
            dong += (f'<tr><td><a href="/cty/{cid}/giathanh/{d["id"]}?tu={tu}&den={den}"><b>{e(d["ma"])}</b></a></td><td>{e(d["ten"])}<br>'
                     f'<span class="mo">{gia_thanh.LOAI[d["loai"]]}</span></td><td class="s">{so(dau)}</td>'
                     + "".join(f'<td class="s">{so(r["ps"][k])}</td>' for k, _ in KM)
                     + f'<td class="s">{so(r["ra"])}</td><td class="s">{so(r["cuoi"])}</td>'
                     f'<td>{G.nhan_tt("Hoàn thành", "xanh") if d["trang_thai"] == "xong" else G.nhan_tt("Đang làm", "lam")}</td></tr>')
        chung = gia_thanh.chi_phi_chung_chua_phan_bo(con, cid, tu, den)
        tt99 = che_do.ma(ct) == "TT99"
        chon = "".join(f'<option value="{m}">{t}</option>' for m, t in gia_thanh.LOAI.items())
        nd = f"""<div class="luoi">{G.o_so("Chi phí phát sinh trong kỳ", so(tong["ps"]) or "0")}{G.o_so("Đã kết chuyển giá thành", so(tong["ra"]) or "0")}
{G.o_so("Dở dang cuối kỳ", so(tong["cuoi"]) or "0")}{G.o_so("Chi phí chung chưa phân bổ", so(chung) or "0", "TK 154 chưa gắn đối tượng")}</div>
<div class="the"><h1>Giá thành</h1>{tb}{G.form_ky(tu, den)}
<table><tr><th>Mã</th><th>Đối tượng</th><th class="s">Dở dang đầu kỳ</th>{"".join(f'<th class="s">{t}</th>' for _, t in KM)}
<th class="s">Kết chuyển giá thành</th><th class="s">Dở dang cuối kỳ</th><th></th></tr>{dong}
<tr class="tong"><td colspan="2">Cộng</td><td class="s">{so(tong["dau"])}</td><td colspan="4"></td><td class="s">{so(tong["ra"])}</td>
<td class="s">{so(tong["cuoi"])}</td><td></td></tr></table>
<p class="mo">Chi phí của đối tượng là các bút toán Nợ 154 có mã đối tượng bằng mã ở đây: phiếu xuất kho cho công trình
(ghi tên công trình đúng mã), chứng từ nhập tay chọn đối tượng, phân bổ chi phí chung.</p></div>
<div class="hai-cot"><div class="the"><h2>Cuối kỳ</h2>
{'<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="kc_tg">'
 f'<input type="hidden" name="tu" value="{tu}"><input type="hidden" name="den" value="{den}">'
 '<button class="phu">Kết chuyển 621, 622, 623, 627 sang 154</button></form>' if tt99 else ''}
<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="phan_bo"><input type="hidden" name="tu" value="{tu}">
<input type="hidden" name="den" value="{den}"><label>Phân bổ chi phí chung theo<select name="tieu_thuc">
<option value="nvl">Chi phí nguyên vật liệu trong kỳ</option><option value="du_toan">Dự toán</option></select></label>
<button>Phân bổ {so(chung) or 0} đ</button></form>
<p class="mo">Khi công trình, đơn hàng hoàn thành: mở đối tượng và bấm Kết chuyển giá thành (Nợ 632 hoặc 155 / Có 154).</p></div>
<details class="the"><summary>Thêm đối tượng tính giá thành</summary><form method="post" class="ngang" style="margin-top:12px">
<input type="hidden" name="hanh_dong" value="them"><label>Mã<input name="ma" required size="10"></label>
<label>Tên<input name="ten" required size="30"></label><label>Loại<select name="loai">{chon}</select></label>
<label>Dự toán<input name="du_toan" size="12"></label><label>Ngày bắt đầu<input type="date" name="ngay_bat_dau"></label>
<button>Thêm</button></form></details></div>"""
        self.gui(G.trang("Giá thành", nd, cid, ct["ten"]))

    def _gt_xem(self, pt, con, ct, did, tu, den):
        cid = ct["id"]
        d = gia_thanh.lay(con, cid, did)
        if not d:
            return self.gui(G.trang("Không tìm thấy", "<p>Không có đối tượng này.</p>", cid, ct["ten"]), 404)
        tb = ""
        if pt == "POST":
            f = {k: v[0].strip() for k, v in self.doc_form().items()}
            try:
                gia_thanh.hoan_thanh(con, cid, did, f.get("ngay") or den, f.get("tk_no") or None,
                                     _so(f["so_tien"]) if f.get("so_tien") else None)
                tb = '<p class="ok">Đã kết chuyển giá thành.</p>'
                d = gia_thanh.lay(con, cid, did)
            except Exception as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        r = gia_thanh.tinh(con, cid, d["ma"], tu, den)
        hang = "".join(f'<tr><td>{t}</td><td class="s">{so(r["dau"][k])}</td><td class="s">{so(r["ps"][k])}</td>'
                       f'<td class="s">{so(r["dau"][k] + r["ps"][k])}</td></tr>' for k, t in KM)
        tdau, tps = sum(r["dau"].values()), sum(r["ps"].values())
        ten_km = dict(KM)
        ct_dong = "".join(f'<tr><td>{ngay_vn(x["ngay_ht"])}</td><td>{e(x["so_ct"])}</td><td>{e(x["dg"])}</td>'
                          f'<td>{e(ten_km.get(x["km"], ""))}</td><td class="s">{so(x["no"])}</td><td class="s">{so(x["co"])}</td></tr>'
                          for x in r["dong"])
        tk_md = "155" if d["loai"] == "san_pham" else "632"
        nd = f"""<div class="luoi">{G.o_so("Dự toán", so(d["du_toan"]) or "—")}{G.o_so("Dở dang đầu kỳ", so(tdau) or "0")}
{G.o_so("Phát sinh trong kỳ", so(tps) or "0")}{G.o_so("Dở dang cuối kỳ", so(r["cuoi"]) or "0")}</div>
<div class="the"><h1>Thẻ tính giá thành: {e(d["ma"])} · {e(d["ten"])}</h1>{tb}{G.form_ky(tu, den)}
<table><tr><th>Khoản mục</th><th class="s">Dở dang đầu kỳ</th><th class="s">Phát sinh trong kỳ</th><th class="s">Cộng</th></tr>{hang}
<tr class="tong"><td>Tổng</td><td class="s">{so(tdau)}</td><td class="s">{so(tps)}</td><td class="s">{so(tdau + tps)}</td></tr>
<tr><td colspan="3">Đã kết chuyển giá thành trong kỳ</td><td class="s">{so(r["ra"])}</td></tr>
<tr class="tong"><td colspan="3">Dở dang cuối kỳ</td><td class="s">{so(r["cuoi"])}</td></tr></table>
{'' if d["trang_thai"] == "xong" else f'''<form method="post" class="ngang" style="margin-top:12px">
<label>Ngày<input type="date" name="ngay" value="{den if den <= date.today().isoformat() else date.today().isoformat()}"></label>
<label>Nợ TK<select name="tk_no"><option value="{tk_md}">{tk_md}</option><option value="{"632" if tk_md == "155" else "155"}">{"632" if tk_md == "155" else "155"}</option></select></label>
<label>Số tiền (để trống = toàn bộ dở dang)<input name="so_tien" size="14"></label><button>Kết chuyển giá thành</button></form>'''}</div>
<div class="the"><h2>Chi tiết phát sinh</h2><table><tr><th>Ngày</th><th>Số CT</th><th>Diễn giải</th><th>Khoản mục</th>
<th class="s">Nợ 154</th><th class="s">Có 154</th></tr>{ct_dong}</table>
<p><a class="nut phu nho" href="/cty/{cid}/giathanh?tu={tu}&den={den}">← Giá thành</a></p></div>"""
        self.gui(G.trang(f"Giá thành {d['ma']}", nd, cid, ct["ten"]))
