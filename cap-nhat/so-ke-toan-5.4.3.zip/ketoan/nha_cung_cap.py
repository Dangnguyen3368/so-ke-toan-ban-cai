"""Danh sach nha cung cap hoa don dien tu de chon cho tung cong ty.

Tat ca nha cung cap deu xuat XML theo cung dinh dang cua Tong cuc Thue, nen
ung dung nap duoc hoa don cua bat ky ai. Lua chon nha cung cap chi de hien
huong dan lay file phu hop.
"""

NHA_CUNG_CAP = [
    ("viettel", "Viettel S-Invoice"),
    ("vnpt", "VNPT Invoice"),
    ("misa", "MISA meInvoice"),
    ("bkav", "BKAV eHoaDon"),
    ("fpt", "FPT eInvoice"),
    ("easy", "EasyInvoice (SoftDreams)"),
    ("mobifone", "MobiFone Invoice"),
    ("minvoice", "M-Invoice"),
    ("cyberbill", "CyberBill"),
    ("thaison", "Thái Sơn E-invoice"),
    ("cmc", "CMC eInvoice"),
    ("khac", "Nhà cung cấp khác"),
    ("cong_thue", "Lập trực tiếp trên cổng thuế (không qua nhà cung cấp)"),
]

TEN = dict(NHA_CUNG_CAP)

HUONG_DAN_CHUNG = (
    "Cách nhanh nhất cho mọi nhà cung cấp là dùng nút \"Tải từ cổng thuế\": cổng hoadondientu.gdt.gov.vn "
    "có đủ hóa đơn bán ra và mua vào của mọi nhà cung cấp. Khi cần lấy từ nhà cung cấp: vào trang quản lý "
    "hóa đơn của họ, mở danh sách hóa đơn đã phát hành, chọn kỳ, chọn tất cả và dùng chức năng tải/xuất "
    "XML hàng loạt (tên nút mỗi nơi một khác). Được file ZIP thì nạp nguyên file ZIP vào đây, không cần giải nén."
)


def huong_dan(ma):
    if ma == "cong_thue":
        return ("Hóa đơn lập trên cổng thuế: dùng nút \"Tải từ cổng thuế\", hoặc trên cổng vào Tra cứu hóa đơn, "
                "xuất Excel danh sách và tải XML từng hóa đơn rồi nạp vào đây.")
    return HUONG_DAN_CHUNG
