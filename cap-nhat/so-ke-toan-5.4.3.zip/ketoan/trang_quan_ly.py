"""Cac trang quan ly (tron vao lop XuLy): bang dieu khien, viec can lam, danh sach / sua / xoa / in chung tu,
ngan hang, cong no, so quy / tien gui / vat tu, luu chuyen tien te, doi chieu, khoa so va nhat ky sua."""
import json
from datetime import date
from urllib.parse import quote

from . import bao_cao, doi_tuong, giao_dien as G, hoa_don, kho, quan_ly, sao_ke, so_sach
from .giao_dien import e, ngay_vn, so

LOAI_CT = {"PT": "Phiếu thu", "PC": "Phiếu chi", "BC": "Báo có", "BN": "Báo nợ", "NTTK": "Nộp tiền vào TK",
           "UNC": "Ủy nhiệm chi", "BH": "Bán hàng", "MH": "Mua hàng", "NV": "Nghiệp vụ khác", "LUONG": "Lương",
           "KH": "Khấu hao", "XK": "Xuất kho", "KC": "Kết chuyển"}
NGUON = {"misa": "MISA", "hddt": "Hóa đơn", "saoke": "Sao kê", "tay": "Nhập tay", "luong": "Lương",
         "ket_chuyen": "Kết chuyển", "kho": "Kho", "tai_san": "Tài sản", "vay": "Khế ước vay"}
TK_CONG_NO = [("131", "Phải thu khách hàng"), ("331", "Phải trả người bán"), ("1388", "Phải thu khác"),
              ("141", "Tạm ứng"), ("334", "Phải trả người lao động"), ("3388", "Phải trả khác")]


def _so_nguyen(s):
    s = (s or "").strip().replace(".", "").replace(",", "").replace(" ", "")
    return int(s) if s.lstrip("-").isdigit() else 0


def _ds_tk(con, cid):
    return "".join(f'<option value="{e(t["so_tk"])}">{e(t["ten"])}</option>' for t in
                   con.execute("SELECT so_tk, ten FROM tai_khoan WHERE cong_ty_id=? ORDER BY so_tk", (cid,)))


def _ngay_du_lieu(con, cid):
    r = con.execute("SELECT MAX(ngay_ht) n FROM chung_tu WHERE cong_ty_id=?", (cid,)).fetchone()
    return r["n"] or date.today().isoformat()


def gan_doi_tuong(d, ma):
    """Gan ma doi tuong vao ben No/Co co TK cong no."""
    if ma:
        if d["tk_no"].startswith(bao_cao.TACH_DOI_TUONG):
            d["doi_tuong_no"] = ma
        if d["tk_co"].startswith(bao_cao.TACH_DOI_TUONG):
            d["doi_tuong_co"] = ma
    return d


def doc_dong_but_toan(f, dien_giai_chung=""):
    """Doc cac dong dinh khoan tu form (tk_no[], tk_co[], so_tien[], dg[], dt[])."""
    dong = []
    n = len(f.get("tk_no", []))
    lay = lambda k, i: (f.get(k) or [""] * n)[i] if i < len(f.get(k) or []) else ""
    for i in range(n):
        tn, tc, st = lay("tk_no", i).strip(), lay("tk_co", i).strip(), lay("so_tien", i)
        if tn or tc or st.strip():
            if not (tn and tc):
                raise ValueError(f"Dòng {i + 1}: thiếu TK Nợ hoặc TK Có")
            dong.append(gan_doi_tuong({"tk_no": tn, "tk_co": tc, "so_tien": _so_nguyen(st),
                                       "dien_giai": lay("dg", i).strip() or dien_giai_chung}, lay("dt", i).strip()))
    if not dong:
        raise ValueError("Chưa có dòng định khoản nào.")
    return dong


def bang_nhap_dong(dong, so_dong=6):
    """Bang nhap dinh khoan (dung cho nhap moi va sua)."""
    hang = ""
    for d in list(dong) + [None] * max(so_dong - len(dong), 2):
        g = (lambda k: e(d[k] if d and d[k] is not None else "")) if d else (lambda k: "")
        dt = (d["doi_tuong_no"] or d["doi_tuong_co"]) if d else ""
        hang += (f'<tr><td><input name="tk_no" size="8" list="dstk" value="{g("tk_no")}"></td>'
                 f'<td><input name="tk_co" size="8" list="dstk" value="{g("tk_co")}"></td>'
                 f'<td><input name="so_tien" size="15" inputmode="numeric" value="{so(d["so_tien"]) if d else ""}"></td>'
                 f'<td><input name="dt" size="12" list="dsdt" value="{e(dt)}"></td>'
                 f'<td><input name="dg" size="46" value="{g("dien_giai")}"></td></tr>')
    return ('<table><tr><th>TK Nợ</th><th>TK Có</th><th>Số tiền</th><th>Đối tượng (mã KH/NCC/NV)</th><th>Diễn giải dòng</th></tr>'
            + hang + "</table>")


def ds_doi_tuong(con, cid):
    return "".join(f'<option value="{e(m)}">{e(t)}</option>' for m, t in sorted(quan_ly.ten_doi_tuong(con, cid).items()))


class TrangQuanLy:
    # ------------------------------------------------------------ bang dieu khien
    def tong_quan(self, pt, con, ct, q, _):
        cid = ct["id"]
        ngay = _ngay_du_lieu(con, cid)
        nam = ngay[:4]
        r = con.execute("SELECT COUNT(*) n, MIN(ngay_ht) a, MAX(ngay_ht) b FROM chung_tu WHERE cong_ty_id=?", (cid,)).fetchone()
        bang, _ = bao_cao.phan_hai_ben(con, cid, bao_cao.ngay_sau(ngay))
        rong = lambda *tt: sum(n - c for k, (n, c) in bang.items() if k.startswith(tt))
        thu = sum(n for k, (n, c) in bang.items() if k.startswith("131"))
        tra = sum(c for k, (n, c) in bang.items() if k.startswith("331"))
        kq = bao_cao.b02(con, cid, f"{nam}-01-01", ngay)
        viec = quan_ly.viec_can_lam(con, ct)
        o = "".join([
            G.o_kpi("tien", "#0d9488", "Tiền mặt và tiền gửi", so(rong("111", "112")) or "0",
                    f"Đến {ngay_vn(ngay)} · <a href='/cty/{cid}/so'>Sổ quỹ, tiền gửi</a>"),
            G.o_kpi("thu", "#db2777", "Phải thu khách hàng", so(thu) or "0", f"<a href='/cty/{cid}/congno?tk=131'>Chi tiết, tuổi nợ →</a>"),
            G.o_kpi("chi", "#7c3aed", "Phải trả người bán", so(tra) or "0", f"<a href='/cty/{cid}/congno?tk=331'>Chi tiết, tuổi nợ →</a>"),
            G.o_kpi("ban", "#2563eb", f"Doanh thu thuần {nam}", so(kq["10"]) or "0", "Không tính bút toán kết chuyển"),
            G.o_kpi("/luuchuyen", "#16a34a" if (kq["50"] or 0) >= 0 else "#dc2626", f"Lợi nhuận trước thuế {nam}", so(kq["50"]) or "0",
                    f"<a href='/cty/{cid}/baocao?muc=bctc'>Báo cáo tài chính →</a>"),
            G.o_kpi("/chungtu", "#ea580c", "Chứng từ đã ghi sổ", so(r["n"]) or "0",
                    f"{ngay_vn(r['a'])} – {ngay_vn(r['b'])}" if r["a"] else "Chưa có"),
        ])
        nguon = con.execute("SELECT nguon, COUNT(*) n FROM chung_tu WHERE cong_ty_id=? GROUP BY nguon ORDER BY n DESC", (cid,)).fetchall()
        dt, cp = [0] * 12, [0] * 12
        for x in con.execute(
                "SELECT CAST(substr(c.ngay_ht,6,2) AS INTEGER) t, b.tk_no n, b.tk_co c, SUM(b.so_tien) st FROM but_toan b "
                "JOIN chung_tu c ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? AND substr(c.ngay_ht,1,4)=? "
                "AND (b.tk_no LIKE '511%' OR b.tk_co LIKE '511%' OR b.tk_no GLOB '[68]*' OR b.tk_co GLOB '[68]*') "
                "AND b.tk_no NOT LIKE '911%' AND b.tk_co NOT LIKE '911%' GROUP BY t, n, c", (cid, nam)):
            i = x["t"] - 1
            if x["c"].startswith("511"):
                dt[i] += x["st"]
            if x["n"].startswith("511"):
                dt[i] -= x["st"]
            if x["n"][:1] in "68" and not x["n"].startswith("821"):
                cp[i] += x["st"]
            if x["c"][:1] in "68" and not x["c"].startswith("821"):
                cp[i] -= x["st"]
        bieu_do = G.bieu_do_cot([f"T{i}" for i in range(1, 13)],
                                [("Doanh thu", "#2563eb", dt), ("Chi phí", "#f97316", cp)], cao=290, rong=780)
        k = quan_ly.ngay_khoa(con, cid)
        from . import phan_he
        suc_khoe = self._suc_khoe(con, cid, ngay, kq, nam)
        dem = {}
        for m, t, u in viec:
            k = "/" + u.split("?")[0]
            so_dau = t.split(" ", 1)[0]
            n = so_dau if so_dau.isdigit() else "!"
            if k not in dem or m == "do":
                dem[k] = (n, m)
        if "/baocao" in dem:
            dem["/baocao?muc=gtgt"] = dem.pop("/baocao")
        dem.setdefault("/chungtu", (so(r["n"]) or "0", "xanh"))
        so_do = phan_he.so_do(cid, phan_he.QUY_TRINH_CHUNG, dem)
        o_ph = "".join(
            f'<a class="o-ph" style="--m:{ph["mau"]}" href="/cty/{cid}/phan-he/{ph["ma"]}"><i>{G.icon(ph["ic"], 20)}</i>'
            f'<span><b>{e(ph["ten"])}</b><small>{e(ph["mo_ta"])}</small></span></a>'
            for ph in phan_he.PHAN_HE if ph["ma"] != "tongquan" and phan_he.chuc_nang(ph))
        nd_nguoi = getattr(G.HIEN_TAI, "nguoi", None)
        chao = f"Xin chào {e(nd_nguoi.get('ho_ten') or nd_nguoi['ten'])}" if nd_nguoi else "Xin chào"
        n_gap = sum(1 for x in viec if x[0] == "do")
        nd = f"""<section class="bia"><div><div class="chao">{chao} · số liệu đến {ngay_vn(ngay)}</div><h1>{e(ct['ten'])}</h1>
<div class="chip-ds"><span class="chip">MST {e(ct['mst'])}</span><span class="chip">Chế độ {e(ct['che_do'])}</span>
<span class="chip">GTGT theo {'quý' if ct['ky_ke_khai_gtgt'] == 'Q' else 'tháng'}</span>
<span class="chip">{f'Sổ khóa đến {ngay_vn(k)}' if ngay_vn(k) else 'Chưa khóa sổ'}</span>
{f'<span class="chip">⚠ {n_gap} việc gấp</span>' if n_gap else ''}</div></div>
<div class="dong-nut"><a class="nut" href="/cty/{cid}/chungtu/moi">{G.icon("cong", 15)}Nhập chứng từ</a>
<a class="nut phu" href="/cty/{cid}/hoadon/cong">{G.icon("tai", 15)}Tải hóa đơn</a>
<a class="nut phu" href="/cty/{cid}/baocao?muc=gtgt">{G.icon("thue", 15)}Lập tờ khai</a>
{f'<a class="nut phu" href="/cty/{cid}/ai/phantich">{G.icon("ai", 15)}Phân tích với AI</a>' if G.muc_duoc_dung("/ai") else ''}
{f'<a class="nut phu" href="/cty/{cid}/sochedo">{G.icon("/sochedo", 15)}Sổ theo thông tư</a>' if G.muc_duoc_dung("/sochedo") else ''}</div></section>
<div class="luoi-kpi">{o}</div>
<div class="bd-hai"><div class="the"><h2>Doanh thu và chi phí theo tháng, năm {nam}</h2>{bieu_do}
<p class="mo nho-chu">Chi phí gồm giá vốn, chi phí quản lý, tài chính, khác (TK 6xx, 811), chưa gồm thuế TNDN. Rê chuột lên cột để xem số.</p></div>
<div class="the"><h2>Việc cần làm <a class="phu-h" href="/cty/{cid}/viec">Tất cả →</a></h2>{self._ds_viec(cid, viec)}
</div></div>
<div class="the"><h2>Quy trình kế toán <span class="phu-h mo">Bấm vào từng bước để mở · số trên góc là việc đang chờ</span></h2>{so_do}
<div class="chu-thich-sd"><span><i></i>Làm trong phần mềm</span><span><i class="ngoai"></i>Bạn tự làm bên ngoài</span></div></div>
<div class="bd-hai"><div class="the"><h2>Phân hệ</h2><div class="luoi-ph">{o_ph}</div></div>
<div class="the"><h2>Sức khỏe tài chính <span class="phu-h mo">đến {ngay_vn(ngay)}</span></h2>{suc_khoe}
<p class="mo nho-chu">Ước tính nhanh từ sổ sách để tham khảo, không thay cho phân tích báo cáo tài chính.</p>
<p class="mo nho-chu">Chứng từ theo nguồn: {' · '.join(f"{e(NGUON.get(x['nguon'], x['nguon']))}: {so(x['n'])}" for x in nguon) or 'chưa có.'}</p></div></div>"""
        self.gui(G.trang("Bảng điều khiển", nd, cid, ct["ten"]))

    def _suc_khoe(self, con, cid, ngay, kq, nam):
        """Chi so suc khoe tai chinh tu B01 / B02 (uoc tinh nhanh, chi de tham khao)."""
        try:
            b, _ = bao_cao.b01(con, cid, bao_cao.ngay_sau(ngay))
        except Exception:
            return '<p class="mo">Chưa đủ số liệu.</p>'
        ts_nh = b["110"] + b["120"] + b["130"] + b["140"] + b["181"]
        no = b["300"]
        dt = kq.get("10") or 0
        so_ngay = max((date.fromisoformat(ngay) - date(int(nam), 1, 1)).days + 1, 1)
        ds = []
        # (ten, gia tri hien thi, ty le 0..1 cho thanh, muc: xanh/vang/do, giai thich)
        if no > 0:
            r = ts_nh / no
            ds.append(("Khả năng thanh toán", f"{r:.2f} lần", min(r / 3, 1), "xanh" if r >= 1.5 else "vang" if r >= 1 else "do",
                       "Tiền, phải thu, tồn kho so với nợ phải trả"))
        if b["500"]:
            r = no / b["500"]
            ds.append(("Hệ số nợ", f"{r * 100:.0f}%", r, "xanh" if r <= .5 else "vang" if r <= .7 else "do", "Nợ phải trả trên tổng nguồn vốn"))
        if dt:
            r = (kq.get("50") or 0) / dt
            ds.append(("Biên lợi nhuận", f"{r * 100:.1f}%", max(min(r * 5, 1), 0), "xanh" if r >= .05 else "vang" if r >= 0 else "do",
                       "Lợi nhuận trước thuế trên doanh thu"))
            n = b["131"] / dt * so_ngay
            ds.append(("Số ngày thu tiền", f"{n:.0f} ngày", min(n / 120, 1), "xanh" if n <= 45 else "vang" if n <= 90 else "do",
                       "Phải thu khách hàng bình quân"))
        if not ds:
            return '<p class="mo">Chưa đủ số liệu.</p>'
        chu = {"xanh": "Tốt", "vang": "Cần chú ý", "do": "Cảnh báo"}
        return '<ul class="sk">' + "".join(
            f'<li><div class="sk-dau"><span>{t}<small>{gt_}</small></span><b>{v}</b>{G.nhan_tt(chu[m], m)}</div>'
            f'<div class="sk-thanh"><i class="{m}" style="width:{max(ty, .03) * 100:.0f}%"></i></div></li>'
            for t, v, ty, m, gt_ in ds) + "</ul>"

    def phan_he(self, pt, con, ct, q, rest):
        """Trang mot phan he: so do quy trinh, chuc nang va viec can lam lien quan."""
        from . import phan_he
        cid = ct["id"]
        ph = phan_he.THEO_MA.get(rest[0] if rest else "")
        if not ph:
            return self.gui(G.trang("Không tìm thấy", "<p>Không có phân hệ này.</p>", cid, ct["ten"]), 404)
        if ph["ma"] == "tongquan":
            return self.chuyen(f"/cty/{cid}")
        ds = phan_he.chuc_nang(ph)
        goc = {u.split("?")[0].lstrip("/").split("/")[0] for u, _ in ds} | {
            (b["u"] or "").split("?")[0].lstrip("/").split("/")[0] for cot in ph["quy_trinh"] for b in cot if b["u"]}
        viec = [x for x in quan_ly.viec_can_lam(con, ct) if x[2].split("?")[0] in goc]
        dem = {}
        for m, t, u in viec:
            so_dau = t.split(" ", 1)[0]
            n = so_dau if so_dau.isdigit() else "!"
            for cot in ph["quy_trinh"]:
                for b in cot:
                    if b["u"] and b["u"].split("?")[0] == "/" + u.split("?")[0] and b["u"] not in dem:
                        dem[b["u"]] = (n, m)
                        break
                else:
                    continue
                break
        so_do = (f'<div class="the"><h2>Quy trình {e(ph["ten"][:1].lower() + ph["ten"][1:])}</h2>{phan_he.so_do(cid, ph["quy_trinh"], dem)}'
                 '<div class="chu-thich-sd"><span><i></i>Làm trong phần mềm (bấm để mở)</span><span><i class="ngoai"></i>Bạn tự làm bên ngoài</span></div></div>'
                 if ph["quy_trinh"] else "")
        cn = "".join(f'<a href="/cty/{cid}{u}">{e(t)}</a>' for u, t in ds)
        nd = f"""<div style="--m:{ph['mau']}"><div class="dau-ph"><i>{G.icon(ph['ic'], 26)}</i><div><h1>{e(ph['ten'])}</h1><p>{e(ph['mo_ta'])}</p></div></div>
{so_do}<div class="bd-hai"><div class="the"><h2>Chức năng</h2><div class="cn-ds">{cn}</div></div>
<div class="the"><h2>Việc cần làm</h2>{self._ds_viec(cid, viec)}</div></div></div>"""
        self.gui(G.trang(ph["ten"], nd, cid, ct["ten"]))

    def _ds_viec(self, cid, viec):
        if not viec:
            return '<p class="ok">Không có việc gì cần xử lý.</p>'
        thu_tu = {"do": 0, "vang": 1, "xanh": 2}
        return '<ul class="viec">' + "".join(
            f'<li><span class="cham {m}"></span><span>{e(t)}</span><a href="/cty/{cid}/{u}">Mở →</a></li>'
            for m, t, u in sorted(viec, key=lambda x: thu_tu[x[0]])) + "</ul>"

    def viec(self, pt, con, ct, q, _):
        viec = quan_ly.viec_can_lam(con, ct)
        han = quan_ly.han_nop(ct)
        bang = "".join(f'<tr><td>{d:%d/%m/%Y}</td><td>{e(t)}</td><td class="s">{(d - date.today()).days} ngày</td></tr>' for d, t in han)
        nd = f"""<div class="the"><h1>Việc cần làm</h1>{self._ds_viec(ct['id'], viec)}</div>
<div class="the"><h2>Hạn nộp trong 45 ngày tới</h2>{'<table><tr><th>Hạn</th><th>Nội dung</th><th class="s">Còn</th></tr>' + bang + '</table>' if han else '<p class="mo">Không có hạn nộp nào trong 45 ngày tới.</p>'}
<p class="mo">Nộp tờ khai trên thuedientu luôn là bước người dùng tự làm. Hạn tính theo quy định chung, nếu trùng ngày nghỉ thì được lùi sang ngày làm việc kế tiếp.</p></div>"""
        self.gui(G.trang("Việc cần làm", nd, ct["id"], ct["ten"]))

    # ------------------------------------------------------------ chung tu: danh sach, xem, sua, xoa
    def chungtu(self, pt, con, ct, q, rest):
        if rest and rest[0] == "moi":
            return self.chungtu_moi(pt, con, ct, q, rest[1:])
        if rest and rest[0].isdigit():
            ct_id = int(rest[0])
            sub = rest[1] if len(rest) > 1 else ""
            if sub == "sua":
                return self._ct_sua(pt, con, ct, q, ct_id)
            if sub == "xoa" and pt == "POST":
                return self._ct_xoa(con, ct, ct_id)
            if sub == "in":
                return self._ct_in(con, ct, ct_id)
            return self._ct_xem(con, ct, ct_id, q.get("tb", ""))
        return self._ct_ds(con, ct, q)

    def _ct_ds(self, con, ct, q):
        cid = ct["id"]
        tu, den = G.ky_mac_dinh(q)
        tim = q.get("q", "").strip()
        nguon = q.get("nguon", "")
        dk, ts = ["c.cong_ty_id=?", "c.ngay_ht BETWEEN ? AND ?"], [cid, tu, den]
        if nguon:
            dk.append("c.nguon=?")
            ts.append(nguon)
        if tim:
            dk.append("(c.so_ct LIKE ? OR c.dien_giai LIKE ?)")
            ts += [f"%{tim}%", f"%{tim}%"]
        ds = con.execute(f"SELECT c.*, (SELECT SUM(so_tien) FROM but_toan WHERE chung_tu_id=c.id) tien, "
                         f"(SELECT COUNT(*) FROM but_toan WHERE chung_tu_id=c.id) n FROM chung_tu c WHERE {' AND '.join(dk)} "
                         f"ORDER BY c.ngay_ht DESC, c.id DESC LIMIT 2000", ts).fetchall()
        k = quan_ly.ngay_khoa(con, cid)
        dong = "".join(
            f'<tr><td>{ngay_vn(r["ngay_ht"])}</td><td><a href="/cty/{cid}/chungtu/{r["id"]}">{e(r["so_ct"])}</a>'
            f'{" 🔒" if k and r["ngay_ht"] <= k else ""}</td><td>{e(LOAI_CT.get(r["loai"] or "", r["loai"] or ""))}</td>'
            f'<td>{e(r["dien_giai"])}</td><td class="s">{so(r["tien"])}</td><td class="s">{r["n"]}</td>'
            f'<td>{G.nhan_tt(NGUON.get(r["nguon"], r["nguon"] or ""), "lam" if r["nguon"] == "tay" else "")}</td></tr>' for r in ds)
        chon = "".join(f'<option value="{m}" {"selected" if m == nguon else ""}>{t}</option>' for m, t in NGUON.items())
        them = (f'<label>Nguồn<select name="nguon"><option value="">Tất cả</option>{chon}</select></label>'
                f'<label>Tìm số CT / diễn giải<input name="q" value="{e(tim)}"></label>')
        nd = f"""<div class="the"><div class="ngang" style="justify-content:space-between"><h1>Danh sách chứng từ</h1>
<a class="nut" href="/cty/{cid}/chungtu/moi">＋ Nhập chứng từ</a></div>{G.form_ky(tu, den, them)}
<p class="mo">{len(ds)} chứng từ{' (hiện 2000 chứng từ mới nhất)' if len(ds) == 2000 else ''}. Bấm số chứng từ để xem, sửa, xóa hoặc in.</p></div>
<table><tr><th>Ngày HT</th><th>Số CT</th><th>Loại</th><th>Diễn giải</th><th class="s">Số tiền</th><th class="s">Dòng</th><th>Nguồn</th></tr>{dong}</table>"""
        self.gui(G.trang("Danh sách chứng từ", nd, cid, ct["ten"]))

    def _ct_xem(self, con, ct, ct_id, tb=""):
        cid = ct["id"]
        c, dong = quan_ly.chung_tu(con, cid, ct_id)
        if not c:
            return self.gui(G.trang("Không tìm thấy", '<p class="loi">Không có chứng từ này.</p>', cid, ct["ten"]), 404)
        ten = quan_ly.ten_doi_tuong(con, cid)
        k = quan_ly.ngay_khoa(con, cid)
        khoa = bool(k and c["ngay_ht"] <= k)
        bang = "".join(
            f'<tr><td>{e(d["dien_giai"])}</td><td>{e(d["tk_no"])}</td><td>{e(d["tk_co"])}</td><td class="s">{so(d["so_tien"])}</td>'
            f'<td>{e(ten.get(d["doi_tuong_no"] or d["doi_tuong_co"]) or d["doi_tuong_no"] or d["doi_tuong_co"])}</td></tr>' for d in dong)
        lien = []
        for bang_lk, nhan, url in (("hoa_don", "Hóa đơn", "hoadon/xem/{id}"), ("sao_ke", "Dòng sao kê", "nganhang?tt=tat_ca"),
                                   ("kho_dong", "Dòng kho", "so/vattu")):
            for r in con.execute(f"SELECT id FROM {bang_lk} WHERE chung_tu_id=? LIMIT 5", (ct_id,)):
                lien.append(f'<a href="/cty/{cid}/{url.format(id=r["id"])}">{nhan} #{r["id"]}</a>')
        tu_dong = c["nguon"] not in ("tay", None)
        tb = {"sua": '<p class="ok">Đã lưu thay đổi. Bản cũ được ghi vào nhật ký sửa.</p>'}.get(tb, "")
        nut = (f'<p class="bao">Chứng từ thuộc kỳ đã khóa sổ (đến {ngay_vn(k)}) nên không sửa, xóa được.</p>' if khoa else
               f'''<a class="nut" href="/cty/{cid}/chungtu/{ct_id}/sua">Sửa</a>
<form method="post" action="/cty/{cid}/chungtu/{ct_id}/xoa" style="display:inline" onsubmit="return confirm('Xóa chứng từ {e(c['so_ct'])}? Bản cũ vẫn lưu trong nhật ký sửa.')">
<button class="nguy">Xóa</button></form>''')
        nd = f"""<div class="the"><h1>Chứng từ {e(c['so_ct'])}</h1>{tb}
<p>Ngày hạch toán <b>{ngay_vn(c['ngay_ht'])}</b> · ngày chứng từ {ngay_vn(c['ngay_ct'])} · {e(LOAI_CT.get(c['loai'] or '', c['loai'] or ''))}
· nguồn {e(NGUON.get(c['nguon'], c['nguon'] or ''))}</p><p>{e(c['dien_giai'])}</p>
{f'<p class="bao">Chứng từ do máy tạo từ {e(NGUON.get(c["nguon"], c["nguon"]))}. Nếu chạy lại chức năng tạo ra nó (nạp lại MISA, ghi sổ lương, trích khấu hao...) thì phần sửa tay có thể bị thay.</p>' if tu_dong and not khoa else ''}
<table><tr><th>Diễn giải</th><th>TK Nợ</th><th>TK Có</th><th class="s">Số tiền</th><th>Đối tượng</th></tr>{bang}
<tr class="tong"><td colspan="3">Cộng</td><td class="s">{so(sum(d['so_tien'] for d in dong))}</td><td></td></tr></table>
{('<p class="mo">Liên kết: ' + ' · '.join(lien) + '</p>') if lien else ''}
<div class="dong-nut">{nut}<a class="nut phu" href="/cty/{cid}/chungtu/{ct_id}/in" target="_blank">In phiếu</a>
<a class="nut phu" href="/cty/{cid}/chungtu">← Danh sách</a></div></div>"""
        self.gui(G.trang(f"Chứng từ {c['so_ct']}", nd, cid, ct["ten"]))

    def _ct_sua(self, pt, con, ct, q, ct_id):
        cid = ct["id"]
        c, dong = quan_ly.chung_tu(con, cid, ct_id)
        if not c:
            return self.gui(G.trang("Không tìm thấy", '<p class="loi">Không có chứng từ này.</p>', cid, ct["ten"]), 404)
        tb = ""
        if pt == "POST":
            f = self.doc_form()
            g = lambda k: (f.get(k) or [""])[0].strip()
            try:
                dau = {"so_ct": g("so_ct"), "ngay_ct": g("ngay_ct"), "ngay_ht": g("ngay_ht"), "loai": g("loai") or None,
                       "dien_giai": g("dien_giai")}
                quan_ly.sua_chung_tu(con, cid, ct_id, dau, doc_dong_but_toan(f, dau["dien_giai"]), self.ten_nguoi())
                return self.chuyen(f"/cty/{cid}/chungtu/{ct_id}?tb=sua")
            except Exception as ex:
                tb = f'<p class="loi">Chưa lưu được: {e(ex)}</p>'
        loai = "".join(f'<option value="{m}" {"selected" if m == c["loai"] else ""}>{t}</option>' for m, t in LOAI_CT.items())
        nd = f"""<div class="the"><h1>Sửa chứng từ {e(c['so_ct'])}</h1>{tb}<form method="post">
<div class="ngang" style="margin-bottom:12px"><label>Loại<select name="loai"><option value=""></option>{loai}</select></label>
<label>Số chứng từ<input name="so_ct" value="{e(c['so_ct'])}" required></label>
<label>Ngày hạch toán<input type="date" name="ngay_ht" value="{e(c['ngay_ht'])}" required></label>
<label>Ngày chứng từ<input type="date" name="ngay_ct" value="{e(c['ngay_ct'])}"></label>
<label>Diễn giải<input name="dien_giai" size="50" value="{e(c['dien_giai'])}"></label></div>
{bang_nhap_dong(dong)}<datalist id="dstk">{_ds_tk(con, cid)}</datalist><datalist id="dsdt">{ds_doi_tuong(con, cid)}</datalist>
<div class="dong-nut"><button>Lưu thay đổi</button><a class="nut phu" href="/cty/{cid}/chungtu/{ct_id}">Hủy</a></div></form></div>"""
        self.gui(G.trang("Sửa chứng từ", nd, cid, ct["ten"]))

    def _ct_xoa(self, con, ct, ct_id):
        cid = ct["id"]
        try:
            quan_ly.xoa_chung_tu(con, cid, ct_id, self.ten_nguoi())
        except Exception as ex:
            return self.gui(G.trang("Không xóa được", f'<p class="loi">{e(ex)}</p>', cid, ct["ten"]), 400)
        self.chuyen(f"/cty/{cid}/chungtu")

    # ------------------------------------------------------------ in chung tu
    def _dau_phieu(self, ct, mau, ten_mau):
        return f"""<div class="dong"><div><b>Đơn vị: {e(ct['ten'])}</b><br>Địa chỉ: {e(ct['dia_chi'] or '')}<br>MST: {e(ct['mst'])}</div>
<div class="g"><b>Mẫu số {mau}</b><br><span class="nghieng">(Ban hành theo Thông tư số 133/2016/TT-BTC<br>ngày 26/08/2016 của Bộ Tài chính)</span></div></div>
<h1>{ten_mau}</h1>"""

    def _ct_in(self, con, ct, ct_id):
        cid = ct["id"]
        c, dong = quan_ly.chung_tu(con, cid, ct_id)
        if not c:
            return self.gui("Không có chứng từ", 404)
        ten = quan_ly.ten_doi_tuong(con, cid)
        tong = sum(d["so_tien"] for d in dong)
        n = date.fromisoformat(c["ngay_ct"] or c["ngay_ht"])
        ngay_chu = f"Ngày {n.day:02d} tháng {n.month:02d} năm {n.year}"
        no111 = [d for d in dong if d["tk_no"].startswith("111") and not d["tk_co"].startswith("111")]
        co111 = [d for d in dong if d["tk_co"].startswith("111") and not d["tk_no"].startswith("111")]
        dt = next((d["doi_tuong_co"] or d["doi_tuong_no"] for d in dong if d["doi_tuong_co"] or d["doi_tuong_no"]), "")
        ten_dt = ten.get(dt, dt)
        tt_dt = doi_tuong.lay(con, cid, dt)
        dia_chi_dt = (tt_dt["dia_chi"] if tt_dt else None) or ""
        gd = e(ct["nguoi_ky"] or "")
        if (no111 and not co111) or (co111 and not no111):
            thu = bool(no111)
            ds = no111 or co111
            tien = sum(d["so_tien"] for d in ds)
            tk_no = ", ".join(sorted({d["tk_no"] for d in ds}))
            tk_co = ", ".join(sorted({d["tk_co"] for d in ds}))
            nguoi = "nộp tiền" if thu else "nhận tiền"
            ky = (["Giám đốc", "Kế toán trưởng", "Người nộp tiền", "Người lập phiếu", "Thủ quỹ"] if thu else
                  ["Giám đốc", "Kế toán trưởng", "Thủ quỹ", "Người lập phiếu", "Người nhận tiền"])
            nd = f"""<div class="to">{self._dau_phieu(ct, '01-TT' if thu else '02-TT', 'PHIẾU THU' if thu else 'PHIẾU CHI')}
<div class="dong"><div></div><div class="g nghieng">{ngay_chu}</div><div>Quyển số: ........<br>Số: <b>{e(c['so_ct'])}</b><br>Nợ: {e(tk_no)}<br>Có: {e(tk_co)}</div></div>
<p>Họ và tên người {nguoi}: <b>{e(ten_dt) or '.' * 90}</b></p>
<p>Địa chỉ: {e(dia_chi_dt) or '.' * 110}</p>
<p>Lý do {'nộp' if thu else 'chi'}: {e(c['dien_giai'] or ds[0]['dien_giai'])}</p>
<p>Số tiền: <b>{so(tien)} đồng</b></p>
<p>Viết bằng chữ: <i>{e(quan_ly.bang_chu(tien))}</i></p>
<p>Kèm theo: ........ chứng từ gốc.</p>
<div class="ky">{''.join(f'<div><b>{t}</b><br><i>(Ký, họ tên{", đóng dấu" if t == "Giám đốc" else ""})</i><br><br><br><br>{gd if t == "Giám đốc" else ""}</div>' for t in ky)}</div>
<p>Đã {'nhận' if thu else 'nhận'} đủ số tiền (viết bằng chữ): ................................................................................</p>
<p class="nghieng">+ Tỷ giá ngoại tệ (vàng bạc, đá quý): ........ + Số tiền quy đổi: ........</p></div>"""
            return self.gui(G.trang_in(f"{'Phiếu thu' if thu else 'Phiếu chi'} {c['so_ct']}", nd))
        kho_dong = con.execute("SELECT so_phieu FROM kho_dong WHERE chung_tu_id=? LIMIT 1", (ct_id,)).fetchone()
        if kho_dong:
            return self.chuyen(f"/cty/{cid}/so/phieu?so={quote(kho_dong['so_phieu'])}")
        hang = "".join(f'<tr><td>{e(d["dien_giai"])}</td><td class="g">{e(d["tk_no"])}</td><td class="g">{e(d["tk_co"])}</td>'
                       f'<td class="s">{so(d["so_tien"])}</td><td>{e(ten.get(d["doi_tuong_no"] or d["doi_tuong_co"], d["doi_tuong_no"] or d["doi_tuong_co"]))}</td></tr>'
                       for d in dong)
        nd = f"""<div class="to"><div class="dong"><div><b>Đơn vị: {e(ct['ten'])}</b><br>MST: {e(ct['mst'])}</div><div></div></div>
<h1>PHIẾU KẾ TOÁN</h1><p class="g nghieng">{ngay_chu} · Số: <b>{e(c['so_ct'])}</b></p>
<p>Nội dung: {e(c['dien_giai'])}</p>
<table class="bang"><tr><th>Diễn giải</th><th>TK Nợ</th><th>TK Có</th><th>Số tiền</th><th>Đối tượng</th></tr>{hang}
<tr><td class="dam">Cộng</td><td></td><td></td><td class="s dam">{so(tong)}</td><td></td></tr></table>
<p>Số tiền bằng chữ: <i>{e(quan_ly.bang_chu(tong))}</i></p>
<div class="ky ba"><div><b>Người lập</b><br><i>(Ký, họ tên)</i></div><div><b>Kế toán trưởng</b><br><i>(Ký, họ tên)</i></div>
<div><b>Giám đốc</b><br><i>(Ký, họ tên)</i><br><br><br><br>{gd}</div></div></div>"""
        self.gui(G.trang_in(f"Phiếu kế toán {c['so_ct']}", nd))

    # ------------------------------------------------------------ in: bang luong, phieu kho
    def in_(self, pt, con, ct, q, rest):
        loai = rest[0] if rest else ""
        if loai == "luong":
            return self._in_luong(con, ct, q.get("thang") or date.today().strftime("%Y-%m"))
        if loai == "ct" and len(rest) > 1 and rest[1].isdigit():
            return self._ct_in(con, ct, int(rest[1]))
        self.gui("Không có mẫu in này", 404)

    def _in_luong(self, con, ct, thang):
        from . import luong
        ds = luong.tinh_thang(con, ct["id"], thang)
        tong = {}
        hang = ""
        for i, (nv, bl, r) in enumerate(ds, 1):
            gt = [r["luong_thoi_gian"], bl["phu_cap_chiu_thue"] + bl["phu_cap_mien_thue"], bl["thuong"], r["tong_thu_nhap"],
                  r["bh"].get("3383", (0, 0))[0], r["bh"].get("3384", (0, 0))[0], r["bh"].get("3385", (0, 0))[0],
                  r["thue_tncn"], bl["khau_tru_khac"], r["thuc_linh"]]
            for j, v in enumerate(gt):
                tong[j] = tong.get(j, 0) + v
            hang += (f'<tr><td class="g">{i}</td><td>{e(nv["ho_ten"])}</td><td>{e(nv["bo_phan"] or "")}</td>'
                     f'<td class="s">{so(bl["luong_co_ban"])}</td><td class="g">{bl["ngay_cong"]:g}</td>'
                     + "".join(f'<td class="s">{so(v)}</td>' for v in gt) + '<td></td></tr>')
        hang += ('<tr class="dam"><td></td><td class="dam">Cộng</td><td></td><td></td><td></td>'
                 + "".join(f'<td class="s dam">{so(tong.get(j, 0))}</td>' for j in range(10)) + '<td></td></tr>')
        nd = f"""<div class="to"><div class="dong"><div><b>Đơn vị: {e(ct['ten'])}</b><br>Bộ phận: ................</div>
<div class="g"><b>Mẫu số 02-LĐTL</b><br><span class="nghieng">(Ban hành theo Thông tư số 133/2016/TT-BTC<br>ngày 26/08/2016 của Bộ Tài chính)</span></div></div>
<h1>BẢNG THANH TOÁN TIỀN LƯƠNG</h1><p class="g">Tháng {thang[5:]} năm {thang[:4]}</p>
<table class="bang"><tr><th rowspan="2">STT</th><th rowspan="2">Họ và tên</th><th rowspan="2">Bộ phận</th><th rowspan="2">Lương cơ bản</th>
<th rowspan="2">Ngày công</th><th rowspan="2">Lương thời gian</th><th rowspan="2">Phụ cấp</th><th rowspan="2">Thưởng</th>
<th rowspan="2">Tổng thu nhập</th><th colspan="5">Các khoản khấu trừ</th><th rowspan="2">Thực lĩnh</th><th rowspan="2">Ký nhận</th></tr>
<tr><th>BHXH 8%</th><th>BHYT 1,5%</th><th>BHTN 1%</th><th>Thuế TNCN</th><th>Khác</th></tr>{hang}</table>
<p>Tổng số tiền (viết bằng chữ): <i>{e(quan_ly.bang_chu(tong.get(9, 0)))}</i></p>
<p class="g nghieng" style="text-align:right">Ngày ..... tháng ..... năm .........</p>
<div class="ky ba"><div><b>Người lập biểu</b><br><i>(Ký, họ tên)</i></div><div><b>Kế toán trưởng</b><br><i>(Ký, họ tên)</i></div>
<div><b>Giám đốc</b><br><i>(Ký, họ tên, đóng dấu)</i><br><br><br><br>{e(ct['nguoi_ky'] or '')}</div></div></div>"""
        self.gui(G.trang_in(f"Bảng lương {thang}", nd, ngang=True))

    # ------------------------------------------------------------ ngan hang
    def nganhang(self, pt, con, ct, q, rest):
        cid = ct["id"]
        sao_ke.chuan_bi(con)
        muc = rest[0] if rest else "ds"
        tb = ""
        tabs = G.tab([("ds", f"/cty/{cid}/nganhang", "Dòng sao kê"), ("nap", f"/cty/{cid}/nganhang/nap", "Nạp sao kê"),
                      ("quytac", f"/cty/{cid}/nganhang/quytac", "Quy tắc tự hạch toán"),
                      ("doichieu", f"/cty/{cid}/nganhang/doichieu", "Đối chiếu số dư")], muc)
        if muc == "nap":
            if pt == "POST":
                from .trang_hoa_don import doc_multipart
                truong, tep = doc_multipart(self)
                for ten_file, b in tep:
                    try:
                        tt, dong = sao_ke.doc(ten_file, b)
                        if truong.get("so_tk"):
                            tt["so_tk"] = truong["so_tk"].strip()
                        if truong.get("ngan_hang"):
                            tt["ngan_hang"] = truong["ngan_hang"].strip()
                        tk = (truong.get("tk") or "").strip() or sao_ke.tk_cho_so_tk(con, cid, tt.get("so_tk") or "") or "1121"
                        n = sao_ke.luu(con, cid, tt, dong, tk)
                        tb += (f'<p class="ok">{e(ten_file)}: {e(tt.get("ngan_hang") or "")} {e(tt.get("so_tk") or "")} → TK {e(tk)}: '
                               f'{len(dong)} dòng đọc được, {n} dòng mới.</p>')
                    except Exception as ex:
                        tb += f'<p class="loi">{e(ten_file)}: {e(ex)}</p>'
                if not tep:
                    tb = '<p class="loi">Chưa chọn file.</p>'
            tkn = con.execute("SELECT * FROM tai_khoan_ngan_hang WHERE cong_ty_id=?", (cid,)).fetchall()
            ds_tkn = "".join(f'<tr><td>{e(r["ngan_hang"])}</td><td>{e(r["so_tk"])}</td><td>{e(r["tk"])}</td></tr>' for r in tkn)
            nd = f"""<div class="the"><h1>Ngân hàng</h1>{tabs}{tb}
<p class="mo">Xuất sao kê từ Internet Banking (MB, Vietcombank, BIDV, VietinBank, Techcombank, ACB...) ra Excel hoặc CSV rồi nạp vào đây.
Máy tự nhận cột ngày, số tiền vào/ra, số dư, nội dung; tự bỏ dòng đã nạp; tự đánh dấu dòng đã có chứng từ trên sổ (cùng số tiền, lệch tối đa 3 ngày).
Có thể nạp cả Sổ tiền gửi ngân hàng xuất từ MISA.</p>
<form method="post" enctype="multipart/form-data" style="display:grid;gap:12px;max-width:760px">
<label>File sao kê (chọn được nhiều file)<input type="file" name="tep" accept=".xlsx,.xls,.csv" multiple required></label>
<div class="ngang"><label>TK trên sổ<input name="tk" size="8" list="dstk" placeholder="tự nhận / 1121"></label>
<label>Số tài khoản ngân hàng<input name="so_tk" size="18" placeholder="tự đọc trong file"></label>
<label>Ngân hàng<input name="ngan_hang" size="14" placeholder="tự nhận"></label></div>
<div><button>Nạp sao kê</button></div></form><datalist id="dstk">{_ds_tk(con, cid)}</datalist></div>
{'<div class="the"><h2>Tài khoản ngân hàng đã biết</h2><table><tr><th>Ngân hàng</th><th>Số tài khoản</th><th>TK trên sổ</th></tr>' + ds_tkn + '</table></div>' if tkn else ''}"""
            return self.gui(G.trang("Ngân hàng", nd, cid, ct["ten"]))
        if muc == "quytac":
            if pt == "POST":
                f = {k: v[0].strip() for k, v in self.doc_form().items()}
                if f.get("xoa"):
                    con.execute("DELETE FROM quy_tac_ngan_hang WHERE cong_ty_id=? AND tu_khoa=? AND chieu=?",
                                (cid, f["xoa"], f.get("chieu", "")))
                    con.commit()
                    sao_ke.goi_y_tat_ca(con, cid)
                    tb = '<p class="ok">Đã xóa quy tắc.</p>'
                elif f.get("tu_khoa") and f.get("tk"):
                    sao_ke.dat_quy_tac(con, cid, f["tu_khoa"], f["tk"], f.get("doi_tuong", ""), f.get("chieu", ""))
                    tb = '<p class="ok">Đã lưu quy tắc và gợi ý lại các dòng chưa ghi sổ.</p>'
            ds = con.execute("SELECT * FROM quy_tac_ngan_hang WHERE cong_ty_id=? ORDER BY tu_khoa", (cid,)).fetchall()
            ten_chieu = {"vao": "Tiền vào", "ra": "Tiền ra", "": "Cả hai"}
            bang = "".join(
                f'<tr><td>{e(r["tu_khoa"])}</td><td>{ten_chieu.get(r["chieu"], r["chieu"])}</td><td>{e(r["tk"])}</td><td>{e(r["doi_tuong"])}</td>'
                f'<td><form method="post"><input type="hidden" name="xoa" value="{e(r["tu_khoa"])}"><input type="hidden" name="chieu" value="{e(r["chieu"])}">'
                f'<button class="nguy nho">Xóa</button></form></td></tr>' for r in ds)
            mac = "".join(f'<tr><td>{e(", ".join(tk_))}</td><td>{ten_chieu[c_]}</td><td>{tk}</td><td>{e(gc)}</td></tr>'
                          for tk_, c_, tk, gc in sao_ke.TU_KHOA)
            nd = f"""<div class="the"><h1>Ngân hàng</h1>{tabs}{tb}
<p class="mo">Khi nội dung chuyển khoản chứa từ khóa, máy gợi ý tài khoản và đối tượng này (ưu tiên hơn các gợi ý tự động).
Ví dụ: từ khóa "tien dien" → 6422; "cong ty abc" → 331, đối tượng NCC00012.</p>
<form method="post" class="ngang"><label>Từ khóa (không cần dấu)<input name="tu_khoa" size="24" required></label>
<label>Chiều<select name="chieu"><option value="">Cả hai</option><option value="vao">Tiền vào</option><option value="ra">Tiền ra</option></select></label>
<label>Tài khoản<input name="tk" size="8" list="dstk" required></label><label>Đối tượng<input name="doi_tuong" size="12" list="dsdt"></label>
<button>Lưu quy tắc</button></form><datalist id="dstk">{_ds_tk(con, cid)}</datalist><datalist id="dsdt">{ds_doi_tuong(con, cid)}</datalist>
{'<table><tr><th>Từ khóa</th><th>Chiều</th><th>TK</th><th>Đối tượng</th><th></th></tr>' + bang + '</table>' if ds else '<p class="mo">Chưa có quy tắc riêng.</p>'}</div>
<details class="the"><summary>Từ khóa máy tự hiểu sẵn</summary><table><tr><th>Từ khóa</th><th>Chiều</th><th>TK</th><th>Ý nghĩa</th></tr>{mac}</table></details>"""
            return self.gui(G.trang("Ngân hàng", nd, cid, ct["ten"]))
        if muc == "doichieu":
            tu, den = G.ky_mac_dinh(q)
            ds = sao_ke.doi_chieu(con, cid, tu, den)
            bang = "".join(
                f'<tr><td>{e(r["tk"])}</td><td>{e(r["tai_khoan"])}</td><td class="s">{so(r["so_du_so"])}</td>'
                f'<td class="s">{so(r["so_du_nh"]) if r["so_du_nh"] is not None else "<span class=mo>file không có số dư</span>"}</td>'
                f'<td class="s {"ok" if r["so_du_nh"] == r["so_du_so"] else "loi"}">{"Khớp" if r["so_du_nh"] == r["so_du_so"] else so((r["so_du_so"] or 0) - (r["so_du_nh"] or 0))}</td>'
                f'<td>{", ".join(f"{k}: {v}" for k, v in sorted(r["dem"].items()))}</td></tr>' for r in ds)
            nd = f"""<div class="the"><h1>Ngân hàng</h1>{tabs}{G.form_ky(tu, den)}
<p class="mo">So số dư cuối kỳ trên sổ (TK 112x) với số dư cuối cùng trên sao kê đến ngày cuối kỳ.
Trạng thái dòng: moi = chưa ghi sổ, da_co = đã có chứng từ sẵn trên sổ, da_ghi = máy đã ghi từ sao kê.</p>
{'<table><tr><th>TK</th><th>Tài khoản ngân hàng</th><th class="s">Số dư trên sổ</th><th class="s">Số dư sao kê</th><th class="s">Chênh</th><th>Số dòng</th></tr>' + bang + '</table>' if ds else '<p class="mo">Chưa có sao kê trong kỳ này.</p>'}</div>"""
            return self.gui(G.trang("Ngân hàng", nd, cid, ct["ten"]))
        # danh sach dong sao ke
        from . import tro_ly_ai as AI
        ai_ok, ai_tb = AI.san_sang(bq=getattr(self, "bq", None))
        f = self.doc_form() if pt == "POST" else {}
        if (f.get("hanh_dong") or [""])[0] == "ai":
            pt = "AI"
            try:
                if not ai_ok:
                    raise AI.LoiAI(ai_tb)
                n = AI.goi_y_sao_ke(con, cid)
                con_lai = len(AI.dong_sao_ke_can_ai(con, cid))
                tb = (f'<p class="ok">AI đã gợi ý {n} dòng (lý do bắt đầu bằng "AI:"). Các dòng này vẫn để "cần xem" và không chọn sẵn: '
                      'xem lại, tích chọn rồi bấm Ghi sổ.' + (f' Còn {con_lai} dòng chưa gợi ý, bấm lại nút AI để làm tiếp.' if con_lai else '')
                      + '</p>') if n else '<p class="mo">Không có dòng "cần xem" nào để AI gợi ý, hoặc AI không đưa ra được tài khoản hợp lệ.</p>'
            except AI.LoiAI as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        if pt == "POST":
            chon = {}
            ids = set(f.get("id", []))
            for i, tk, dt in zip(f.get("dong", []), f.get("tk", []), f.get("dt", [])):
                if i in ids:
                    chon[int(i)] = (tk.strip(), dt.strip())
            if (f.get("hanh_dong") or [""])[0] == "bo_qua":
                for i in chon:
                    con.execute("UPDATE sao_ke SET trang_thai='da_co' WHERE id=? AND cong_ty_id=? AND trang_thai='moi'", (i, cid))
                con.commit()
                tb = f'<p class="ok">Đã đánh dấu {len(chon)} dòng là đã có trên sổ (không ghi thêm).</p>'
            else:
                n, loi = sao_ke.ghi_so(con, cid, chon)
                tb = f'<p class="ok">Đã ghi sổ {n} dòng sao kê.</p>' + "".join(f'<p class="loi">{e(x)}</p>' for x in loi)
        tt = q.get("tt", "moi")
        tu, den = q.get("tu", "0000-01-01"), q.get("den", "9999-12-31")
        dk = "" if tt == "tat_ca" else " AND trang_thai=?"
        ts = [cid, tu, den] + ([] if tt == "tat_ca" else [tt])
        ds = con.execute(f"SELECT * FROM sao_ke WHERE cong_ty_id=? AND ngay BETWEEN ? AND ?{dk} ORDER BY ngay, id LIMIT 3000", ts).fetchall()
        dem = {r["trang_thai"]: r["n"] for r in con.execute(
            "SELECT trang_thai, COUNT(*) n FROM sao_ke WHERE cong_ty_id=? GROUP BY trang_thai", (cid,))}
        n_can_ai = con.execute("SELECT COUNT(*) FROM sao_ke WHERE cong_ty_id=? AND trang_thai='moi' AND ly_do LIKE '%(cần xem)%' "
                               "AND ly_do NOT LIKE ?", (cid, AI.DANH_DAU_AI + "%")).fetchone()[0] if ai_ok else 0
        lk_ct = lambda i: f'<a href="/cty/{cid}/chungtu/{i}">Chứng từ</a>' if i else ""
        ten_tt = {"moi": ("Chưa ghi sổ", "vang"), "da_co": ("Đã có trên sổ", "xanh"), "da_ghi": ("Máy đã ghi", "lam")}
        dong = ""
        for r in ds:
            moi = r["trang_thai"] == "moi"
            can_xem = "(cần xem)" in (r["ly_do"] or "")
            o_chon = f'<input type="checkbox" name="id" value="{r["id"]}"{"" if can_xem else " checked"}>' if moi else ""
            dong += (f'<tr><td>{o_chon}'
                     f'<input type="hidden" name="dong" value="{r["id"]}"></td><td>{ngay_vn(r["ngay"])}</td>'
                     f'<td>{e(r["ngan_hang"] or "")}<br><span class="mo">{e(r["so_tk"])}</span></td>'
                     f'<td style="max-width:420px">{e(r["noi_dung"])}</td><td class="s ok">{so(r["vao"])}</td><td class="s loi">{so(r["ra"])}</td>'
                     + (f'<td><input name="tk" size="7" list="dstk" value="{e(r["tk_goi_y"] or "")}"></td>'
                        f'<td><input name="dt" size="10" list="dsdt" value="{e(r["dt_goi_y"] or "")}"></td>'
                        f'<td class="mo" style="font-size:12.5px">{e(r["ly_do"] or "")}</td>' if moi else
                        f'<td><input type="hidden" name="tk" value=""><input type="hidden" name="dt" value="">'
                        f'{G.nhan_tt(*ten_tt.get(r["trang_thai"], (r["trang_thai"], "")))}</td><td></td>'
                        f'<td>{lk_ct(r["chung_tu_id"])}</td>')
                     + "</tr>")
        loc = "".join(f'<a class="nut{"" if tt == m else " phu"} nho" href="/cty/{cid}/nganhang?tt={m}">{t} ({dem.get(m, 0) if m != "tat_ca" else sum(dem.values())})</a>'
                      for m, t in (("moi", "Chưa ghi sổ"), ("da_co", "Đã có trên sổ"), ("da_ghi", "Máy đã ghi"), ("tat_ca", "Tất cả")))
        nd = f"""<div class="the"><h1>Ngân hàng</h1>{tabs}{tb}<div class="dong-nut">{loc}</div>
<p class="mo">Kiểm tra tài khoản đối ứng máy gợi ý (dòng "cần xem" không được chọn sẵn), sửa nếu cần, rồi bấm Ghi sổ. Mỗi dòng thành một chứng từ
NTTK (tiền vào) hoặc UNC (tiền ra). Muốn máy nhớ cách hạch toán cho lần sau, thêm ở thẻ Quy tắc.</p></div>
<form method="post" action="/cty/{cid}/nganhang?tt={tt}">
{('<div class="dong-nut"><button name="hanh_dong" value="ghi">Ghi sổ các dòng đã chọn</button>'
  '<button class="phu" name="hanh_dong" value="bo_qua">Đánh dấu đã có trên sổ</button>'
  + (f'<button class="phu" name="hanh_dong" value="ai" title="Gửi tối đa {AI.TOI_DA_DONG_SAO_KE} dòng mỗi lần">Nhờ AI gợi ý dòng cần xem ({n_can_ai})</button>'
     if ai_ok and n_can_ai else '') + '</div>') if tt == 'moi' and ds else ''}
<table><tr><th></th><th>Ngày</th><th>Tài khoản</th><th>Nội dung</th><th class="s">Tiền vào</th><th class="s">Tiền ra</th>
<th>TK đối ứng</th><th>Đối tượng</th><th>Lý do gợi ý</th></tr>{dong or '<tr><td colspan="9" class="mo">Không có dòng nào.</td></tr>'}</table>
<datalist id="dstk">{_ds_tk(con, cid)}</datalist><datalist id="dsdt">{ds_doi_tuong(con, cid)}</datalist></form>"""
        self.gui(G.trang("Ngân hàng", nd, cid, ct["ten"]))

    # ------------------------------------------------------------ cong no
    def congno(self, pt, con, ct, q, rest):
        cid = ct["id"]
        tk = q.get("tk", "131")
        muc = q.get("muc", "tonghop")
        ngay = _ngay_du_lieu(con, cid)
        tu = q.get("tu", f"{ngay[:4]}-01-01")
        den = q.get("den", ngay)
        chon = "".join(f'<option value="{m}" {"selected" if m == tk else ""}>{m} - {t}</option>' for m, t in TK_CONG_NO)
        ma = q.get("ma")
        if ma is not None:
            dau, ds = quan_ly.chi_tiet_doi_tuong(con, cid, tk, ma, tu, den)
            ten = quan_ly.ten_doi_tuong(con, cid).get(ma) or ("(chưa gắn đối tượng)" if not ma else ma)
            dau_no = tk.startswith(("131", "1388", "141"))
            hien = lambda v: so(v if dau_no else -v) or "0"
            bang = "".join(f'<tr><td>{ngay_vn(r["ngay"])}</td><td><a href="/cty/{cid}/chungtu/{r["id"]}">{e(r["so_ct"])}</a></td>'
                           f'<td>{e(r["dien_giai"])}</td><td>{e(r["tk_du"])}</td><td class="s">{so(r["no"])}</td><td class="s">{so(r["co"])}</td>'
                           f'<td class="s">{hien(r["du"])}</td></tr>' for r in ds)
            nd = f"""<div class="the"><h1>Sổ chi tiết công nợ: {e(ten)}</h1><p class="mo">TK {e(tk)} · mã {e(ma or '(trống)')}</p>
{G.form_ky(tu, den, f'<input type="hidden" name="tk" value="{e(tk)}"><input type="hidden" name="ma" value="{e(ma)}">')}</div>
<table><tr><th>Ngày</th><th>Số CT</th><th>Diễn giải</th><th>TK đối ứng</th><th class="s">Nợ</th><th class="s">Có</th>
<th class="s">Số dư ({'Nợ' if dau_no else 'Có'})</th></tr><tr class="c1"><td colspan="6">Số dư đầu kỳ</td><td class="s">{hien(dau)}</td></tr>{bang}
<tr class="tong"><td colspan="4">Cộng phát sinh</td><td class="s">{so(sum(r['no'] for r in ds))}</td><td class="s">{so(sum(r['co'] for r in ds))}</td>
<td class="s">{hien(ds[-1]['du'] if ds else dau)}</td></tr></table>
<p><a class="nut phu" href="/cty/{cid}/congno?tk={e(tk)}&tu={tu}&den={den}">← Tổng hợp công nợ</a></p>"""
            return self.gui(G.trang("Công nợ", nd, cid, ct["ten"]))
        tabs = G.tab([("tonghop", f"/cty/{cid}/congno?tk={tk}&tu={tu}&den={den}", "Tổng hợp theo đối tượng"),
                      ("tuoino", f"/cty/{cid}/congno?tk={tk}&muc=tuoino&den={den}", "Tuổi nợ")], muc)
        loc = f'<label>Tài khoản<select name="tk">{chon}</select></label><input type="hidden" name="muc" value="{muc}">'
        if muc == "tuoino":
            ngay_t = bao_cao.ngay_sau(den)
            ds, goc = quan_ly.tuoi_no(con, cid, tk, ngay_t)
            tong = [sum(r["nhom"][i] for r in ds) for i in range(4)]
            bang = "".join(
                f'<tr><td><a href="/cty/{cid}/congno?tk={tk}&ma={quote(r["ma"])}&tu={tu}&den={den}">{e(r["ten"])}</a><br><span class="mo">{e(r["ma"])}</span></td>'
                + "".join(f'<td class="s{" loi" if i == 3 and v else ""}">{so(v)}</td>' for i, v in enumerate(r["nhom"]))
                + f'<td class="s"><b>{so(r["tong"])}</b></td><td class="s">{so(r["tra_truoc"])}</td></tr>' for r in ds)
            nd = f"""<div class="the"><h1>Công nợ</h1>{tabs}
<form class="ngang" method="get">{loc}<label>Tính đến ngày<input type="date" name="den" value="{e(den)}"></label><button>Xem</button></form>
<p class="mo">Khoản phát sinh trước được coi là trả trước. Số dư lấy từ mốc {ngay_vn(goc)} (số dư đầu kỳ hoặc bảng công nợ nạp từ MISA) được tính tuổi từ ngày mốc.</p></div>
<table><tr><th>Đối tượng</th><th class="s">0–30 ngày</th><th class="s">31–60 ngày</th><th class="s">61–90 ngày</th><th class="s">Trên 90 ngày</th>
<th class="s">Tổng còn nợ</th><th class="s">Trả trước / dư ngược</th></tr>{bang}
<tr class="tong"><td>Cộng</td>{''.join(f'<td class="s">{so(v)}</td>' for v in tong)}<td class="s">{so(sum(tong))}</td><td class="s">{so(sum(r['tra_truoc'] for r in ds))}</td></tr></table>"""
            return self.gui(G.trang("Công nợ", nd, cid, ct["ten"]))
        ds = quan_ly.cong_no(con, cid, tk, tu, den)
        k = ["dau_no", "dau_co", "ps_no", "ps_co", "cuoi_no", "cuoi_co"]
        bang = "".join(
            f'<tr><td><a href="/cty/{cid}/congno?tk={tk}&ma={quote(r["ma"])}&tu={tu}&den={den}">{e(r["ten"])}</a></td><td>{e(r["ma"])}</td>'
            + "".join(f'<td class="s">{so(r[x])}</td>' for x in k) + "</tr>" for r in ds)
        chua = next((r for r in ds if not r["ma"]), None)
        nd = f"""<div class="the"><h1>Công nợ</h1>{tabs}{G.form_ky(tu, den, loc)}
{'<p class="bao">Có phát sinh chưa gắn đối tượng (thường là số liệu nạp từ MISA, vì sổ NKC của MISA không ghi mã đối tượng). Hóa đơn, sao kê ghi sổ trong hệ thống này tự gắn đối tượng; chứng từ nhập tay thì điền cột Đối tượng.</p>' if chua and (chua['ps_no'] or chua['ps_co']) else ''}</div>
<table><tr><th>Đối tượng</th><th>Mã</th><th class="s">Dư Nợ đầu</th><th class="s">Dư Có đầu</th><th class="s">PS Nợ</th><th class="s">PS Có</th>
<th class="s">Dư Nợ cuối</th><th class="s">Dư Có cuối</th></tr>{bang}
<tr class="tong"><td colspan="2">Cộng</td>{''.join(f'<td class="s">{so(sum(r[x] for r in ds))}</td>' for x in k)}</tr></table>"""
        self.gui(G.trang("Công nợ", nd, cid, ct["ten"]))

    # ------------------------------------------------------------ so quy, tien gui, vat tu
    def so_(self, pt, con, ct, q, rest):
        cid = ct["id"]
        muc = rest[0] if rest else "quy"
        if muc == "phieu":
            return self._phieu_kho(con, ct, q.get("so", ""))
        ngay = _ngay_du_lieu(con, cid)
        tu = q.get("tu", f"{ngay[:4]}-01-01")
        den = q.get("den", f"{ngay[:4]}-12-31")
        tabs = G.tab([("quy", f"/cty/{cid}/so/quy?tu={tu}&den={den}", "Sổ quỹ tiền mặt"),
                      ("tiengui", f"/cty/{cid}/so/tiengui?tu={tu}&den={den}", "Sổ tiền gửi ngân hàng"),
                      ("vattu", f"/cty/{cid}/so/vattu?tu={tu}&den={den}", "Sổ chi tiết vật tư, hàng hóa")], muc)
        if muc == "vattu":
            return self._so_vattu(con, ct, q, tu, den, tabs)
        goc = "111" if muc == "quy" else "112"
        tks = [r["so_tk"] for r in con.execute("SELECT so_tk FROM tai_khoan WHERE cong_ty_id=? AND so_tk LIKE ? ORDER BY so_tk",
                                               (cid, goc + "%"))]
        tk = q.get("tk") if q.get("tk") in tks else goc
        th = next((r for r in so_sach.tong_hop_tai_khoan(con, cid, tu, den) if r["so_tk"] == tk), None)
        du = (th["dau_no"] - th["dau_co"]) if th else 0
        dau = du
        bang = ""
        n_tong = c_tong = 0
        for d in so_sach.so_cai(con, cid, tk, tu, den):
            du += d["no"] - d["co"]
            n_tong += d["no"]
            c_tong += d["co"]
            bang += (f'<tr><td>{ngay_vn(d["ngay_ht"])}</td><td>{e(d["so_ct"]) if d["no"] else ""}</td><td>{e(d["so_ct"]) if d["co"] else ""}</td>'
                     f'<td>{e(d["dien_giai"])}</td><td>{e(d["tk_du"])}</td><td class="s">{so(d["no"])}</td><td class="s">{so(d["co"])}</td>'
                     f'<td class="s{" loi" if du < 0 else ""}">{so(du) or "0"}</td></tr>')
        chon = "".join(f'<option value="{t}" {"selected" if t == tk else ""}>{t}</option>' for t in tks)
        ten = "Sổ quỹ tiền mặt (S05a-DNN)" if muc == "quy" else "Sổ tiền gửi ngân hàng (S06-DNN)"
        nd = f"""<div class="the"><h1>Sổ quỹ, tiền gửi, vật tư</h1>{tabs}
{G.form_ky(tu, den, f'<label>Tài khoản<select name="tk">{chon}</select></label>')}
<p class="dong-nut"><button class="phu" onclick="window.print()">In sổ</button></p></div>
<div class="the"><h2>{ten} · TK {e(tk)}</h2><p class="mo">Từ {ngay_vn(tu)} đến {ngay_vn(den)}</p>
<table><tr><th>Ngày</th><th>Số phiếu {'thu' if muc == 'quy' else 'báo có'}</th><th>Số phiếu {'chi' if muc == 'quy' else 'báo nợ'}</th><th>Diễn giải</th><th>TK đối ứng</th>
<th class="s">{'Thu' if muc == 'quy' else 'Gửi vào'}</th><th class="s">{'Chi' if muc == 'quy' else 'Rút ra'}</th><th class="s">Tồn</th></tr>
<tr class="c1"><td colspan="7">Số dư đầu kỳ</td><td class="s">{so(dau) or '0'}</td></tr>{bang}
<tr class="tong"><td colspan="5">Cộng phát sinh / Số dư cuối kỳ</td><td class="s">{so(n_tong)}</td><td class="s">{so(c_tong)}</td><td class="s">{so(du) or '0'}</td></tr></table>
{'<p class="loi">Quỹ tiền mặt có lúc âm: kiểm tra lại thứ tự hoặc ngày các phiếu thu, chi.</p>' if muc == 'quy' and 'class="s loi"' in bang else ''}</div>"""
        self.gui(G.trang("Sổ quỹ, tiền gửi", nd, cid, ct["ten"]))

    def _so_vattu(self, con, ct, q, tu, den, tabs):
        cid = ct["id"]
        vts = con.execute("SELECT * FROM vat_tu WHERE cong_ty_id=? ORDER BY ma", (cid,)).fetchall()
        ma = q.get("ma") or (vts[0]["ma"] if vts else "")
        chon = "".join(f'<option value="{e(v["ma"])}" {"selected" if v["ma"] == ma else ""}>{e(v["ma"])} - {e(v["ten"])}</option>' for v in vts)
        dau = kho._ton(con, cid, tu).get(ma, [0, 0])
        sl, gt = dau
        bang = ""
        for r in con.execute("SELECT * FROM kho_dong WHERE cong_ty_id=? AND ma_vt=? AND ngay BETWEEN ? AND ? AND NOT (loai='D' AND ngay=?) "
                             "ORDER BY ngay, CASE loai WHEN 'X' THEN 1 ELSE 0 END, id", (cid, ma, tu, den, tu)):
            x = r["loai"] == "X"
            sl += -r["so_luong"] if x else r["so_luong"]
            gt += -(r["thanh_tien"] or 0) if x else (r["thanh_tien"] or 0)
            dg = (r["thanh_tien"] / r["so_luong"]) if r["thanh_tien"] and r["so_luong"] else None
            sl_dong = f"{r['so_luong']:g}"
            bang += (f'<tr><td>{ngay_vn(r["ngay"])}</td><td><a href="/cty/{cid}/so/phieu?so={quote(r["so_phieu"])}">{e(r["so_phieu"])}</a></td>'
                     f'<td>{e(r["dien_giai"] or "")}</td><td>{e(r["tk_doi_ung"] or "")}</td><td class="s">{so(round(dg)) if dg else ""}</td>'
                     f'<td class="s">{"" if x else sl_dong}</td><td class="s">{"" if x else so(r["thanh_tien"])}</td>'
                     f'<td class="s">{sl_dong if x else ""}</td>'
                     f'<td class="s">{(so(r["thanh_tien"]) or "<span class=mo>chưa tính giá</span>") if x else ""}</td>'
                     f'<td class="s{" loi" if sl < 0 else ""}">{sl:g}</td><td class="s">{so(gt)}</td></tr>')
        nd = f"""<div class="the"><h1>Sổ quỹ, tiền gửi, vật tư</h1>{tabs}
{G.form_ky(tu, den, f'<label>Vật tư, hàng hóa<select name="ma">{chon}</select></label>') if vts else '<p class="mo">Chưa có vật tư nào.</p>'}</div>
{f'''<div class="the"><h2>Sổ chi tiết vật liệu, dụng cụ, sản phẩm, hàng hóa (S07-DNN) · {e(ma)}</h2>
<table><tr><th>Ngày</th><th>Số phiếu</th><th>Diễn giải</th><th>TK đối ứng</th><th class="s">Đơn giá</th><th class="s">SL nhập</th><th class="s">TT nhập</th>
<th class="s">SL xuất</th><th class="s">TT xuất</th><th class="s">SL tồn</th><th class="s">TT tồn</th></tr>
<tr class="c1"><td colspan="9">Tồn đầu kỳ</td><td class="s">{dau[0]:g}</td><td class="s">{so(dau[1])}</td></tr>{bang}</table>
<p class="mo">Bấm số phiếu để in Phiếu nhập kho (01-VT) hoặc Phiếu xuất kho (02-VT).</p></div>''' if vts else ''}"""
        self.gui(G.trang("Sổ chi tiết vật tư", nd, cid, ct["ten"]))

    def _phieu_kho(self, con, ct, so_phieu):
        cid = ct["id"]
        ds = con.execute("SELECT k.*, v.ten, v.dvt, v.tk_kho FROM kho_dong k LEFT JOIN vat_tu v ON v.cong_ty_id=k.cong_ty_id AND v.ma=k.ma_vt "
                         "WHERE k.cong_ty_id=? AND k.so_phieu=? ORDER BY k.id", (cid, so_phieu)).fetchall()
        if not ds:
            return self.gui("Không có phiếu này", 404)
        nhap = ds[0]["loai"] != "X"
        n = date.fromisoformat(ds[0]["ngay"])
        tong = sum(r["thanh_tien"] or 0 for r in ds)
        hang = "".join(
            f'<tr><td class="g">{i}</td><td>{e(r["ten"] or r["ma_vt"])}</td><td>{e(r["ma_vt"])}</td><td class="g">{e(r["dvt"] or "")}</td>'
            f'<td class="s">{r["so_luong"]:g}</td><td class="s">{r["so_luong"]:g}</td>'
            f'<td class="s">{so(round(r["thanh_tien"] / r["so_luong"])) if r["thanh_tien"] and r["so_luong"] else ""}</td>'
            f'<td class="s">{so(r["thanh_tien"])}</td></tr>' for i, r in enumerate(ds, 1))
        tk_kho = ", ".join(sorted({r["tk_kho"] or "" for r in ds} - {""}))
        tk_du = ", ".join(sorted({r["tk_doi_ung"] or "" for r in ds} - {""})) or ("331" if nhap else "")
        nd = f"""<div class="to">{self._dau_phieu(ct, '01-VT' if nhap else '02-VT', 'PHIẾU NHẬP KHO' if nhap else 'PHIẾU XUẤT KHO')}
<div class="dong"><div></div><div class="g nghieng">Ngày {n.day:02d} tháng {n.month:02d} năm {n.year}<br>Số: <b>{e(so_phieu)}</b></div>
<div>Nợ: {e(tk_kho if nhap else tk_du)}<br>Có: {e(tk_du if nhap else tk_kho)}</div></div>
<p>Họ và tên người {'giao' if nhap else 'nhận'} hàng: ............................................................</p>
<p>{'Theo' if nhap else 'Lý do xuất kho'}: {e(ds[0]['dien_giai'] or '')}</p>
<p>{'Nhập' if nhap else 'Xuất'} tại kho: ........................ Địa điểm: ........................</p>
<table class="bang"><tr><th rowspan="2">STT</th><th rowspan="2">Tên, nhãn hiệu, quy cách, phẩm chất vật tư, dụng cụ, sản phẩm, hàng hóa</th>
<th rowspan="2">Mã số</th><th rowspan="2">Đơn vị tính</th><th colspan="2">Số lượng</th><th rowspan="2">Đơn giá</th><th rowspan="2">Thành tiền</th></tr>
<tr><th>{'Theo chứng từ' if nhap else 'Yêu cầu'}</th><th>{'Thực nhập' if nhap else 'Thực xuất'}</th></tr>{hang}
<tr><td></td><td class="dam">Cộng</td><td></td><td></td><td></td><td></td><td></td><td class="s dam">{so(tong)}</td></tr></table>
<p>Tổng số tiền (viết bằng chữ): <i>{e(quan_ly.bang_chu(tong)) if tong else '..........................................'}</i></p>
<p>Số chứng từ gốc kèm theo: ........</p>
<div class="ky bon"><div><b>Người lập phiếu</b><br><i>(Ký, họ tên)</i></div><div><b>Người {'giao' if nhap else 'nhận'} hàng</b><br><i>(Ký, họ tên)</i></div>
<div><b>Thủ kho</b><br><i>(Ký, họ tên)</i></div><div><b>Kế toán trưởng</b><br><i>(Ký, họ tên)</i></div></div></div>"""
        self.gui(G.trang_in(f"{'Phiếu nhập' if nhap else 'Phiếu xuất'} {so_phieu}", nd))

    # ------------------------------------------------------------ luu chuyen tien te
    def luuchuyen(self, pt, con, ct, q, rest):
        cid = ct["id"]
        ngay = _ngay_du_lieu(con, cid)
        tu = q.get("tu", f"{ngay[:4]}-01-01")
        den = q.get("den", f"{ngay[:4]}-12-31")
        kq = quan_ly.luu_chuyen_tien(con, cid, tu, den)
        try:
            tu0, den0 = f"{int(tu[:4]) - 1}{tu[4:]}", f"{int(den[:4]) - 1}{den[4:]}".replace("-02-29", "-02-28")
            kq0 = quan_ly.luu_chuyen_tien(con, cid, tu0, den0)
        except ValueError:
            kq0 = {}
        dam = {"20", "30", "40", "50", "60", "70"}
        muc = {"01": "I. Lưu chuyển tiền từ hoạt động kinh doanh", "21": "II. Lưu chuyển tiền từ hoạt động đầu tư",
               "31": "III. Lưu chuyển tiền từ hoạt động tài chính"}
        bang = ""
        for ma, ten in quan_ly.B03:
            if ma in muc:
                bang += f'<tr class="c1"><td colspan="4">{muc[ma]}</td></tr>'
            bang += (f'<tr class="{"tong" if ma in dam else ""}"><td>{e(ten)}</td><td class="g">{ma}</td>'
                     f'<td class="s">{so(kq[ma])}</td><td class="s">{so(kq0.get(ma, 0))}</td></tr>')
        lech = kq["70"] - sum(n - c for k, (n, c) in bao_cao.phan_hai_ben(con, cid, bao_cao.ngay_sau(den))[0].items()
                              if k.startswith(("111", "112", "113")))
        nd = f"""<div class="the"><h1>Báo cáo lưu chuyển tiền tệ (Mẫu số B03-DNN, phương pháp trực tiếp)</h1>{G.form_ky(tu, den)}
<p class="mo">Mỗi bút toán có TK 111, 112, 113 được xếp vào chỉ tiêu theo tài khoản đối ứng (131/511 → mục 01, 331/152/156/133 → 02, 334 → 03,
635 → 04, 3334 → 05, 211/241 → 21, 341 → 33/34, 411 → 31/32, 421 → 35; còn lại → 06/07).
TT133 không bắt buộc doanh nghiệp nhỏ và vừa lập B03, nhưng khuyến khích lập.</p>
{'<p class="ok">Tiền cuối kỳ (mã 70) khớp số dư TK 111 + 112 + 113 trên sổ.</p>' if not lech else f'<p class="loi">Mã 70 lệch số dư tiền trên sổ {so(lech)} đ.</p>'}
<p><button class="phu" onclick="window.print()">In báo cáo</button></p></div>
<div class="the"><table><tr><th>Chỉ tiêu</th><th>Mã số</th><th class="s">Kỳ này</th><th class="s">Cùng kỳ năm trước</th></tr>{bang}</table></div>"""
        self.gui(G.trang("Lưu chuyển tiền tệ", nd, cid, ct["ten"]))

    # ------------------------------------------------------------ doi chieu
    def doichieu(self, pt, con, ct, q, rest):
        cid = ct["id"]
        ngay = q.get("ngay") or _ngay_du_lieu(con, cid)
        ds = quan_ly.doi_chieu(con, cid, ngay)
        bang = "".join(
            f'<tr><td>{e(nd_)}</td><td class="s">{so(a) or "0"}</td><td class="s">{so(b) or "0"}</td>'
            f'<td class="s">{G.nhan_tt("Khớp", "xanh") if not c else "<span class=loi>" + so(c) + "</span>"}</td><td class="mo">{e(gc)}</td></tr>'
            for nd_, a, b, c, gc in ds)
        chua, huy = quan_ly.hoa_don_can_xem(con, cid)
        lk_ct = lambda i: f'<a href="/cty/{cid}/chungtu/{i}">Chứng từ</a>' if i else ""
        hd = lambda h: (f'<tr><td>{ngay_vn(h["ngay_lap"])}</td><td><a href="/cty/{cid}/hoadon/xem/{h["id"]}">{e(h["khhdon"])}-{e(h["shdon"])}</a></td>'
                        f'<td>{"Mua" if h["chieu"] == "mua" else "Bán"}</td><td>{e(h["nb_ten"] if h["chieu"] == "mua" else h["nm_ten"])}</td>'
                        f'<td class="s">{so(h["tong_tien"])}</td><td>{e(hoa_don.TRANG_THAI.get(h["trang_thai"]))}</td>'
                        f'<td>{lk_ct(h["chung_tu_id"])}</td></tr>')
        dau_bang = '<table><tr><th>Ngày</th><th>Số HĐ</th><th>Chiều</th><th>Đối tác</th><th class="s">Tổng tiền</th><th>Trạng thái</th><th></th></tr>'
        nd = f"""<div class="the"><h1>Đối chiếu sổ cái với sổ chi tiết</h1>
<form class="ngang" method="get"><label>Tại cuối ngày<input type="date" name="ngay" value="{e(ngay)}"></label><button>Đối chiếu</button></form>
<p class="mo">Mỗi dòng so số dư hoặc phát sinh trên sổ cái với số liệu từ phân hệ chi tiết. Dòng lệch cần xem ghi chú và chứng từ liên quan.</p>
{'<table><tr><th>Nội dung</th><th class="s">Sổ cái</th><th class="s">Sổ chi tiết</th><th class="s">Chênh</th><th>Ghi chú</th></tr>' + bang + '</table>' if ds else '<p class="mo">Chưa có số liệu để đối chiếu.</p>'}</div>
<div class="the"><h2>Hóa đơn đã ghi sổ nhưng sau đó bị hủy hoặc thay thế ({len(huy)})</h2>
{(dau_bang + ''.join(hd(h) for h in huy) + '</table><p class="bao">Xóa hoặc điều chỉnh chứng từ của các hóa đơn này, rồi ghi sổ hóa đơn thay thế (nếu có).</p>') if huy else '<p class="ok">Không có.</p>'}</div>
<div class="the"><h2>Hóa đơn chưa ghi sổ ({len(chua)})</h2>
{(dau_bang + ''.join(hd(h) for h in chua[:300]) + '</table>' + (f'<p class="mo">Hiện 300 / {len(chua)} hóa đơn.</p>' if len(chua) > 300 else '')) if chua else '<p class="ok">Tất cả hóa đơn hợp lệ đã ghi sổ.</p>'}
<p><a class="nut phu" href="/cty/{cid}/hoadon">Mở trang Hóa đơn để ghi sổ</a></p></div>"""
        self.gui(G.trang("Đối chiếu, kiểm tra", nd, cid, ct["ten"]))

    # ------------------------------------------------------------ danh muc doi tuong
    def doituong(self, pt, con, ct, q, rest):
        cid = ct["id"]
        doi_tuong.chuan_bi(con)
        if rest and rest[0] == "excel":
            b = doi_tuong.mau_excel(con, cid)
            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quote('Danh_muc_doi_tuong_' + ct['mst'] + '.xlsx')}")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            return self.wfile.write(b)
        tb = ""
        if pt == "POST":
            try:
                if self.headers.get("Content-Type", "").startswith("multipart/"):
                    from .trang_hoa_don import doc_multipart
                    _, tep = doc_multipart(self)
                    if not tep:
                        raise ValueError("Chưa chọn file.")
                    n, loi = doi_tuong.nap_excel(con, cid, tep[0][1])
                    tb = f'<p class="ok">Đã nạp {n} đối tượng.</p>' + "".join(f'<p class="loi">{e(x)}</p>' for x in loi[:20])
                else:
                    f = {k: v[0].strip() for k, v in self.doc_form().items()}
                    hd = f.get("hanh_dong")
                    if hd == "tu_dong":
                        n = doi_tuong.tu_bo_sung(con, cid)
                        tb = f'<p class="ok">Đã thêm {n} đối tượng mới từ hóa đơn, công nợ, nhân viên, chứng từ.</p>'
                    elif hd == "xoa":
                        doi_tuong.xoa(con, cid, f["ma"])
                        tb = f'<p class="ok">Đã xóa {e(f["ma"])}.</p>'
                    else:
                        doi_tuong.luu(con, cid, f)
                        con.commit()
                        tb = f'<p class="ok">Đã lưu {e(f.get("ten"))}.</p>'
            except ValueError as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        loai = q.get("loai", "")
        tim = q.get("q", "").strip()
        ds = doi_tuong.danh_sach(con, cid, loai, tim)
        sua = doi_tuong.lay(con, cid, q["sua"]) if q.get("sua") else None
        v = lambda k: e(sua[k] if sua and sua[k] is not None else "")
        dem = {r["loai"]: r["n"] for r in con.execute("SELECT loai, COUNT(*) n FROM doi_tuong WHERE cong_ty_id=? GROUP BY loai", (cid,))}
        tabs = G.tab([("", f"/cty/{cid}/doituong", f"Tất cả ({sum(dem.values())})")] +
                     [(k, f"/cty/{cid}/doituong?loai={k}", f"{t} ({dem.get(k, 0)})") for k, t in doi_tuong.LOAI.items()], loai)
        bang = "".join(
            f'<tr><td><b>{e(r["ma"])}</b></td><td>{e(r["ten"])}</td><td>{G.nhan_tt(doi_tuong.LOAI.get(r["loai"], r["loai"]))}</td>'
            f'<td>{e(r["mst"] or "")}</td><td>{e(r["dia_chi"] or "")}</td><td>{e(r["dien_thoai"] or "")}</td>'
            f'<td style="white-space:nowrap"><a class="nut phu nho" href="/cty/{cid}/doituong?sua={quote(r["ma"])}#sua">Sửa</a> '
            f'<a class="nut phu nho" href="/cty/{cid}/congno?tk={"331" if r["loai"] == "NCC" else "334" if r["loai"] == "NV" else "131"}&ma={quote(r["ma"])}">Công nợ</a></td></tr>'
            for r in ds[:2000])
        chon_loai = "".join(f'<option value="{k}" {"selected" if sua and sua["loai"] == k else ""}>{t}</option>' for k, t in doi_tuong.LOAI.items())
        nd = f"""<div class="the"><h1>Khách hàng, nhà cung cấp, nhân viên</h1>{tb}{tabs}
<form class="ngang" method="get"><input type="hidden" name="loai" value="{e(loai)}"><label>Tìm mã, tên, MST<input name="q" value="{e(tim)}"></label><button class="phu">Tìm</button></form>
<div class="dong-nut"><form method="post"><input type="hidden" name="hanh_dong" value="tu_dong"><button>Lấy tự động từ hóa đơn, công nợ, nhân viên</button></form>
<a class="nut phu" href="/cty/{cid}/doituong/excel">Tải Excel (dùng làm mẫu để sửa, thêm)</a></div>
<form method="post" enctype="multipart/form-data" class="ngang"><label>Nạp Excel (mẫu trên, hoặc danh sách khách hàng / nhà cung cấp xuất từ MISA)<input type="file" name="tep" accept=".xlsx" required></label><button class="phu">Nạp</button></form>
<p class="mo">Mã đối tượng là mã dùng ở cột Đối tượng khi nhập chứng từ. Hóa đơn điện tử dùng mã = MST đối tác, ghi sổ hóa đơn là tự thêm vào danh mục. Địa chỉ ở đây được in lên phiếu thu, phiếu chi.</p></div>
<details class="the" id="sua" {"open" if sua else ""}><summary>{"Sửa " + e(sua["ma"]) if sua else "Thêm đối tượng"}</summary>
<form method="post" class="ngang" style="margin-top:12px">
<label>Mã<input name="ma" size="14" required value="{v('ma')}"></label><label>Tên<input name="ten" size="40" required value="{v('ten')}"></label>
<label>Loại<select name="loai">{chon_loai}</select></label><label>Mã số thuế<input name="mst" size="15" value="{v('mst')}"></label>
<label>Địa chỉ<input name="dia_chi" size="50" value="{v('dia_chi')}"></label><label>Điện thoại<input name="dien_thoai" size="14" value="{v('dien_thoai')}"></label>
<label>Email<input name="email" size="22" value="{v('email')}"></label><label>Ghi chú<input name="ghi_chu" size="22" value="{v('ghi_chu')}"></label>
<button>Lưu</button></form>
{f'<form method="post" style="margin-top:10px" onsubmit="return confirm(&quot;Xóa {e(sua["ma"])} khỏi danh mục? Chứng từ đã ghi không bị ảnh hưởng.&quot;)"><input type="hidden" name="hanh_dong" value="xoa"><input type="hidden" name="ma" value="{v("ma")}"><button class="nguy">Xóa khỏi danh mục</button></form>' if sua else ''}</details>
<table><tr><th>Mã</th><th>Tên</th><th>Loại</th><th>MST</th><th>Địa chỉ</th><th>Điện thoại</th><th></th></tr>{bang or '<tr><td colspan="7" class="mo">Chưa có đối tượng nào. Bấm "Lấy tự động" để máy điền từ số liệu đã có.</td></tr>'}</table>"""
        self.gui(G.trang("Khách hàng, nhà cung cấp", nd, cid, ct["ten"]))

    # ------------------------------------------------------------ khoa so, nhat ky
    def khoaso(self, pt, con, ct, q, rest):
        cid = ct["id"]
        tb = ""
        k = quan_ly.ngay_khoa(con, cid)
        if pt == "POST":
            f = {x: v[0].strip() for x, v in self.doc_form().items()}
            moi = f.get("den_ngay") or None
            lui = (not moi) or (k and moi < k)
            if lui and not self.la_quan_tri():
                tb = '<p class="loi">Chỉ người Quản trị mới mở khóa hoặc lùi ngày khóa sổ.</p>'
            else:
                quan_ly.khoa(con, cid, moi, self.ten_nguoi())
                k = moi
                tb = f'<p class="ok">{"Đã khóa sổ đến " + ngay_vn(moi) if moi else "Đã mở khóa sổ."}</p>'
        nk = con.execute("SELECT * FROM nhat_ky_sua WHERE cong_ty_id IN (?, 0) ORDER BY id DESC LIMIT 300", (cid,)).fetchall()
        ten_hd = {"sua": ("Sửa", "vang"), "xoa": ("Xóa", "do"), "khoa": ("Khóa sổ", "lam"), "mo_khoa": ("Mở khóa", "vang"),
                  "khoi_phuc": ("Khôi phục dữ liệu", "do"), "thao_tac": ("Thao tác", "")}

        def chi_tiet(r):
            if not r["noi_dung"]:
                return ""
            try:
                d = json.loads(r["noi_dung"])
            except ValueError:
                return e(r["noi_dung"])
            if isinstance(d, dict) and "dong" in d:
                c = d["chung_tu"]
                dong = "".join(f'<tr><td>{e(x["tk_no"])}</td><td>{e(x["tk_co"])}</td><td class="s">{so(x["so_tien"])}</td><td>{e(x.get("dien_giai"))}</td></tr>'
                               for x in d["dong"])
                return (f'<details><summary>Bản trước khi {"sửa" if r["hanh_dong"] == "sua" else "xóa"}</summary>'
                        f'<p>{ngay_vn(c["ngay_ht"])} · {e(c["dien_giai"])}</p><table><tr><th>Nợ</th><th>Có</th><th class="s">Tiền</th><th>Diễn giải</th></tr>{dong}</table></details>')
            if isinstance(d, dict) and "truoc" in d:
                return f'Trước: {ngay_vn(d["truoc"]) or "chưa khóa"} → sau: {ngay_vn(d["sau"]) or "mở khóa"}'
            return e(json.dumps(d, ensure_ascii=False))[:300]
        bang = "".join(
            f'<tr><td style="white-space:nowrap">{e(r["luc"].replace("T", " "))}</td><td>{e(r["nguoi"] or "")}</td>'
            f'<td>{G.nhan_tt(*ten_hd.get(r["hanh_dong"], (r["hanh_dong"], "")))}</td><td>{e(r["so_ct"] or "")}</td><td>{chi_tiet(r)}</td></tr>' for r in nk)
        nd = f"""<div class="the"><h1>Khóa sổ</h1>{tb}
<p>Hiện tại: {f'<b>sổ đã khóa đến hết ngày {ngay_vn(k)}</b>. Không thêm, sửa, xóa được chứng từ có ngày hạch toán từ ngày này trở về trước, kể cả khi nạp lại MISA, ghi sổ lương, trích khấu hao.' if k else '<b>chưa khóa kỳ nào</b>.'}</p>
<p class="mo">Nên khóa sổ ngay sau khi nộp tờ khai của kỳ, để số liệu đã kê khai không bị thay đổi vô tình. Mở khóa hoặc lùi ngày khóa cần quyền Quản trị và được ghi vào nhật ký.</p>
<form method="post" class="ngang"><label>Khóa sổ đến hết ngày<input type="date" name="den_ngay" value="{e(k or '')}"></label><button>Lưu ngày khóa</button></form>
{f'<form method="post" class="ngang" style="margin-top:10px" onsubmit="return confirm(\'Mở khóa sổ?\')"><input type="hidden" name="den_ngay" value=""><button class="nguy">Mở khóa sổ</button></form>' if k else ''}</div>
<div class="the"><h2>Nhật ký sửa, xóa, khóa sổ</h2>
{'<table><tr><th>Lúc</th><th>Người</th><th>Hành động</th><th>Số CT</th><th>Chi tiết</th></tr>' + bang + '</table>' if nk else '<p class="mo">Chưa có thay đổi nào.</p>'}</div>"""
        self.gui(G.trang("Khóa sổ", nd, cid, ct["ten"]))
