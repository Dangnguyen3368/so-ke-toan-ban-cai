"""Tai hoa don tu cong hoadondientu.gdt.gov.vn.

Dung dung cac dia chi ma trang web cua cong goi khi nguoi dung tra cuu, voi
tai khoan dang nhap cua chinh doanh nghiep. Nguoi dung tu go captcha; mat
khau khong duoc luu lai.

Thang 11/2026 cong da bo cong ket noi :30000; moi API nay nam duoi
https://hoadondientu.gdt.gov.vn/api/... (cong 443) va cong chan yeu cau
thieu cac tieu de request-id / Action / End-Point ma trang web tu gui.

Luu y: day khong phai dich vu chinh thuc co tai lieu. Neu Tong cuc Thue doi
cach hoat dong cua cong, phan nay can sua lai; khi do van dung duoc cach
xuat Excel / XML tay roi nap vao ung dung.
"""
import io
import json
import ssl
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from calendar import monthrange
from datetime import date, datetime

GOC = "https://hoadondientu.gdt.gov.vn/api"
TRANG = "https://hoadondientu.gdt.gov.vn"
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
       "Chrome/131.0.0.0 Safari/537.36")
END_POINT = "/tra-cuu/tra-cuu-hoa-don"
# Cong gioi han toc do (loi 429): cho bao nhieu giay truoc moi lan thu lai, va nghi giua cac yeu cau.
CHO_429 = (20, 40, 60, 90)
NGHI_TRANG = 1.0
NGHI_XML = 0.7


class LoiCong(Exception):
    pass


def _goi(url, token=None, du_lieu=None, nhi_phan=False, lan=3, hanh_dong="", them_tieu_de=None):
    tieu_de = {"User-Agent": _UA, "Accept": "application/json, text/plain, */*",
               "Origin": TRANG, "Referer": TRANG + "/",
               "request-id": str(uuid.uuid4()), "End-Point": END_POINT,
               "Action": urllib.parse.quote(hanh_dong, safe="")}
    if token:
        tieu_de["Authorization"] = f"Bearer {token}"
        tieu_de["Accept-Language"] = "vi"
    tieu_de.update(them_tieu_de or {})
    body = None
    if du_lieu is not None:
        body = json.dumps(du_lieu).encode()
        tieu_de["Content-Type"] = "application/json"
    lan_429 = 0
    i = 0
    while i < lan:
        try:
            req = urllib.request.Request(url, data=body, headers=tieu_de)
            with urllib.request.urlopen(req, timeout=60, context=ssl.create_default_context()) as r:
                b = r.read()
                return b if nhi_phan else json.loads(b.decode("utf-8") or "null")
        except urllib.error.HTTPError as ex:
            noi_dung = ex.read().decode("utf-8", "replace")[:300]
            if ex.code == 401:
                raise LoiCong("Phiên đăng nhập hết hạn hoặc sai thông tin. Hãy đăng nhập lại.") from ex
            if ex.code == 403:
                try:
                    tb = json.loads(noi_dung).get("message") or noi_dung
                except (ValueError, AttributeError):
                    tb = noi_dung
                raise LoiCong(f"Cổng thuế chặn yêu cầu (403): {tb}") from ex
            if ex.code == 429:
                if lan_429 >= len(CHO_429):
                    raise LoiCong("Cổng thuế báo tải quá nhiều (429). Chờ vài phút rồi bấm Tải về lại; "
                                  "hóa đơn đã tải sẽ không bị tải lại.") from ex
                try:
                    cho = min(int(ex.headers.get("Retry-After") or 0), 300)
                except (TypeError, ValueError):
                    cho = 0
                time.sleep(max(cho, CHO_429[lan_429]))
                lan_429 += 1
                continue
            if ex.code == 500 and "ckey" in noi_dung:
                raise LoiCong("cổng bắt gõ captcha cho nhóm này") from ex
            if ex.code == 400:
                raise LoiCong(f"Cổng thuế từ chối yêu cầu: {noi_dung}") from ex
            if i == lan - 1:
                raise LoiCong(f"Cổng thuế lỗi {ex.code}: {noi_dung}") from ex
        except (urllib.error.URLError, TimeoutError) as ex:
            if i == lan - 1:
                raise LoiCong(f"Không kết nối được cổng thuế: {ex}") from ex
        time.sleep(2 * (i + 1))
        i += 1


def lay_captcha():
    """Tra ve (key, svg) de hien cho nguoi dung go."""
    d = _goi(f"{GOC}/captcha")
    return d["key"], d["content"]


def dang_nhap(mst, mat_khau, ckey, cvalue):
    d = _goi(f"{GOC}/security-taxpayer/authenticate",
             du_lieu={"username": mst, "password": mat_khau, "ckey": ckey, "cvalue": cvalue})
    if not d or not d.get("token"):
        raise LoiCong(f"Đăng nhập không thành công: {d}")
    return d["token"]


def chia_thang(tu, den):
    """Chia khoang ngay thanh tung thang (cong chi cho tra trong mot thang)."""
    a = datetime.strptime(tu, "%Y-%m-%d").date()
    b = datetime.strptime(den, "%Y-%m-%d").date()
    while a <= b:
        cuoi = date(a.year, a.month, monthrange(a.year, a.month)[1])
        yield a, min(cuoi, b)
        a = date(cuoi.year + (cuoi.month == 12), cuoi.month % 12 + 1, 1)


# (ten nhom, duong dan, loai, dieu kien them)
NHOM_TRA_CUU = {
    "ban": [("Bán ra có mã", "query", "sold", ""),
            ("Bán ra máy tính tiền", "sco-query", "sold", "")],
    "mua": [("Mua vào có mã", "query", "purchase", ";ttxly==5"),
            ("Mua vào không mã", "query", "purchase", ";ttxly==6"),
            ("Mua vào máy tính tiền", "sco-query", "purchase", ";ttxly==8")],
}


def _ten_hanh_dong(goc, loai, viec="Tìm kiếm"):
    """Chuoi 'Action' giong het trang web cua cong gui (vd 'Tìm kiếm (hóa đơn mua vào)')."""
    chieu = "bán ra" if loai == "sold" else "mua vào"
    mtt = "máy tính tiền " if goc == "sco-query" else ""
    return f"{viec} (hóa đơn {mtt}{chieu})"


def _url_tra_cuu(goc, loai, tim, trang_thai=None, co=50):
    """Dung URL giong het trang web cua cong: sort, size, state, search; khong ma hoa / : ; =."""
    url = f"{GOC}/{goc}/invoices/{loai}?sort=tdlap:desc&size={co}"
    if trang_thai:
        url += "&state=" + urllib.parse.quote(str(trang_thai), safe="/:;=,+-_.~")
    return url + "&search=" + urllib.parse.quote(tim, safe="/:;=,()")


def ds_hoa_don(token, chieu, tu, den, bao=print, hom_nay=None, mtt=False):
    """Lay danh sach hoa don (du lieu tom tat) cho mot chieu, moi thang mot lan tra.

    - Cong khong cho tra ngay trong tuong lai ("Truy van khong hop le"), nen ngay cuoi
      bi cat ve hom nay.
    - Mot nhom / mot thang bi cong tu choi thi bo qua va bao lai, cac phan khac van tai
      (truoc day mot loi lam mat het ca lan tai). Chi het phien moi dung han.
    - Hoa don may tinh tien (sco-query) tren web phai go captcha moi lan tra; nhom do bi
      chan mot lan thi khong thu lai cac thang sau.
    """
    hom_nay = hom_nay or date.today()
    if den > hom_nay.isoformat():
        den = hom_nay.isoformat()
    if tu > den:
        return
    bo_qua = set()
    for a, b in chia_thang(tu, den):
        for nhom, goc, loai, them in NHOM_TRA_CUU[chieu]:
            if nhom in bo_qua or (goc == "sco-query" and not mtt):
                continue
            tim = (f"tdlap=ge={a:%d/%m/%Y}T00:00:00;tdlap=le={b:%d/%m/%Y}T23:59:59{them}")
            trang_thai = None
            while True:
                try:
                    d = _goi(_url_tra_cuu(goc, loai, tim, trang_thai), token,
                             hanh_dong="" if trang_thai else _ten_hanh_dong(goc, loai)) or {}
                except LoiCong as ex:
                    if "hết hạn" in str(ex):
                        raise
                    if "429" in str(ex):
                        bao(f"Dừng ở \"{nhom}\" tháng {a:%m/%Y}: {ex}")
                        return
                    if goc == "sco-query":
                        bo_qua.add(nhom)
                        bao(f"Không tải được nhóm \"{nhom}\": {ex}. Nhóm này hãy tải tay trên cổng rồi nạp file.")
                    else:
                        bao(f"Không tải được \"{nhom}\" tháng {a:%m/%Y}: {ex}")
                    break
                for x in d.get("datas") or []:
                    x["_goc"] = goc
                    x["_nhom"] = nhom
                    x["_loai"] = loai
                    yield x
                trang_thai = d.get("state")
                if not trang_thai or not d.get("datas"):
                    break
                time.sleep(NGHI_TRANG)


def tu_json(x):
    """Doi mot dong JSON cua cong sang dict hoa don cua ung dung."""
    tts = [{"tsuat": t.get("tsuat") or "", "thtien": int(t.get("thtien") or 0), "tthue": int(t.get("tthue") or 0)}
           for t in (x.get("thttltsuat") or [])]
    khhdon = x.get("khhdon") or ""
    return {
        "nbmst": x.get("nbmst") or "", "nb_ten": x.get("nbten"),
        "nmmst": x.get("nmmst") or "", "nm_ten": x.get("nmten") or x.get("nmtnmua"),
        "khmshdon": str(x.get("khmshdon") or ""), "khhdon": khhdon, "shdon": str(x.get("shdon") or ""),
        "ngay_lap": (x.get("tdlap") or "")[:10], "ma_cqt": x.get("mhdon"),
        "tien_hang": int(x.get("tgtcthue") or 0), "tien_thue": int(x.get("tgtthue") or 0),
        "tong_tien": int(x.get("tgtttbso") or 0), "theo_thue_suat": tts or None,
        "trang_thai": int(x.get("tthai") or 1),
        "may_tinh_tien": 1 if x.get("_goc") == "sco-query" else 0,
    }


def tai_xml(token, x):
    """Tai file XML cua mot hoa don. Tra ve bytes XML hoac None neu cong khong cho tai."""
    q = urllib.parse.urlencode({"nbmst": x["nbmst"], "khhdon": x["khhdon"],
                                "shdon": x["shdon"], "khmshdon": x["khmshdon"]})
    try:
        goc = x.get("_goc", "query")
        b = _goi(f"{GOC}/{goc}/invoices/export-xml?{q}", token, nhi_phan=True, lan=2,
                 hanh_dong=_ten_hanh_dong(goc, x.get("_loai", "purchase"), "Xuất xml"))
    except LoiCong as ex:
        if "hết hạn" in str(ex) or "429" in str(ex) or "captcha" in str(ex):
            raise
        return None
    if b[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            for n in z.namelist():
                if n.lower().endswith(".xml"):
                    return z.read(n)
        return None
    return b if b.lstrip()[:1] == b"<" else None


def ds_mtt(token, chieu, tu, den, ckey, cvalue):
    """Hoa don may tinh tien (sco-query) trong mot thang. Cong bat go captcha cho moi lan tra,
    giong trang web: captcha (ckey, cvalue) gui kem trong tham so va tieu de.
    Tra ve list dong JSON. Sai captcha thi nem LoiCong."""
    nhom, goc, loai, them = [n for n in NHOM_TRA_CUU[chieu] if n[1] == "sco-query"][0]
    a = datetime.strptime(tu, "%Y-%m-%d").date()
    b = min(datetime.strptime(den, "%Y-%m-%d").date(), date.today())
    if a > b:
        return []
    cap = {"ckey": ckey, "cvalue": cvalue}
    tim = f"tdlap=ge={a:%d/%m/%Y}T00:00:00;tdlap=le={b:%d/%m/%Y}T23:59:59{them}"
    kq, trang_thai = [], None
    while True:
        url = _url_tra_cuu(goc, loai, tim, trang_thai) + "&" + urllib.parse.urlencode(cap)
        try:
            d = _goi(url, token, hanh_dong="" if trang_thai else _ten_hanh_dong(goc, loai), them_tieu_de=cap) or {}
        except LoiCong as ex:
            if "hết hạn" in str(ex) or "429" in str(ex):
                raise
            raise LoiCong(f"Cổng không nhận captcha hoặc từ chối ({ex}). Gõ captcha mới rồi bấm tải lại.") from ex
        for x in d.get("datas") or []:
            x["_goc"], x["_nhom"], x["_loai"] = goc, nhom, loai
            kq.append(x)
        trang_thai = d.get("state")
        if not trang_thai or not d.get("datas"):
            return kq
        time.sleep(NGHI_TRANG)


def khoa_hd(h):
    """Khoa nhan dien mot hoa don (giong khoa trung trong hoa_don.luu)."""
    return (str(h.get("nbmst") or ""), str(h.get("khmshdon") or ""), str(h.get("khhdon") or ""),
            str(h.get("shdon") or ""))


def tai_ve(token, chieu, tu, den, kem_xml=True, bao=print, da_co_xml=(), ds=None):
    """Tai danh sach (va XML) hoa don. Tra ve list dict hoa don san sang de luu.

    da_co_xml: tap khoa_hd cua hoa don da co XML trong so, khong tai lai XML (do bi cong gioi han).
    Neu cong van bao qua nhieu (429) khi tai XML thi dung tai XML, van giu danh sach.
    """
    from . import hoa_don

    kq = []
    dung_xml = False
    for x in (ds if ds is not None else ds_hoa_don(token, chieu, tu, den, bao=bao)):
        h = tu_json(x)
        if kem_xml and not dung_xml and khoa_hd(h) not in da_co_xml:
            try:
                b = tai_xml(token, x)
            except LoiCong as ex:
                if "hết hạn" in str(ex):
                    raise
                dung_xml = True
                bao(f"Không tải được XML cho các hóa đơn còn lại: {ex}")
                b = None
            if b:
                try:
                    tu_xml = hoa_don.doc_xml(b)
                    tu_xml["trang_thai"] = h["trang_thai"]  # trang thai moi nhat lay tu cong
                    tu_xml["may_tinh_tien"] = h["may_tinh_tien"]
                    h = tu_xml
                except ValueError:
                    pass
            time.sleep(NGHI_XML)
        kq.append(h)
        if len(kq) % 20 == 0:
            bao(f"Đã tải {len(kq)} hóa đơn {'bán ra' if chieu == 'ban' else 'mua vào'}...")
    return kq
