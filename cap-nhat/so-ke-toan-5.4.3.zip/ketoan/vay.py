"""Khe uoc vay: hop dong vay ngan hang / ca nhan, lich tra goc lai, ghi so nhan tien vay va tung ky tra.

Cach tra:
- 'goc_deu'  : goc chia deu moi ky, lai tinh tren du no con lai (pho bien o ngan hang).
- 'nien_kim' : moi ky tra so tien bang nhau (goc + lai).
- 'cuoi_ky'  : hang ky chi tra lai, goc tra mot lan o ky cuoi.
Lai moi ky = du no dau ky x lai suat nam x so ngay thuc te / 365.
But toan: nhan vay  No TK tien / Co TK vay (3411); tra ky  No 3411 (goc), No 635 (lai) / Co TK tien.
"""
import calendar
from datetime import date, timedelta

from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS khe_uoc_vay (
    id INTEGER PRIMARY KEY,
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    so_khe_uoc TEXT NOT NULL,
    ben_cho_vay TEXT NOT NULL,
    ma_doi_tuong TEXT NOT NULL DEFAULT '',
    ngay_vay TEXT NOT NULL,
    so_tien INTEGER NOT NULL CHECK (so_tien > 0),
    lai_suat REAL NOT NULL DEFAULT 0,          -- %/nam
    so_ky INTEGER NOT NULL CHECK (so_ky > 0),  -- so thang
    cach_tra TEXT NOT NULL DEFAULT 'goc_deu',
    tk_vay TEXT NOT NULL DEFAULT '3411',
    tk_tien TEXT NOT NULL DEFAULT '1121',
    tk_lai TEXT NOT NULL DEFAULT '635',
    muc_dich TEXT,
    UNIQUE (cong_ty_id, so_khe_uoc)
);
"""

CACH_TRA = {"goc_deu": "Gốc đều, lãi theo dư nợ", "nien_kim": "Trả đều (gốc + lãi bằng nhau)",
            "cuoi_ky": "Trả lãi hằng tháng, gốc cuối kỳ"}


def chuan_bi(con):
    con.executescript(SCHEMA)


def _cong_thang(d, n):
    m = d.month - 1 + n
    y, m = d.year + m // 12, m % 12 + 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def lich_tra(kv):
    """List dict: ky, ngay, du_dau, goc, lai, tong, du_cuoi (so nguyen dong)."""
    ngay0 = date.fromisoformat(kv["ngay_vay"])
    n, du, ls = int(kv["so_ky"]), int(kv["so_tien"]), float(kv["lai_suat"] or 0) / 100
    cach = kv["cach_tra"]
    tra_deu = 0
    if cach == "nien_kim":
        r = ls / 12
        tra_deu = round(du * r / (1 - (1 + r) ** -n)) if r else round(du / n)
    kq, truoc = [], ngay0
    for k in range(1, n + 1):
        ngay = _cong_thang(ngay0, k)
        lai = round(du * ls * (ngay - truoc).days / 365)
        if k == n:
            goc = du
        elif cach == "goc_deu":
            goc = round(int(kv["so_tien"]) / n)
        elif cach == "nien_kim":
            goc = max(min(tra_deu - round(du * ls / 12), du), 0)
        else:
            goc = 0
        kq.append({"ky": k, "ngay": ngay.isoformat(), "du_dau": du, "goc": goc, "lai": lai, "tong": goc + lai, "du_cuoi": du - goc})
        du -= goc
        truoc = ngay
    return kq


def so_ct_nhan(kv):
    return f"VAY-{kv['so_khe_uoc']}"


def so_ct_ky(kv, ky):
    return f"TRAVAY-{kv['so_khe_uoc']}-{ky:02d}"


def them(con, cid, d):
    chuan_bi(con)
    cot = ["so_khe_uoc", "ben_cho_vay", "ma_doi_tuong", "ngay_vay", "so_tien", "lai_suat", "so_ky", "cach_tra",
           "tk_vay", "tk_tien", "tk_lai", "muc_dich"]
    v = {k: d.get(k) for k in cot if d.get(k) not in (None, "")}
    if not v.get("so_khe_uoc") or not v.get("ben_cho_vay") or not v.get("ngay_vay"):
        raise ValueError("Cần số khế ước, bên cho vay và ngày vay.")
    v["so_tien"], v["so_ky"] = int(v.get("so_tien") or 0), int(v.get("so_ky") or 0)
    v["lai_suat"] = float(str(v.get("lai_suat") or 0).replace(",", "."))
    if v["so_tien"] <= 0 or v["so_ky"] <= 0:
        raise ValueError("Số tiền vay và số kỳ phải lớn hơn 0.")
    if v.get("cach_tra", "goc_deu") not in CACH_TRA:
        raise ValueError("Cách trả không đúng.")
    date.fromisoformat(v["ngay_vay"])
    cur = con.execute(f"INSERT INTO khe_uoc_vay (cong_ty_id, {', '.join(v)}) VALUES (?{', ?' * len(v)})", [cid, *v.values()])
    con.commit()
    return cur.lastrowid


def lay(con, cid, kid):
    chuan_bi(con)
    return con.execute("SELECT * FROM khe_uoc_vay WHERE cong_ty_id=? AND id=?", (cid, kid)).fetchone()


def danh_sach(con, cid):
    chuan_bi(con)
    return con.execute("SELECT * FROM khe_uoc_vay WHERE cong_ty_id=? ORDER BY ngay_vay DESC, so_khe_uoc", (cid,)).fetchall()


def da_ghi(con, cid, so_ct):
    r = con.execute("SELECT id FROM chung_tu WHERE cong_ty_id=? AND so_ct=?", (cid, so_ct)).fetchone()
    return r["id"] if r else None


def _tk(con, cid, *tks):
    for t in tks:
        db.them_tai_khoan(con, cid, t, f"TK {t}")


def ghi_nhan_vay(con, cid, kv):
    """Ghi so nhan tien vay (bo qua neu da ghi). Tra ve id chung tu."""
    so = so_ct_nhan(kv)
    if da_ghi(con, cid, so):
        return da_ghi(con, cid, so)
    _tk(con, cid, kv["tk_tien"], kv["tk_vay"])
    dg = f"Nhận tiền vay {kv['ben_cho_vay']} theo khế ước {kv['so_khe_uoc']}"
    ct = db.ghi_chung_tu(con, cid, so, kv["ngay_vay"], kv["ngay_vay"],
                         [{"tk_no": kv["tk_tien"], "tk_co": kv["tk_vay"], "so_tien": kv["so_tien"], "dien_giai": dg,
                           "doi_tuong_co": kv["ma_doi_tuong"] or ""}], loai="BC", dien_giai=dg, nguon="vay")
    con.commit()
    return ct


def ghi_ky(con, cid, kv, ky, goc=None, lai=None, ngay=None):
    """Ghi so ky tra thu `ky` (co the sua goc, lai, ngay theo chung tu ngan hang thuc te). Tra ve id chung tu."""
    so = so_ct_ky(kv, ky)
    if da_ghi(con, cid, so):
        raise ValueError(f"Kỳ {ky} đã ghi sổ ({so}). Xóa chứng từ đó ở Danh sách chứng từ nếu cần ghi lại.")
    l = next(x for x in lich_tra(kv) if x["ky"] == ky)
    goc = l["goc"] if goc is None else int(goc)
    lai = l["lai"] if lai is None else int(lai)
    ngay = ngay or l["ngay"]
    _tk(con, cid, kv["tk_tien"], kv["tk_vay"], kv["tk_lai"])
    dong = []
    if goc:
        dong.append({"tk_no": kv["tk_vay"], "tk_co": kv["tk_tien"], "so_tien": goc, "doi_tuong_no": kv["ma_doi_tuong"] or "",
                     "dien_giai": f"Trả gốc vay kỳ {ky} khế ước {kv['so_khe_uoc']}"})
    if lai:
        dong.append({"tk_no": kv["tk_lai"], "tk_co": kv["tk_tien"], "so_tien": lai,
                     "dien_giai": f"Lãi vay kỳ {ky} khế ước {kv['so_khe_uoc']}"})
    if not dong:
        raise ValueError("Kỳ này không có tiền gốc hay lãi.")
    ct = db.ghi_chung_tu(con, cid, so, ngay, ngay, dong, loai="BN", nguon="vay",
                         dien_giai=f"Trả nợ vay {kv['ben_cho_vay']} kỳ {ky} ({kv['so_khe_uoc']})")
    con.commit()
    return ct


def tinh_hinh(con, cid, kv, hom_nay=None):
    """Du no theo so (gom ca tra ngoai lich), ky tiep theo chua ghi, so ky da ghi."""
    hn = (hom_nay or date.today()).isoformat()
    lich = lich_tra(kv)
    ghi = {x["ky"] for x in lich if da_ghi(con, cid, so_ct_ky(kv, x["ky"]))}
    goc_da_tra = sum(r["s"] or 0 for r in con.execute(
        "SELECT SUM(b.so_tien) s FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? AND c.so_ct LIKE ? "
        "AND b.tk_no=?", (cid, f"TRAVAY-{kv['so_khe_uoc']}-%", kv["tk_vay"])))
    tiep = next((x for x in lich if x["ky"] not in ghi), None)
    return {"du_no": int(kv["so_tien"]) - goc_da_tra, "da_ghi_ky": ghi, "ky_tiep": tiep,
            "qua_han": bool(tiep and tiep["ngay"] < hn), "nhan_vay": bool(da_ghi(con, cid, so_ct_nhan(kv)))}


def viec(con, cid, hom_nay=None):
    """Viec can lam: ky tra den han trong 7 ngay hoac qua han ma chua ghi so."""
    chuan_bi(con)
    hn = hom_nay or date.today()
    v = []
    for kv in danh_sach(con, cid):
        t = tinh_hinh(con, cid, kv, hn)
        k = t["ky_tiep"]
        if k and k["ngay"] <= (hn + timedelta(days=7)).isoformat():
            v.append(("do" if t["qua_han"] else "vang",
                      f"Khế ước {kv['so_khe_uoc']}: kỳ {k['ky']} {'quá hạn' if t['qua_han'] else 'đến hạn'} "
                      f"{k['ngay'][8:]}/{k['ngay'][5:7]}, {k['tong']:,.0f} đ chưa ghi sổ".replace(",", "."),
                      f"vay/{kv['id']}"))
    return v
