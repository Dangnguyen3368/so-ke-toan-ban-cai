"""Hoa don dien tu: doc file, luu, chong trung, ghi so.

Moi nha cung cap hoa don (Viettel, VNPT, MISA, BKAV, FPT, EasyInvoice...) deu
phai xuat XML theo cung mot dinh dang cua Tong cuc Thue (TT78/2021, QD 1450),
nen bo doc XML o day dung chung cho tat ca.

Nguon nap:
- File XML (hoac ZIP chua XML) tai tu cong thue hay tu nha cung cap.
- File Excel danh sach hoa don xuat tu hoadondientu.gdt.gov.vn.
- Du lieu JSON tu cong thue (module cong_hddt).
"""
import io
import json
import re
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

import openpyxl

from . import db, kho

TRANG_THAI = {1: "Hóa đơn mới", 2: "Thay thế", 3: "Điều chỉnh", 4: "Đã bị thay thế",
              5: "Đã bị điều chỉnh", 6: "Đã bị hủy"}
KHONG_GHI_SO = {4, 6}   # hoa don da bi thay the / huy: khong ghi so

SCHEMA = """
CREATE TABLE IF NOT EXISTS hoa_don (
    id INTEGER PRIMARY KEY,
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    chieu TEXT NOT NULL,                 -- 'mua' hoac 'ban'
    nbmst TEXT NOT NULL, nb_ten TEXT,
    nmmst TEXT, nm_ten TEXT,
    khmshdon TEXT NOT NULL, khhdon TEXT NOT NULL, shdon TEXT NOT NULL,
    ngay_lap TEXT NOT NULL,              -- YYYY-MM-DD
    ma_cqt TEXT,
    tien_hang INTEGER NOT NULL DEFAULT 0,
    tien_thue INTEGER NOT NULL DEFAULT 0,
    tong_tien INTEGER NOT NULL DEFAULT 0,
    theo_thue_suat TEXT,                 -- JSON [{tsuat, thtien, tthue}]
    dong_hang TEXT,                      -- JSON danh sach hang hoa
    trang_thai INTEGER NOT NULL DEFAULT 1,
    tinh_chat TEXT,                      -- 'thay_the', 'dieu_chinh' hoac NULL
    hd_lien_quan TEXT,
    may_tinh_tien INTEGER NOT NULL DEFAULT 0,
    co_xml INTEGER NOT NULL DEFAULT 0,
    xml TEXT,
    nguon TEXT,
    chung_tu_id INTEGER REFERENCES chung_tu(id) ON DELETE SET NULL,
    UNIQUE (cong_ty_id, nbmst, khmshdon, khhdon, shdon)
);
CREATE INDEX IF NOT EXISTS ix_hd_ngay ON hoa_don(cong_ty_id, chieu, ngay_lap);

CREATE TABLE IF NOT EXISTS quy_tac_dinh_khoan (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    chieu TEXT NOT NULL,
    mst_doi_tac TEXT NOT NULL,           -- '' = mac dinh cho moi doi tac
    tk TEXT NOT NULL,
    PRIMARY KEY (cong_ty_id, chieu, mst_doi_tac)
);
CREATE TABLE IF NOT EXISTS quy_tac_mat_hang (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    chieu TEXT NOT NULL,
    ten_chuan TEXT NOT NULL,             -- ten hang da bo dau, viet thuong, gon khoang trang
    ten TEXT,                            -- ten hien thi
    tk TEXT NOT NULL,
    so_lan INTEGER NOT NULL DEFAULT 1,
    tu_hoc INTEGER NOT NULL DEFAULT 1,   -- 1 = may tu hoc khi ghi so, 0 = nguoi dung dat
    PRIMARY KEY (cong_ty_id, chieu, ten_chuan)
);
"""


def chuan_bi(con):
    con.executescript(SCHEMA)
    kho.chuan_bi(con)
    cot = {r["name"] for r in con.execute("PRAGMA table_info(cong_ty)")}
    for ten, kieu in [("nha_cung_cap_hd", "TEXT"), ("tk_mua_mac_dinh", "TEXT DEFAULT '6422'"),
                      ("tk_ban_mac_dinh", "TEXT DEFAULT '5113'")]:
        if ten not in cot:
            con.execute(f"ALTER TABLE cong_ty ADD COLUMN {ten} {kieu}")
    con.commit()


# ---------------------------------------------------------------- doc XML
def _ten(tag):
    return tag.rsplit("}", 1)[-1]


def _con(el, ten):
    if el is None:
        return None
    for c in el:
        if _ten(c.tag) == ten:
            return c
    return None


def _tim(el, ten):
    """Tim phan tu dau tien co ten `ten` o bat ky do sau nao."""
    if el is None:
        return None
    for c in el.iter():
        if _ten(c.tag) == ten:
            return c
    return None


def _ds(el):
    return list(el) if el is not None else []


def _chu(el, *duong):
    for t in duong:
        el = _con(el, t)
    return (el.text or "").strip() if el is not None and el.text else ""


def _tien(s):
    if s in (None, ""):
        return 0
    try:
        return int(round(float(str(s).replace(",", ""))))
    except ValueError:
        return 0


def _so_thuc(s):
    try:
        return float(str(s).replace(",", ""))
    except (TypeError, ValueError):
        return None


def doc_xml(du_lieu):
    """Doc mot hoa don XML (bytes). Tra ve dict hoa don hoac nem ValueError."""
    try:
        goc = ET.fromstring(du_lieu)
    except ET.ParseError as ex:
        raise ValueError(f"File XML hỏng: {ex}")
    hd = goc if _ten(goc.tag) == "HDon" else _tim(goc, "HDon")
    dl = _tim(hd, "DLHDon")
    if dl is None:
        raise ValueError("Không phải file hóa đơn điện tử (thiếu DLHDon)")
    tt = _con(dl, "TTChung")
    nd = _con(dl, "NDHDon")
    nb, nm, toan = _con(nd, "NBan"), _con(nd, "NMua"), _con(nd, "TToan")

    lq = _con(tt, "TTHDLQuan")
    tc = _chu(lq, "TCHDon") if lq is not None else ""
    tinh_chat = {"1": "thay_the", "2": "dieu_chinh"}.get(tc)
    hd_lq = None
    if lq is not None:
        hd_lq = "-".join(x for x in (_chu(lq, "KHMSHDCLQuan"), _chu(lq, "KHHDCLQuan"), _chu(lq, "SHDCLQuan")) if x)

    dong = []
    for h in _ds(_con(nd, "DSHHDVu")):
        if _ten(h.tag) != "HHDVu":
            continue
        dong.append({
            "tinh_chat": _chu(h, "TChat"), "ma": _chu(h, "MHHDVu"), "ten": _chu(h, "THHDVu"),
            "dvt": _chu(h, "DVTinh"), "so_luong": _so_thuc(_chu(h, "SLuong")),
            "don_gia": _so_thuc(_chu(h, "DGia")), "thanh_tien": _tien(_chu(h, "ThTien")),
            "thue_suat": _chu(h, "TSuat"),
        })

    tts = []
    for l in _ds(_con(toan, "THTTLTSuat")):
        if _ten(l.tag) == "LTSuat":
            tts.append({"tsuat": _chu(l, "TSuat"), "thtien": _tien(_chu(l, "ThTien")),
                        "tthue": _tien(_chu(l, "TThue"))})

    ty_gia = _so_thuc(_chu(tt, "TGia")) or 1
    quy_doi = (lambda v: int(round(v * ty_gia))) if ty_gia != 1 else (lambda v: v)
    tien_hang = _tien(_chu(toan, "TgTCThue"))
    tien_thue = _tien(_chu(toan, "TgTThue"))
    tong = _tien(_chu(toan, "TgTTTBSo")) or tien_hang + tien_thue
    if not tts and (tien_hang or tien_thue):
        tts = [{"tsuat": dong[0]["thue_suat"] if dong else "", "thtien": tien_hang, "tthue": tien_thue}]

    ngay = _chu(tt, "NLap")[:10]
    mccqt = _tim(hd, "MCCQT")
    return {
        "nbmst": _chu(nb, "MST"), "nb_ten": _chu(nb, "Ten"),
        "nmmst": _chu(nm, "MST"), "nm_ten": _chu(nm, "Ten") or _chu(nm, "HVTNMHang"),
        "khmshdon": _chu(tt, "KHMSHDon"), "khhdon": _chu(tt, "KHHDon"),
        "shdon": str(int(_chu(tt, "SHDon"))) if _chu(tt, "SHDon").isdigit() else _chu(tt, "SHDon"),
        "ngay_lap": ngay, "ma_cqt": (mccqt.text or "").strip() if mccqt is not None and mccqt.text else None,
        "tien_hang": quy_doi(tien_hang), "tien_thue": quy_doi(tien_thue), "tong_tien": quy_doi(tong),
        "theo_thue_suat": [{**x, "thtien": quy_doi(x["thtien"]), "tthue": quy_doi(x["tthue"])} for x in tts],
        "dong_hang": dong, "tinh_chat": tinh_chat, "hd_lien_quan": hd_lq or None,
        # Ky hieu thu 4 la 'M' = hoa don khoi tao tu may tinh tien (vd C25MAA)
        "may_tinh_tien": 1 if len(_chu(tt, "KHHDon")) >= 4 and _chu(tt, "KHHDon")[3] == "M" else 0,
        "xml": du_lieu.decode("utf-8", "replace") if isinstance(du_lieu, bytes) else du_lieu,
    }


# ---------------------------------------------------------------- doc Excel cong thue
_COT_EXCEL = {
    "khmshdon": ["ký hiệu mẫu số", "mẫu số"],
    "khhdon": ["ký hiệu hóa đơn", "ký hiệu"],
    "shdon": ["số hóa đơn"],
    "ngay_lap": ["ngày lập"],
    "nbmst": ["mst người bán", "mã số thuế người bán", "mst người bán/mst người xuất hàng"],
    "nb_ten": ["tên người bán"],
    "nmmst": ["mst người mua", "mã số thuế người mua"],
    "nm_ten": ["tên người mua"],
    "tien_hang": ["tổng tiền chưa thuế"],
    "tien_thue": ["tổng tiền thuế"],
    "tong_tien": ["tổng tiền thanh toán"],
    "trang_thai": ["trạng thái hóa đơn"],
}


def _khop_cot(tieu_de):
    t = [str(x or "").strip().lower().replace("\n", " ") for x in tieu_de]
    vt = {}
    for k, ten in _COT_EXCEL.items():
        for i, x in enumerate(t):
            if any(x == n or x.startswith(n) for n in ten) and i not in vt.values():
                vt[k] = i
                break
    return vt


def _ngay_excel(v):
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d")
    s = str(v or "").strip()
    for f in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(s[:10], f).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return ""


def doc_excel_cong_thue(du_lieu):
    """Doc file Excel danh sach hoa don xuat tu hoadondientu.gdt.gov.vn."""
    wb = openpyxl.load_workbook(io.BytesIO(du_lieu), read_only=True, data_only=True)
    try:
        dong = list(wb.active.iter_rows(values_only=True))
    finally:
        wb.close()
    vt = None
    kq = []
    for r in dong:
        if vt is None:
            m = _khop_cot(r)
            if {"khhdon", "shdon", "ngay_lap"} <= set(m):
                vt = m
            continue
        g = lambda k: r[vt[k]] if k in vt and vt[k] < len(r) else None
        if not g("shdon") or not _ngay_excel(g("ngay_lap")):
            continue
        tt = str(g("trang_thai") or "").lower()
        trang_thai = 6 if "hủy" in tt else 4 if "bị thay thế" in tt else 5 if "bị điều chỉnh" in tt \
            else 2 if "thay thế" in tt else 3 if "điều chỉnh" in tt else 1
        shd = str(g("shdon")).strip()
        kq.append({
            "khmshdon": str(g("khmshdon") or "1").strip(), "khhdon": str(g("khhdon")).strip(),
            "shdon": str(int(float(shd))) if re.fullmatch(r"\d+(\.0)?", shd) else shd,
            "ngay_lap": _ngay_excel(g("ngay_lap")),
            "nbmst": str(g("nbmst") or "").strip(), "nb_ten": str(g("nb_ten") or "").strip(),
            "nmmst": str(g("nmmst") or "").strip(), "nm_ten": str(g("nm_ten") or "").strip(),
            "tien_hang": _tien(g("tien_hang")), "tien_thue": _tien(g("tien_thue")),
            "tong_tien": _tien(g("tong_tien")), "trang_thai": trang_thai,
        })
    if vt is None:
        raise ValueError("Không nhận ra file Excel danh sách hóa đơn của cổng thuế")
    return kq


# ---------------------------------------------------------------- doc file bat ky
def doc_file(ten, du_lieu):
    """Doc mot file (.xml, .zip, .xlsx). Tra ve (list hoa don, list loi)."""
    ten = ten.lower()
    hds, loi = [], []
    if ten.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(du_lieu)) as z:
            for n in z.namelist():
                if n.lower().endswith((".xml", ".zip", ".xlsx")):
                    a, b = doc_file(n, z.read(n))
                    hds += a
                    loi += b
    elif ten.endswith(".xml"):
        try:
            hds.append(doc_xml(du_lieu))
        except ValueError as ex:
            loi.append(f"{ten}: {ex}")
    elif ten.endswith((".xlsx", ".xlsm")):
        try:
            hds += doc_excel_cong_thue(du_lieu)
        except Exception as ex:
            loi.append(f"{ten}: {ex}")
    return hds, loi


def doc_thu_muc(duong):
    hds, loi = [], []
    for p in sorted(Path(duong).rglob("*")):
        if p.is_file() and p.suffix.lower() in (".xml", ".zip", ".xlsx"):
            a, b = doc_file(p.name, p.read_bytes())
            hds += a
            loi += b
    return hds, loi


# ---------------------------------------------------------------- luu
def luu(con, cid, hds, nguon):
    """Luu danh sach hoa don. Tra ve dict dem moi / cap nhat / bo qua."""
    mst = con.execute("SELECT mst FROM cong_ty WHERE id=?", (cid,)).fetchone()["mst"]
    dem = {"moi": 0, "cap_nhat": 0, "khong_lien_quan": 0}
    for h in hds:
        if h.get("nbmst") == mst:
            chieu = "ban"
        elif h.get("nmmst") == mst or nguon in ("cong_thue_mua",):
            chieu = "mua"
        else:
            dem["khong_lien_quan"] += 1
            continue
        khoa = (cid, h["nbmst"], h["khmshdon"], h["khhdon"], h["shdon"])
        cu = con.execute("SELECT id, co_xml FROM hoa_don WHERE cong_ty_id=? AND nbmst=? AND khmshdon=? "
                         "AND khhdon=? AND shdon=?", khoa).fetchone()
        gt = {
            "chieu": chieu, "nb_ten": h.get("nb_ten"), "nmmst": h.get("nmmst"), "nm_ten": h.get("nm_ten"),
            "ngay_lap": h["ngay_lap"], "tien_hang": h.get("tien_hang", 0), "tien_thue": h.get("tien_thue", 0),
            "tong_tien": h.get("tong_tien", 0),
        }
        for k in ("ma_cqt", "tinh_chat", "hd_lien_quan", "trang_thai", "may_tinh_tien"):
            if h.get(k) is not None:
                gt[k] = h[k]
        if h.get("theo_thue_suat"):
            gt["theo_thue_suat"] = json.dumps(h["theo_thue_suat"], ensure_ascii=False)
        if h.get("xml"):
            gt.update(xml=h["xml"], co_xml=1, dong_hang=json.dumps(h.get("dong_hang", []), ensure_ascii=False))
        elif cu and cu["co_xml"]:
            # Da co XML day du: chi cap nhat trang thai tu danh sach
            gt = {k: v for k, v in gt.items() if k in ("trang_thai",)}
        if cu:
            if gt:
                con.execute(f"UPDATE hoa_don SET {', '.join(k + '=?' for k in gt)} WHERE id=?",
                            list(gt.values()) + [cu["id"]])
            dem["cap_nhat"] += 1
        else:
            gt.update(cong_ty_id=cid, nbmst=h["nbmst"], khmshdon=h["khmshdon"], khhdon=h["khhdon"],
                      shdon=h["shdon"], nguon=nguon)
            con.execute(f"INSERT INTO hoa_don ({', '.join(gt)}) VALUES ({', '.join('?' * len(gt))})",
                        list(gt.values()))
            dem["moi"] += 1
    con.commit()
    return dem


def danh_sach(con, cid, chieu, tu, den):
    return con.execute(
        "SELECT * FROM hoa_don WHERE cong_ty_id=? AND chieu=? AND ngay_lap BETWEEN ? AND ? "
        "ORDER BY ngay_lap, khhdon, CAST(shdon AS INTEGER)", (cid, chieu, tu, den)).fetchall()


def tong_theo_thue_suat(ds):
    """Cong tien hang va tien thue theo thue suat (dung cho bang ke 01/GTGT)."""
    kq = {}
    for h in ds:
        if h["trang_thai"] in KHONG_GHI_SO:
            continue
        for x in json.loads(h["theo_thue_suat"] or "[]") or [
                {"tsuat": "?", "thtien": h["tien_hang"], "tthue": h["tien_thue"]}]:
            t = kq.setdefault(x["tsuat"] or "?", [0, 0])
            t[0] += x["thtien"]
            t[1] += x["tthue"]
    return kq


# ---------------------------------------------------------------- dinh khoan
def tk_cho(con, cid, chieu, mst_doi_tac):
    r = con.execute("SELECT tk FROM quy_tac_dinh_khoan WHERE cong_ty_id=? AND chieu=? AND mst_doi_tac=?",
                    (cid, chieu, mst_doi_tac or "")).fetchone()
    if r:
        return r["tk"]
    r = con.execute("SELECT tk FROM quy_tac_dinh_khoan WHERE cong_ty_id=? AND chieu=? AND mst_doi_tac=''",
                    (cid, chieu)).fetchone()
    if r:
        return r["tk"]
    ct = con.execute("SELECT tk_mua_mac_dinh, tk_ban_mac_dinh FROM cong_ty WHERE id=?", (cid,)).fetchone()
    return (ct["tk_mua_mac_dinh"] if chieu == "mua" else ct["tk_ban_mac_dinh"]) or ("6422" if chieu == "mua" else "5113")


def dat_quy_tac(con, cid, chieu, mst_doi_tac, tk):
    con.execute("INSERT OR REPLACE INTO quy_tac_dinh_khoan VALUES (?,?,?,?)", (cid, chieu, mst_doi_tac or "", tk))
    con.commit()


def ten_chuan_hang(ten):
    from .sao_ke import khong_dau
    s = re.sub(r"[^a-z0-9]+", " ", khong_dau(ten or "").lower()).strip()
    return re.sub(r"\s+", " ", s)[:120]


def tk_mat_hang(con, cid, chieu, ten):
    r = con.execute("SELECT tk FROM quy_tac_mat_hang WHERE cong_ty_id=? AND chieu=? AND ten_chuan=?",
                    (cid, chieu, ten_chuan_hang(ten))).fetchone()
    return r["tk"] if r else None


def dat_tk_mat_hang(con, cid, chieu, ten, tk, tu_hoc=False):
    """Luu tai khoan cho mot mat hang. Quy tac nguoi dung dat (tu_hoc=False) khong bi may ghi de."""
    tc = ten_chuan_hang(ten)
    if not tc:
        return
    cu = con.execute("SELECT tk, tu_hoc FROM quy_tac_mat_hang WHERE cong_ty_id=? AND chieu=? AND ten_chuan=?",
                     (cid, chieu, tc)).fetchone()
    if cu and tu_hoc and not cu["tu_hoc"]:
        return
    if cu:
        con.execute("UPDATE quy_tac_mat_hang SET tk=?, ten=?, so_lan=so_lan+?, tu_hoc=? WHERE cong_ty_id=? AND chieu=? "
                    "AND ten_chuan=?", (tk, ten, 1 if tu_hoc else 0, 1 if tu_hoc else 0, cid, chieu, tc))
    else:
        con.execute("INSERT INTO quy_tac_mat_hang VALUES (?,?,?,?,?,1,?)", (cid, chieu, tc, ten, tk, 1 if tu_hoc else 0))


def _chia_theo_mat_hang(con, cid, h, tk_mac_dinh):
    """Chia tien hang theo tai khoan da hoc cho tung mat hang. Tra ve {tk: tien} hoac None neu khong hoc duoc gi."""
    try:
        dl = h["dong_hang"]
    except (KeyError, IndexError):
        return None
    dong = [d for d in json.loads(dl or "[]") if d.get("ten") and d.get("tinh_chat") in ("1", "", None)]
    if not dong:
        return None
    nhom, hoc = {}, False
    for d in dong:
        tk = tk_mat_hang(con, cid, h["chieu"], d["ten"])
        hoc = hoc or bool(tk)
        nhom[tk or tk_mac_dinh] = nhom.get(tk or tk_mac_dinh, 0) + (d.get("thanh_tien") or 0)
    if not hoc:
        return None
    lech = h["tien_hang"] - sum(nhom.values())     # chiet khau, dong ghi chu...: don vao nhom lon nhat
    if lech:
        lon = max(nhom, key=lambda k: abs(nhom[k]))
        nhom[lon] += lech
    return {k: v for k, v in nhom.items() if v}


def goi_y_dinh_khoan(con, cid, h):
    """Danh sach dong but toan goi y cho mot hoa don.

    Thu tu chon tai khoan hang/doanh thu: theo mat hang da hoc (chia nhieu dong neu khac nhau),
    roi quy tac theo doi tac, roi tai khoan mac dinh cua cong ty."""
    mua = h["chieu"] == "mua"
    doi_tac = h["nbmst"] if mua else (h["nmmst"] or "")
    tk = tk_cho(con, cid, h["chieu"], doi_tac)
    ten = h["nb_ten"] if mua else h["nm_ten"]
    dg = f"{'Mua' if mua else 'Bán'} theo HĐ {h['khhdon']}-{h['shdon']} {ten or ''}".strip()
    dong = []

    def them(no, co, tien, dt_no="", dt_co="", dien_giai=dg):
        if tien < 0:  # dieu chinh giam: dao chieu
            no, co, dt_no, dt_co, tien = co, no, dt_co, dt_no, -tien
        if tien:
            dong.append({"tk_no": no, "tk_co": co, "so_tien": tien, "dien_giai": dien_giai,
                         "doi_tuong_no": dt_no, "doi_tuong_co": dt_co})

    chia = _chia_theo_mat_hang(con, cid, h, tk) or {tk: h["tien_hang"]}
    for t, tien in sorted(chia.items(), key=lambda x: -abs(x[1])):
        if mua:
            them(t, "331", tien, dt_co=doi_tac)
        else:
            them("131", t, tien, dt_no=doi_tac)
    if mua:
        them("1331", "331", h["tien_thue"], dt_co=doi_tac, dien_giai="Thuế GTGT - " + dg)
    else:
        them("131", "33311", h["tien_thue"], dt_no=doi_tac, dien_giai="Thuế GTGT - " + dg)
    return dong


def ky_misa(con, cid):
    """(tu, den) cua chung tu nap tu MISA, hoac None."""
    r = con.execute("SELECT MIN(ngay_ht) a, MAX(ngay_ht) b FROM chung_tu WHERE cong_ty_id=? AND nguon='misa'",
                    (cid,)).fetchone()
    return (r["a"], r["b"]) if r and r["a"] else None


def ghi_so(con, cid, ids, cho_trung_misa=False):
    """Ghi so cac hoa don chua ghi. Tra ve (so da ghi, list loi).

    Hoa don co ngay nam trong khoang da nap so tu MISA bi chan (de khong hach toan hai lan),
    tru khi cho_trung_misa=True."""
    da, loi = 0, []
    misa = None if cho_trung_misa else ky_misa(con, cid)
    for i in ids:
        h = con.execute("SELECT * FROM hoa_don WHERE id=? AND cong_ty_id=?", (i, cid)).fetchone()
        if not h or h["chung_tu_id"]:
            continue
        if h["trang_thai"] in KHONG_GHI_SO:
            loi.append(f"{h['khhdon']}-{h['shdon']}: {TRANG_THAI[h['trang_thai']].lower()}, không ghi sổ")
            continue
        if misa and misa[0] <= h["ngay_lap"] <= misa[1]:
            loi.append(f"{h['khhdon']}-{h['shdon']}: ngày {h['ngay_lap'][8:]}/{h['ngay_lap'][5:7]}/{h['ngay_lap'][:4]} "
                       "nằm trong kỳ đã nạp sổ từ MISA, có thể đã hạch toán rồi nên không ghi")
            continue
        try:
            dong = goi_y_dinh_khoan(con, cid, h)
            if not dong:
                raise ValueError("hóa đơn không có số tiền")
            ct = db.ghi_chung_tu(
                con, cid, f"{'MH' if h['chieu'] == 'mua' else 'BH'}-{h['khhdon']}-{h['shdon']}",
                h["ngay_lap"], h["ngay_lap"], dong, loai="MH" if h["chieu"] == "mua" else "BH",
                dien_giai=dong[0]["dien_giai"], nguon="hddt")
            con.execute("UPDATE hoa_don SET chung_tu_id=? WHERE id=?", (ct, i))
            from . import doi_tuong
            doi_tuong.chuan_bi(con)
            ma_dt = h["nbmst"] if h["chieu"] == "mua" else (h["nmmst"] or "")
            if ma_dt:
                doi_tuong.luu(con, cid, {"ma": ma_dt, "ten": (h["nb_ten"] if h["chieu"] == "mua" else h["nm_ten"]) or ma_dt,
                                         "loai": "NCC" if h["chieu"] == "mua" else "KH", "mst": ma_dt,
                                         "dia_chi": doi_tuong._dia_chi_xml(h["xml"], "NBan" if h["chieu"] == "mua" else "NMua")},
                              ghi_de=False)
            tk_hang = [d for d in dong if not d["dien_giai"].startswith("Thuế GTGT")]
            tk = (tk_hang[0]["tk_no"] if h["chieu"] == "mua" else tk_hang[0]["tk_co"]) if tk_hang else tk_cho(
                con, cid, h["chieu"], h["nbmst"] if h["chieu"] == "mua" else (h["nmmst"] or ""))
            # Hoc tai khoan theo mat hang khi ca hoa don chi dung mot tai khoan
            if len(tk_hang) == 1:
                for d in json.loads(h["dong_hang"] or "[]"):
                    if d.get("ten") and d.get("tinh_chat") in ("1", "", None):
                        dat_tk_mat_hang(con, cid, h["chieu"], d["ten"], tk, tu_hoc=True)
            # Hang hoa vat tu: tu tao phieu nhap kho / phieu xuat ban tu chi tiet XML
            if h["co_xml"] and h["chieu"] == "mua" and tk[:3] in ("152", "153", "156"):
                kho.nhap_tu_hoa_don(con, cid, h, tk, ct)
            elif h["co_xml"] and h["chieu"] == "ban" and tk.startswith("5111"):
                kho.xuat_tu_hoa_don_ban(con, cid, h)
            da += 1
        except Exception as ex:
            loi.append(f"{h['khhdon']}-{h['shdon']}: {ex}")
    con.commit()
    return da, loi
