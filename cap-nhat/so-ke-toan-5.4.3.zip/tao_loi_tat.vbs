' Tao loi tat "iFix Ke toan" tren Desktop va Start Menu (chay an, co bieu tuong).
Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
d = fs.GetParentFolderName(WScript.ScriptFullName)
' Xoa loi tat ten cu (So ke toan)
For Each cu In Array(sh.SpecialFolders("Desktop") & "\So ke toan.lnk", sh.SpecialFolders("Programs") & "\So ke toan.lnk", sh.SpecialFolders("Programs") & "\Tat So ke toan.lnk")
  If fs.FileExists(cu) Then fs.DeleteFile cu
Next
For Each noi In Array(sh.SpecialFolders("Desktop"), sh.SpecialFolders("Programs"))
  Set s = sh.CreateShortcut(noi & "\iFix Ke toan.lnk")
  s.TargetPath = sh.ExpandEnvironmentStrings("%WINDIR%") & "\System32\wscript.exe"
  s.Arguments = """" & d & "\chay_an.vbs"""
  s.WorkingDirectory = d
  s.IconLocation = d & "\so_ke_toan.ico,0"
  s.Description = "iFix Ke toan"
  s.Save
Next
Set s = sh.CreateShortcut(sh.SpecialFolders("Programs") & "\Tat iFix Ke toan.lnk")
s.TargetPath = sh.ExpandEnvironmentStrings("%WINDIR%") & "\System32\wscript.exe"
s.Arguments = """" & d & "\tat_so_ke_toan.vbs"""
s.WorkingDirectory = d
s.Save
