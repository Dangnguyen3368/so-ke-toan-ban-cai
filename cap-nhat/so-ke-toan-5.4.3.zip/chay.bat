@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
if exist "%~dp0python\python.exe" (
  "%~dp0python\python.exe" -m ketoan.ung_dung
  goto het
)
py -3 -m ketoan.ung_dung
if errorlevel 9009 python -m ketoan.ung_dung
:het
pause
