"""Cac trang Hoa don va Cai dat cua ung dung (tron vao lop XuLy)."""
import base64
import json
from email.parser import BytesParser
from email.policy import HTTP

from . import che_do, cong_hddt, giao_dien, hoa_don, nha_cung_cap

PHIEN_CONG = {}   # cong_ty_id -> token dang nhap cong thue (chi trong bo nho)


def _U():
    return giao_dien


def doc_multipart(handler, theo_truong=False):
    """Tra ve (dict truong chu, list (ten_file, bytes)).

    theo_truong=True: thay list bang dict {ten truong: list (ten_file, bytes)}."""
    n = int(handler.headers.get("Content-Length") or 0)
    than = handler.rfile.read(n)
    msg = BytesParser(policy=HTTP).parsebytes(
        b"Content-Type: " + handler.headers["Content-Type"].encode() + b"\r\n\r\n" + than)
    truong, tep = {}, []
    for phan in msg.iter_parts():
        ten = phan.get_param("name", header="content-disposition")
        ten_tep = phan.get_filename()
        du_lieu = phan.get_payload(decode=True) or b""
        if ten_tep:
            if du_lieu:
                tep.append((ten_tep, du_lieu) if not theo_truong else (ten, ten_tep, du_lieu))
        elif ten:
            truong[ten] = du_lieu.decode("utf-8", "replace")
    if theo_truong:
        d = {}
        for ten, ten_tep, du_lieu in tep:
            d.setdefault(ten, []).append((ten_tep, du_lieu))
        return truong, d
    return truong, tep


class TrangHoaDon:
    # ------------------------------------------------------------ Cai dat
    def caidat(self, pt, con, ct, q, rest):
        U = _U()
        e = U.e
        cid = ct["id"]
        tb = ""
        if pt == "POST":
            f = {k: v[0].strip() for k, v in self.doc_form().items()}
            cot = ["ten", "dia_chi", "ma_cqt", "ten_cqt", "nguoi_ky", "ky_ke_khai_gtgt",
                   "nha_cung_cap_hd", "tk_mua_mac_dinh", "tk_ban_mac_dinh"]
            con.execute(f"UPDATE cong_ty SET {', '.join(c + '=?' for c in cot)} WHERE id=?",
                        [f.get(c) or None for c in cot] + [cid])
            con.commit()
            tb = '<p class="ok">Đã lưu.</p>'
            if f.get("che_do") and che_do.ma(f["che_do"]) != che_do.ma(ct):
                n = che_do.doi_che_do(con, cid, f["che_do"])
                tb = (f'<p class="ok">Đã lưu và chuyển sang {U.e(che_do.ten_day_du(f["che_do"]))}'
                      f'{f", thêm {n} tài khoản của chế độ mới" if n else ""}. Tài khoản và số liệu cũ giữ nguyên.</p>')
            ct = con.execute("SELECT * FROM cong_ty WHERE id=?", (cid,)).fetchone()
        ncc = "".join(f'<option value="{m}" {"selected" if ct["nha_cung_cap_hd"] == m else ""}>{e(t)}</option>'
                      for m, t in nha_cung_cap.NHA_CUNG_CAP)
        o = lambda k, nhan, w=40: f'<label>{nhan}<input name="{k}" size="{w}" value="{e(ct[k] or "")}"></label>'
        hd = nha_cung_cap.huong_dan(ct["nha_cung_cap_hd"]) if ct["nha_cung_cap_hd"] else ""
        nd = f"""<div class="the"><h1>Cài đặt công ty</h1>{tb}<p class="mo">MST {e(ct['mst'])}</p>
<form method="post" style="display:grid;gap:10px;max-width:760px">
{o('ten', 'Tên công ty', 60)}{o('dia_chi', 'Địa chỉ', 60)}
<div style="display:flex;gap:10px;flex-wrap:wrap">{o('ma_cqt', 'Mã cơ quan thuế', 10)}{o('ten_cqt', 'Tên cơ quan thuế', 40)}</div>
{o('nguoi_ky', 'Người ký tờ khai')}
<label>Chế độ kế toán<select name="che_do">{"".join(f'<option value="{m}" {"selected" if che_do.ma(ct) == m else ""}>{e(che_do.ten_day_du(m))}</option>' for m in che_do.CHE_DO)}</select></label>
<p class="mo" style="margin:0">{e(che_do.CHE_DO[che_do.ma(ct)]["hieu_luc"])}{". " if che_do.CHE_DO[che_do.ma(ct)]["hieu_luc"] else ""}Đổi chế độ nên làm từ đầu năm tài chính; ứng dụng thêm tài khoản của chế độ mới, không xóa tài khoản và số liệu cũ.</p>
<label>Kỳ kê khai GTGT<select name="ky_ke_khai_gtgt"><option value="Q" {'selected' if ct['ky_ke_khai_gtgt'] == 'Q' else ''}>Theo quý</option>
<option value="M" {'selected' if ct['ky_ke_khai_gtgt'] == 'M' else ''}>Theo tháng</option></select></label>
<label>Nhà cung cấp hóa đơn điện tử<select name="nha_cung_cap_hd"><option value="">(chưa chọn)</option>{ncc}</select></label>
<div style="display:flex;gap:10px;flex-wrap:wrap">{o('tk_mua_mac_dinh', 'TK mặc định cho hóa đơn mua vào', 8)}
{o('tk_ban_mac_dinh', 'TK doanh thu mặc định cho hóa đơn bán ra', 8)}</div>
<div><button>Lưu</button></div></form>{f'<p class="mo">{e(hd)}</p>' if hd else ''}</div>"""
        self.gui(U.trang("Cài đặt", nd, cid, ct["ten"]))

    # ------------------------------------------------------------ Hoa don
    def hoadon(self, pt, con, ct, q, rest):
        sub = rest[0] if rest else ""
        f = {"": self._hd_ds, "nap": self._hd_nap, "cong": self._hd_cong, "ghiso": self._hd_ghiso,
             "quytac": self._hd_quytac, "xem": self._hd_xem, "mathang": self._hd_mathang}.get(sub)
        if not f:
            return self.gui("Không có trang này", 404)
        return f(pt, con, ct, q, rest[1:])

    def _hd_ds(self, pt, con, ct, q, rest, thong_bao=""):
        U = _U()
        e, so, nv = U.e, U.so, U.ngay_vn
        cid = ct["id"]
        chieu = q.get("chieu", "mua")
        tu, den = U.ky_mac_dinh(q)
        ds = hoa_don.danh_sach(con, cid, chieu, tu, den)
        tts = hoa_don.tong_theo_thue_suat(ds)
        chua = [h for h in ds if not h["chung_tu_id"] and h["trang_thai"] not in hoa_don.KHONG_GHI_SO]
        misa = hoa_don.ky_misa(con, cid)
        dong = ""
        for h in ds:
            mst_dt = h["nbmst"] if chieu == "mua" else h["nmmst"]
            ten_dt = h["nb_ten"] if chieu == "mua" else h["nm_ten"]
            huy = h["trang_thai"] in hoa_don.KHONG_GHI_SO
            o = ("" if h["chung_tu_id"] or huy else f'<input type="checkbox" name="id" value="{h["id"]}" checked>')
            ghi = "Đã ghi" if h["chung_tu_id"] else ("" if huy else e(hoa_don.tk_cho(con, cid, chieu, mst_dt)))
            dong += (f'<tr{" style=\"color:#999\"" if huy else ""}><td>{o}</td><td>{nv(h["ngay_lap"])}</td>'
                     f'<td><a href="/cty/{cid}/hoadon/xem/{h["id"]}">{e(h["khhdon"])}-{e(h["shdon"])}</a></td>'
                     f'<td>{e(ten_dt)}<br><span class="mo">{e(mst_dt)}</span></td>'
                     f'<td class="s">{so(h["tien_hang"])}</td><td class="s">{so(h["tien_thue"])}</td>'
                     f'<td class="s">{so(h["tong_tien"])}</td><td>{e(hoa_don.TRANG_THAI.get(h["trang_thai"]))}'
                     f'{" · MTT" if h["may_tinh_tien"] else ""}{"" if h["co_xml"] else " · chưa có XML"}</td><td>{ghi}</td></tr>')
        bang_ts = "".join(f'<tr><td>{e(k)}</td><td class="s">{so(v[0])}</td><td class="s">{so(v[1])}</td></tr>'
                          for k, v in sorted(tts.items()))
        doi_tac = sorted({(h["nbmst"] if chieu == "mua" else h["nmmst"]) or "" for h in ds} - {""})
        chon_dt = "".join(f'<option value="{e(m)}">' for m in doi_tac)
        tab = lambda c, t: (f'<a class="nut{"" if chieu == c else " phu"}" '
                            f'href="/cty/{cid}/hoadon?chieu={c}&tu={tu}&den={den}">{t}</a>')
        nd = f"""<div class="the"><h1>Hóa đơn điện tử</h1>{thong_bao}
<p>{tab('mua', 'Mua vào')} {tab('ban', 'Bán ra')}
<a class="nut phu" href="/cty/{cid}/hoadon/cong">Tải từ cổng thuế</a>
<a class="nut phu" href="/cty/{cid}/hoadon/nap">Nạp file XML / ZIP / Excel</a></p>
{U.form_ky(tu, den, f'<input type="hidden" name="chieu" value="{chieu}">')}
<p class="mo">{len(ds)} hóa đơn, {len(chua)} chưa ghi sổ.</p>
<table style="max-width:520px"><tr><th>Thuế suất</th><th>Tiền hàng</th><th>Tiền thuế</th></tr>{bang_ts}</table></div>
<div class="the"><h2>Quy tắc định khoản</h2><p class="mo">Đặt tài khoản cho từng {'nhà cung cấp' if chieu == 'mua' else 'khách hàng'}.
Lần sau máy tự dùng tài khoản này. Để trống MST để đặt mặc định cho mọi đối tác.</p>
<form class="ngang" method="post" action="/cty/{cid}/hoadon/quytac?chieu={chieu}&tu={tu}&den={den}">
<label>MST đối tác<input name="mst" list="dsdt" size="16"></label><datalist id="dsdt">{chon_dt}</datalist>
<label>Tài khoản{' (vd 156, 152, 6422, 242)' if chieu == 'mua' else ' (vd 5111, 5113)'}<input name="tk" size="8" required></label>
<button>Lưu quy tắc</button></form></div>
<form method="post" action="/cty/{cid}/hoadon/ghiso?chieu={chieu}&tu={tu}&den={den}">
<p class="ngang"><button>Ghi sổ các hóa đơn đã chọn</button>
{f'<label class="chon"><input type="checkbox" name="trung_misa" value="1"> Vẫn ghi cả hóa đơn trong kỳ đã nạp sổ MISA ({U.ngay_vn(misa[0])} – {U.ngay_vn(misa[1])})</label>' if misa else ''}
<a class="nut phu" href="/cty/{cid}/hoadon/mathang?chieu={chieu}">Tài khoản theo mặt hàng</a></p>
<table><tr><th></th><th>Ngày</th><th>Ký hiệu - Số</th><th>{'Người bán' if chieu == 'mua' else 'Người mua'}</th>
<th>Tiền hàng</th><th>Thuế GTGT</th><th>Tổng</th><th>Trạng thái</th><th>TK ghi sổ</th></tr>{dong}</table></form>"""
        self.gui(U.trang("Hóa đơn", nd, cid, ct["ten"]))

    def _hd_quytac(self, pt, con, ct, q, rest):
        f = {k: v[0].strip() for k, v in self.doc_form().items()}
        chieu = q.get("chieu", "mua")
        tb = ""
        if not con.execute("SELECT 1 FROM tai_khoan WHERE cong_ty_id=? AND so_tk=?", (ct["id"], f.get("tk"))).fetchone():
            tb = f'<p class="loi">Tài khoản {_U().e(f.get("tk"))} chưa có trong danh mục.</p>'
        else:
            hoa_don.dat_quy_tac(con, ct["id"], chieu, f.get("mst", ""), f["tk"])
            tb = '<p class="ok">Đã lưu quy tắc.</p>'
        return self._hd_ds("GET", con, ct, q, rest, tb)

    def _hd_ghiso(self, pt, con, ct, q, rest):
        f = self.doc_form()
        ids = [int(x) for x in f.get("id", [])]
        da, loi = hoa_don.ghi_so(con, ct["id"], ids, cho_trung_misa=bool(f.get("trung_misa")))
        e = _U().e
        tb = f'<p class="ok">Đã ghi sổ {da} hóa đơn.</p>' + "".join(f'<p class="loi">{e(x)}</p>' for x in loi)
        return self._hd_ds("GET", con, ct, q, rest, tb)

    def _hd_xem(self, pt, con, ct, q, rest):
        U = _U()
        e, so = U.e, U.so
        cid = ct["id"]
        h = con.execute("SELECT * FROM hoa_don WHERE id=? AND cong_ty_id=?", (int(rest[0]), cid)).fetchone()
        if not h:
            return self.gui("Không có hóa đơn", 404)
        tb = ""
        from . import tro_ly_ai as AI
        ai_ok, ai_tb = AI.san_sang(bq=getattr(self, "bq", None))
        ai_gy = {}
        f = self.doc_form() if pt == "POST" else {}
        if f.get("hanh_dong") == ["ai"]:
            pt = "AI"
            try:
                if not ai_ok:
                    raise AI.LoiAI(ai_tb)
                ai_gy = AI.goi_y_hoa_don(con, cid, h)
                tb = (f'<p class="ok">AI đã gợi ý {len(ai_gy)} mặt hàng (ô tô màu). Xem lại, sửa nếu cần, rồi bấm '
                      '<b>Lưu tài khoản theo mặt hàng</b>. Chưa lưu thì chưa có tác dụng.</p>')
            except AI.LoiAI as ex:
                tb = f'<p class="loi">{e(ex)}</p>'
        if pt == "POST":
            for ten, tk in zip(f.get("ten", []), f.get("tk", [])):
                tk = tk.strip()
                if not tk:
                    continue
                if not con.execute("SELECT 1 FROM tai_khoan WHERE cong_ty_id=? AND so_tk=?", (cid, tk)).fetchone():
                    tb += f'<p class="loi">Tài khoản {e(tk)} chưa có trong danh mục.</p>'
                    continue
                hoa_don.dat_tk_mat_hang(con, cid, h["chieu"], ten, tk)
            con.commit()
            tb = tb or '<p class="ok">Đã lưu tài khoản cho các mặt hàng. Lần sau gặp lại mặt hàng này máy tự dùng.</p>'
        dong = "".join(
            f'<tr><td>{e(d.get("ten"))}<input type="hidden" name="ten" value="{e(d.get("ten"))}"></td><td>{e(d.get("dvt"))}</td>'
            f'<td class="s">{e(d.get("so_luong") or "")}</td>'
            f'<td class="s">{so(d.get("don_gia") or 0)}</td><td class="s">{so(d.get("thanh_tien"))}</td><td>{e(d.get("thue_suat"))}</td>'
            + (f'<td><input name="tk" size="7" list="dstk" style="background:#fff7d6" value="{e(ai_gy[d.get("ten")][0])}" '
               f'title="{e(ai_gy[d.get("ten")][1])}"><br><span class="mo" style="font-size:12px">AI: {e(ai_gy[d.get("ten")][1])}</span></td></tr>'
               if d.get("ten") in ai_gy else
               f'<td><input name="tk" size="7" list="dstk" value="{e(hoa_don.tk_mat_hang(con, cid, h["chieu"], d.get("ten")) or "")}"></td></tr>')
            for d in json.loads(h["dong_hang"] or "[]"))
        dstk = "".join(f'<option value="{e(t["so_tk"])}">{e(t["ten"])}</option>' for t in
                       con.execute("SELECT so_tk, ten FROM tai_khoan WHERE cong_ty_id=? ORDER BY so_tk", (cid,)))
        dk = "".join(f'<tr><td>{e(d["tk_no"])}</td><td>{e(d["tk_co"])}</td><td class="s">{so(d["so_tien"])}</td><td>{e(d["dien_giai"])}</td></tr>'
                     for d in hoa_don.goi_y_dinh_khoan(con, cid, h))
        nd = f"""<div class="the"><h1>Hóa đơn {e(h['khmshdon'])}{e(h['khhdon'])} số {e(h['shdon'])}</h1>
<p>Ngày lập {U.ngay_vn(h['ngay_lap'])} · {e(hoa_don.TRANG_THAI.get(h['trang_thai']))}
{' · liên quan HĐ ' + e(h['hd_lien_quan']) if h['hd_lien_quan'] else ''} · mã CQT {e(h['ma_cqt'] or '')}</p>
<p>Người bán: <b>{e(h['nb_ten'])}</b> ({e(h['nbmst'])})<br>Người mua: <b>{e(h['nm_ten'])}</b> ({e(h['nmmst'])})</p>
<p>Tiền hàng {so(h['tien_hang'])} · Thuế {so(h['tien_thue'])} · Tổng {so(h['tong_tien'])}</p></div>
<div class="the"><h2>Hàng hóa, dịch vụ</h2>{tb}{('<form method="post"><p class="mo">Ghi tài khoản cho từng mặt hàng (vd 156, 152, 6422, 242). Máy nhớ theo tên hàng cho mọi hóa đơn sau, kể cả của nhà cung cấp khác.</p>'
 '<div class="cuon"><table><tr><th>Tên</th><th>ĐVT</th><th>SL</th><th>Đơn giá</th><th>Thành tiền</th><th>Thuế suất</th><th>TK hạch toán</th></tr>' + dong +
 '</table></div><datalist id="dstk">' + dstk + '</datalist><p class="dong-nut"><button>Lưu tài khoản theo mặt hàng</button>'
 + (f'<button class="phu" name="hanh_dong" value="ai" formnovalidate>Nhờ AI gợi ý tài khoản</button>' if ai_ok else
    f'<a class="mo" href="/he-thong/ai" title="{e(ai_tb)}">Trợ lý AI chưa bật</a>') + '</p></form>') if dong else '<p class="mo">Chưa có XML nên chưa có chi tiết hàng hóa.</p>'}</div>
<div class="the"><h2>{'Đã ghi sổ' if h['chung_tu_id'] else 'Định khoản gợi ý'}</h2>
<table><tr><th>TK Nợ</th><th>TK Có</th><th>Số tiền</th><th>Diễn giải</th></tr>{dk}</table></div>"""
        self.gui(U.trang("Hóa đơn", nd, cid, ct["ten"]))

    def _hd_mathang(self, pt, con, ct, q, rest):
        U = _U()
        e = U.e
        cid = ct["id"]
        chieu = q.get("chieu", "mua")
        tb = ""
        if pt == "POST":
            f = self.doc_form()
            xoa = set(f.get("xoa", []))
            for tc, tk in zip(f.get("tc", []), f.get("tk", [])):
                if tc in xoa:
                    con.execute("DELETE FROM quy_tac_mat_hang WHERE cong_ty_id=? AND chieu=? AND ten_chuan=?", (cid, chieu, tc))
                elif tk.strip():
                    con.execute("UPDATE quy_tac_mat_hang SET tk=?, tu_hoc=CASE WHEN tk=? THEN tu_hoc ELSE 0 END "
                                "WHERE cong_ty_id=? AND chieu=? AND ten_chuan=?", (tk.strip(), tk.strip(), cid, chieu, tc))
            con.commit()
            tb = '<p class="ok">Đã lưu.</p>'
        ds = con.execute("SELECT * FROM quy_tac_mat_hang WHERE cong_ty_id=? AND chieu=? ORDER BY ten_chuan", (cid, chieu)).fetchall()
        dong = "".join(
            f'<tr><td>{e(r["ten"])}<input type="hidden" name="tc" value="{e(r["ten_chuan"])}"></td>'
            f'<td><input name="tk" size="8" value="{e(r["tk"])}"></td><td class="s">{r["so_lan"]}</td>'
            f'<td>{"Máy tự học" if r["tu_hoc"] else "Người dùng đặt"}</td>'
            f'<td><input type="checkbox" name="xoa" value="{e(r["ten_chuan"])}"></td></tr>' for r in ds)
        tab = lambda c, t: f'<a class="nut{"" if chieu == c else " phu"}" href="/cty/{cid}/hoadon/mathang?chieu={c}">{t}</a>'
        nd = f"""<div class="the"><h1>Tài khoản theo mặt hàng</h1>{tb}
<p>{tab('mua', 'Mua vào')} {tab('ban', 'Bán ra')}</p>
<p class="mo">Khi ghi sổ một hóa đơn chỉ dùng một tài khoản, máy ghi nhớ tài khoản cho từng mặt hàng trên hóa đơn đó.
Lần sau gặp mặt hàng cùng tên (không phân biệt dấu, hoa thường), máy dùng tài khoản này trước quy tắc theo nhà cung cấp;
hóa đơn có nhiều loại hàng sẽ được tách thành nhiều dòng định khoản. Tài khoản người dùng đặt không bị máy ghi đè.</p></div>
<form method="post" class="the">{'<div class="cuon"><table><tr><th>Mặt hàng</th><th>Tài khoản</th><th>Số lần gặp</th><th>Nguồn</th><th>Xóa</th></tr>' + dong + '</table></div><p><button>Lưu</button></p>' if ds else '<p class="mo">Chưa học được mặt hàng nào. Ghi sổ vài hóa đơn có XML là máy bắt đầu học.</p>'}</form>"""
        self.gui(U.trang("Tài khoản theo mặt hàng", nd, cid, ct["ten"]))

    def _hd_nap(self, pt, con, ct, q, rest):
        U = _U()
        e = U.e
        cid = ct["id"]
        kq = ""
        if pt == "POST":
            loai = self.headers.get("Content-Type", "")
            if loai.startswith("multipart/"):
                truong, tep = doc_multipart(self)
                hds, loi = [], []
                for ten, b in tep:
                    a, l = hoa_don.doc_file(ten, b)
                    hds += a
                    loi += l
            else:
                truong = {k: v[0].strip().strip('"') for k, v in self.doc_form().items()}
                hds, loi = hoa_don.doc_thu_muc(truong.get("thu_muc", ""))
            dem = hoa_don.luu(con, cid, hds, "file")
            kq = (f'<div class="the"><h2>Kết quả</h2><p class="ok">Đọc được {len(hds)} hóa đơn: {dem["moi"]} mới, '
                  f'{dem["cap_nhat"]} đã có (cập nhật).</p>'
                  + (f'<p class="loi">{dem["khong_lien_quan"]} hóa đơn không có MST {e(ct["mst"])} ở người bán hay người mua nên bỏ qua.</p>'
                     if dem["khong_lien_quan"] else "")
                  + "".join(f'<p class="loi">{e(x)}</p>' for x in loi[:50])
                  + f'<p><a class="nut" href="/cty/{cid}/hoadon">Xem danh sách hóa đơn</a></p></div>')
        hd = nha_cung_cap.huong_dan(ct["nha_cung_cap_hd"] or "")
        ten_ncc = nha_cung_cap.TEN.get(ct["nha_cung_cap_hd"] or "", "chưa chọn")
        nd = f"""<div class="the"><h1>Nạp hóa đơn từ file</h1>
<p>Nhận file XML hóa đơn của <b>mọi nhà cung cấp</b> (chuẩn Tổng cục Thuế), file ZIP chứa nhiều XML,
và file Excel danh sách hóa đơn xuất từ hoadondientu.gdt.gov.vn. Hóa đơn trùng sẽ không bị nạp hai lần.</p>
<p class="mo">Nhà cung cấp hóa đơn của công ty: {e(ten_ncc)} (đổi ở <a href="/cty/{cid}/caidat">Cài đặt</a>). {e(hd)}</p>
<form method="post" enctype="multipart/form-data" class="ngang">
<label>Chọn file (chọn được nhiều file)<input type="file" name="tep" multiple accept=".xml,.zip,.xlsx"></label>
<button>Nạp</button></form>
<p class="mo" style="margin-top:14px">Hoặc nạp cả một thư mục trên máy:</p>
<form method="post" class="ngang"><label>Đường dẫn thư mục<input name="thu_muc" size="60" placeholder="E:\\HoaDon\\2025-Q4"></label>
<button>Nạp thư mục</button></form></div>{kq}"""
        self.gui(U.trang("Nạp hóa đơn", nd, cid, ct["ten"]))

    def _hd_cong(self, pt, con, ct, q, rest):
        U = _U()
        e = U.e
        cid = ct["id"]
        tb = ""
        if pt == "POST":
            f = {k: v[0].strip() for k, v in self.doc_form().items()}
            try:
                if f.get("hanh_dong") == "dang_nhap":
                    PHIEN_CONG[cid] = cong_hddt.dang_nhap(f["tai_khoan"], f["mat_khau"], f["ckey"], f["cvalue"])
                    tb = '<p class="ok">Đăng nhập cổng thuế thành công.</p>'
                elif f.get("hanh_dong") == "thoat":
                    PHIEN_CONG.pop(cid, None)
                elif f.get("hanh_dong") == "tai":
                    token = PHIEN_CONG.get(cid)
                    if not token:
                        raise cong_hddt.LoiCong("Chưa đăng nhập.")
                    dong_kq = []
                    canh_bao = []
                    ghi_cb = lambda s: canh_bao.append(s) if s.startswith("Không tải được") else None  # noqa: E731
                    for chieu in (["mua", "ban"] if f.get("chieu") == "ca_hai" else [f.get("chieu", "mua")]):
                        hds = cong_hddt.tai_ve(token, chieu, f["tu"], f["den"], kem_xml=bool(f.get("kem_xml")),
                                               bao=ghi_cb)
                        dem = hoa_don.luu(con, cid, hds, f"cong_thue_{chieu}")
                        co_xml = sum(1 for h in hds if h.get("xml"))
                        dong_kq.append(f"{'Mua vào' if chieu == 'mua' else 'Bán ra'}: {len(hds)} hóa đơn "
                                       f"({dem['moi']} mới, {dem['cap_nhat']} cập nhật, {co_xml} có XML)")
                    tb = ('<p class="ok">' + "<br>".join(dong_kq) + "</p>"
                          + "".join(f'<p class="loi">{e(x)}</p>' for x in canh_bao)
                          + f'<p><a class="nut" href="/cty/{cid}/hoadon?tu={f["tu"]}&den={f["den"]}">Xem hóa đơn</a></p>')
            except cong_hddt.LoiCong as ex:
                if "hết hạn" in str(ex):
                    PHIEN_CONG.pop(cid, None)
                tb = f'<p class="loi">{e(ex)}</p>'
            except KeyError as ex:
                tb = f'<p class="loi">Thiếu thông tin: {e(ex)}</p>'

        if cid in PHIEN_CONG:
            tu, den = U.ky_mac_dinh(q)
            nd = f"""<div class="the"><h1>Tải hóa đơn từ cổng thuế</h1>{tb}
<p class="ok">Đang đăng nhập cổng thuế cho MST {e(ct['mst'])}.</p>
<form method="post" class="ngang"><input type="hidden" name="hanh_dong" value="tai">
<label>Loại<select name="chieu"><option value="ca_hai">Cả mua vào và bán ra</option><option value="mua">Mua vào</option>
<option value="ban">Bán ra</option></select></label>
<label>Từ ngày<input type="date" name="tu" value="{tu}"></label><label>Đến ngày<input type="date" name="den" value="{den}"></label>
<label style="flex-direction:row;align-items:center;gap:6px"><input type="checkbox" name="kem_xml" value="1" checked>Tải cả file XML (có chi tiết hàng hóa, chậm hơn)</label>
<button>Tải về</button></form>
<p class="mo">Máy tự chia theo từng tháng và lấy cả hóa đơn có mã, không mã và máy tính tiền. Một quý vài trăm hóa đơn mất vài phút; đừng đóng trang khi đang tải.</p>
<form method="post"><input type="hidden" name="hanh_dong" value="thoat"><button class="nut phu">Thoát phiên cổng thuế</button></form></div>"""
            return self.gui(U.trang("Cổng thuế", nd, cid, ct["ten"]))

        try:
            ckey, svg = cong_hddt.lay_captcha()
            anh = base64.b64encode(svg.encode("utf-8")).decode()
            form = f"""<form method="post" style="display:grid;gap:10px;max-width:460px">
<input type="hidden" name="hanh_dong" value="dang_nhap"><input type="hidden" name="ckey" value="{e(ckey)}">
<label>Tên đăng nhập (MST)<input name="tai_khoan" value="{e(ct['mst'])}" required></label>
<label>Mật khẩu cổng hóa đơn<input type="password" name="mat_khau" required></label>
<div><img alt="captcha" src="data:image/svg+xml;base64,{anh}" style="height:56px;background:#fff;border:1px solid #ddd"></div>
<label>Mã captcha<input name="cvalue" required autocomplete="off"></label><div><button>Đăng nhập</button>
<a class="nut phu" href="/cty/{cid}/hoadon/cong">Đổi captcha</a></div></form>
<p class="mo">Mật khẩu chỉ dùng để đăng nhập lần này, không lưu lại ở đâu.</p>"""
        except cong_hddt.LoiCong as ex:
            form = (f'<p class="loi">{e(ex)}</p><p>Nếu cổng thuế đang lỗi, hãy vào hoadondientu.gdt.gov.vn xuất Excel '
                    f'danh sách hoặc tải XML, rồi <a href="/cty/{cid}/hoadon/nap">nạp file</a>.</p>')
        nd = f'<div class="the"><h1>Đăng nhập cổng hóa đơn điện tử</h1>{tb}{form}</div>'
        self.gui(U.trang("Cổng thuế", nd, cid, ct["ten"]))
