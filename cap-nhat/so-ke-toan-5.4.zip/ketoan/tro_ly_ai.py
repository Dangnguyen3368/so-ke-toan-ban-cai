"""Tro ly AI: khach tu chon hang AI (Claude, ChatGPT, Gemini, DeepSeek) bang ma API cua chinh ho,
hoac AI chay tren may (Ollama, LM Studio, hay may chu bat ky noi chuan OpenAI) de du lieu khong ra ngoai.

- Cai dat luu trong du_lieu/cai_dat.json, muc "ai". Ma API chi nam tren may khach, chi gui toi hang AI da chon.
- Chi dung thu vien chuan (urllib), khong them goi cai dat.
- Tinh nang dau tien: goi y tai khoan hach toan cho mat hang tren hoa don va cho dong sao ke ngan hang.
  AI chi GOI Y; nguoi dung xem lai roi moi luu / ghi so. Tai khoan AI dua ra phai co trong danh muc cua cong ty.
"""
import json
import re
import urllib.error
import urllib.request

from . import cai_dat

# ma -> thong tin hang. "kieu" la dinh dang API: anthropic | openai | gemini
NHA_CUNG_CAP = {
    "claude": {"ten": "Claude (Anthropic)", "kieu": "anthropic", "dia_chi": "https://api.anthropic.com/v1",
               "mo_hinh": ["claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5"],
               "lay_ma": "https://console.anthropic.com/settings/keys", "can_ma": True},
    "chatgpt": {"ten": "ChatGPT (OpenAI)", "kieu": "openai", "dia_chi": "https://api.openai.com/v1",
                "mo_hinh": ["gpt-5-mini", "gpt-5", "gpt-5-nano"],
                "lay_ma": "https://platform.openai.com/api-keys", "can_ma": True},
    "gemini": {"ten": "Gemini (Google)", "kieu": "gemini", "dia_chi": "https://generativelanguage.googleapis.com/v1beta",
               "mo_hinh": ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.5-flash-lite"],
               "lay_ma": "https://aistudio.google.com/apikey", "can_ma": True},
    "deepseek": {"ten": "DeepSeek", "kieu": "openai", "dia_chi": "https://api.deepseek.com",
                 "mo_hinh": ["deepseek-chat", "deepseek-reasoner"],
                 "lay_ma": "https://platform.deepseek.com/api_keys", "can_ma": True},
    "local": {"ten": "AI trên máy (Ollama, LM Studio...)", "kieu": "openai", "dia_chi": "http://localhost:11434/v1",
              "mo_hinh": ["qwen2.5:7b", "qwen2.5:14b", "llama3.1:8b", "gemma2:9b"],
              "lay_ma": "https://ollama.com/download", "can_ma": False},
}
DIA_CHI_LOCAL_MAU = [("http://localhost:11434/v1", "Ollama"), ("http://localhost:1234/v1", "LM Studio")]
THOI_GIAN_CHO = 120  # giay; AI tren may yeu co the cham


class LoiAI(Exception):
    pass


# ------------------------------------------------------------------ cai dat

def cau_hinh(cd=None):
    """dict: bat, nha_cung_cap, mo_hinh, ma (ma API cua hang dang chon), dia_chi."""
    ai = dict((cd if cd is not None else cai_dat.doc()).get("ai") or {})
    ncc = ai.get("nha_cung_cap") if ai.get("nha_cung_cap") in NHA_CUNG_CAP else "claude"
    tt = NHA_CUNG_CAP[ncc]
    ma = (ai.get("ma") or {}).get(ncc, "")
    dia_chi = (ai.get("dia_chi") or {}).get(ncc) or tt["dia_chi"]
    return {"bat": bool(ai.get("bat")), "nha_cung_cap": ncc, "mo_hinh": (ai.get("mo_hinh") or {}).get(ncc) or tt["mo_hinh"][0],
            "ma": ma, "dia_chi": dia_chi.rstrip("/")}


def luu_cau_hinh(bat, nha_cung_cap, mo_hinh="", ma=None, dia_chi=""):
    """ma=None hoac '' thi giu ma cu; ma='-' thi xoa ma cua hang nay."""
    if nha_cung_cap not in NHA_CUNG_CAP:
        raise ValueError("Chưa chọn hãng AI.")
    cd = cai_dat.doc()
    ai = dict(cd.get("ai") or {})
    ai["bat"] = bool(bat)
    ai["nha_cung_cap"] = nha_cung_cap
    for k in ("mo_hinh", "ma", "dia_chi"):
        ai[k] = dict(ai.get(k) or {})
    ai["mo_hinh"][nha_cung_cap] = (mo_hinh or "").strip()
    if ma == "-":
        ai["ma"].pop(nha_cung_cap, None)
    elif ma and ma.strip():
        ai["ma"][nha_cung_cap] = ma.strip()
    if nha_cung_cap == "local":
        ai["dia_chi"]["local"] = (dia_chi or "").strip()
    cd["ai"] = ai
    cai_dat.ghi(cd)
    return cau_hinh(cd)


def che_ma(ma):
    """Hien ma API dang che: sk-...abcd."""
    if not ma:
        return ""
    return (ma[:3] + "…" + ma[-4:]) if len(ma) > 10 else "…" + ma[-2:]


def duoc_phep(bq=None):
    """(duoc dung, thong bao). Goi ban quyen co the gioi han tinh nang AI: neu trang thai ban quyen co
    danh sach 'tinh_nang' ma khong co 'ai' thi khong cho dung."""
    tn = (bq or {}).get("tinh_nang")
    if tn is not None and "ai" not in tn:
        return False, "Gói bản quyền hiện tại chưa có Trợ lý AI. Liên hệ để nâng cấp gói."
    return True, ""


def san_sang(cd=None, bq=None):
    """(san sang, thong bao) de hien nut AI tren cac trang."""
    ok, tb = duoc_phep(bq)
    if not ok:
        return ok, tb
    c = cau_hinh(cd)
    if not c["bat"]:
        return False, "Chưa bật Trợ lý AI (Cài đặt chung → Trợ lý AI)."
    if NHA_CUNG_CAP[c["nha_cung_cap"]]["can_ma"] and not c["ma"]:
        return False, f"Chưa nhập mã API cho {NHA_CUNG_CAP[c['nha_cung_cap']]['ten']} (Cài đặt chung → Trợ lý AI)."
    return True, ""


# ------------------------------------------------------------------ goi API

def _post(url, du_lieu, tieu_de):
    """Gui POST JSON, tra ve JSON. Tach rieng de kiem thu thay the duoc."""
    req = urllib.request.Request(url, data=json.dumps(du_lieu).encode("utf-8"), method="POST",
                                 headers={"Content-Type": "application/json", **tieu_de})
    try:
        with urllib.request.urlopen(req, timeout=THOI_GIAN_CHO) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as ex:
        try:
            chi_tiet = json.loads(ex.read().decode("utf-8", "replace"))
            err = chi_tiet.get("error") if isinstance(chi_tiet, dict) else None
            if isinstance(err, dict):
                chi_tiet = err.get("message") or err
            elif isinstance(chi_tiet, list) and chi_tiet and isinstance(chi_tiet[0], dict):
                chi_tiet = (chi_tiet[0].get("error") or {}).get("message") or chi_tiet
        except Exception:
            chi_tiet = ""
        goi_y = {401: "Mã API sai hoặc đã bị thu hồi.", 403: "Mã API không có quyền dùng mô hình này.",
                 404: "Sai tên mô hình hoặc sai địa chỉ.", 429: "Hết hạn mức hoặc hết tiền trong tài khoản AI, thử lại sau.",
                 402: "Tài khoản AI hết tiền."}.get(ex.code, "")
        raise LoiAI(f"Hãng AI trả lỗi {ex.code}. {goi_y} {chi_tiet}".strip()) from None
    except (urllib.error.URLError, TimeoutError, OSError) as ex:
        ly_do = getattr(ex, "reason", ex)
        raise LoiAI(f"Không kết nối được tới AI ({ly_do}). Kiểm tra mạng, hoặc với AI trên máy thì kiểm tra Ollama / LM Studio đã chạy chưa.") from None
    except ValueError:
        raise LoiAI("AI trả về dữ liệu không đọc được.") from None


KIEU_TEP = {".pdf": "application/pdf", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
            ".webp": "image/webp", ".gif": "image/gif"}


def doc_duoc_tep(cd=None):
    """(doc duoc anh, doc duoc PDF) voi hang dang chon."""
    ncc = cau_hinh(cd)["nha_cung_cap"]
    return {"claude": (True, True), "chatgpt": (True, True), "gemini": (True, True),
            "deepseek": (False, False), "local": (True, False)}[ncc]


def hoi(he_thong, cau_hoi, cd=None, toi_da=2000, tep=None, lich_su=None):
    """Gui mot cau hoi, tra ve chu AI tra loi.

    tep: list (kieu mime, bytes) anh / PDF gui kem. lich_su: list (vai 'user'|'assistant', chu) cac luot truoc."""
    import base64
    c = cau_hinh(cd)
    ncc = c["nha_cung_cap"]
    tt = NHA_CUNG_CAP[ncc]
    if tt["can_ma"] and not c["ma"]:
        raise LoiAI(f"Chưa nhập mã API cho {tt['ten']}.")
    tep = tep or []
    if tep:
        anh, pdf = doc_duoc_tep(cd)
        for mime, _ in tep:
            if (mime == "application/pdf" and not pdf) or (mime != "application/pdf" and not anh):
                raise LoiAI(f"{tt['ten']} không đọc được {'file PDF' if mime == 'application/pdf' else 'ảnh'}. "
                            + ("Hãy chụp ảnh hóa đơn (JPG, PNG) rồi nạp ảnh, hoặc " if mime == "application/pdf" and anh else "")
                            + "chọn Claude, ChatGPT hoặc Gemini trong Cài đặt chung → Trợ lý AI.")
    b64 = [(m, base64.b64encode(b).decode("ascii")) for m, b in tep]
    lich_su = [(v, t) for v, t in (lich_su or []) if v in ("user", "assistant") and t]
    kieu, mh, ma, dc = tt["kieu"], c["mo_hinh"], c["ma"], c["dia_chi"]
    if kieu == "anthropic":
        nd = [{"type": "document" if m == "application/pdf" else "image",
               "source": {"type": "base64", "media_type": m, "data": d}} for m, d in b64]
        nd.append({"type": "text", "text": cau_hoi})
        kq = _post(dc + "/messages", {"model": mh, "max_tokens": toi_da, "system": he_thong,
                                      "messages": [{"role": v, "content": t} for v, t in lich_su]
                                      + [{"role": "user", "content": nd}]},
                   {"x-api-key": ma, "anthropic-version": "2023-06-01"})
        chu = "".join(k.get("text", "") for k in kq.get("content") or [] if k.get("type") == "text")
    elif kieu == "gemini":
        phan = [{"inline_data": {"mime_type": m, "data": d}} for m, d in b64] + [{"text": cau_hoi}]
        kq = _post(f"{dc}/models/{mh}:generateContent",
                   {"systemInstruction": {"parts": [{"text": he_thong}]},
                    "contents": [{"role": "model" if v == "assistant" else "user", "parts": [{"text": t}]} for v, t in lich_su]
                    + [{"role": "user", "parts": phan}],
                    "generationConfig": {"maxOutputTokens": toi_da}},
                   {"x-goog-api-key": ma})
        ung_vien = (kq.get("candidates") or [{}])[0]
        chu = "".join(p.get("text", "") for p in (ung_vien.get("content") or {}).get("parts") or [])
    else:  # openai va cac may chu noi chuan OpenAI (DeepSeek, Ollama, LM Studio)
        if b64:
            nd = [({"type": "file", "file": {"filename": "chung_tu.pdf", "file_data": f"data:{m};base64,{d}"}}
                   if m == "application/pdf" else {"type": "image_url", "image_url": {"url": f"data:{m};base64,{d}"}})
                  for m, d in b64] + [{"type": "text", "text": cau_hoi}]
        else:
            nd = cau_hoi
        bd = {"model": mh, "messages": [{"role": "system", "content": he_thong}]
              + [{"role": v, "content": t} for v, t in lich_su] + [{"role": "user", "content": nd}]}
        if ncc == "chatgpt":
            bd["max_completion_tokens"] = toi_da * 4  # mo hinh suy luan tinh ca phan nghi
        else:
            bd["max_tokens"] = toi_da
        kq = _post(dc + "/chat/completions", bd, {"Authorization": f"Bearer {ma}"} if ma else {})
        chu = ((kq.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
    chu = re.sub(r"<think>.*?</think>", "", chu, flags=re.S).strip()  # mo hinh suy luan chay tren may
    if not chu:
        raise LoiAI("AI không trả lời (có thể bị chặn nội dung hoặc hết hạn mức).")
    return chu


def thu_ket_noi(cd=None):
    """Tra ve cau tra loi ngan cua AI, hoac nem LoiAI."""
    return hoi("Bạn là trợ lý kế toán. Trả lời thật ngắn.", "Trả lời đúng một câu: 'Kết nối thành công'.", cd, toi_da=50)


def doc_json(chu):
    """Lay khoi JSON dau tien trong cau tra loi (bo ```json ... ```)."""
    m = re.search(r"```(?:json)?\s*(.*?)```", chu, re.S)
    if m:
        chu = m.group(1)
    for mo, dong in (("[", "]"), ("{", "}")):
        a, b = chu.find(mo), chu.rfind(dong)
        if a >= 0 and b > a:
            try:
                return json.loads(chu[a:b + 1])
            except ValueError:
                continue
    raise LoiAI("AI trả lời không đúng định dạng, thử lại hoặc chọn mô hình khác.")


# ------------------------------------------------------------------ goi y hach toan

HE_THONG_KT = (
    "Bạn là kế toán trưởng Việt Nam, hạch toán theo chế độ kế toán doanh nghiệp nhỏ và vừa (Thông tư 133/2016/TT-BTC). "
    "Chỉ dùng tài khoản có trong danh mục được cung cấp; chọn tài khoản chi tiết nhất phù hợp. "
    "Trả lời DUY NHẤT bằng JSON, không giải thích thêm ngoài JSON."
)


def _danh_muc_tk(con, cid):
    return {r["so_tk"]: r["ten"] for r in con.execute(
        "SELECT so_tk, ten FROM tai_khoan WHERE cong_ty_id=? ORDER BY so_tk", (cid,))}


def _chu_danh_muc(dm):
    return "\n".join(f"{k}: {v}" for k, v in dm.items())


def _cong_ty(con, cid):
    r = con.execute("SELECT * FROM cong_ty WHERE id=?", (cid,)).fetchone()
    return f"{r['ten']} (MST {r['mst']})" if r else ""


def goi_y_hoa_don(con, cid, h, cd=None):
    """Goi y TK cho tung mat hang cua hoa don h. Tra ve {ten mat hang: (tk, ly do)}; bo tk khong co trong danh muc."""
    dong = json.loads(h["dong_hang"] or "[]")
    if not dong:
        raise LoiAI("Hóa đơn chưa có chi tiết hàng hóa (cần nạp file XML).")
    mua = h["chieu"] == "mua"
    dm = _danh_muc_tk(con, cid)
    hang = [{"stt": i + 1, "ten": d.get("ten"), "dvt": d.get("dvt"), "so_luong": d.get("so_luong"),
             "thanh_tien": d.get("thanh_tien")} for i, d in enumerate(dong[:80])]
    cau = (f"Công ty: {_cong_ty(con, cid)}\n"
           f"Hóa đơn {'MUA VÀO từ' if mua else 'BÁN RA cho'}: {h['nb_ten'] if mua else h['nm_ten']}, ngày {h['ngay_lap']}, "
           f"tiền hàng {h['tien_hang']}, thuế {h['tien_thue']}.\n"
           f"Các mặt hàng:\n{json.dumps(hang, ensure_ascii=False)}\n\n"
           f"Danh mục tài khoản của công ty:\n{_chu_danh_muc(dm)}\n\n"
           + ("Với hóa đơn mua: chọn tài khoản ghi NỢ cho từng mặt hàng (hàng hóa 156, nguyên vật liệu 152, công cụ dụng cụ 153, "
              "TSCĐ 211, chi phí trả trước 242, chi phí quản lý/bán hàng 642x...). Đối ứng 331 và thuế 1331 máy tự ghi.\n"
              if mua else
              "Với hóa đơn bán: chọn tài khoản ghi CÓ doanh thu cho từng mặt hàng (511x, hoặc 711 nếu là thanh lý). "
              "Đối ứng 131 và thuế 33311 máy tự ghi.\n")
           + 'Trả về JSON dạng: [{"stt": 1, "tk": "156", "ly_do": "ngắn gọn"}]')
    kq = doc_json(hoi(HE_THONG_KT, cau, cd))
    if isinstance(kq, dict):
        kq = kq.get("ket_qua") or kq.get("items") or [kq]
    ra = {}
    for x in kq if isinstance(kq, list) else []:
        try:
            d = dong[int(x.get("stt")) - 1]
        except (TypeError, ValueError, IndexError, AttributeError):
            continue
        tk = str(x.get("tk") or "").strip()
        if tk in dm:
            ra[d.get("ten")] = (tk, str(x.get("ly_do") or "")[:200])
    if not ra:
        raise LoiAI("AI không đưa ra được tài khoản nào có trong danh mục.")
    return ra


DANH_DAU_AI = "AI: "
TOI_DA_DONG_SAO_KE = 40


def dong_sao_ke_can_ai(con, cid, gioi_han=TOI_DA_DONG_SAO_KE):
    """Dong sao ke chua ghi so ma may chua chac (ly do co '(cần xem)'), AI chua goi y."""
    return con.execute(
        "SELECT * FROM sao_ke WHERE cong_ty_id=? AND trang_thai='moi' AND ly_do LIKE '%(cần xem)%' "
        "AND ly_do NOT LIKE ? ORDER BY ngay, id LIMIT ?", (cid, DANH_DAU_AI + "%", gioi_han)).fetchall()


def goi_y_sao_ke(con, cid, cd=None):
    """Nho AI goi y TK doi ung (va doi tuong) cho cac dong sao ke chua chac. Ghi vao tk_goi_y, dt_goi_y, ly_do
    (van giu '(cần xem)' de nguoi dung xem lai). Tra ve so dong da goi y."""
    ds = dong_sao_ke_can_ai(con, cid)
    if not ds:
        return 0
    dm = _danh_muc_tk(con, cid)
    dt = {r["ma"]: (r["ten"], r["loai"]) for r in con.execute(
        "SELECT ma, ten, loai FROM doi_tuong WHERE cong_ty_id=? ORDER BY ma LIMIT 300", (cid,))} \
        if con.execute("SELECT 1 FROM sqlite_master WHERE name='doi_tuong'").fetchone() else {}
    dong = [{"id": s["id"], "ngay": s["ngay"], "tk_ngan_hang": s["tk"], "tien_vao": s["vao"], "tien_ra": s["ra"],
             "noi_dung": s["noi_dung"][:300]} for s in ds]
    cau = (f"Công ty: {_cong_ty(con, cid)}\n"
           "Các dòng sao kê ngân hàng dưới đây chưa rõ cách hạch toán. Với mỗi dòng, chọn tài khoản ĐỐI ỨNG với tài khoản tiền gửi "
           "(tiền vào: TK tiền gửi ghi Nợ, đối ứng ghi Có; tiền ra: đối ứng ghi Nợ). Nếu là khách hàng hoặc nhà cung cấp có trong danh sách "
           "đối tượng thì điền mã đối tượng, không chắc thì để trống.\n"
           f"Dòng sao kê:\n{json.dumps(dong, ensure_ascii=False)}\n\n"
           f"Danh mục tài khoản:\n{_chu_danh_muc(dm)}\n\n"
           + (f"Đối tượng (mã: tên, loại):\n" + "\n".join(f"{m}: {t} ({l})" for m, (t, l) in dt.items()) + "\n\n" if dt else "")
           + 'Trả về JSON dạng: [{"id": 123, "tk": "6422", "doi_tuong": "", "ly_do": "ngắn gọn"}]')
    kq = doc_json(hoi(HE_THONG_KT, cau, cd, toi_da=4000))
    if isinstance(kq, dict):
        kq = kq.get("ket_qua") or kq.get("items") or [kq]
    hop_le = {s["id"] for s in ds}
    n = 0
    for x in kq if isinstance(kq, list) else []:
        try:
            i = int(x.get("id"))
        except (TypeError, ValueError, AttributeError):
            continue
        tk = str(x.get("tk") or "").strip()
        if i not in hop_le or tk not in dm:
            continue
        ma = str(x.get("doi_tuong") or "").strip()
        if ma not in dt:
            ma = ""
        con.execute("UPDATE sao_ke SET tk_goi_y=?, dt_goi_y=?, ly_do=? WHERE id=? AND cong_ty_id=?",
                    (tk, ma, f"{DANH_DAU_AI}{str(x.get('ly_do') or '')[:160]} (cần xem)", i, cid))
        n += 1
    con.commit()
    return n
