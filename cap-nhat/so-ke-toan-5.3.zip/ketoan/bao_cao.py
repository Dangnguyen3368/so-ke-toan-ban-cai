"""Bao cao tai chinh theo TT133: B01a-DNN, B02-DNN, bang can doi tai khoan cho XML.

So du tinh theo "dau ngay": so du dau ngay 01/01/N+1 = so du cuoi nam N.

Tai khoan luong tinh (131, 331...) duoc tach hai ben theo doi tuong:
1. Neu but toan / so du dau ky co ma doi tuong thi tinh tu so.
2. Neu khong, lay bang tong hop cong no da nap (vi du tu MISA) dung ngay do.
3. Neu khong co ca hai thi lay so du ròng va canh bao.
"""
import re
from datetime import date, timedelta

import openpyxl

from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS cong_no_doi_tuong (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    ngay TEXT NOT NULL,                 -- so du dau ngay nay (= cuoi ngay hom truoc)
    so_tk TEXT NOT NULL,
    ma TEXT NOT NULL,
    ten TEXT,
    du_no INTEGER NOT NULL DEFAULT 0,
    du_co INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (cong_ty_id, ngay, so_tk, ma)
);
"""

TACH_DOI_TUONG = ("131", "331", "1388", "141", "334", "338")


def chuan_bi(con):
    con.executescript(SCHEMA)


def ngay_sau(s):
    return (date.fromisoformat(s) + timedelta(days=1)).isoformat()


def ngay_truoc(s):
    return (date.fromisoformat(s) - timedelta(days=1)).isoformat()


# ---------------- so du chi tiet ----------------

def _snap(con, cid, ngay):
    r = con.execute("SELECT MAX(ngay) n FROM so_du_dau_ky WHERE cong_ty_id=? AND ngay<=?", (cid, ngay)).fetchone()
    return r["n"] or "0000-00-00"


def so_du_doi_tuong(con, cid, ngay):
    """{(tai khoan ghi so, ma doi tuong): No - Co} dau ngay `ngay`."""
    ns = _snap(con, cid, ngay)
    d = {}
    for r in con.execute("SELECT so_tk, doi_tuong, du_no - du_co s FROM so_du_dau_ky WHERE cong_ty_id=? AND ngay=?",
                         (cid, ns)):
        k = (r["so_tk"], r["doi_tuong"] or "")
        d[k] = d.get(k, 0) + r["s"]
    q = ("SELECT b.tk_no, b.doi_tuong_no, b.tk_co, b.doi_tuong_co, b.so_tien FROM but_toan b "
         "JOIN chung_tu c ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? AND c.ngay_ht>=? AND c.ngay_ht<?")
    for r in con.execute(q, (cid, ns, ngay)):
        k = (r["tk_no"], r["doi_tuong_no"] or "")
        d[k] = d.get(k, 0) + r["so_tien"]
        k = (r["tk_co"], r["doi_tuong_co"] or "")
        d[k] = d.get(k, 0) - r["so_tien"]
    return d


def phan_hai_ben(con, cid, ngay):
    """{tai khoan ghi so: (du No, du Co)} dau ngay `ngay`, da tach doi tuong.

    Tra ve (bang, canh_bao)."""
    chuan_bi(con)
    dt = so_du_doi_tuong(con, cid, ngay)
    theo_tk = {}
    for (tk, ma), v in dt.items():
        theo_tk.setdefault(tk, {})
        theo_tk[tk][ma] = theo_tk[tk].get(ma, 0) + v
    nhap = {}
    for r in con.execute("SELECT so_tk, ma, du_no, du_co FROM cong_no_doi_tuong WHERE cong_ty_id=? AND ngay=?",
                         (cid, ngay)):
        nhap.setdefault(r["so_tk"], []).append((r["du_no"], r["du_co"]))
    kq, cb = {}, []
    for tk, ds in theo_tk.items():
        rong = sum(ds.values())
        can_tach = tk.startswith(TACH_DOI_TUONG)
        if can_tach and any(m for m in ds):
            no = sum(v for v in ds.values() if v > 0)
            kq[tk] = (no, no - rong)
        elif can_tach and tk in nhap:
            no = sum(a for a, _ in nhap[tk])
            co = sum(b for _, b in nhap[tk])
            if abs((no - co) - rong) > 1:
                cb.append(f"TK {tk}: bảng công nợ đã nạp (dư ròng {no - co:,}) lệch sổ ({rong:,}); "
                          f"đã điều chỉnh phần chênh vào bên còn lại.".replace(",", "."))
                if rong - (no - co) > 0:
                    no += rong - (no - co)
                else:
                    co += (no - co) - rong
            kq[tk] = (no, co)
        else:
            if can_tach and rong and tk[:3] in ("131", "331"):
                cb.append(f"TK {tk}: chưa có số dư theo từng khách hàng/nhà cung cấp, đang lấy số ròng. "
                          "Nạp bảng tổng hợp công nợ để tách hai bên.")
            kq[tk] = (max(rong, 0), max(-rong, 0))
    return {k: v for k, v in kq.items() if v != (0, 0)}, cb


def phat_sinh(con, cid, tu, den):
    """{tai khoan ghi so: (PS No, PS Co)} tu ngay `tu` den het ngay `den`."""
    d = {}
    q = ("SELECT b.tk_no, b.tk_co, b.so_tien FROM but_toan b JOIN chung_tu c ON c.id=b.chung_tu_id "
         "WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ?")
    for r in con.execute(q, (cid, tu, den)):
        a = d.get(r["tk_no"], (0, 0))
        d[r["tk_no"]] = (a[0] + r["so_tien"], a[1])
        a = d.get(r["tk_co"], (0, 0))
        d[r["tk_co"]] = (a[0], a[1] + r["so_tien"])
    return d


def nap_cong_no_misa(con, cid, du_lieu_hoac_duong):
    """Nap bang 'Tong hop cong no phai thu/phai tra' cua MISA (so du cuoi ky theo doi tuong).

    Tra ve (so_tk, ngay, so dong)."""
    chuan_bi(con)
    import io
    src = io.BytesIO(du_lieu_hoac_duong) if isinstance(du_lieu_hoac_duong, bytes) else du_lieu_hoac_duong
    wb = openpyxl.load_workbook(src, read_only=True, data_only=True)
    try:
        dong = [list(r) for r in wb.active.iter_rows(values_only=True)]
    finally:
        wb.close()
    tk, den = None, None
    for r in dong[:8]:
        s = " ".join(str(x) for x in r if x is not None)
        m = re.search(r"Tài khoản:\s*(\d+)", s)
        if m:
            tk = m.group(1)
        m = re.search(r"Năm\s+(\d{4})", s)
        if m:
            den = f"{m.group(1)}-12-31"
        m = re.search(r"đến ngày\s*(\d{1,2})/(\d{1,2})/(\d{4})", s, re.I)
        if m:
            den = f"{m.group(3)}-{int(m.group(2)):02d}-{int(m.group(1)):02d}"
    if not tk or not den:
        raise ValueError("Không đọc được tài khoản hoặc kỳ ở đầu file (cần dòng 'Tài khoản: 131; Năm 2025').")
    ngay = ngay_sau(den)
    con.execute("DELETE FROM cong_no_doi_tuong WHERE cong_ty_id=? AND ngay=? AND so_tk LIKE ?", (cid, ngay, tk + "%"))
    n = 0
    for r in dong:
        v = [x for x in r if x is not None]
        if len(v) >= 9 and isinstance(v[-1], (int, float)) and isinstance(v[-2], (int, float)) \
                and str(v[2]).strip().isdigit():
            no, co = int(round(v[-2])), int(round(v[-1]))
            if no or co:
                con.execute("INSERT OR REPLACE INTO cong_no_doi_tuong VALUES (?,?,?,?,?,?,?)",
                            (cid, ngay, str(v[2]).strip(), str(v[0]).strip(), str(v[1]).strip(), no, co))
                n += 1
    con.commit()
    return tk, den, n


# ---------------- B01a-DNN ----------------
# (ma chi tieu, ten, cac so hang). So hang: (tien to TK, ben, dau)
#   ben N = phan du No, C = phan du Co, K = Co tru No (co the am)
B01 = [
    ("110", "I. Tiền và các khoản tương đương tiền", [("111", "N"), ("112", "N")]),
    ("121", "1. Chứng khoán kinh doanh", [("121", "N")]),
    ("122", "2. Đầu tư nắm giữ đến ngày đáo hạn", [("128", "N")]),
    ("123", "3. Đầu tư góp vốn vào đơn vị khác", [("228", "N")]),
    ("124", "4. Dự phòng tổn thất đầu tư tài chính", [("2291", "C", -1), ("2292", "C", -1)]),
    ("131", "1. Phải thu của khách hàng", [("131", "N")]),
    ("132", "2. Trả trước cho người bán", [("331", "N")]),
    ("133", "3. Vốn kinh doanh ở đơn vị trực thuộc", [("1361", "N")]),
    ("134", "4. Phải thu khác", [("1368", "N"), ("1386", "N"), ("1388", "N"), ("141", "N"), ("334", "N"),
                                 ("338", "N"), ("3368", "N")]),
    ("135", "5. Tài sản thiếu chờ xử lý", [("1381", "N")]),
    ("136", "6. Dự phòng phải thu khó đòi", [("2293", "C", -1)]),
    ("141", "1. Hàng tồn kho", [("15", "N")]),
    ("142", "2. Dự phòng giảm giá hàng tồn kho", [("2294", "C", -1)]),
    ("151", "- Nguyên giá", [("211", "N")]),
    ("152", "- Giá trị hao mòn lũy kế", [("214", "C", -1), ("2147", "C", 1)]),
    ("161", "- Nguyên giá", [("217", "N")]),
    ("162", "- Giá trị hao mòn lũy kế", [("2147", "C", -1)]),
    ("170", "VI. XDCB dở dang", [("241", "N")]),
    ("181", "1. Thuế GTGT được khấu trừ", [("133", "N")]),
    ("182", "2. Tài sản khác", [("242", "N"), ("2288", "N"), ("333", "N")]),
    ("311", "1. Phải trả người bán", [("331", "C")]),
    ("312", "2. Người mua trả tiền trước", [("131", "C")]),
    ("313", "3. Thuế và các khoản phải nộp Nhà nước", [("333", "C")]),
    ("314", "4. Phải trả người lao động", [("334", "C")]),
    ("315", "5. Phải trả khác", [("335", "C"), ("338", "C"), ("1388", "C"), ("1386", "C"), ("141", "C"),
                                 ("3368", "C"), ("1368", "C")]),
    ("316", "6. Vay và nợ thuê tài chính", [("341", "C")]),
    ("317", "7. Phải trả nội bộ về vốn kinh doanh", [("3361", "C")]),
    ("318", "8. Dự phòng phải trả", [("352", "C")]),
    ("319", "9. Quỹ khen thưởng, phúc lợi", [("353", "C")]),
    ("320", "10. Quỹ phát triển khoa học và công nghệ", [("356", "C")]),
    ("411", "1. Vốn góp của chủ sở hữu", [("4111", "K")]),
    ("412", "2. Thặng dư vốn cổ phần", [("4112", "K")]),
    ("413", "3. Vốn khác của chủ sở hữu", [("4118", "K")]),
    ("414", "4. Cổ phiếu quỹ", [("419", "K")]),
    ("415", "5. Chênh lệch tỷ giá hối đoái", [("413", "K")]),
    ("416", "6. Các quỹ thuộc vốn chủ sở hữu", [("418", "K")]),
    ("417", "7. Lợi nhuận sau thuế chưa phân phối", [("421", "K"), ("5", "K"), ("6", "K"), ("7", "K"),
                                                       ("8", "K"), ("911", "K")]),
]
TONG_B01 = {
    "120": ["121", "122", "123", "124"], "130": ["131", "132", "133", "134", "135", "136"],
    "140": ["141", "142"], "150": ["151", "152"], "160": ["161", "162"], "180": ["181", "182"],
    "200": ["110", "120", "130", "140", "150", "160", "170", "180"],
    "300": [f"{i}" for i in range(311, 321)], "400": [f"{i}" for i in range(411, 418)], "500": ["300", "400"],
}
TEN_TONG = {"120": "II. Đầu tư tài chính", "130": "III. Các khoản phải thu", "140": "IV. Hàng tồn kho",
            "150": "V. Tài sản cố định", "160": "VI. Bất động sản đầu tư", "180": "VII. Tài sản khác",
            "200": "TỔNG CỘNG TÀI SẢN", "300": "I. NỢ PHẢI TRẢ", "400": "II. VỐN CHỦ SỞ HỮU",
            "500": "TỔNG CỘNG NGUỒN VỐN"}
THU_TU_B01 = ["110", "120", "121", "122", "123", "124", "130", "131", "132", "133", "134", "135", "136",
              "140", "141", "142", "150", "151", "152", "160", "161", "162", "170", "180", "181", "182", "200",
              "300"] + [f"{i}" for i in range(311, 321)] + ["400"] + [f"{i}" for i in range(411, 418)] + ["500"]


def _thuoc(tk, tien_to):
    return tk.startswith(tien_to)


def b01(con, cid, ngay):
    """Bang can doi ke toan tai dau ngay `ngay` (vi du 2026-01-01 cho cuoi nam 2025).

    Tra ve (dict chi tieu -> so, canh_bao)."""
    bang, cb = phan_hai_ben(con, cid, ngay)
    kq = {}
    dung = {"N": set(), "C": set()}
    for ma, _, hang in B01:
        t = 0
        for h in hang:
            tt, ben = h[0], h[1]
            dau = h[2] if len(h) > 2 else 1
            for tk, (no, co) in bang.items():
                if _thuoc(tk, tt):
                    if ben == "N":
                        t += dau * no
                        dung["N"].add(tk)
                    elif ben == "C":
                        t += dau * co
                        dung["C"].add(tk)
                    else:
                        t += dau * (co - no)
                        dung["N"].add(tk)
                        dung["C"].add(tk)
        kq[ma] = t
    for ma in ["120", "130", "140", "150", "160", "180", "200", "300", "400", "500"]:
        kq[ma] = sum(kq[x] for x in TONG_B01[ma])
    for tk, (no, co) in sorted(bang.items()):
        if no and tk not in dung["N"]:
            cb.append(f"TK {tk} dư Nợ {no:,} chưa được đưa vào chỉ tiêu nào của B01.".replace(",", "."))
        if co and tk not in dung["C"]:
            cb.append(f"TK {tk} dư Có {co:,} chưa được đưa vào chỉ tiêu nào của B01.".replace(",", "."))
    if kq["200"] != kq["500"]:
        cb.append(f"Tổng tài sản ({kq['200']:,}) khác tổng nguồn vốn ({kq['500']:,}).".replace(",", "."))
    return kq, cb


# ---------------- B02-DNN ----------------
THU_TU_B02 = [
    ("01", "1. Doanh thu bán hàng và cung cấp dịch vụ"), ("02", "2. Các khoản giảm trừ doanh thu"),
    ("10", "3. Doanh thu thuần (10 = 01 - 02)"), ("11", "4. Giá vốn hàng bán"),
    ("20", "5. Lợi nhuận gộp (20 = 10 - 11)"), ("21", "6. Doanh thu hoạt động tài chính"),
    ("22", "7. Chi phí tài chính"), ("23", "- Trong đó: Chi phí lãi vay"),
    ("24", "8. Chi phí quản lý kinh doanh"), ("30", "9. Lợi nhuận thuần từ HĐKD (30 = 20 + 21 - 22 - 24)"),
    ("31", "10. Thu nhập khác"), ("32", "11. Chi phí khác"), ("40", "12. Lợi nhuận khác (40 = 31 - 32)"),
    ("50", "13. Tổng lợi nhuận kế toán trước thuế (50 = 30 + 40)"), ("51", "14. Chi phí thuế TNDN"),
    ("60", "15. Lợi nhuận sau thuế TNDN (60 = 50 - 51)"),
]


def b02(con, cid, tu, den):
    """Ket qua kinh doanh tu `tu` den `den`, khong tinh but toan ket chuyen sang 911.

    Tra ve dict chi tieu -> so, kem cac khoan con (6421, 6422, 5111...) de dung cho 03-1A."""
    no, co = {}, {}
    lai_vay = 0
    q = ("SELECT b.tk_no, b.tk_co, b.so_tien, COALESCE(b.dien_giai, c.dien_giai, '') dg FROM but_toan b "
         "JOIN chung_tu c ON c.id=b.chung_tu_id WHERE c.cong_ty_id=? AND c.ngay_ht BETWEEN ? AND ?")
    for r in con.execute(q, (cid, tu, den)):
        a, b, t = r["tk_no"], r["tk_co"], r["so_tien"]
        if a.startswith("911") or b.startswith("911"):
            continue
        no[a] = no.get(a, 0) + t
        co[b] = co.get(b, 0) + t
        if a.startswith("635") and "lãi vay" in (r["dg"] or "").lower():
            lai_vay += t

    def n(tt):  # phat sinh No tru Co
        return sum(v for k, v in no.items() if k.startswith(tt)) - sum(v for k, v in co.items() if k.startswith(tt))

    kq = {
        "01": sum(v for k, v in co.items() if k.startswith("511")),
        "02": sum(v for k, v in no.items() if k.startswith("511")),
        "11": n("632"), "21": -n("515"), "22": n("635"), "23": lai_vay, "24": n("642"),
        "31": -n("711"), "32": n("811"), "51": n("821"),
    }
    kq["10"] = kq["01"] - kq["02"]
    kq["20"] = kq["10"] - kq["11"]
    kq["30"] = kq["20"] + kq["21"] - kq["22"] - kq["24"]
    kq["40"] = kq["31"] - kq["32"]
    kq["50"] = kq["30"] + kq["40"]
    kq["60"] = kq["50"] - kq["51"]
    kq["_chi_tiet"] = {"6421": n("6421"), "6422": n("6422"), "642_khac": n("642") - n("6421") - n("6422")}
    return kq


# ---------------- ket chuyen ----------------

def ket_chuyen(con, cid, tu, den):
    """Ket chuyen doanh thu, chi phi (loai 5-8) sang 911 va lai/lo sang 4212 cho ky tu..den.

    Chay lai se thay chung tu cu. Tra ve (chung_tu_id hoac None, loi nhuan)."""
    so_ct = f"KC-{den[:7].replace('-', '')}"
    cu = con.execute("SELECT id FROM chung_tu WHERE cong_ty_id=? AND so_ct=? AND nguon='ket_chuyen'",
                     (cid, so_ct)).fetchone()
    if cu:
        con.execute("DELETE FROM chung_tu WHERE id=?", (cu["id"],))
    bang, _ = phan_hai_ben(con, cid, ngay_sau(den))
    dong, ln = [], 0
    for tk in sorted(bang):
        if tk[0] not in "5678":
            continue
        no, co = bang[tk]
        rong = no - co
        if rong > 0:
            dong.append({"tk_no": "911", "tk_co": tk, "so_tien": rong, "dien_giai": f"Kết chuyển {tk}"})
            ln -= rong
        elif rong < 0:
            dong.append({"tk_no": tk, "tk_co": "911", "so_tien": -rong, "dien_giai": f"Kết chuyển {tk}"})
            ln -= rong
    if not dong:
        con.commit()
        return None, 0
    db.them_tai_khoan(con, cid, "911", "Xác định kết quả kinh doanh")
    db.them_tai_khoan(con, cid, "4212", "Lợi nhuận sau thuế chưa phân phối năm nay")
    if ln > 0:
        dong.append({"tk_no": "911", "tk_co": "4212", "so_tien": ln, "dien_giai": "Kết chuyển lãi"})
    elif ln < 0:
        dong.append({"tk_no": "4212", "tk_co": "911", "so_tien": -ln, "dien_giai": "Kết chuyển lỗ"})
    ct = db.ghi_chung_tu(con, cid, so_ct, den, den, dong, loai="KC", dien_giai=f"Kết chuyển kết quả đến {den}",
                         nguon="ket_chuyen")
    con.commit()
    return ct, ln


def chuyen_nam(con, cid, nam):
    """Dau nam N+1: chuyen so du 4212 (nam nay) sang 4211 (nam truoc)."""
    ngay = f"{nam + 1}-01-01"
    so_ct = f"KCLN-{nam}"
    cu = con.execute("SELECT id FROM chung_tu WHERE cong_ty_id=? AND so_ct=?", (cid, so_ct)).fetchone()
    if cu:
        con.execute("DELETE FROM chung_tu WHERE id=?", (cu["id"],))
    bang, _ = phan_hai_ben(con, cid, ngay)
    rong = sum(no - co for tk, (no, co) in bang.items() if tk.startswith("4212"))
    if not rong:
        con.commit()
        return None
    db.them_tai_khoan(con, cid, "4211", "Lợi nhuận sau thuế chưa phân phối năm trước")
    d = ({"tk_no": "4212", "tk_co": "4211", "so_tien": -rong} if rong < 0
         else {"tk_no": "4211", "tk_co": "4212", "so_tien": rong})
    d["dien_giai"] = f"Chuyển lợi nhuận năm {nam} sang năm trước"
    ct = db.ghi_chung_tu(con, cid, so_ct, ngay, ngay, [d], loai="KC", dien_giai=d["dien_giai"], nguon="ket_chuyen")
    con.commit()
    return ct


# ---------------- bang can doi tai khoan (phu luc XML) ----------------

def cdtk_hai_ben(con, cid, tu, den, cac_tk):
    """So du dau, phat sinh, so du cuoi cho tung TK trong `cac_tk` (TK cha = cong hai ben cua TK con).

    Tra ve {tk: (dau_no, dau_co, ps_no, ps_co, cuoi_no, cuoi_co)} va 'tongCong'."""
    dau, cb1 = phan_hai_ben(con, cid, tu)
    cuoi, cb2 = phan_hai_ben(con, cid, ngay_sau(den))
    ps = phat_sinh(con, cid, tu, den)
    kq = {}
    for tk in cac_tk:
        v = [0] * 6
        for i, bang in ((0, dau), (4, cuoi)):
            for k, (n, c) in bang.items():
                if k.startswith(tk):
                    v[i] += n
                    v[i + 1] += c
        for k, (n, c) in ps.items():
            if k.startswith(tk):
                v[2] += n
                v[3] += c
        kq[tk] = tuple(v)
    cap1 = [tk for tk in cac_tk if len(tk) == 3]
    kq["tongCong"] = tuple(sum(kq[t][i] for t in cap1) for i in range(6))
    thieu = sorted({k[:3] for b in (dau, cuoi, ps) for k in b} - set(cap1))
    cb = cb2 + [f"TK {t} có số liệu nhưng mẫu XML không có dòng cho tài khoản này." for t in thieu]
    return kq, cb
