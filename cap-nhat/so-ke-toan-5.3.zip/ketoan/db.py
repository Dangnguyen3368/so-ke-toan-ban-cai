"""Co so du lieu SQLite cua so ke toan.

Moi cong ty mot dong trong bang cong_ty; moi bang khac deu co cong_ty_id
de mot file du lieu chua duoc nhieu cong ty.

But toan luu theo kieu cap No/Co (tk_no, tk_co, so_tien) giong so Nhat ky
chung: moi dong la mot dinh khoan don, nen tong No luon bang tong Co.
So tien luu bang so nguyen (dong).
"""
import sqlite3
from pathlib import Path

from . import tt133

SCHEMA = """
CREATE TABLE IF NOT EXISTS cong_ty (
    id INTEGER PRIMARY KEY,
    mst TEXT NOT NULL UNIQUE,
    ten TEXT NOT NULL,
    dia_chi TEXT,
    che_do TEXT NOT NULL DEFAULT 'TT133',
    ky_ke_khai_gtgt TEXT NOT NULL DEFAULT 'Q',      -- Q = quy, M = thang
    ma_cqt TEXT,
    ten_cqt TEXT,
    nguoi_ky TEXT
);

CREATE TABLE IF NOT EXISTS tai_khoan (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    so_tk TEXT NOT NULL,
    ten TEXT NOT NULL,
    tk_cha TEXT,
    tinh_chat TEXT NOT NULL,                         -- N, C, L, K
    PRIMARY KEY (cong_ty_id, so_tk)
);

CREATE TABLE IF NOT EXISTS so_du_dau_ky (
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    ngay TEXT NOT NULL,                              -- YYYY-MM-DD
    so_tk TEXT NOT NULL,
    doi_tuong TEXT NOT NULL DEFAULT '',              -- ma KH/NCC/NV neu co
    du_no INTEGER NOT NULL DEFAULT 0,
    du_co INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (cong_ty_id, ngay, so_tk, doi_tuong)
);

CREATE TABLE IF NOT EXISTS chung_tu (
    id INTEGER PRIMARY KEY,
    cong_ty_id INTEGER NOT NULL REFERENCES cong_ty(id),
    so_ct TEXT NOT NULL,
    ngay_ct TEXT NOT NULL,
    ngay_ht TEXT NOT NULL,
    loai TEXT,                                       -- PT, PC, BH, MH, NK, XK, ...
    dien_giai TEXT,
    nguon TEXT,                                      -- 'misa', 'hddt', 'saoke', 'tay'
    UNIQUE (cong_ty_id, so_ct, ngay_ht)
);

CREATE TABLE IF NOT EXISTS but_toan (
    id INTEGER PRIMARY KEY,
    chung_tu_id INTEGER NOT NULL REFERENCES chung_tu(id) ON DELETE CASCADE,
    stt INTEGER NOT NULL,
    dien_giai TEXT,
    tk_no TEXT NOT NULL,
    tk_co TEXT NOT NULL,
    so_tien INTEGER NOT NULL CHECK (so_tien >= 0),
    doi_tuong_no TEXT NOT NULL DEFAULT '',
    doi_tuong_co TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS ix_ct_ngay ON chung_tu(cong_ty_id, ngay_ht);
CREATE INDEX IF NOT EXISTS ix_bt_ct ON but_toan(chung_tu_id);
"""


def mo(duong_dan):
    """Mo (hoac tao) file du lieu."""
    Path(duong_dan).parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(duong_dan))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    con.executescript(SCHEMA)
    return con


def tao_cong_ty(con, mst, ten, **kw):
    """Tao cong ty (neu chua co) va nap he thong tai khoan TT133. Tra ve id."""
    row = con.execute("SELECT id FROM cong_ty WHERE mst = ?", (mst,)).fetchone()
    if row:
        return row["id"]
    cot = ["mst", "ten"] + list(kw)
    cur = con.execute(
        f"INSERT INTO cong_ty ({', '.join(cot)}) VALUES ({', '.join('?' * len(cot))})",
        [mst, ten] + list(kw.values()),
    )
    cid = cur.lastrowid
    for so_tk, ten_tk, tc in tt133.TAI_KHOAN:
        them_tai_khoan(con, cid, so_tk, ten_tk, tc)
    con.commit()
    return cid


def tk_cha(con, cid, so_tk):
    """Tai khoan cha = tai khoan dai nhat dang co la tien to cua so_tk."""
    for n in range(len(so_tk) - 1, 2, -1):
        r = con.execute(
            "SELECT so_tk FROM tai_khoan WHERE cong_ty_id=? AND so_tk=?", (cid, so_tk[:n])
        ).fetchone()
        if r:
            return r["so_tk"]
    return None


def them_tai_khoan(con, cid, so_tk, ten, tinh_chat=None):
    """Them tai khoan; tai khoan chi tiet tu mo ke thua tinh chat cua tai khoan cha."""
    if con.execute(
        "SELECT 1 FROM tai_khoan WHERE cong_ty_id=? AND so_tk=?", (cid, so_tk)
    ).fetchone():
        return
    cha = tk_cha(con, cid, so_tk)
    if tinh_chat is None:
        if cha:
            tinh_chat = con.execute(
                "SELECT tinh_chat FROM tai_khoan WHERE cong_ty_id=? AND so_tk=?", (cid, cha)
            ).fetchone()["tinh_chat"]
        else:
            tinh_chat = "K" if so_tk[0] in "56789" else "L"
    con.execute(
        "INSERT INTO tai_khoan (cong_ty_id, so_tk, ten, tk_cha, tinh_chat) VALUES (?,?,?,?,?)",
        (cid, so_tk, ten, cha, tinh_chat),
    )


def ghi_chung_tu(con, cid, so_ct, ngay_ct, ngay_ht, dong, loai=None, dien_giai=None, nguon="tay"):
    """Ghi mot chung tu voi danh sach dong but toan.

    dong: list dict co tk_no, tk_co, so_tien, (dien_giai, doi_tuong_no, doi_tuong_co).
    Tai khoan phai co trong danh muc; so tien phai duong.
    """
    for d in dong:
        for k in ("tk_no", "tk_co"):
            if not con.execute(
                "SELECT 1 FROM tai_khoan WHERE cong_ty_id=? AND so_tk=?", (cid, d[k])
            ).fetchone():
                raise ValueError(f"{so_ct}: tài khoản {d[k]} chưa có trong danh mục")
        if d["so_tien"] <= 0:
            raise ValueError(f"{so_ct}: số tiền phải lớn hơn 0")
    cur = con.execute(
        "INSERT INTO chung_tu (cong_ty_id, so_ct, ngay_ct, ngay_ht, loai, dien_giai, nguon) "
        "VALUES (?,?,?,?,?,?,?)",
        (cid, so_ct, ngay_ct, ngay_ht, loai, dien_giai, nguon),
    )
    ct_id = cur.lastrowid
    for i, d in enumerate(dong, 1):
        con.execute(
            "INSERT INTO but_toan (chung_tu_id, stt, dien_giai, tk_no, tk_co, so_tien, "
            "doi_tuong_no, doi_tuong_co) VALUES (?,?,?,?,?,?,?,?)",
            (ct_id, i, d.get("dien_giai"), d["tk_no"], d["tk_co"], int(d["so_tien"]),
             d.get("doi_tuong_no", ""), d.get("doi_tuong_co", "")),
        )
    return ct_id
