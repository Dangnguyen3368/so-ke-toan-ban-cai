"""Ban quyen: dung thu co thoi han va key kich hoat theo may.

- Key do chu phan mem tao bang khoa bi mat RSA (cong cu tao key giu rieng, khong gui khach).
  Ung dung chi chua khoa cong khai nen chi kiem tra duoc, khong tao duoc key.
- Noi dung key: ten khach, ma may, han dung (trong = vinh vien), so cong ty toi da (0 = khong gioi han).
- Chua co key: dung thu SO_NGAY_DUNG_THU ngay tinh tu lan chay dau, toi da CONG_TY_DUNG_THU cong ty.
- Het han: chuyen sang CHI XEM va xuat du lieu, khong khoa du lieu cua khach.
"""
import base64
import hashlib
import json
import sys
import time
import uuid
from datetime import date, timedelta

DIEN_THOAI = "0914 993 368"  # so lien he cap key / gia han (Zalo, dien thoai)
# Lien he hien o chan menu, trang Ban quyen. De trong muc nao thi muc do khong hien.
LIEN_HE = {
    "zalo": "https://zalo.me/0914993368",
    "facebook": "https://www.facebook.com/dang.nguyenphong",
    "tiktok": "https://www.tiktok.com/@user3090242863966",
}
SO_NGAY_DUNG_THU = 30
CONG_TY_DUNG_THU = 3

# Khoa cong khai RSA (n, e). Khoa bi mat tuong ung chi nam trong cong cu tao key cua chu phan mem.
N = int(
    "22333285839283099047893233005995187200214627508979943754430526566124254855775294"
    "33541542058699170731082622350556695890155882315763358310604493041175086887326438"
    "52305804244426878803685905446281666862343374820709755306860554304653196141797698"
    "25602617741039392318686261858147828396489382912078925697599353111793564746349530"
    "37620137177944714654276956791068693843255739867331454127109178141750443119900094"
    "08199778892766861069733815913314483593850038126008828724213806742919139396078808"
    "97663608059537611816041123460465182872624158338117925109034035931720646422021424"
    "211175623137607976967022361564305512585231181668043837019"
)
E = 65537

_DIGEST_SHA256 = bytes.fromhex("3031300d060960864801650304020105000420")
_LUU_RAM = {"luc": 0, "kq": None}


# ------------------------------------------------------------------ ky / kiem tra

def _ma_hoa(thong_diep, k):
    h = hashlib.sha256(thong_diep).digest()
    t = _DIGEST_SHA256 + h
    return int.from_bytes(b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t, "big")


def ky(thong_diep, n, d):
    """Ky (dung trong cong cu tao key, can khoa bi mat d)."""
    k = (n.bit_length() + 7) // 8
    return pow(_ma_hoa(thong_diep, k), d, n).to_bytes(k, "big")


def kiem_chu_ky(thong_diep, chu_ky, n=None, e=E):
    n = n or N
    if not n:
        return False
    k = (n.bit_length() + 7) // 8
    s = int.from_bytes(chu_ky, "big")
    return len(chu_ky) == k and s < n and pow(s, e, n) == _ma_hoa(thong_diep, k)


def _b64(b):
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _ub64(s):
    s = "".join(s.split())
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def tao_key(ten_khach, ma_may, han, so_cong_ty, n, d):
    """Tao chuoi key (can khoa bi mat n, d). han: 'YYYY-MM-DD' hoac '' (vinh vien)."""
    nd = json.dumps({"t": ten_khach, "m": chuan_ma_may(ma_may), "h": han or "", "c": int(so_cong_ty or 0),
                     "l": date.today().isoformat()}, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return _b64(nd) + "." + _b64(ky(nd, n, d))


def doc_key(chuoi, n=None):
    """Tra ve dict noi dung key neu chu ky dung, nguoc lai raise ValueError."""
    try:
        a, b = "".join((chuoi or "").split()).split(".")
        nd, ck = _ub64(a), _ub64(b)
    except Exception:
        raise ValueError("Key không đúng định dạng. Hãy dán nguyên chuỗi key nhận được.")
    if not kiem_chu_ky(nd, ck, n):
        raise ValueError("Key không hợp lệ.")
    return json.loads(nd.decode("utf-8"))


# ------------------------------------------------------------------ ma may

def chuan_ma_may(s):
    s = "".join(ch for ch in (s or "").upper() if ch.isalnum())
    return "-".join(s[i:i + 4] for i in range(0, len(s), 4))


def ma_may():
    """Ma nhan dien may: bam tu MachineGuid cua Windows (hoac dia chi mang neu khong co)."""
    goc = ""
    if sys.platform == "win32":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                                winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
                goc = winreg.QueryValueEx(k, "MachineGuid")[0]
        except OSError:
            goc = ""
    if not goc:
        try:
            goc = open("/etc/machine-id").read().strip()
        except OSError:
            goc = str(uuid.getnode())
    return chuan_ma_may(hashlib.sha256(("soketoan:" + goc).encode()).hexdigest()[:12])


# ------------------------------------------------------------------ luu trang thai (nhieu noi)

def _reg(ghi=None):
    """Doc/ghi ngay bat dau dung thu trong registry nguoi dung (chi Windows)."""
    if sys.platform != "win32":
        return None
    try:
        import winreg
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\SoKeToan") as k:
            if ghi:
                winreg.SetValueEx(k, "BatDau", 0, winreg.REG_SZ, ghi)
                return ghi
            return winreg.QueryValueEx(k, "BatDau")[0]
    except OSError:
        return None


def _bang(con):
    con.execute("CREATE TABLE IF NOT EXISTS ban_quyen (khoa TEXT PRIMARY KEY, gia_tri TEXT)")


def _doc(con, k):
    _bang(con)
    r = con.execute("SELECT gia_tri FROM ban_quyen WHERE khoa=?", (k,)).fetchone()
    return r[0] if r else None


def _ghi(con, k, v):
    _bang(con)
    con.execute("INSERT OR REPLACE INTO ban_quyen VALUES (?,?)", (k, v))
    con.commit()


def _ngay_bat_dau(con):
    from . import cai_dat
    cd = cai_dat.doc()
    cac = [x for x in (_doc(con, "bat_dau"), cd.get("bat_dau"), _reg()) if x]
    bd = min(cac) if cac else date.today().isoformat()
    if _doc(con, "bat_dau") != bd:
        _ghi(con, "bat_dau", bd)
    if cd.get("bat_dau") != bd:
        cai_dat.dat(bat_dau=bd)
    if _reg() != bd:
        _reg(bd)
    return bd


def kich_hoat(con, chuoi):
    """Kiem tra va luu key. Tra ve noi dung key."""
    from . import cai_dat
    k = doc_key(chuoi)
    if chuan_ma_may(k["m"]) != ma_may():
        raise ValueError(f"Key này dành cho máy {k['m']}, không phải máy này ({ma_may()}).")
    if k.get("h") and k["h"] < date.today().isoformat():
        raise ValueError(f"Key đã hết hạn từ {k['h']}.")
    s = "".join(chuoi.split())
    _ghi(con, "key", s)
    cai_dat.dat(key=s)
    _LUU_RAM["luc"] = 0
    return k


def trang_thai(con, hom_nay=None):
    """dict: loai ('key' | 'dung_thu' | 'het_han' | 'dong_ho'), cho_ghi, con_ngay, han, ten_khach, so_cong_ty, thong_bao."""
    if hom_nay is None and _LUU_RAM["kq"] and time.time() - _LUU_RAM["luc"] < 60:
        return _LUU_RAM["kq"]
    from . import cai_dat
    hn = hom_nay or date.today()
    kq = None
    # Chong lui dong ho: nho ngay lon nhat da thay
    da_thay = _doc(con, "da_thay")
    if da_thay and hn.isoformat() < (date.fromisoformat(da_thay) - timedelta(days=2)).isoformat():
        kq = {"loai": "dong_ho", "cho_ghi": False, "con_ngay": 0, "han": None, "ten_khach": "", "so_cong_ty": 0,
              "thong_bao": f"Ngày trên máy ({hn:%d/%m/%Y}) sớm hơn ngày đã dùng ({date.fromisoformat(da_thay):%d/%m/%Y}). "
                           "Chỉnh lại đồng hồ máy tính rồi mở lại ứng dụng."}
    elif not da_thay or hn.isoformat() > da_thay:
        _ghi(con, "da_thay", hn.isoformat())
    if kq is None:
        for chuoi in (_doc(con, "key"), cai_dat.doc().get("key")):
            if not chuoi:
                continue
            try:
                k = doc_key(chuoi)
            except ValueError:
                continue
            if chuan_ma_may(k["m"]) != ma_may():
                continue
            con_ngay = (date.fromisoformat(k["h"]) - hn).days if k.get("h") else None
            if con_ngay is not None and con_ngay < 0:
                kq = {"loai": "het_han", "cho_ghi": False, "con_ngay": 0, "han": k["h"], "ten_khach": k["t"],
                      "so_cong_ty": k.get("c", 0),
                      "thong_bao": f"Key đã hết hạn từ {date.fromisoformat(k['h']):%d/%m/%Y}. Ứng dụng chuyển sang chỉ xem; "
                                   f"liên hệ {DIEN_THOAI} để gia hạn."}
            else:
                kq = {"loai": "key", "cho_ghi": True, "con_ngay": con_ngay, "han": k.get("h") or None, "ten_khach": k["t"],
                      "so_cong_ty": k.get("c", 0),
                      "thong_bao": (f"Key còn {con_ngay} ngày (hết hạn {date.fromisoformat(k['h']):%d/%m/%Y}). "
                                    f"Liên hệ {DIEN_THOAI} để gia hạn." if con_ngay is not None and con_ngay <= 15 else "")}
            break
    if kq is None:
        bd = date.fromisoformat(_ngay_bat_dau(con))
        het = bd + timedelta(days=SO_NGAY_DUNG_THU)
        con_ngay = (het - hn).days
        if con_ngay > 0:
            kq = {"loai": "dung_thu", "cho_ghi": True, "con_ngay": con_ngay, "han": het.isoformat(), "ten_khach": "",
                  "so_cong_ty": CONG_TY_DUNG_THU,
                  "thong_bao": f"Bản dùng thử: còn {con_ngay} ngày (đến {het:%d/%m/%Y}), tối đa {CONG_TY_DUNG_THU} công ty."}
        else:
            kq = {"loai": "het_han", "cho_ghi": False, "con_ngay": 0, "han": het.isoformat(), "ten_khach": "",
                  "so_cong_ty": CONG_TY_DUNG_THU,
                  "thong_bao": f"Hết hạn dùng thử từ {het:%d/%m/%Y}. Dữ liệu vẫn xem và xuất được; "
                               f"nhập key kích hoạt để tiếp tục ghi sổ (liên hệ {DIEN_THOAI})."}
    if hom_nay is None:
        _LUU_RAM.update(luc=time.time(), kq=kq)
    return kq


def so_cong_ty_toi_da(tt):
    """0 = khong gioi han."""
    return int(tt.get("so_cong_ty") or 0)


def xoa_luu_tam():
    _LUU_RAM.update(luc=0, kq=None)
