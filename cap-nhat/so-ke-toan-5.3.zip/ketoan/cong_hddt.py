"""Tai hoa don tu cong hoadondientu.gdt.gov.vn.

Dung dung cac dia chi ma trang web cua cong goi khi nguoi dung tra cuu, voi
tai khoan dang nhap cua chinh doanh nghiep. Nguoi dung tu go captcha; mat
khau khong duoc luu lai.

Luu y: day khong phai dich vu chinh thuc co tai lieu. Neu Tong cuc Thue doi
cach hoat dong cua cong, phan nay can sua lai; khi do van dung duoc cach
xuat Excel / XML tay roi nap vao ung dung.
"""
import io
import json
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from calendar import monthrange
from datetime import date, datetime

GOC = "https://hoadondientu.gdt.gov.vn:30000"
_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) SoKeToan/1.0"


class LoiCong(Exception):
    pass


def _goi(url, token=None, du_lieu=None, nhi_phan=False, lan=3):
    tieu_de = {"User-Agent": _UA, "Accept": "application/json, */*"}
    if token:
        tieu_de["Authorization"] = f"Bearer {token}"
    body = None
    if du_lieu is not None:
        body = json.dumps(du_lieu).encode()
        tieu_de["Content-Type"] = "application/json"
    for i in range(lan):
        try:
            req = urllib.request.Request(url, data=body, headers=tieu_de)
            with urllib.request.urlopen(req, timeout=60, context=ssl.create_default_context()) as r:
                b = r.read()
                return b if nhi_phan else json.loads(b.decode("utf-8") or "null")
        except urllib.error.HTTPError as ex:
            noi_dung = ex.read().decode("utf-8", "replace")[:300]
            if ex.code in (401, 403):
                raise LoiCong("Phiên đăng nhập hết hạn hoặc sai thông tin. Hãy đăng nhập lại.") from ex
            if ex.code == 400:
                raise LoiCong(f"Cổng thuế từ chối yêu cầu: {noi_dung}") from ex
            if i == lan - 1:
                raise LoiCong(f"Cổng thuế lỗi {ex.code}: {noi_dung}") from ex
        except (urllib.error.URLError, TimeoutError) as ex:
            if i == lan - 1:
                raise LoiCong(f"Không kết nối được cổng thuế: {ex}") from ex
        time.sleep(2 * (i + 1))


def lay_captcha():
    """Tra ve (key, svg) de hien cho nguoi dung go."""
    d = _goi(f"{GOC}/captcha")
    return d["key"], d["content"]


def dang_nhap(mst, mat_khau, ckey, cvalue):
    d = _goi(f"{GOC}/security-taxpayer/authenticate",
             du_lieu={"username": mst, "password": mat_khau, "ckey": ckey, "cvalue": cvalue})
    if not d or not d.get("token"):
        raise LoiCong(f"Đăng nhập không thành công: {d}")
    return d["token"]


def chia_thang(tu, den):
    """Chia khoang ngay thanh tung thang (cong chi cho tra trong mot thang)."""
    a = datetime.strptime(tu, "%Y-%m-%d").date()
    b = datetime.strptime(den, "%Y-%m-%d").date()
    while a <= b:
        cuoi = date(a.year, a.month, monthrange(a.year, a.month)[1])
        yield a, min(cuoi, b)
        a = date(cuoi.year + (cuoi.month == 12), cuoi.month % 12 + 1, 1)


# (ten nhom, duong dan, loai, dieu kien them)
NHOM_TRA_CUU = {
    "ban": [("Bán ra có mã", "query", "sold", ""),
            ("Bán ra máy tính tiền", "sco-query", "sold", "")],
    "mua": [("Mua vào có mã", "query", "purchase", ";ttxly==5"),
            ("Mua vào không mã", "query", "purchase", ";ttxly==6"),
            ("Mua vào máy tính tiền", "sco-query", "purchase", ";ttxly==8")],
}


def ds_hoa_don(token, chieu, tu, den):
    """Lay danh sach hoa don (du lieu tom tat) cho mot chieu, moi thang mot lan tra."""
    for a, b in chia_thang(tu, den):
        for nhom, goc, loai, them in NHOM_TRA_CUU[chieu]:
            tim = (f"tdlap=ge={a:%d/%m/%Y}T00:00:00;tdlap=le={b:%d/%m/%Y}T23:59:59{them}")
            trang_thai = None
            while True:
                q = {"sort": "tdlap:desc,khmshdon:asc,shdon:desc", "size": "50", "search": tim}
                if trang_thai:
                    q["state"] = trang_thai
                d = _goi(f"{GOC}/{goc}/invoices/{loai}?" + urllib.parse.urlencode(q, safe=":=;,"),
                         token) or {}
                for x in d.get("datas") or []:
                    x["_goc"] = goc
                    x["_nhom"] = nhom
                    yield x
                trang_thai = d.get("state")
                if not trang_thai or not d.get("datas"):
                    break
                time.sleep(0.3)


def tu_json(x):
    """Doi mot dong JSON cua cong sang dict hoa don cua ung dung."""
    tts = [{"tsuat": t.get("tsuat") or "", "thtien": int(t.get("thtien") or 0), "tthue": int(t.get("tthue") or 0)}
           for t in (x.get("thttltsuat") or [])]
    khhdon = x.get("khhdon") or ""
    return {
        "nbmst": x.get("nbmst") or "", "nb_ten": x.get("nbten"),
        "nmmst": x.get("nmmst") or "", "nm_ten": x.get("nmten") or x.get("nmtnmua"),
        "khmshdon": str(x.get("khmshdon") or ""), "khhdon": khhdon, "shdon": str(x.get("shdon") or ""),
        "ngay_lap": (x.get("tdlap") or "")[:10], "ma_cqt": x.get("mhdon"),
        "tien_hang": int(x.get("tgtcthue") or 0), "tien_thue": int(x.get("tgtthue") or 0),
        "tong_tien": int(x.get("tgtttbso") or 0), "theo_thue_suat": tts or None,
        "trang_thai": int(x.get("tthai") or 1),
        "may_tinh_tien": 1 if x.get("_goc") == "sco-query" else 0,
    }


def tai_xml(token, x):
    """Tai file XML cua mot hoa don. Tra ve bytes XML hoac None neu cong khong cho tai."""
    q = urllib.parse.urlencode({"nbmst": x["nbmst"], "khhdon": x["khhdon"],
                                "shdon": x["shdon"], "khmshdon": x["khmshdon"]})
    try:
        b = _goi(f"{GOC}/{x.get('_goc', 'query')}/invoices/export-xml?{q}", token, nhi_phan=True, lan=2)
    except LoiCong as ex:
        if "hết hạn" in str(ex):
            raise
        return None
    if b[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            for n in z.namelist():
                if n.lower().endswith(".xml"):
                    return z.read(n)
        return None
    return b if b.lstrip()[:1] == b"<" else None


def tai_ve(token, chieu, tu, den, kem_xml=True, bao=print):
    """Tai danh sach (va XML) hoa don. Tra ve list dict hoa don san sang de luu."""
    from . import hoa_don

    kq = []
    for x in ds_hoa_don(token, chieu, tu, den):
        h = tu_json(x)
        if kem_xml:
            b = tai_xml(token, x)
            if b:
                try:
                    tu_xml = hoa_don.doc_xml(b)
                    tu_xml["trang_thai"] = h["trang_thai"]  # trang thai moi nhat lay tu cong
                    tu_xml["may_tinh_tien"] = h["may_tinh_tien"]
                    h = tu_xml
                except ValueError:
                    pass
            time.sleep(0.2)
        kq.append(h)
        if len(kq) % 20 == 0:
            bao(f"Đã tải {len(kq)} hóa đơn {'bán ra' if chieu == 'ban' else 'mua vào'}...")
    return kq
