"""So ke toan TT133 tu xay."""
PHIEN_BAN = "5.4.1"
NGAY_PHAT_HANH = "2026-11-27"
